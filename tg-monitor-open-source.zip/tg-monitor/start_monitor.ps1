﻿param([switch]$NoBrowser)

$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
Set-Location -LiteralPath $PSScriptRoot

function Install-LocalPython {
    # Official complete x64 runtime used and tested by the Windows build.
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'TG Monitor needs Windows x64.' }
    $version = '3.14.6'
    $filename = "python-$version-amd64.zip"
    $url = "https://www.python.org/ftp/python/$version/$filename"
    $expectedSha256 = '75afa83f93b284d19040e24bc440ab741c09582c0d5310504d607a4e08c3dbaf'
    $runtimeRoot = Join-Path $PSScriptRoot '.runtime'
    $runtimePython = Join-Path $runtimeRoot 'python'
    $runtimeExe = Join-Path $runtimePython 'python.exe'
    $downloadDir = Join-Path $runtimeRoot 'download'
    $archive = Join-Path $downloadDir $filename
    New-Item -ItemType Directory -Path $downloadDir -Force | Out-Null
    Write-Host 'Downloading official Python runtime into the project folder...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try { Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing }
    catch { throw "Could not download Python from python.org. Check Internet access and retry. ($($_.Exception.Message))" }
    $actualSha256 = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash
    if ($actualSha256 -ne $expectedSha256) { throw 'Python archive checksum does not match the official release.' }
    Expand-Archive -LiteralPath $archive -DestinationPath $runtimePython -Force
    & $runtimeExe -m ensurepip --upgrade | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'Could not initialize pip in the local Python runtime.' }
    & $runtimeExe -c 'import pip, tkinter, sys; r=tkinter.Tk(); r.withdraw(); r.destroy(); sys.exit(0 if sys.version_info >= (3, 10) else 1)'
    if ($LASTEXITCODE -ne 0) { throw 'Local Python runtime is not usable.' }
    Remove-Item -LiteralPath $archive -Force
    return $runtimeExe
}

if ($NoBrowser -and -not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'config.ini'))) {
    throw 'config.ini is missing. Run start_monitor.bat interactively first.'
}

$pythonCommand = $null
$pythonArgs = @()
$candidates = @(
    @{ Exe = (Join-Path $PSScriptRoot '.runtime\python\python.exe'); Args = @() },
    @{ Exe = 'py'; Args = @('-3') },
    @{ Exe = 'python'; Args = @() }
)
foreach ($pattern in @(
    (Join-Path $env:LOCALAPPDATA 'Python\pythoncore-*\python.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python*\python.exe'),
    (Join-Path $env:ProgramFiles 'Python*\python.exe')
)) {
    foreach ($found in @(Get-Item -Path $pattern -ErrorAction SilentlyContinue)) {
        $candidates += @{ Exe = $found.FullName; Args = @() }
    }
}
foreach ($candidate in $candidates) {
    if (-not (Get-Command $candidate.Exe -ErrorAction SilentlyContinue)) { continue }
    $argsForCandidate = $candidate.Args
    try {
        & $candidate.Exe @argsForCandidate -c 'import sys, venv, ensurepip, tkinter; r=tkinter.Tk(); r.withdraw(); r.destroy(); sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>$null
        if ($LASTEXITCODE -eq 0) {
            $pythonCommand = $candidate.Exe
            $pythonArgs = $argsForCandidate
            break
        }
    } catch { }
}
if (-not $pythonCommand) {
    $pythonCommand = Install-LocalPython
    $pythonArgs = @()
}

$venvPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    Write-Host 'Creating local Python environment...'
    & $pythonCommand @pythonArgs -m venv (Join-Path $PSScriptRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Could not create .venv.' }
}
try {
    & $venvPython -c 'import sys; sys.exit(0 if sys.prefix != sys.base_prefix else 1)' 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'invalid environment' }
} catch { throw 'The local .venv cannot run here. Rename it, then run start_monitor.bat again.' }

$requirements = Join-Path $PSScriptRoot 'requirements.lock'
$stamp = Join-Path $PSScriptRoot '.venv\requirements.sha256'
$requiredHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $requirements).Hash
if (-not (Test-Path -LiteralPath $stamp) -or (Get-Content -LiteralPath $stamp -Raw).Trim() -ne $requiredHash) {
    Write-Host 'Installing dependencies into .venv...'
    & $venvPython -m pip install -r $requirements
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check network access and run again.' }
    Set-Content -LiteralPath $stamp -Value $requiredHash -NoNewline
}

# Keep the source archive location compatible with earlier source installations.
$launcherArgs = @((Join-Path $PSScriptRoot 'launcher.py'), '--data-dir', $PSScriptRoot)
if ($NoBrowser) {
    $launcherArgs += '--headless'
    & $venvPython @launcherArgs
    exit $LASTEXITCODE
}
$windowedPython = Join-Path $PSScriptRoot '.venv\Scripts\pythonw.exe'
if (-not (Test-Path -LiteralPath $windowedPython)) { throw 'pythonw.exe is missing. Rename .venv and run again.' }
# Environment preparation may use a console; application settings use the desktop UI.
$quotedArgs = ($launcherArgs | ForEach-Object { '"' + $_ + '"' }) -join ' '
Start-Process -FilePath $windowedPython -ArgumentList $quotedArgs -WorkingDirectory $PSScriptRoot -WindowStyle Hidden

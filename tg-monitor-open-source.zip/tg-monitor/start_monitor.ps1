﻿param([switch]$NoBrowser)

$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
Set-Location -LiteralPath $PSScriptRoot

function Read-Secret([string]$Prompt) {
    $secure = Read-Host -Prompt $Prompt -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Install-LocalPython {
    # Official complete x64 runtime used and tested by the Windows build.
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'TG Monitor needs Windows x64.' }
    $version = '3.14.6'
    $filename = "python-$version-amd64.zip"
    $url = "https://www.python.org/ftp/python/$version/$filename"
    $expectedSha256 = '75afa83f93b284d19040e24bc440ab741c09582c0d5310504d607a4e08c3dbaf'
    $runtimeRoot = Join-Path $PSScriptRoot '.runtime'
    $runtimePython = Join-Path $runtimeRoot 'python'
    $runtimeExe = Join-Path $runtimePython 'python.exe'
    $downloadDir = Join-Path $runtimeRoot 'download'
    $archive = Join-Path $downloadDir $filename
    New-Item -ItemType Directory -Path $downloadDir -Force | Out-Null
    Write-Host 'Downloading official Python runtime into the project folder...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try { Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing }
    catch { throw "Could not download Python from python.org. Check Internet access and retry. ($($_.Exception.Message))" }
    $actualSha256 = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash
    if ($actualSha256 -ne $expectedSha256) { throw 'Python archive checksum does not match the official release.' }
    Expand-Archive -LiteralPath $archive -DestinationPath $runtimePython -Force
    & $runtimeExe -m ensurepip --upgrade | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'Could not initialize pip in the local Python runtime.' }
    & $runtimeExe -c 'import pip, tkinter, sys; tkinter.Tcl(); sys.exit(0 if sys.version_info >= (3, 10) else 1)'
    if ($LASTEXITCODE -ne 0) { throw 'Local Python runtime is not usable.' }
    Remove-Item -LiteralPath $archive -Force
    return $runtimeExe
}

$configPath = Join-Path $PSScriptRoot 'config.ini'
if (-not (Test-Path -LiteralPath $configPath)) {
    if ($NoBrowser) { throw 'config.ini is missing. Run start_monitor.bat interactively first.' }
    Write-Host 'First run: enter your own Telegram API credentials from my.telegram.org.'
    do { $apiId = (Read-Host 'api_id (digits)').Trim() } until ($apiId -match '^[1-9][0-9]*$')
    do { $apiHash = (Read-Secret 'api_hash (hidden)').Trim() } until ($apiHash -match '^[0-9a-fA-F]{32}$')
    $panelPassword = Read-Secret 'Panel password (hidden; optional for local-only access)'
    if ($panelPassword -match '[\r\n]') { throw 'Panel password must be one line.' }
    $lines = @(
        '[telegram]', "api_id = $apiId", "api_hash = $apiHash", '',
        '[server]', 'host = 127.0.0.1', 'port = 8090', '',
        '[archive]', 'max_media_mb = 1024', '',
        '[security]', "panel_password = $panelPassword"
    )
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllLines($configPath, $lines, $utf8)
    $apiHash = $null
    $panelPassword = $null
    Write-Host 'Created local config.ini.'
}

$cfg = Get-Content -LiteralPath $configPath
$portLine = $cfg | Where-Object { $_ -match '^\s*port\s*=\s*\d+\s*$' } | Select-Object -First 1
$port = if ($portLine) { ($portLine -split '=', 2)[1].Trim() } else { '8090' }
$url = "http://127.0.0.1:$port/"
$hashBytes = [System.Security.Cryptography.SHA256]::Create().ComputeHash(
    [System.Text.Encoding]::UTF8.GetBytes($PSScriptRoot.ToLowerInvariant()))
$mutexName = 'Local\TGMonitor_' + ([System.BitConverter]::ToString($hashBytes).Replace('-', '').Substring(0, 24))
$mutex = New-Object System.Threading.Mutex($false, $mutexName)
try { $acquired = $mutex.WaitOne(0) }
catch [System.Threading.AbandonedMutexException] { $acquired = $true }
if (-not $acquired) {
    if (-not $NoBrowser) { Start-Process $url }
    Write-Host 'TG Monitor is already running from this folder.'
    exit 0
}

$pythonCommand = $null
$pythonArgs = @()
$candidates = @(
    @{ Exe = (Join-Path $PSScriptRoot '.runtime\python\python.exe'); Args = @() },
    @{ Exe = 'py'; Args = @('-3') },
    @{ Exe = 'python'; Args = @() }
)
foreach ($pattern in @(
    (Join-Path $env:LOCALAPPDATA 'Python\pythoncore-*\python.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python*\python.exe'),
    (Join-Path $env:ProgramFiles 'Python*\python.exe')
)) {
    foreach ($found in @(Get-Item -Path $pattern -ErrorAction SilentlyContinue)) {
        $candidates += @{ Exe = $found.FullName; Args = @() }
    }
}
foreach ($candidate in $candidates) {
    if (-not (Get-Command $candidate.Exe -ErrorAction SilentlyContinue)) { continue }
    $argsForCandidate = $candidate.Args
    try {
        & $candidate.Exe @argsForCandidate -c 'import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>$null
        if ($LASTEXITCODE -eq 0) {
            $pythonCommand = $candidate.Exe
            $pythonArgs = $argsForCandidate
            break
        }
    } catch { }
}
if (-not $pythonCommand) {
    $pythonCommand = Install-LocalPython
    $pythonArgs = @()
}

$venvPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    Write-Host 'Creating local Python environment...'
    & $pythonCommand @pythonArgs -m venv (Join-Path $PSScriptRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Could not create .venv.' }
}
try {
    & $venvPython -c 'import sys; sys.exit(0 if sys.prefix != sys.base_prefix else 1)' 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'invalid environment' }
} catch { throw 'The local .venv cannot run here. Rename it, then run start_monitor.bat again.' }

$requirements = Join-Path $PSScriptRoot 'requirements.lock'
$stamp = Join-Path $PSScriptRoot '.venv\requirements.sha256'
$requiredHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $requirements).Hash
if (-not (Test-Path -LiteralPath $stamp) -or (Get-Content -LiteralPath $stamp -Raw).Trim() -ne $requiredHash) {
    Write-Host 'Installing dependencies into .venv...'
    & $venvPython -m pip install -r $requirements
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check network access and run again.' }
    Set-Content -LiteralPath $stamp -Value $requiredHash -NoNewline
}

$portProbe = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, [int]$port)
try { $portProbe.Start() }
catch { throw "Port $port is already in use. Stop the other process or change port in config.ini." }
finally { $portProbe.Stop() }

$browserJob = $null
if (-not $NoBrowser) {
    $browserJob = Start-Job -ArgumentList $url -ScriptBlock {
        param($panelUrl)
        for ($attempt = 0; $attempt -lt 30; $attempt++) {
            try {
                $request = [System.Net.WebRequest]::Create($panelUrl)
                $request.Timeout = 2000
                $response = $request.GetResponse()
                $response.Close()
                Start-Process $panelUrl
                return
            } catch { Start-Sleep -Seconds 1 }
        }
    }
}
Write-Host "Starting TG Monitor at $url. Close this window to stop it."
try {
    & $venvPython (Join-Path $PSScriptRoot 'app.py')
    exit $LASTEXITCODE
} finally {
    if ($browserJob) {
        Stop-Job $browserJob -ErrorAction SilentlyContinue
        Remove-Job $browserJob -Force -ErrorAction SilentlyContinue
    }
}

# Third-party components

TG Monitor's own code is licensed under MIT (LICENSE). The following components
retain their original licenses; MIT does not replace their terms. License texts
are copied from the pinned packages installed in the build environment.

The Windows bundle includes Python 3.14.6, Tcl/Tk, SQLite and OpenSSL.
Python's license and bundled notices: [Python](third_party_licenses/Python-LICENSE.txt).
Other runtime notices: [Tcl](third_party_licenses/Tcl-license.terms),
[Tk](third_party_licenses/Tk-license.terms),
[SQLite](third_party_licenses/SQLite.txt),
[OpenSSL](third_party_licenses/OpenSSL-LICENSE.txt).
PyInstaller's license includes a bootloader distribution exception; retain its original text.
Build tools are listed for transparency and are not needed to run TG Monitor.

| Component | Version | Used for | License metadata | Original notices |
| --- | --- | --- | --- | --- |
| annotated-doc | 0.0.5 | Runtime | MIT | [LICENSE](third_party_licenses/annotated-doc/LICENSE) |
| annotated-types | 0.8.0 | Runtime | MIT | [LICENSE](third_party_licenses/annotated-types/LICENSE) |
| anyio | 4.15.1 | Runtime | MIT | [LICENSE](third_party_licenses/anyio/LICENSE) |
| click | 8.5.0 | Runtime | BSD-3-Clause | [LICENSE.txt](third_party_licenses/click/LICENSE.txt) |
| colorama | 0.4.6 | Runtime | OSI Approved :: BSD License | [LICENSE.txt](third_party_licenses/colorama/LICENSE.txt) |
| fastapi | 0.142.2 | Runtime | MIT | [LICENSE](third_party_licenses/fastapi/LICENSE) |
| h11 | 0.16.0 | Runtime | MIT | [LICENSE.txt](third_party_licenses/h11/LICENSE.txt) |
| idna | 3.20 | Runtime | BSD-3-Clause | [LICENSE.md](third_party_licenses/idna/LICENSE.md) |
| opentelemetry-api | 1.45.0 | Runtime | Apache-2.0 | [LICENSE](third_party_licenses/opentelemetry-api/LICENSE) |
| pillow | 12.3.0 | Runtime | MIT-CMU | [LICENSE](third_party_licenses/pillow/LICENSE) |
| pyaes | 1.6.1 | Runtime | License :: OSI Approved :: MIT License | [LICENSE.txt](third_party_licenses/pyaes/LICENSE.txt) |
| pyasn1 | 0.6.4 | Runtime | BSD-2-Clause | [LICENSE.rst](third_party_licenses/pyasn1/LICENSE.rst) |
| pydantic | 2.13.5 | Runtime | MIT | [LICENSE](third_party_licenses/pydantic/LICENSE) |
| pydantic_core | 2.46.5 | Runtime | MIT | [LICENSE](third_party_licenses/pydantic-core/LICENSE) |
| qrcode | 8.2 | Runtime | BSD | [LICENSE](third_party_licenses/qrcode/LICENSE) |
| rsa | 4.9.1 | Runtime | Apache-2.0 | [LICENSE](third_party_licenses/rsa/LICENSE) |
| starlette | 1.7.0 | Runtime | BSD-3-Clause | [LICENSE.md](third_party_licenses/starlette/LICENSE.md) |
| Telethon | 1.45.0 | Runtime | MIT | [LICENSE](third_party_licenses/telethon/LICENSE) |
| typing-inspection | 0.4.4 | Runtime | MIT | [LICENSE](third_party_licenses/typing-inspection/LICENSE) |
| typing_extensions | 4.16.0 | Runtime | PSF-2.0 | [LICENSE](third_party_licenses/typing-extensions/LICENSE) |
| uvicorn | 0.54.0 | Runtime | BSD-3-Clause | [LICENSE.md](third_party_licenses/uvicorn/LICENSE.md) |
| pyinstaller | 6.22.3 | Build only | GPLv2-or-later with a special exception which allows to use PyInstaller to build and distribute non-free programs (including commercial ones) | [COPYING.txt](third_party_licenses/pyinstaller/COPYING.txt) |
| pyinstaller-hooks-contrib | 2026.8 | Build only | OSI Approved :: Apache Software License; OSI Approved :: GNU General Public License v2 (GPLv2) | [LICENSE](third_party_licenses/pyinstaller-hooks-contrib/LICENSE) |
| altgraph | 0.17.5 | Build only | MIT | [LICENSE](third_party_licenses/altgraph/LICENSE) |
| packaging | 26.3 | Build only | Apache-2.0 OR BSD-2-Clause | [LICENSE](third_party_licenses/packaging/LICENSE), [LICENSE.APACHE](third_party_licenses/packaging/LICENSE.APACHE), [LICENSE.BSD](third_party_licenses/packaging/LICENSE.BSD) |
| pefile | 2024.8.26 | Build only | MIT | [LICENSE](third_party_licenses/pefile/LICENSE) |
| pywin32-ctypes | 0.2.3 | Build only | BSD-3-Clause | [LICENSE.txt](third_party_licenses/pywin32-ctypes/LICENSE.txt) |
| setuptools | 84.0.0 | Build only | MIT | [LICENSE](third_party_licenses/setuptools/LICENSE), [LICENSE.APACHE](third_party_licenses/setuptools/LICENSE.APACHE), [LICENSE.BSD](third_party_licenses/setuptools/LICENSE.BSD), [LICENSE.txt](third_party_licenses/setuptools/LICENSE.txt), [NOTICE](third_party_licenses/setuptools/NOTICE) |

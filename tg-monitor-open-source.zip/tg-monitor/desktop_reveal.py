"""Show an existing archive file in the single logged-in Windows desktop."""
import base64
import json
import secrets
import subprocess


def reveal_in_interactive_session(full, base):
    def encoded(value):
        return base64.b64encode(value.encode("utf-8")).decode("ascii")
    result_dir = base / ".desktop-reveal"
    result_dir.mkdir(exist_ok=True)
    result_path = result_dir / (secrets.token_hex(16) + ".json")
    inner = r'''
$ErrorActionPreference='Stop'
$full=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('FULL_B64'))
$result=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('RESULT_B64'))
try {
 $folder=[IO.Path]::GetDirectoryName($full)
 $name=[IO.Path]::GetFileName($full)
 $shell=New-Object -ComObject Shell.Application
 $shell.Open($folder)
 $matched=$null
 for($i=0;$i -lt 60;$i++) {
  foreach($window in @($shell.Windows())) {
   try {
    if([string]::Equals($window.Document.Folder.Self.Path,$folder,[StringComparison]::OrdinalIgnoreCase)) {
     $item=$window.Document.Folder.ParseName($name)
     if($item) {
      $window.Document.SelectItem($item,29)
      $selected=$window.Document.SelectedItems()
      if($selected.Count -eq 1 -and [string]::Equals($selected.Item(0).Path,$full,[StringComparison]::OrdinalIgnoreCase)) { $matched=$window; break }
     }
    }
   } catch {}
  }
  if($matched) {break}
  Start-Sleep -Milliseconds 100
 }
 if(-not $matched) {throw 'Explorer did not select the requested file'}
 Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class TGRevealWindow { [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int n); [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); }'
 [void][TGRevealWindow]::ShowWindow([IntPtr]$matched.HWND,3)
 [void][TGRevealWindow]::SetForegroundWindow([IntPtr]$matched.HWND)
 $report=@{ok=$true;selected=$true;foreground=([TGRevealWindow]::GetForegroundWindow() -eq [IntPtr]$matched.HWND);maximized=$true}
} catch { $report=@{ok=$false;reason=$_.Exception.Message} }
# Publish the small result atomically; never expose half-written JSON.
$report | ConvertTo-Json -Compress | Set-Content -LiteralPath ($result+'.tmp') -Encoding UTF8
Move-Item -LiteralPath ($result+'.tmp') -Destination $result
'''.replace("FULL_B64", encoded(str(full))).replace("RESULT_B64", encoded(str(result_path)))
    inner_encoded = base64.b64encode(inner.encode("utf-16le")).decode("ascii")
    task_name = "TGMonitor-Reveal-" + secrets.token_hex(12)
    outer = r'''
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$result=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('RESULT_B64'))
$taskName='TASK_NAME'
$registered=$false
try {
 $desktops=@(Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" | Where-Object {$_.SessionId -gt 0})
 $sessions=@($desktops.SessionId | Select-Object -Unique)
 if($sessions.Count -ne 1) {throw 'Open one Windows desktop session on the server to show the file'}
 $owner=Invoke-CimMethod -InputObject $desktops[0] -MethodName GetOwner
 if($owner.ReturnValue -ne 0) {throw 'Cannot determine the Windows desktop owner'}
 $user=$owner.Domain+'\'+$owner.User
 $action=New-ScheduledTaskAction -Execute ($env:WINDIR+'\System32\WindowsPowerShell\v1.0\powershell.exe') -Argument '-NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand INNER_ENCODED'
 $principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds 20)
 Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings | Out-Null
 $registered=$true
 Start-ScheduledTask -TaskName $taskName
 for($i=0;$i -lt 100;$i++) { if(Test-Path -LiteralPath $result) {break}; Start-Sleep -Milliseconds 100 }
 if(-not (Test-Path -LiteralPath $result)) {throw 'The Windows desktop did not respond in time'}
 Get-Content -LiteralPath $result -Raw
} catch { @{ok=$false;reason=$_.Exception.Message} | ConvertTo-Json -Compress }
finally {
 if($registered) {
  if((Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue).State -eq 'Running') {Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue}
  Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
 }
}
'''.replace("RESULT_B64", encoded(str(result_path))).replace("TASK_NAME", task_name).replace("INNER_ENCODED", inner_encoded)
    try:
        completed = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
            "-EncodedCommand", base64.b64encode(outer.encode("utf-16le")).decode("ascii")],
            capture_output=True, timeout=25, creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        report = json.loads(completed.stdout.decode("utf-8-sig").strip())
        if not report.get("ok"):
            return {"ok":False,"reason":"Не удалось открыть папку в рабочем столе Windows: " + str(report.get("reason", "неизвестная ошибка"))}
        return report
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        return {"ok":False,"reason":f"Не удалось показать файл в рабочем столе Windows: {exc}"}
    finally:
        result_path.unlink(missing_ok=True)
        result_path.with_name(result_path.name + ".tmp").unlink(missing_ok=True)

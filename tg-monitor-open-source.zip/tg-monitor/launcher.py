"""Portable Windows launcher. The server and archive belong to this installation."""
import argparse
import configparser
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser


def data_home(value=None):
    root = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
    return Path(value or os.environ.get("TG_MONITOR_HOME") or root / "data").expanduser().resolve()


def installation_id(home):
    return hashlib.sha256(str(home).casefold().encode()).hexdigest()[:24]


def write_configuration(home, api_id, api_hash, port=8090, password=""):
    if not str(api_id).isdecimal() or int(api_id) <= 0 or not re.fullmatch(r"[0-9a-fA-F]{32}", api_hash):
        raise ValueError("Введите числовой api_id и api_hash из 32 символов с my.telegram.org.")
    if not 1024 <= int(port) <= 65535:
        raise ValueError("Порт должен быть числом от 1024 до 65535.")
    if "\n" in password or "\r" in password:
        raise ValueError("Пароль должен быть одной строкой.")
    home.mkdir(parents=True, exist_ok=True)
    config = configparser.ConfigParser(interpolation=None)
    config.read_dict({"telegram": {"api_id": str(api_id), "api_hash": api_hash},
                      "server": {"host": "127.0.0.1", "port": str(port)},
                      "archive": {"max_media_mb": "1024"},
                      "security": {"panel_password": password}})
    temporary = home / "config.ini.tmp"
    with temporary.open("w", encoding="utf-8") as output:
        config.write(output)
    temporary.replace(home / "config.ini")


def read_port(home):
    config = configparser.ConfigParser(interpolation=None)
    config.read(home / "config.ini", encoding="utf-8")
    return config.getint("server", "port", fallback=8090)


def ensure_configuration(home):
    """Initialize a new archive from application defaults, never from account data."""
    if (home / "config.ini").exists():
        return
    resource = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    application = Path(sys.executable).resolve().parent if getattr(sys,"frozen",False) else resource
    for path in (resource / "app-defaults.ini", application / "app-defaults.ini"):
        if path.is_file():
            defaults = configparser.ConfigParser(interpolation=None)
            defaults.read(path,encoding="utf-8")
            write_configuration(home,defaults.get("telegram","api_id"),defaults.get("telegram","api_hash"),
                                port=int(os.environ.get("TG_MONITOR_PORT",defaults.get("server","port",fallback="8090"))))
            return
    raise ValueError("Эта сборка не настроена. Используйте готовую версию TG Monitor или подготовьте config.ini перед запуском.")


def health(url):
    try:
        with urllib.request.urlopen(url + "api/health", timeout=1) as response:
            return json.load(response)
    except Exception:
        return None


def run_server(home):
    home.mkdir(parents=True, exist_ok=True)
    os.environ["TG_MONITOR_HOME"] = str(home)
    # PyInstaller's windowed executable has no console; uvicorn needs real streams.
    logfile = (home / "run.log").open("a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = logfile
    try:
        ensure_configuration(home)
        import app
        import uvicorn
        server = uvicorn.Server(uvicorn.Config(app.app, host=app.HOST, port=app.PORT,
                               log_level="warning", timeout_graceful_shutdown=8))
        app.RUNTIME_SERVER = server
        server.run()
    except BaseException:
        import traceback
        traceback.print_exc()
        return 1
    finally:
        logfile.flush()
    return 0


def acquire_mutex(home):
    if sys.platform != "win32":
        return None
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateMutexW.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p)
    kernel.CreateMutexW.restype = ctypes.c_void_p
    handle = kernel.CreateMutexW(None, False, "Local\\TGMonitorApp_" + installation_id(home))
    if not handle:
        raise OSError(ctypes.get_last_error(), "Не удалось открыть блокировку приложения")
    return handle, ctypes.get_last_error() == 183


def desktop(home):
    import tkinter as tk
    from tkinter import messagebox, ttk
    root = tk.Tk()
    root.title("TG Monitor")
    root.geometry("560x400")
    root.minsize(520, 380)
    root.configure(bg="#eef3f9")
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("TFrame", background="#eef3f9")
    style.configure("TLabel", background="#eef3f9", foreground="#17212b", font=("Segoe UI", 10))
    style.configure("TButton", padding=(12, 9), font=("Segoe UI", 10))
    container = ttk.Frame(root, padding=24)
    container.pack(fill="both", expand=True)
    ttk.Label(container, text="TG Monitor", font=("Segoe UI", 21, "bold")).pack(anchor="w")
    process = None
    control_token = secrets.token_urlsafe(32)
    started_at = None
    stopping_at = None
    log_handle = None
    url = None
    already_running = False
    mutex = acquire_mutex(home)
    if mutex and mutex[1]:
        root.withdraw()
        if (home / "config.ini").exists():
            webbrowser.open(f"http://127.0.0.1:{read_port(home)}/")
        messagebox.showinfo("TG Monitor", "Приложение уже запущено или запускается из этой папки.", parent=root)
        root.destroy()
        return 0

    def start():
        nonlocal process, started_at, log_handle, url, already_running
        try:
            ensure_configuration(home)
            home.mkdir(parents=True, exist_ok=True)
            url = f"http://127.0.0.1:{read_port(home)}/"
            check = health(url)
            if check and check.get("installation") != installation_id(home):
                raise ValueError("Этот порт занят другой установкой. Измените port в data/config.ini.")
            already_running = bool(check)
            if not already_running:
                try:
                    with socket.socket() as probe:
                        probe.bind(("127.0.0.1", read_port(home)))
                except OSError as exc:
                    raise ValueError("Порт занят другой программой. Измените port в data/config.ini.") from exc
                env = os.environ.copy()
                env["TG_MONITOR_CONTROL_TOKEN"] = control_token
                env["TG_MONITOR_HOME"] = str(home)
                args = [sys.executable]
                if not getattr(sys, "frozen", False):
                    args.append(str(Path(__file__).resolve()))
                args += ["--server", "--data-dir", str(home)]
                log_handle = (home / "launcher.log").open("a", encoding="utf-8")
                process = subprocess.Popen(args, env=env, cwd=home, stdout=log_handle, stderr=log_handle,
                                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            started_at = time.monotonic()
        except Exception as exc:
            messagebox.showerror("Не удалось запустить TG Monitor", str(exc), parent=root)
            root.destroy()
            return
        ttk.Label(container, text="Запись продолжается, пока приложение запущено.").pack(anchor="w", pady=(8, 24))
        status = ttk.Label(container, text="Запуск сервера…", font=("Segoe UI", 12, "bold"))
        status.pack(anchor="w", pady=(0, 8))
        ttk.Label(container, text=str(home), wraplength=480).pack(anchor="w", pady=(0, 20))
        open_button = ttk.Button(container, text="Открыть панель", command=lambda: webbrowser.open(url), state="disabled")
        open_button.pack(fill="x", pady=4)
        ttk.Button(container, text="Открыть папку данных", command=lambda: os.startfile(home)).pack(fill="x", pady=4)
        stop_button = ttk.Button(container, text="Закрыть окно" if already_running else "Остановить и закрыть", command=close)
        stop_button.pack(fill="x", pady=4)
        browser_opened = False

        def poll():
            nonlocal browser_opened
            if stopping_at is not None:
                if process is None or process.poll() is not None:
                    root.destroy()
                    return
                if time.monotonic() - stopping_at > 20:
                    process.terminate()
                root.after(500, poll)
                return
            if process is not None and process.poll() is not None:
                status.configure(text="Сервер остановлен. Подробнее: data/run.log", foreground="#bf3b30")
                return
            check = health(url)
            if check and check.get("installation") == installation_id(home):
                status.configure(text="Приложение запущено", foreground="#278447")
                open_button.configure(state="normal")
                if not browser_opened:
                    webbrowser.open(url)
                    browser_opened = True
            elif time.monotonic() - started_at > 120:
                status.configure(text="Запуск затянулся. Проверьте data/run.log", foreground="#9a5d00")
            root.after(1500, poll)
        poll()

    def close():
        nonlocal stopping_at
        if process is not None and process.poll() is None and stopping_at is None:
            if not messagebox.askyesno("Остановить TG Monitor?", "Запись сообщений остановится до следующего запуска. Сохранённые данные останутся.", parent=root):
                return
            stopping_at = time.monotonic()
            try:
                req = urllib.request.Request(url + "api/runtime/stop", data=b"", method="POST",
                                             headers={"Authorization": "Bearer " + control_token})
                with urllib.request.urlopen(req, timeout=2):
                    pass
            except Exception:
                # Startup may still be running; poll gives it time, then stops the child.
                pass
        else:
            root.destroy()

    root.protocol("WM_DELETE_WINDOW", close)
    start()
    root.mainloop()
    if log_handle:
        log_handle.close()
    if mutex:
        ctypes.WinDLL("kernel32").CloseHandle(ctypes.c_void_p(mutex[0]))
    return 0


def main():
    parser = argparse.ArgumentParser(description="TG Monitor")
    parser.add_argument("--data-dir", help="Archive folder; default: data next to the application")
    parser.add_argument("--server", "--headless", action="store_true", dest="server", help="Run without a desktop window")
    args = parser.parse_args()
    home = data_home(args.data_dir)
    return run_server(home) if args.server else desktop(home)


if __name__ == "__main__":
    raise SystemExit(main())

# Explicit allowlist: code and frontend only. No database, credentials or sessions.
from PyInstaller.utils.hooks import collect_submodules

a = Analysis(['launcher.py'], pathex=[], binaries=[],
             datas=[('frontend', 'frontend')],
             hiddenimports=collect_submodules('uvicorn') + collect_submodules('qrcode'),
             hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='TG Monitor',
          debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
          console=False, disable_windowed_traceback=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='TGMonitor-Windows-x64')

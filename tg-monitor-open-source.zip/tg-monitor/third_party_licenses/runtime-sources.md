# Runtime license sources

Python: LICENSE.txt from the official Python 3.14.6 Windows x64 ZIP.
Tcl/Tk: https://github.com/tcltk/tcl/blob/core-8-6-branch/license.terms and https://github.com/tcltk/tk/blob/core-8-6-branch/license.terms
OpenSSL 3.5.7: https://github.com/openssl/openssl/blob/openssl-3.5.7/LICENSE.txt
SQLite 3.50.4: https://www.sqlite.org/copyright.html

# Разработка TG Monitor

Исходники приложения доступны под MIT. Можно изменять, собирать и распространять свои версии, сохраняя LICENSE. Сторонние компоненты сохраняют собственные лицензии из THIRD_PARTY_NOTICES.md и third_party_licenses.

## Что редактировать

| Файл | Назначение |
| --- | --- |
| frontend/index.html | Разметка интерфейса |
| frontend/style.css | Цвета, размеры, расположение и адаптивность |
| frontend/app.js | Действия пользователя, поиск, отображение и запросы API |
| app.py | API, SQLite, Telegram, загрузка медиа и миграции базы |
| launcher.py | Окно запуска, первичная настройка и остановка сервера |
| TGMonitor.spec | Состав Windows EXE |
| scripts/build_portable.ps1 | Чистая упаковка исходников и приложения |
| requirements.lock | Зафиксированные зависимости приложения |
| tests | Проверки на временных базах и данных |

Интерфейс использует обычные HTML, CSS и JavaScript. Node.js, npm и сборка фронтенда для работы приложения не нужны.

## Запуск из исходников

Используйте Windows x64 и Python с Tcl/Tk; сборка проверена на Python 3.14.6 x64. Для быстрого запуска дважды нажмите start_monitor.bat. Скрипт найдёт Python или скачает проверенный официальный x64 runtime в .runtime, создаст .venv и попросит собственные ключи Telegram. Администратор не нужен. Первый запуск требует интернет для установки пакетов.

Можно настроить среду вручную:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock
.\.venv\Scripts\python.exe launcher.py --data-dir .\data
```

Перед первым запуском скопируйте config.example.ini в data/config.ini и заполните собственные API ID и API hash. Окна ввода ключей в launcher.py нет. Изолируйте данные разработки в data; не подключайте одну Telegram-сессию одновременно к двум экземплярам приложения. Для сервера без окна предварительно настройте data, затем выполните:

```powershell
.\.venv\Scripts\python.exe launcher.py --headless --data-dir .\data
```

При изменении HTML/CSS/JS перезагрузите страницу. В готовой сборке интерфейс находится в _internal/frontend: его тоже можно редактировать и обновлять без перекомпиляции EXE. Если браузер использует старую статику, увеличьте параметры v у ссылок в index.html или обновите страницу с Ctrl+F5.

Изменение Python-кода требует штатного перезапуска сервера; для готового EXE дополнительно требуется пересборка. Новые столбцы базы добавляйте через init_db() с миграцией существующего архива. Пути медиа храните относительно каталога данных, идентификаторы аккаунтов и чатов сохраняйте в ключах записей.

## Проверки

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -q
node --test tests/test_frontend.cjs
```

Node.js нужен только для необязательных тестов JavaScript. Тесты Python используют временные базы и искусственные клиенты Telegram. Проверка реального Telegram выполняется отдельно на тестовом аккаунте. Границы проведённых проверок указаны в AUDIT.md.

## Сборка

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe scripts/collect_licenses.py
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts/build_portable.ps1
.\.venv\Scripts\python.exe scripts/verify_bundle.py .\dist\TGMonitor-Windows-x64
```

Если dist/TGMonitor-Windows-x64 или ZIP уже существует, переименуйте предыдущий результат перед сборкой. Сборщик не подменяет работающий EXE. Для другой среды сборки есть параметр -BuildPython. Для упаковки только исходников используйте -SourceOnly. В готовом приложении Python и библиотеки включены в комплект.

## Публикация

Публикуйте чистый архив исходников, созданный scripts/build_portable.ps1 -SourceOnly. Собственная рабочая папка может содержать сессии, ключи, медиа и базы: они не являются частью исходного кода. .gitignore исключает их из обычного добавления в Git; сборщик использует явный список файлов. LICENSE и third_party_licenses должны сохраняться в распространяемых копиях. Заголовки и пути в локальных журналах сборки не нужны для запуска и не входят в распространяемый архив.

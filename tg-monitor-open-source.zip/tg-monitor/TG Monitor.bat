@echo off
setlocal
set "TG_APP=%~dp0dist\TGMonitor-Windows-x64\TG Monitor.exe"
if not exist "%TG_APP%" (
 echo Build the Windows application first using build_portable.ps1.
 pause
 exit /b 1
)
start "" "%TG_APP%" --data-dir "%~dp0."

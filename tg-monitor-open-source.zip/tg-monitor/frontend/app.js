// TG Monitor — логика панели
const PALETTE = ["#e17076","#7bc862","#e5ca77","#65aadd","#a695e7","#ee7aae","#faa774","#6ec9cb"];
const ST_LABEL = {recording:"запись идёт", paused:"на паузе", reconnecting:"переподключение",
                  linking:"ожидает подключения", error:"нужен повторный вход",
                  disconnected:"отключён"};
const EV_LABEL = {login:"Подключён", logout:"Отключён",
                  revoked:"сеанс завершён из Telegram"};
const $ = id => document.getElementById(id);

async function j(url, opts) {
  const r = await fetch(url, opts);
  const data = await r.json();
  if (r.status === 401) showLogin();
  if (!r.ok) throw new Error(data?.reason || ("HTTP " + r.status));
  return data;
}

function showLogin() {
  const m = $("login-modal");
  if (m.style.display !== "flex") {
    m.style.display = "flex";
    $("login-pass").focus();
  }
}

async function doLogin(el) {
  if (el?.disabled) return;
  btnBusy(el, true, "Проверяю…");
  try {
    const r = await j("/api/login", {method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({password: $("login-pass").value})});
    if (r.ok) { location.reload(); return; }
    $("login-status").textContent = r.reason || "неверный пароль";
  } catch (e) { $("login-status").textContent = e instanceof TypeError ? "Нет связи с панелью. Попробуйте ещё раз." : e.message; }
  finally { btnBusy(el, false); }
}
const esc = s => String(s ?? "").replace(/[&<>"']/g,
  c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const linkify = s => s.replace(/(https?:\/\/[^\s<)"']+)/g,
  '<a href="$1" target="_blank" rel="noreferrer" style="color:#3390ec;word-break:break-all">$1</a>');
const pl = (n, one, few, many) =>
  n % 10 == 1 && n % 100 != 11 ? one :
  (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? few : many);

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const p = n => String(n).padStart(2, "0");
  return `${p(d.getDate())}-${p(d.getMonth()+1)}-${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function fmtDay(iso) { return fmtDate(iso).slice(0, 10); }

function avatar(id, name, size = 46) {
  const words = (name || "?").split(" ").filter(Boolean);
  const ini = words.slice(0, 2).map(w => w[0]).join("").toUpperCase() || "?";
  const color = PALETTE[Math.abs(Number(id) || 0) % PALETTE.length];
  return `<span class="ava" style="background:${color};width:${size}px;height:${size}px;font-size:${Math.round(size/2.6)}px">${esc(ini)}</span>`;
}

function accountLabel(a) {
  const name = String(a?.name || "").trim();
  const phone = String(a?.phone || "").trim();
  const username = a?.username ? "@" + String(a.username).trim().replace(/^@+/, "") : "";
  const identifier = phone || username;
  const placeholder = ["Новый аккаунт", "Ожидает скана QR", "Ожидает код"];
  if (!name || placeholder.includes(name)) return identifier || name || "Неизвестный аккаунт";
  if (phone && name !== phone) return `${name} (${phone})`;
  if (username && name.toLocaleLowerCase() !== username.toLocaleLowerCase()) return `${name} (${username})`;
  return name;
}

// ---------- мелкие помощники интерфейса ----------

let toastTimer = null;
function toast(msg, kind) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "show" + (kind ? " " + kind : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.className = "", 2800);
}

const skelCard = () => `<div class="skel-card"><span class="skel-ava"></span>
  <div style="flex:1;min-width:0">
    <div class="skel skel-line" style="width:34%"></div>
    <div class="skel skel-line" style="width:58%;margin-top:9px"></div>
  </div></div>`;
const skelCards = n => skelCard().repeat(n);
const skelFeed = () => `
  <div class="day"><span class="skel" style="display:inline-block;width:96px;height:20px;border-radius:999px"></span></div>
  <div class="row in"><div class="skel skel-bub"></div></div>
  <div class="row out"><div class="skel skel-bub" style="width:130px"></div></div>
  <div class="row in"><div class="skel skel-bub" style="width:220px"></div></div>
  <div class="row out"><div class="skel skel-bub" style="width:90px"></div></div>`;
const errLine = msg => `<p class="sub err" style="padding:14px 4px">${esc(msg)}</p>`;

// ---------- плееры голосовых и аудио ----------

const SVG_PLAY = `<svg class="ic-play" viewBox="0 0 24 24" width="16" height="16"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>`;
const SVG_PAUSE = `<svg class="ic-pause" viewBox="0 0 24 24" width="16" height="16"><path d="M6 5h4v14H6zM14 5h4v14h-4z" fill="currentColor"/></svg>`;
const SVG_MIC = `<svg viewBox="0 0 24 24" width="17" height="17"><path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v5a3 3 0 0 0 3 3zm6-3a6 6 0 0 1-12 0H4a8 8 0 0 0 7 7.93V22h2v-3.07A8 8 0 0 0 20 11z" fill="currentColor"/></svg>`;
const SVG_NOTE = `<svg viewBox="0 0 24 24" width="17" height="17"><path d="M12 4v9.55A4 4 0 1 0 14 17V8h4V4z" fill="currentColor"/></svg>`;
const SVG_EYE = `<svg viewBox="0 0 24 24" width="15" height="15"><path d="M12 5C7 5 2.7 8.1 1 12c1.7 3.9 6 7 11 7s9.3-3.1 11-7c-1.7-3.9-6-7-11-7zm0 11.5A4.5 4.5 0 1 1 12 7.5a4.5 4.5 0 0 1 0 9zm0-7.2a2.7 2.7 0 1 0 0 5.4 2.7 2.7 0 0 0 0-5.4z" fill="currentColor"/></svg>`;

function playerHTML(src, kind) {
  const voice = kind === "voice";
  return `
  <div class="pl ${voice ? "pl-voice" : "pl-audio"}">
    <span class="pl-ico">${voice ? SVG_MIC : SVG_NOTE}</span>
    <button class="pl-btn" aria-label="${voice ? "Слушать голосовое" : "Играть аудио"}">${SVG_PLAY}${SVG_PAUSE}</button>
    <div class="pl-body">
      <div class="pl-top"><span class="pl-kind">${voice ? "Голосовое" : "Аудио"}</span>
        <span class="pl-time">…</span></div>
      <div class="pl-bar"><i class="pl-fill"></i></div>
    </div>
    <audio preload="metadata" src="${esc(src)}"></audio>
  </div>`;
}

function fmtDur(s) {
  if (!isFinite(s) || s < 0) return "–:––";
  const m = Math.floor(s / 60), x = Math.floor(s % 60);
  return `${m}:${String(x).padStart(2, "0")}`;
}

function initPlayers(root) {
  root.querySelectorAll(".pl").forEach(pl => {
    const au = pl.querySelector("audio");
    const btn = pl.querySelector(".pl-btn");
    const fill = pl.querySelector(".pl-fill");
    const time = pl.querySelector(".pl-time");
    au.addEventListener("loadedmetadata", () => { time.textContent = fmtDur(au.duration); });
    au.addEventListener("timeupdate", () => {
      if (!au.duration) return;
      fill.style.width = (100 * au.currentTime / au.duration) + "%";
      time.textContent = `${fmtDur(au.currentTime)} / ${fmtDur(au.duration)}`;
    });
    au.addEventListener("ended", () => {
      pl.classList.remove("playing");
      fill.style.width = "0%";
      time.textContent = fmtDur(au.duration);
    });
    // играет только один плеер на всю панель — другие останавливаем
    au.addEventListener("play", () => {
      document.querySelectorAll(".pl.playing").forEach(o => {
        if (o === pl) return;
        const a = o.querySelector("audio");
        a.pause();
        a.currentTime = 0;
        o.querySelector(".pl-fill").style.width = "0%";
      });
      pl.classList.add("playing");
    });
    au.addEventListener("pause", () => pl.classList.remove("playing"));
    btn.addEventListener("click", () => { au.paused ? au.play().catch(() => toast("Не удалось воспроизвести файл. Проверь, что он доступен и поддерживается браузером.", "err")) : au.pause(); });
    pl.querySelector(".pl-bar").addEventListener("click", e => {
      if (!au.duration) return;
      const r = e.currentTarget.getBoundingClientRect();
      au.currentTime = Math.min(Math.max((e.clientX - r.left) / r.width, 0), 1) * au.duration;
      if (au.paused) au.play().catch(() => toast("Не удалось воспроизвести файл.", "err"));
    });
  });
}

// ---------- подсветка совпадений (вне HTML-тегов) ----------

function hlOutsideTags(html, q) {
  if (!q) return html;
  const rx = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
  return html.split(/(<[^>]+>)/)
             .map((s, i) => i % 2 ? s : s.replace(rx, m => `<mark>${m}</mark>`))
             .join("");
}

// ---------- аккаунты ----------

let currentView = "accounts";
let chatReturnView = "accounts";
let searchReturnView = "accounts";
let accountFetchSeq = 0;
let lastAccountSnapshot = null;
let accountList = [];

async function loadAccounts(animate = true) {
  if ($("qr-modal").style.display === "flex") return;   // не дёргаем список под окном подключения
  const requestSeq = ++accountFetchSeq;
  let list;
  try { list = await j("/api/accounts"); }
  catch (e) {
    if (requestSeq !== accountFetchSeq) return;
    if (animate) $("accounts").innerHTML =
      errLine("Не удалось загрузить аккаунты — проверь, что панель запущена, и обнови страницу.");
    return;
  }
  if (requestSeq !== accountFetchSeq) return;
  accountList = list;
  refreshSearchAccounts();
  const snapshot = JSON.stringify(list);
  if (snapshot === lastAccountSnapshot) return;
  lastAccountSnapshot = snapshot;
  // главная — только активные; отключённые живут в «Архиве»;
  // заготовки линковки не показываем — их состояние видно в окне подключения
  const active = list.filter(a => a.status !== "disconnected" && a.status !== "linking");
  const archived = list.filter(a => a.status === "disconnected");
  const total = list.reduce((s, a) => s + (a.n || 0), 0);
  const rec = active.filter(a => a.status === "recording").length;
  $("stats").textContent =
    `${rec} записывают · ${total} ${pl(total, "сообщение", "сообщения", "сообщений")}`;
  // вкладка «Архив» живёт только когда в архиве что-то есть — пустую не показываем
  const tabArch = $("tab-archive");
  tabArch.style.display = archived.length ? "" : "none";
  tabArch.textContent = "Архив";
  if (!archived.length && currentView === "archive") switchView("accounts");

  $("accounts").innerHTML = active.length
    ? active.map(a => acctCard(a, animate)).join("") + addCard(animate)
    : (archived.length
        ? `<div class="empty"><div class="empty-ico">&#128230;</div>
           <div class="empty-t">Нет активных аккаунтов</div>
           <div class="sub">Подключи новый или верни аккаунт из «Архива»</div></div>` + addCard(animate)
        : emptyAccounts(animate));
  $("archived-accounts").innerHTML = archived.length
    ? archived.map(a => acctCard(a, animate)).join("")
    : `<div class="empty"><div class="empty-ico">&#128230;</div><div class="empty-t">Архив пуст</div>
       <div class="sub">Отключённые аккаунты и их переписки будут собираться здесь</div></div>`;
}

function acctCard(a, animate) {
  const off = a.status === "disconnected";
  const btnBF = a.bf && a.bf.state === "running"
    ? `<button class="btn warn" onclick="bfStop(this,${a.id})">Остановить загрузку</button>`
    : off ? "" : `<button class="btn" onclick="bfStart(this,${a.id})">Загрузить историю</button>`;
  const btnPower = off
    ? `<button class="btn primary" onclick="connectAccount(this)">Подключить</button>`
    : a.status === "paused"
    ? `<button class="btn primary" onclick="act(this,${a.id},'resume')">Продолжить</button>`
    : `<button class="btn" onclick="act(this,${a.id},'pause')">Пауза</button>`;
  const btnDisc = (off || a.status === "linking")
    ? "" : `<button class="btn" onclick="discAccount(this,${a.id})">Отключить</button>`;
  let bfLine = "";
  if (a.bf && a.bf.state === "running") {
    const pct = a.bf.total ? Math.round(100 * a.bf.done / a.bf.total) : 0;
    bfLine = `<div class="bf">
        <div class="bf-bar"><i style="width:${pct}%"></i></div>
        <div class="bf-txt">загрузка истории: ${a.bf.done}/${a.bf.total} чатов · ${a.bf.msgs} сообщ.` +
        `${a.bf.current_chat ? ` · сейчас: ${esc(a.bf.current_chat)}` : ""}` +
        `${a.bf.current_message ? ` · сообщение №${a.bf.current_message}` : ""}` +
        `${a.bf.current_media_size ? ` · медиа ${(a.bf.current_media_size / 1e6).toFixed(1)} МБ` : ""}` +
        `${a.bf.note ? ` · ${esc(a.bf.note)}` : ""}` +
        (a.bf.bytes ? ` · ${(a.bf.bytes / 1e6).toFixed(1)} МБ` : "") + `</div>
      </div>`;
  } else if (a.bf && a.bf.state === "error") {
    bfLine = `<div class="bf-txt err">история: ошибка (${esc(a.bf.note || "")}) — нажми «Загрузить историю» ещё раз</div>`;
  } else if (a.bf && (a.bf.state === "done" || a.bf.state === "partial")) {
    bfLine = a.bf.note
      ? `<div class="bf-txt err">⚠ ${esc(a.bf.note)}</div>`
      : "";
  }
  return `
  <div class="card acct${animate ? " anim" : ""}">
    ${avatar(a.id, a.name || a.phone || a.username || "?", 48)}
    <div class="cmain">
      <div class="ctop">
        <span class="nm">${esc(accountLabel(a))}</span>
        <span class="pill st-${esc(a.status)}"><i class="dot"></i>${ST_LABEL[a.status] || esc(a.status)}</span>
      </div>
      <div class="pv">${a.n || 0} ${pl(a.n || 0, "сообщение", "сообщения", "сообщений")}` +
        `${a.last ? " · " + fmtDate(a.last) : ""}</div>
      ${a.last_ev_kind ? `<div class="evline ev-${esc(a.last_ev_kind)}">
        <i class="dot"></i>${EV_LABEL[a.last_ev_kind] || esc(a.last_ev_kind)} · ${fmtDate(a.last_ev_time)}</div>` : ""}
      ${bfLine}
      ${a.ingest?.storage_error ? '<div class="bf-txt err">Ошибка записи: проверьте свободное место и доступ к папке архива.</div>' : ""}
      ${a.ingest?.pending ? `<div class="bf-txt${a.ingest.retrying ? " err" : ""}">Фоновая обработка: ${a.ingest.pending}${a.ingest.retrying ? ` · ожидают повтора: ${a.ingest.retrying}` : ""}</div>` : ""}
    </div>
    <div class="cactions">
      <button class="btn primary" data-action="open-chats" data-account-id="${a.id}" data-account-name="${esc(accountLabel(a))}">Чаты</button>
      ${btnBF}
      ${btnPower}
      ${btnDisc}
    </div>
  </div>`;
}

function refreshSearchAccounts() {
  const sel = $("q-account");
  if (!sel) return;
  const previous = sel.value || "0";
  sel.innerHTML = `<option value="0">Все аккаунты</option>` + accountList
    .filter(a => a.status !== "linking")
    .map(a => `<option value="${a.id}">${esc(accountLabel(a))}${a.status === "disconnected" ? " · архив" : ""}</option>`)
    .join("");
  sel.value = [...sel.options].some(o => o.value === previous) ? previous : "0";
}

function addCard(animate) {
  return `
  <div class="card add${animate ? " anim" : ""}" role="button" tabindex="0"
       onclick="connectAccount(this)" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();connectAccount(this)}">
    <span class="ava plus"></span>
    <div style="min-width:0"><div class="nm">Подключить аккаунт</div>
    <div class="pv">Вход по QR-коду или номеру телефона</div></div>
  </div>`;
}

function emptyAccounts(animate) {
  return `
  <div class="empty">
    <div class="empty-ico">&#128228;</div>
    <div class="empty-t">Здесь пока пусто</div>
    <div class="sub">Подключи первый Telegram-аккаунт — архив начнёт собираться сам</div>
  </div>` + addCard(animate);
}

async function act(el, id, action) {
  btnBusy(el, true, "Выполняю…");
  try { await j(`/api/accounts/${id}/${action}`, {method: "POST"}); }
  catch (e) { toast(e.message || "Действие не получилось — попробуй ещё раз", "err"); }
  finally { btnBusy(el, false); }
  loadAccounts();
}

async function bfStart(el, id) {
  btnBusy(el, true, "Запускаю…");
  try { await j(`/api/accounts/${id}/backfill`, {method: "POST"}); }
  catch (e) { toast("Не удалось начать загрузку — попробуй ещё раз", "err"); }
  finally { btnBusy(el, false); }
  loadAccounts();
}

async function bfStop(el, id) {
  btnBusy(el, true, "Останавливаю…");
  try { await j(`/api/accounts/${id}/backfill/stop`, {method: "POST"}); }
  catch (e) { toast("Не удалось остановить — попробуй ещё раз", "err"); }
  finally { btnBusy(el, false); }
  loadAccounts();
}

async function discAccount(el, id) {
  if (!confirm("Отключить аккаунт от панели?\n\n" +
               "• запись остановится, ключ сессии удалится\n" +
               "• весь архив — сообщения, чаты, медиа — сохранится полностью\n" +
               "• при повторном подключении (QR или по номеру) сканирование продолжится с момента отключения")) return;
  btnBusy(el, true, "Отключаю…");
  try { await j(`/api/accounts/${id}/disconnect`, {method: "POST"}); }
  catch (e) { toast("Не удалось отключить — попробуй ещё раз", "err"); }
  finally { btnBusy(el, false); }
  loadAccounts();
}

// ---------- QR-подключение ----------

let qrFid = null, qrTimer = null, phFid = null, phBusy = false;
let connectionSeq = 0, connectionFocus = null;

function btnBusy(btn, on, text) {
  if (!btn || (btn.tagName && btn.tagName !== "BUTTON")) return;
  if (on) {
    btn.dataset.txt = btn.textContent;
    btn.textContent = text;
    btn.disabled = true;
  } else if (btn.isConnected && btn.dataset.txt !== undefined) {
    btn.textContent = btn.dataset.txt;
    btn.disabled = false;
    delete btn.dataset.txt;
  }
}

async function connectAccount(el) {
  // окно открывается мгновенно; QR подставится, когда Telegram его выдаст
  if (phBusy) return;                     // уже готовим — второе нажатие игнорируем
  const seq = ++connectionSeq;
  connectionFocus = document.activeElement;
  phBusy = true;
  btnBusy(el, true, "Готовлю…");
  qrFid = null;
  clearInterval(qrTimer);
  connectTab("qr");
  resetPhonePane();
  const img = $("qr-img");
  $("qr-modal").style.display = "flex";
  $("tab-qr").focus();
  img.classList.remove("ready");
  img.style.display = "none";
  img.src = "";
  $("qr-scan").style.display = "none";
  $("qr-spinner").style.display = "block";
  $("qr-pwd").style.display = "none";
  $("qr-password").value = "";
  $("qr-retry").style.display = "none";
  $("qr-status").textContent = "Готовлю QR-код... (несколько секунд)";
  try {
    const r = await j("/api/accounts/add", {method: "POST"});
    if (seq !== connectionSeq) {
      if (r.fid) await j(`/api/qr/${r.fid}/cancel`, {method: "POST"}).catch(() => {});
      return;
    }
    if (!r.ok || !r.fid) {
      $("qr-spinner").style.display = "none";
      $("qr-status").textContent = r.reason || "Не получилось создать QR.";
      $("qr-retry").style.display = "inline-flex";
      return;
    }
    qrFid = r.fid;
    $("qr-spinner").style.display = "none";
    img.style.display = "block";
    $("qr-scan").style.display = "block";
    $("qr-status").textContent = "Ожидаю скан... (QR обновляется сам)";
    refreshQr();
    qrTimer = setInterval(pollQr, 2000);
  } catch (e) {
    if (seq !== connectionSeq) return;
    $("qr-spinner").style.display = "none";
    $("qr-status").textContent = "Панель недоступна или связь оборвалась.";
    $("qr-retry").style.display = "inline-flex";
  } finally {
    phBusy = false;
    btnBusy(el, false);
  }
}
function refreshQr() { $("qr-img").src = `/api/qr/${qrFid}.png?t=${Date.now()}`; }
async function pollQr() {
  const seq = connectionSeq, fid = qrFid;
  if (!fid) return;
  let st;
  try { st = await j(`/api/qr/${fid}/status`); }
  catch (e) { return; }
  if (seq !== connectionSeq || fid !== qrFid) return;
  if (st.state === "waiting") { refreshQr(); return; }
  if (st.state === "pwd") {
    $("qr-status").textContent = "Скан принят! Введи пароль 2FA:";
    $("qr-scan").style.display = "none";
    $("qr-pwd").style.display = "block";
    $("qr-password").focus();
    clearInterval(qrTimer);
    return;
  }
  if (st.state === "authorized") { closeQr(); loadAccounts(); switchView("accounts"); settleAccounts(); return; }
  $("qr-status").textContent = "Состояние: " + st.state + " — переподключи заново, если надолго зависло.";
}
async function sendPwd() {
  const seq = connectionSeq;
  const pwd = $("qr-password").value;
  if (!pwd) return;
  try {
    const r = await j(`/api/qr/${qrFid}/password`, {method: "POST",
      headers: {"Content-Type": "application/json"}, body: JSON.stringify({password: pwd})});
    if (seq !== connectionSeq) return;
    if (r.ok) { closeQr(); loadAccounts(); }
    else $("qr-status").textContent = "Пароль не принят, попробуй ещё раз.";
  } catch (e) { if (seq === connectionSeq) $("qr-status").textContent = "Ошибка связи — попробуй ещё раз."; }
}
function settleAccounts() {
  // после успешного входа статус аккаунта ещё «переезжает» (склейка с архивом) —
  // дотягиваем список быстрыми обновлениями, чтобы ничего не мигало
  let n = 0;
  const t = setInterval(() => {
    loadAccounts(false);
    if (++n >= 10) clearInterval(t);
  }, 700);
}

function closeQr() {
  ++connectionSeq;
  $("qr-modal").style.display = "none";
  clearInterval(qrTimer);
  connectionFocus?.focus();
  if (qrFid) {                       // отмена до скана — убираем за собой несоздавшийся аккаунт
    j(`/api/qr/${qrFid}/cancel`, {method: "POST"}).catch(() => {});
    qrFid = null;
    loadAccounts();
  }
  if (phFid) {                       // то же для незавершённого входа по номеру
    j(`/api/phone/${phFid}/cancel`, {method: "POST"}).catch(() => {});
    phFid = null;
    loadAccounts();
  }
}

// ---------- вкладка и флоу «по номеру телефона» ----------

function connectTab(which) {
  $("tab-qr").classList.toggle("active", which === "qr");
  $("tab-phone").classList.toggle("active", which === "phone");
  $("pane-qr").style.display = which === "qr" ? "block" : "none";
  $("pane-phone").style.display = which === "phone" ? "block" : "none";
  if (which === "phone") resetPhonePane();
}

function resetPhonePane() {
  if (phFid) j(`/api/phone/${phFid}/cancel`, {method: "POST"}).catch(() => {});
  phFid = null;
  $("ph-step1").style.display = "block";
  $("ph-step2").style.display = "none";
  $("ph-step3").style.display = "none";
  for (const id of ["ph-phone", "ph-code", "ph-pass"]) $(id).value = "";
  $("ph-status").textContent = "";
}

async function phoneSendCode(el) {
  if (phBusy) return;
  phBusy = true;
  const seq = connectionSeq;
  btnBusy(el, true, "Отправляю…");
  const phone = $("ph-phone").value.trim();
  const st = $("ph-status");
  st.textContent = "";
  try {
    const r = await j("/api/accounts/add-phone", {method: "POST",
      headers: {"Content-Type": "application/json"}, body: JSON.stringify({phone})});
    if (seq !== connectionSeq) {
      if (r.fid) await j(`/api/phone/${r.fid}/cancel`, {method: "POST"}).catch(() => {});
      return;
    }
    if (!r.ok) { st.textContent = r.reason || "Не получилось — проверь номер"; return; }
    phFid = r.fid;
    $("ph-step1").style.display = "none";
    $("ph-step2").style.display = "block";
    $("ph-code").focus();
  } catch (e) { if (seq === connectionSeq) st.textContent = "Связь оборвалась — попробуй ещё раз"; }
  finally { phBusy = false; btnBusy(el, false); }
}

async function phoneSendCode2(el) {
  if (phBusy) return;
  phBusy = true;
  const seq = connectionSeq;
  btnBusy(el, true, "Проверяю…");
  const st = $("ph-status");
  st.textContent = "";
  try {
    const r = await j(`/api/phone/${phFid}/code`, {method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({code: $("ph-code").value.trim()})});
    if (seq !== connectionSeq) return;
    if (r.ok) { phFid = null; closeQr(); loadAccounts(); switchView("accounts"); settleAccounts(); return; }
    if (r.state === "pwd") {
      $("ph-step2").style.display = "none";
      $("ph-step3").style.display = "block";
      $("ph-pass").focus();
      return;
    }
    if (r.state === "dead") { resetPhonePane(); st.textContent = r.reason; return; }
    st.textContent = r.reason || "Код не принят";
  } catch (e) { if (seq === connectionSeq) st.textContent = "Связь оборвалась — попробуй ещё раз"; }
  finally { phBusy = false; btnBusy(el, false); }
}

async function phoneSendPwd(el) {
  if (phBusy) return;
  phBusy = true;
  const seq = connectionSeq;
  btnBusy(el, true, "Проверяю…");
  const st = $("ph-status");
  st.textContent = "";
  try {
    const r = await j(`/api/phone/${phFid}/password`, {method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({password: $("ph-pass").value})});
    if (seq !== connectionSeq) return;
    if (r.ok) { phFid = null; closeQr(); loadAccounts(); switchView("accounts"); settleAccounts(); return; }
    if (r.state === "dead") { resetPhonePane(); st.textContent = r.reason; return; }
    st.textContent = r.reason || "Пароль не принят";
  } catch (e) { if (seq === connectionSeq) st.textContent = "Связь оборвалась — попробуй ещё раз"; }
  finally { phBusy = false; btnBusy(el, false); }
}

// ---------- чаты и лента ----------

let currentAccount = null;
let feedRequestSeq = 0;
let chatsForAccount = [], chatSearchTimer = null, chatSearchSeq = 0;

async function openChats(accountId, name) {
  feedRequestSeq++;
  chatSearchSeq++;
  clearTimeout(chatSearchTimer);
  currentChatId = null;
  switchView("chats");
  window.scrollTo(0, 0);                       // «окно» чатов начинается от верха страницы
  $("chats-title").textContent = "Чаты: " + (name || "");
  $("chat-q").value = "";
  $("chat-q-clear").hidden = true;
  $("chat-search-hint").hidden = true;
  $("chat-search-hint").textContent = "";
  chatsForAccount = [];
  $("feed-wrap").style.display = "none";
  $("chats-head").style.display = "flex";
  $("chats").style.display = "block";
  $("chats").innerHTML = skelCards(4);
  currentAccount = accountId;
  let chats;
  try { chats = await j(`/api/chats?account_id=${accountId}`); }
  catch (e) { $("chats").innerHTML = errLine("Не удалось загрузить чаты — вернись назад и зайди ещё раз."); return; }
  if (currentAccount !== accountId) return;
  chatsForAccount = chats;
  if ($("chat-q").value.trim()) doChatsSearch();
  else renderChats(chats);
}

function chatLabel(title, type) {
  const name = title || "(без названия)";
  return type === "group" ? `${name} (общий чат)` : name;
}

function chatCard(c) {
  const label = chatLabel(c.title, c.type);
  return `
    <button type="button" class="card click anim chat-card" data-action="open-feed" data-chat-id="${c.chat_id}" data-chat-title="${esc(c.title || "")}">
      ${avatar(c.chat_id, c.title, 44)}
      <div style="min-width:0;flex:1">
        <div class="nm">${esc(label)}</div>
        <div class="pv">${esc(c.preview)} · ${fmtDay(c.last)}</div>
      </div>
      <span class="badge">${c.n}</span>
    </button>`;
}

function renderChats(chats) {
  $("chats").innerHTML = chats.map(chatCard).join("") ||
    `<div class="empty"><div class="empty-ico">&#128172;</div><div class="empty-t">Пока пусто</div>
     <div class="sub">Сообщения появятся сами — или нажми «Загрузить историю» на карточке аккаунта</div></div>`;
}

function chatMessageResult(r, q) {
  const chat = chatsForAccount.find(c => Number(c.chat_id) === Number(r.chat_id));
  const label = chatLabel(r.chat, chat?.type);
  return `<button type="button" class="card click anim search-result chat-message-hit"
      data-action="open-chat-message-result" data-account-id="${r.account_id}" data-chat-id="${r.chat_id}"
      data-chat-title="${esc(r.chat || "")}" data-search-query="${esc(q)}"
      aria-label="Открыть совпадение в чате ${esc(label)}, ${fmtDate(r.date)}">
    ${avatar(r.chat_id, r.chat, 42)}
    <span class="chat-message-info">
      <span class="sr-top"><span class="nm">${esc(label)}</span><time class="sr-date">${fmtDate(r.date)}</time></span>
      <span class="pv">${r.out ? "Исходящее" : "Входящее"} · ${hlOutsideTags(esc((r.text || "").slice(0, 180)), q)}</span>
    </span>
  </button>`;
}

function doChatsSearch() {
  clearTimeout(chatSearchTimer);
  const requestSeq = ++chatSearchSeq;
  const q = $("chat-q").value.trim();
  const accountId = currentAccount;
  const query = q.toLocaleLowerCase();
  $("chat-q-clear").hidden = !q;
  const titleMatches = q
    ? chatsForAccount.filter(c => String(c.title || "").toLocaleLowerCase().includes(query))
    : chatsForAccount;

  if (!q) {
    $("chat-search-hint").hidden = true;
  $("chat-search-hint").textContent = "";
    renderChats(chatsForAccount);
    return;
  }
  $("chat-search-hint").hidden = false;
  if (q.length < 2) {
    $("chat-search-hint").textContent = `По имени найдено чатов: ${titleMatches.length}. Для поиска по сообщениям введи ещё символ.`;
    $("chats").innerHTML = titleMatches.map(chatCard).join("") ||
      `<div class="empty"><div class="empty-t">Совпадений нет</div><div class="sub">Попробуй другую часть имени</div></div>`;
    return;
  }

  $("chat-search-hint").textContent = "Ищу по имени и сообщениям…";
  $("chats").innerHTML = `<div class="searching"><span class="dots"><i></i><i></i><i></i></span>ищу по сообщениям…</div>`;
  chatSearchTimer = setTimeout(async () => {
    let messages;
    try {
      const params = new URLSearchParams({q, account_id: String(accountId)});
      messages = await j(`/api/search?${params}`);
    } catch (e) {
      if (requestSeq === chatSearchSeq) $("chat-search-hint").textContent = "Не удалось выполнить поиск. Попробуй ещё раз.";
      return;
    }
    if (requestSeq !== chatSearchSeq || currentAccount !== accountId || $("chat-q").value.trim() !== q) return;

    const nameSection = titleMatches.length
      ? `<div class="chat-search-section">Чаты по имени · ${titleMatches.length}</div>${titleMatches.map(chatCard).join("")}`
      : "";
    const messageSection = messages.length
      ? `<div class="chat-search-section">Сообщения · показано ${messages.length}${messages.length === 50 ? " (уточни запрос, чтобы сузить выдачу)" : ""}</div>${messages.map(r => chatMessageResult(r, q)).join("")}`
      : "";
    $("chat-search-hint").textContent = `По имени: ${titleMatches.length} · по сообщениям: ${messages.length}`;
    $("chats").innerHTML = nameSection + messageSection ||
      `<div class="empty"><div class="empty-t">Совпадений нет</div><div class="sub">Проверь имя или попробуй другие слова</div></div>`;
  }, 250);
}

function clearChatsSearch() {
  clearTimeout(chatSearchTimer);
  chatSearchSeq++;
  $("chat-q").value = "";
  $("chat-q-clear").hidden = true;
  $("chat-search-hint").hidden = true;
  $("chat-search-hint").textContent = "";
  renderChats(chatsForAccount);
  $("chat-q").focus();
}

let currentChatId = null, currentChatTitle = "", feedSearchTimer = null;
let feedMessages = [], feedHasOlder = false, feedOlderLoading = false;
let mediaFocusTimer = null;

async function showFeed(chatId, title, searchQuery = "", aroundMsgId = 0) {
  const head = $("chats-head"), list = $("chats"), searchBar = $("chat-search-bar"), wrap = $("feed-wrap");
  if (chatId === null) {                       // назад к списку чатов
    feedRequestSeq++;
    currentChatId = null;
    wrap.style.display = "none";
    head.style.display = "flex";
    searchBar.style.display = "block";
    list.style.display = "block";
    return;
  }
  head.style.display = "none";
  searchBar.style.display = "none";
  list.style.display = "none";
  wrap.style.display = "flex";
  window.scrollTo(0, 0);                       // окно переписки — от верха страницы
  currentChatId = chatId;
  const chat = chatsForAccount.find(c => Number(c.chat_id) === Number(chatId));
  currentChatTitle = chatLabel(chat?.title || title, chat?.type);
  const requestSeq = ++feedRequestSeq;
  feedMessages = [];
  feedHasOlder = false;
  $("feed-title").textContent = currentChatTitle;
  clearFeedSearch(true);                       // новый чат — поиск по старому не тянем
  $("feed").innerHTML = skelFeed();
  let msgs;
  try {
    msgs = searchQuery ? [] : aroundMsgId
      ? await fetchFeed(chatId, "", 200, 0, aroundMsgId) : await fetchFeed(chatId);
  } catch (e) {
    if (requestSeq !== feedRequestSeq || currentChatId !== chatId) return;
    $("feed").innerHTML = errLine("Не удалось загрузить сообщения — обнови страницу (F5) и зайди в чат ещё раз.");
    return;
  }
  if (requestSeq !== feedRequestSeq || currentChatId !== chatId) return;
  feedMessages = msgs;
  feedHasOlder = msgs.length === 200;
  if (searchQuery) {
    $("fq").value = searchQuery;
    doFeedSearch();
    return;
  }
  renderFeedMessages(msgs, "");
}

async function fetchFeed(chatId, q = "", limit = 200, beforeMsgId = 0, aroundMsgId = 0) {
  const params = new URLSearchParams({
    account_id: currentAccount, chat_id: chatId, limit: String(limit)
  });
  if (q) params.set("q", q);
  if (beforeMsgId) params.set("before_msg_id", String(beforeMsgId));
  if (aroundMsgId) params.set("around_msg_id", String(aroundMsgId));
  return await j(`/api/messages?${params}`);
}

async function loadOlderMessages() {
  if (feedOlderLoading || !feedHasOlder || !feedMessages.length ||
      currentChatId === null || $("fq").value.trim().length >= 2) return;
  const accountId = currentAccount, chatId = currentChatId;
  const requestSeq = feedRequestSeq;
  const beforeMsgId = feedMessages[0].msg_id;
  const feed = $("feed"), oldHeight = feed.scrollHeight, oldTop = feed.scrollTop;
  feedOlderLoading = true;
  try {
    const older = await fetchFeed(chatId, "", 200, beforeMsgId);
    if (requestSeq !== feedRequestSeq || currentAccount !== accountId ||
        currentChatId !== chatId || $("fq").value.trim().length >= 2) return;
    if (!older.length) {
      feedHasOlder = false;
      return;
    }
    feedMessages = [...older, ...feedMessages];
    feedHasOlder = older.length === 200;
    renderFeedMessages(feedMessages, "");
    feed.scrollTop = feed.scrollHeight - oldHeight + oldTop;
  } catch (e) {
    toast("Не удалось подгрузить более старые сообщения", "err");
  } finally {
    feedOlderLoading = false;
  }
}

function renderFeedMessages(msgs, q) {
  const isSearch = !!q;
  let html = "", prevOut = null, prevDay = null;
  for (const m of msgs) {
    const day = (m.date || "").slice(0, 10);
    if (day !== prevDay) {
      html += `<div class="day"><span>${esc(fmtDay(m.date))}</span></div>`;
      prevOut = null; prevDay = day;
    }
    const grp = (m.out === prevOut) ? "grp" : "first";
    prevOut = m.out;
    let att = "";
    if (m.media_type) {
      const p = m.file_path ? "/" + m.file_path : null;
      const mediaState = {downloading:"загружается…", incomplete:"не дозагружен",
        unavailable:"файл удалён или недоступен в Telegram", storage_full:"не скачан: мало места на диске",
        dismissed:"файл скрыт в каталоге"}[m.media_status];
      if (!p) att = `<div class="att">[${esc(m.media_type)} — ${esc(mediaState || "не скачан")}` +
        `${m.media_error ? `: ${esc(m.media_error)}` : ""}]</div>`;
      else if (m.media_type === "photo") att = `<img class="ph" src="${esc(p)}" loading="lazy">`;
      else if (m.media_type === "video") att = `<video controls preload="none" width="320" src="${esc(p)}"></video>`;
      else if (["voice", "audio"].includes(m.media_type)) att = playerHTML(p, m.media_type);
      else att = `<span class="fchip" data-action="reveal-file" data-file-path="${esc(p)}" title="Показать файл в папке">&#128196; файл</span>`;
    }
    const who = m.out
      ? '<b class="ou">ТЫ</b>'
      : `<b class="in">${esc(m.sender_label || (m.chat_type === "group" ? `Участник · ${m.sender_id || "?"}` : "СОБЕСЕДНИК"))}</b>`;
    const body = m.text ? `<div class="t">${hlOutsideTags(linkify(esc(m.text)), q)}</div>` : "";
    html += `<div class="row ${m.out ? "out" : "in"} ${grp}" data-message-id="${m.msg_id}">
      <div class="m">${att}${body}
      <div class="meta">${who} · ${esc(fmtDate(m.date))}</div></div></div>`;
  }
  const feed = $("feed");
  if (isSearch) {
    feed.innerHTML = html
      ? `<div class="fq-note"><span>по запросу «${esc(q)}» найдено: ${msgs.length}</span></div>` +
        `<div class="feed-in">${html}</div>`
      : `<div class="empty"><div class="empty-ico">&#128269;</div>
         <div class="empty-t">Ничего не нашлось</div>
         <div class="sub">В этом чате нет «${esc(q)}» — попробуй другое слово</div></div>`;
    feed.scrollTop = 0;                       // результаты — от шапки вниз
  } else {
    feed.innerHTML = html
      ? `<div class="feed-in">${html}</div>`
      : `<div class="empty"><div class="empty-t">Нет сообщений</div></div>`;
    feed.scrollTop = feed.scrollHeight;        // сразу к последним сообщениям
  }
  initPlayers(feed);
}

// ---------- поиск внутри чата ----------

function doFeedSearch() {
  clearTimeout(feedSearchTimer);
  const requestSeq = ++feedRequestSeq;
  feedSearchTimer = setTimeout(async () => {
    if (currentChatId === null) return;
    const q = $("fq").value.trim();
    const accountId = currentAccount, chatId = currentChatId;
    $("fq-clear").style.display = q ? "flex" : "none";
    let msgs;
    try {
      msgs = await fetchFeed(chatId, q.length >= 2 ? q : "",
                             q.length >= 2 ? 1000 : 200);
    } catch (e) { return; }
    if (requestSeq !== feedRequestSeq || currentAccount !== accountId ||
        currentChatId !== chatId || $("fq").value.trim() !== q) return;
    if (q.length < 2) {
      feedMessages = msgs;
      feedHasOlder = msgs.length === 200;
    }
    renderFeedMessages(msgs, q.length >= 2 ? q : "");
  }, 250);
}

function clearFeedSearch(silent = false) {
  if (!silent) {
    $("fq").value = "";
    $("fq-clear").style.display = "none";
    doFeedSearch();                            // вернёт обычную ленту
  } else {                                      // вход в новый чат
    $("fq").value = "";
    $("fq-clear").style.display = "none";
    clearTimeout(feedSearchTimer);
  }
}

// ---------- показ документа в папке ----------

async function revealFile(p) {
  try {
    const r = await j("/api/reveal?path=" + encodeURIComponent(p.replace(/^\/+/, "")));
    if (!r.ok) toast(r.reason || "Не получилось открыть папку", "err");
    else if (r.foreground && r.maximized) toast("Файл выделен в Проводнике");
    else if (r.foreground) toast("Проводник открыл файл, но окно не удалось развернуть", "err");
    else toast("Файл выделен, но Windows не вывела Проводник на передний план", "err");
  } catch (e) { toast("Не получилось открыть папку", "err"); }
}

// ---------- поиск ----------

let searchTimer = null, searchRequestSeq = 0;
function doSearch() {
  clearTimeout(searchTimer);
  const requestSeq = ++searchRequestSeq;
  const q = $("q").value.trim();
  const accountId = Number($("q-account").value || 0);
  $("q-clear").hidden = !q;
  if (q.length < 2) {
    $("results").innerHTML = "";
    $("search-hint").textContent = q
      ? "Добавь ещё один символ, чтобы начать поиск."
      : "Введи минимум 2 символа. Поиск идёт по всем аккаунтам.";
    return;
  }
  $("search-hint").textContent = "";
  searchTimer = setTimeout(async () => {
    $("results").innerHTML = `<div class="searching"><span class="dots"><i></i><i></i><i></i></span>ищу…</div>`;
    let rows;
    const params = new URLSearchParams({q, account_id: String(accountId)});
    try { rows = await j("/api/search?" + params); }
    catch (e) {
      if (requestSeq === searchRequestSeq && $("q").value.trim() === q && Number($("q-account").value || 0) === accountId)
        $("results").innerHTML = errLine("Поиск не удался — попробуй ещё раз.");
      return;
    }
    if (requestSeq !== searchRequestSeq || $("q").value.trim() !== q || Number($("q-account").value || 0) !== accountId) return;
    $("results").innerHTML = rows.length ? `<div class="search-count">Показано совпадений: ${rows.length}${rows.length === 50 ? " · уточни запрос, чтобы сузить результаты" : ""}</div>` + rows.map(r => `
      <button type="button" class="card click anim search-result" data-action="open-search-result" data-account-id="${r.account_id}" data-account-name="${esc(r.account || "")}" data-chat-id="${r.chat_id}" data-chat-title="${esc(r.chat || "")}" data-search-query="${esc(q)}" aria-label="Открыть сообщение из чата ${esc(r.chat || "")}, ${fmtDate(r.date)}">
        ${avatar(r.chat_id, r.chat, 42)}
        <div style="min-width:0;flex:1">
          <div class="sr-top"><span class="acct-chip">${esc(r.account)}</span><span class="nm">${esc(r.chat || "Без названия")}</span>
            <time class="sr-date">${fmtDate(r.date)}</time></div>
          <div class="pv">${r.out ? "Исходящее" : "Входящее"} · ${hlOutsideTags(esc((r.text || "").slice(0, 180)), q)}</div>
        </div>
      </button>`).join("") :
      `<div class="empty"><div class="empty-t">Ничего не нашлось</div>
       <div class="sub">Попробуй другое слово или часть слова</div></div>`;
  }, 250);
}

function clearSearch(focus = true) {
  clearTimeout(searchTimer);
  searchRequestSeq++;
  $("q").value = "";
  $("q-clear").hidden = true;
  $("results").innerHTML = "";
  $("search-hint").textContent = "Введи текст сообщения. Поиск идёт по всем аккаунтам.";
  if (focus) $("q").focus();
}

// ---------- очистка архива: период сообщений и выбор отдельных файлов ----------

let deleteConfirmResolve = null, deleteConfirmPreviousFocus = null;
function askDeleteConfirmation(message) {
  if (deleteConfirmResolve) return Promise.resolve(false);
  $("delete-confirm-text").textContent = message;
  $("delete-confirm-modal").style.display = "flex";
  deleteConfirmPreviousFocus = document.activeElement;
  $("delete-confirm-cancel").focus();
  return new Promise(resolve => { deleteConfirmResolve = resolve; });
}

function answerDeleteConfirm(yes) {
  if (!deleteConfirmResolve) return;
  const resolve = deleteConfirmResolve;
  deleteConfirmResolve = null;
  $("delete-confirm-modal").style.display = "none";
  deleteConfirmPreviousFocus?.focus();
  resolve(yes);
}

let cleanupChatsAccount = null;
let cleanupFiles = [];
let cleanupFileFetchSeq = 0, cleanupSearchTimer, catalogSearchTimer;
let cleanupPreviewSeq = 0;
let cleanupPreview = null;

function setCleanupAction(action) {
  if (action === 'catalog') { switchView('files'); return; }
  if (!['period', 'full', 'files'].includes(action)) return;
  const page = document.querySelector('.cleanup-page');
  page.dataset.action = action;
  for (const name of ['period', 'full', 'files']) {
    const selected = name === action;
    const tab = $(`cl-mode-${name}`);
    const panel = $(`cl-panel-${name}`);
    tab.classList.toggle('active', selected);
    tab.setAttribute('aria-selected', String(selected));
    tab.tabIndex = selected ? 0 : -1;
    panel.hidden = !selected;
    panel.classList.toggle('active', selected);
  }

}

function cleanupTabKeydown(event) {
  const order = ['period', 'full', 'files'];
  const current = document.querySelector('.cleanup-page').dataset.action;
  let index = order.indexOf(current);
  if (event.key === 'ArrowRight') index = (index + 1) % order.length;
  else if (event.key === 'ArrowLeft') index = (index + order.length - 1) % order.length;
  else if (event.key === 'Home') index = 0;
  else if (event.key === 'End') index = order.length - 1;
  else return;
  event.preventDefault();
  setCleanupAction(order[index]);
  $(`cl-mode-${order[index]}`).focus();
}

function cleanupFilters() {
  return {account_id: Number($("cl-account").value || 0), chat_id: Number($("cl-chat").value || 0),
          from: $("cl-from").value, to: $("cl-to").value};
}

function cleanupPeriodReady(filters = cleanupFilters()) {
  return filters.account_id > 0 && !!filters.from && !!filters.to && filters.from <= filters.to;
}

function cleanupPreviewParams(filters) {
  return new URLSearchParams({account_id: filters.account_id, chat_id: filters.chat_id,
    from_date: filters.from, to_date: filters.to});
}

async function updateCleanupPreview() {
  const seq = ++cleanupPreviewSeq;
  const filters = cleanupFilters();
  const preview = $("cl-preview");
  const deleteButton = $("cl-delete-messages");
  const showFilesButton = $("cl-show-files");
  cleanupPreview = null;
  deleteButton.disabled = true;
  showFilesButton.disabled = true;
  preview.className = "cleanup-preview";
  if (!filters.account_id || !filters.from || !filters.to) {
    preview.textContent = "Выбери период для очистки.";
    return;
  }
  if (filters.from > filters.to) {
    preview.textContent = "Начало периода позже его конца. Исправь даты.";
    preview.classList.add("err");
    return;
  }
  preview.textContent = "Считаю сообщения в выбранном периоде…";
  showFilesButton.disabled = false;
  try {
    const data = await j("/api/cleanup/preview?" + cleanupPreviewParams(filters));
    if (seq !== cleanupPreviewSeq) return;
    cleanupPreview = {...data, filters: {...filters}};
    if (data.messages) preview.classList.add("ready");
    preview.innerHTML = data.messages
      ? `В выбранный период попадёт <strong>${data.messages}</strong> ${pl(data.messages, "сообщение", "сообщения", "сообщений")}` +
        (data.files ? ` и ${data.files} ${pl(data.files, "файл", "файла", "файлов")}` : ".")
      : "В выбранном периоде сообщений нет.";
    deleteButton.disabled = !data.messages;
  } catch (e) {
    if (seq !== cleanupPreviewSeq) return;
    preview.textContent = "Не удалось посчитать сообщения. Удаление пока недоступно.";
    preview.classList.add("err");
  }
}

function refreshCleanupAccounts(preferredId) {
  const sel = $("cl-account");
  const previous = preferredId || Number(sel.value || 0);
  sel.innerHTML = accountList.filter(a => a.status !== "linking")
    .map(a => `<option value="${a.id}">${esc(accountLabel(a))} · ${a.n || 0} сообщ.</option>`).join("");
  if (!sel.options.length) {
    sel.innerHTML = `<option value="">Нет аккаунтов</option>`;
    $("cl-chat").innerHTML = `<option value="0">Все чаты аккаунта</option>`;
    updateFullCleanupControls();
    return;
  }
  sel.value = String(accountList.some(a => a.id === previous && a.status !== "linking")
    ? previous : Number(sel.options[0].value));
  loadCleanupChats();
}

async function loadCleanupChats() {
  const accountId = Number($("cl-account").value || 0);
  if (!accountId) return;
  const sel = $("cl-chat");
  const previousChat = cleanupChatsAccount === accountId ? sel.value : "0";
  sel.innerHTML = `<option value="0">Все чаты аккаунта</option>`;
  updateFullCleanupControls();
  cleanupChatsAccount = accountId;
  try {
    const chats = await j(`/api/cleanup/chats?account_id=${accountId}`);
    if (cleanupChatsAccount !== accountId) return;
    for (const c of chats) {
      const o = document.createElement("option");
      o.value = c.chat_id;
      o.textContent = `${chatLabel(c.title, c.type)} (${c.n})`;
      sel.appendChild(o);
    }
    if ([...sel.options].some(o => o.value === previousChat)) sel.value = previousChat;
    updateFullCleanupControls();
    updateCleanupPreview();
  } catch (e) { $("cl-status").textContent = "Не удалось загрузить список чатов."; }
}

async function runCleanup(el, mode) {
  const filters = cleanupFilters();
  if (mode === "delete" && !cleanupPeriodReady(filters)) {
    $("cl-status").textContent = "Чтобы удалить сообщения, укажи начало и конец периода.";
    return;
  }
  const chatName = $("cl-chat").selectedOptions[0]?.textContent || "все чаты";
  const accountName = accountList.find(a => a.id === filters.account_id);
  const scope = `${accountName ? accountLabel(accountName) : "аккаунт"} · ` +
    (filters.chat_id ? `чат «${chatName}»` : "все чаты") +
    (filters.from && filters.to ? ` · ${filters.from} — ${filters.to}` : "");
  if (!filters.account_id) { $("cl-status").textContent = "Сначала подключи аккаунт."; return; }
  if (mode === "delete") {
    let estimate;
    try { estimate = await j("/api/cleanup/preview?" + cleanupPreviewParams(filters)); }
    catch (e) { $("cl-status").textContent = "Не удалось проверить количество сообщений. Удаление не выполнено."; return; }
    if (!estimate.messages) { $("cl-status").textContent = "За выбранный период сообщений нет."; return; }
    const withMedia = $("cl-media").checked;
    const mediaText = withMedia ? ` Связанные файлы (${estimate.files}) тоже будут удалены.` : " Файлы останутся в хранилище.";
    if (!await askDeleteConfirmation(`«Да» переместит в локальную корзину TG Monitor ${estimate.messages} сообщений.\n\n${scope}.${mediaText}\n\nСообщения в Telegram не удалятся.`)) return;
  }
  if (mode === "restore" && !confirm(`Восстановить переписку для ${scope}?`)) return;
  btnBusy(el, true, mode === "delete" ? "Удаляю…" : "Восстанавливаю…");
  $("cl-status").textContent = "";
  try {
    const r = await j("/api/cleanup", {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({...filters, with_media: $("cl-media").checked, mode})});
    $("cl-status").textContent = mode === "delete"
      ? `В корзину перемещено сообщений: ${r.deleted}` + (r.files != null ? ` · удалено файлов: ${r.files}` : "") +
        (r.protected ? ` · общих файлов сохранено: ${r.protected}` : "") +
        (r.failed ? ` · файлов не удалось удалить: ${r.failed}` : "") + "."
      : r.sync_started ? `Восстановление из Telegram запущено${r.restored ? ` для ${r.restored} сообщений из корзины` : ""}.`
        : "Сообщений для восстановления в этом охвате нет.";
    loadAccounts(false);
    refreshCleanupAccounts(filters.account_id);
    if (mode === "delete" && $("cl-media").checked) loadCleanupFiles();
  } catch (e) { $("cl-status").textContent = "Не удалось выполнить очистку. Проверь соединение и попробуй ещё раз."; }
  btnBusy(el, false);
}

function updateFullCleanupControls(changed) {
  if (changed === "account" && $("cl-delete-account").checked) $("cl-clear-chat").checked = false;
  if (changed === "chat" && $("cl-clear-chat").checked) $("cl-delete-account").checked = false;
  const hasAccount = Number($("cl-account").value || 0) > 0;
  const hasChat = Number($("cl-chat").value || 0) !== 0;
  $("cl-delete-account").disabled = !hasAccount;
  $("cl-clear-chat").disabled = !hasAccount || !hasChat;
  if (!hasAccount) $("cl-delete-account").checked = false;
  if (!hasChat) $("cl-clear-chat").checked = false;
  $("cl-delete-full").disabled = !hasAccount ||
    !($("cl-delete-account").checked || ($("cl-clear-chat").checked && hasChat));
}

async function runFullCleanup(el) {
  const accountId = Number($("cl-account").value || 0);
  const chatId = Number($("cl-chat").value || 0);
  const scope = $("cl-delete-account").checked ? "account" :
    ($("cl-clear-chat").checked && chatId ? "chat" : "");
  if (!accountId || !scope) return;
  const account = accountList.find(a => a.id === accountId);
  const accountName = account ? accountLabel(account) : `аккаунт ${accountId}`;
  const chatName = $("cl-chat").selectedOptions[0]?.textContent || `чат ${chatId}`;
  let estimate;
  try {
    estimate = await j("/api/cleanup/full/preview?" +
      new URLSearchParams({scope, account_id: accountId, chat_id: scope === "chat" ? chatId : 0}));
  } catch (e) { $("cl-full-status").textContent = e.message || "Не удалось проверить данные."; return; }
  if (Number($("cl-account").value) !== accountId ||
      (scope === "chat" && Number($("cl-chat").value) !== chatId)) return;
  const counts = `${estimate.messages} сообщений, ${estimate.deleted} записей корзины` +
    ` и до ${estimate.files} связанных медиафайлов`;
  const consequences = scope === "account"
    ? `«Да» полностью удалит ${accountName} из TG Monitor: все его локальные чаты, ${counts}, сессию входа и историю событий. Запись этого аккаунта остановится. Сам Telegram-аккаунт и сообщения в Telegram останутся. Для нового подключения понадобится повторная авторизация.`
    : `«Да» очистит чат «${chatName}» аккаунта ${accountName}: ${counts} без ограничения по датам. Новые сообщения продолжат записываться; старая история не вернётся автоматически. Кнопка «Восстановить из Telegram» может загрузить её снова. Сообщения в Telegram останутся.`;
  if (!await askDeleteConfirmation(consequences)) return;
  btnBusy(el, true, "Удаляю…");
  $("cl-full-status").textContent = "";
  try {
    const r = await j("/api/cleanup/full", {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({scope, account_id: accountId, chat_id: scope === "chat" ? chatId : 0,
        confirmation: scope === "account" ? "DELETE_ACCOUNT" : "CLEAR_CHAT"})});
    $("cl-delete-account").checked = false;
    $("cl-clear-chat").checked = false;
    $("cl-full-status").textContent = (scope === "account" ? "Аккаунт удалён из TG Monitor." : "Чат очищен в TG Monitor.") +
      ` Удалено: ${r.messages} сообщений, ${r.deleted} записей корзины, ${r.files} файлов.` +
      (r.protected ? ` Общих файлов сохранено: ${r.protected}.` : "") +
      (r.failed ? ` Не удалось удалить файлов: ${r.failed}.` : "") +
      (r.session_failed ? ` Не удалось удалить файлов сессии: ${r.session_failed}.` : "");
    await loadAccounts(false);
    refreshCleanupAccounts(scope === "chat" ? accountId : undefined);
    resetCleanupFiles();
  } catch (e) { $("cl-full-status").textContent = `Удаление не выполнено: ${e.message || "ошибка сервера"}.`; }
  updateFullCleanupControls();
  btnBusy(el, false);
}

function formatBytes(n) {
  if (!n) return "";
  return n < 1e6 ? `${Math.max(1, Math.round(n / 1024))} КБ`
    : n < 1024 ** 3 ? `${(n / 1e6).toFixed(1)} МБ` : `${(n / 1024 ** 3).toFixed(2)} ГБ`;
}

function formatStorageBytes(value) {
  const bytes = Math.max(0, Number(value) || 0);
  if (bytes < 1024) return `${Math.round(bytes)} Б`;
  const units = ["КБ", "МБ", "ГБ", "ТБ", "ПБ"];
  let size = bytes / 1024, unit = 0;
  while (size >= 1024 && unit < units.length - 1) { size /= 1024; unit++; }
  return `${size.toFixed(size >= 100 ? 0 : size >= 10 ? 1 : 2)} ${units[unit]}`;
}

async function loadStorageStats(force = false) {
  const error = $("storage-error");
  error.hidden = true;
  try {
    const data = await j(`/api/storage${force ? "?force=1" : ""}`);
    const free = Number(data.disk_free_bytes) || 0;
    const archive = Number(data.archive_bytes) || 0;
    const percent = archive + free ? archive / (archive + free) * 100 : 0;
    $("storage-location").textContent = `Диск ${data.disk_root || "приложения"}`;

    $("storage-free").textContent = formatStorageBytes(free);
    const meter = document.querySelector(".storage-meter");
    meter.setAttribute("aria-valuenow", String(Math.round(percent)));
    meter.setAttribute("aria-valuetext", `${formatStorageBytes(archive)} занимает архив, ${formatStorageBytes(free)} свободно`);
    $("storage-meter-fill").style.width = `${percent}%`;
    $("storage-archive-total").textContent = formatStorageBytes(data.archive_bytes);
    $("storage-sql").textContent = formatStorageBytes((Number(data.database_bytes) || 0) + (Number(data.database_backups_bytes) || 0) + (Number(data.sessions_bytes) || 0));
    $("storage-media").textContent = formatStorageBytes(data.media_bytes);
    const warning = $("storage-warning");
    warning.hidden = !data.disk_warning_level;
    warning.className = `storage-warning ${data.disk_warning_level || ""}`;
    if (data.disk_warning_level) {
      const urgency = data.disk_warning_level === "critical" ? "Критически мало места" : "Мало свободного места";
      $("storage-warning-text").textContent = `${urgency}: осталось ${formatStorageBytes(free)} на диске ${data.disk_root || "приложения"}. Освободи место, чтобы архив продолжал сохранять файлы.`;
    }
  } catch (e) {
    error.textContent = `Не удалось получить размер хранилища: ${e.message || "ошибка сервера"}.`;
    error.hidden = false;
  }
}

function openStorageCleanup() {
  switchView("files");
}

let catalogFiles = [], catalogOffset = 0, catalogMore = false, catalogTotal = 0;
let catalogFetchSeq = 0, mediaActionBusy = 0;
const CATALOG_PAGE_SIZE = 100;
const MEDIA_LABEL = {document: "Документ", photo: "Фото", voice: "Голосовое", audio: "Аудио", video: "Видео"};

async function refreshPendingMediaCount() {
  try {
    const data = await j("/api/media/pending/count");
    const n = data.pending || 0;
    const badge = $("pending-approval-badge");
    badge.hidden = n === 0;
    badge.textContent = n ? String(n) : "";

  } catch (_) {}
}

async function loadMediaCatalog(reset = true) {
  const seq = ++catalogFetchSeq;
  if (reset) {
    catalogFiles = []; catalogOffset = 0; catalogMore = false;
    renderMediaCatalog(true);
  }
  const start = reset ? 0 : catalogOffset;
  $("media-load-more").disabled = true;
  const status = $("media-catalog-status");
  status.textContent = "Загружаю список файлов…";
  try {
    const qs = new URLSearchParams({sort: $("media-sort").value,
      direction: $("media-direction").value, offset: String(start), limit: CATALOG_PAGE_SIZE,
      q: $("media-search").value.trim(), pending_only: String($("media-filter").value === "pending")});
    const data = await j(`/api/media/catalog?${qs}`);
    if (seq !== catalogFetchSeq) return;
    catalogFiles = reset ? (data.items || []) : [...catalogFiles, ...(data.items || [])];
    catalogOffset = catalogFiles.length; catalogMore = data.more; catalogTotal = data.total;
    const pending = data.pending || 0;
    const badge = $("media-pending-count");
    badge.hidden = pending === 0;
    badge.textContent = pending ? `${pending} ждут решения` : "";

    status.textContent = catalogTotal
      ? `Файлы: ${catalogFiles.length} из ${catalogTotal}`
      : $("media-search").value.trim() ? "По запросу ничего не найдено."
      : $("media-filter").value === "pending" ? "Сейчас нет файлов, ожидающих решения."
      : "В базе пока нет медиафайлов.";
    renderMediaCatalog(reset, start);
  } catch (e) {
    if (seq === catalogFetchSeq) status.textContent = `Не удалось загрузить список: ${e.message || "ошибка сервера"}.`;
  } finally { if (seq === catalogFetchSeq) $("media-load-more").disabled = false; }
}

function renderMediaCatalog(replace = true, appendStart = 0) {
  const html = catalogFiles.slice(replace ? 0 : appendStart).map((f, localIndex) => {
    const index = replace ? localIndex : appendStart + localIndex;
    const inBin = f.record_state === "deleted";
    const fileOnDisk = !!f.file_path && (f.file_exists === true || f.partial_exists === true);
    const missingFile = !!f.file_path && f.file_exists === false && f.partial_exists !== true;
    const pending = (f.approval_status === "pending" || (inBin && !f.file_path &&
      (f.file_size || 0) > 1024 ** 3 && !["approved", "rejected"].includes(f.media_approval)))
      && !["unavailable", "dismissed"].includes(f.media_status);
    const rejected = f.approval_status === "rejected";
    const approved = f.approval_status === "approved";
    const dismissButton = `<button class="file-view-btn media-dismiss" data-media-action="dismiss" data-media-index="${index}" title="Убрать из списка" aria-label="Убрать файл из списка">×</button>`;
    const decision = missingFile && !["unavailable", "incomplete", "storage_full", "downloading"].includes(f.media_status) ? `<span class="media-decision missing">Файл отсутствует или неполный</span><div class="media-row-actions">${!inBin ? `<button class="btn" data-media-action="retry" data-media-index="${index}">Попробовать загрузить</button>` : ""}${dismissButton}</div>`
      : f.media_status === "unavailable" ? `<span class="media-decision missing">Файл удалён или недоступен в Telegram</span>${f.partial_exists ? `<small>Сохранена часть: ${formatStorageBytes(f.stored_size)} из ${formatStorageBytes(f.file_size)}</small>` : ""}${f.media_error ? `<small>${esc(f.media_error)}</small>` : ""}${dismissButton}`
      : f.media_status === "incomplete" ? `<span class="media-decision missing">${f.partial_exists ? "Загрузка не завершена" : "Файл отсутствует на диске"}</span>${f.partial_exists ? `<small>Сохранена часть: ${formatStorageBytes(f.stored_size)} из ${formatStorageBytes(f.file_size)}</small>` : ""}${f.media_error && f.media_error !== "Файл отсутствует или имеет неполный размер на диске." ? `<small>${esc(f.media_error)}</small>` : ""}<div class="media-row-actions">${!inBin ? `<button class="btn" data-media-action="retry" data-media-index="${index}">Повторить загрузку</button>` : ""}${dismissButton}</div>`
      : f.media_status === "storage_full" ? `<span class="media-decision pending">Не скачан: мало места на диске</span>${f.media_error ? `<small>${esc(f.media_error)}</small>` : ""}<div class="media-row-actions">${!inBin ? `<button class="btn" data-media-action="retry" data-media-index="${index}">Повторить</button>` : ""}${dismissButton}</div>`
      : f.media_status === "downloading" ? '<span class="media-decision">Идёт загрузка…</span>'
      : pending ? `<span class="media-decision pending">${inBin ? "В корзине · " : ""}Требуется решение · файл больше 1 ГБ</span>
        <div class="media-row-actions"><button class="btn media-approve" data-media-action="approve" data-media-index="${index}">Одобрить</button>
        <button class="btn" data-media-action="reject" data-media-index="${index}">Отклонить</button></div>`
      : rejected ? `<span class="media-decision rejected">${inBin ? "В корзине · " : ""}Загрузка отклонена</span><button class="btn media-approve" data-media-action="approve" data-media-index="${index}">Одобрить и скачать</button>`
      : approved && !f.file_path ? `<span class="media-decision">Одобрено · загрузка не завершена</span>
        <button class="btn media-approve" data-media-action="approve" data-media-index="${index}">Повторить загрузку</button>`
      : f.file_path ? (inBin ? `<span class="media-decision">В корзине</span>` : "")
      : inBin ? `<span class="media-decision">В корзине</span>`
      : `<span class="media-decision">Не скачан</span>`;
    return `<div class="cleanup-file media-catalog-row">
      <div class="cleanup-file-lbl"><input type="checkbox" class="media-catalog-check" data-index="${index}" aria-label="Выбрать файл ${esc(f.file_name || f.msg_id)}">
        <span class="cleanup-file-main"><b>${esc(f.file_name || f.media_type || "Файл")}</b>
          <span>${esc(MEDIA_LABEL[f.media_type] || "Файл")} · ${esc(f.chat_title || "Чат")} · ${esc(f.account_label || "Аккаунт")}</span>
          <span>${esc(fmtDate(f.date))}${f.file_size ? ` · ${formatBytes(f.file_size)}` : " · размер неизвестен"}</span>
          ${decision}</span>
      </div>
      <div class="media-row-links">${fileOnDisk ? `<button class="file-view-btn" data-action="reveal-file" data-file-path="/${esc(f.file_path)}" title="Показать файл в папке">В папке</button>` : ""}
        ${!inBin ? `<button class="file-view-btn" data-media-action="context" data-media-index="${index}" title="Открыть сообщение в переписке">Переписка</button>` : `<span class="media-bin-note">В корзине</span>`}</div>
    </div>`;
  }).join("");
  const list = $("media-catalog-list");
  if (replace) list.innerHTML = html;
  else list.insertAdjacentHTML("beforeend", html);
  $("media-load-more").hidden = !catalogMore;
  updateCatalogSelection();
}

function updateCatalogSelection() {
  const n = document.querySelectorAll(".media-catalog-check:checked").length;
  const hasItems = catalogFiles.length > 0;
  $("media-select-all").disabled = !hasItems;
  $("media-clear-selection").disabled = !n;
  $("media-clear-selection").hidden = !n;
  const del = $("media-delete-selected");
  del.hidden = !n;
  del.textContent = `Удалить выбранные файлы (${n})`;
}

function selectCatalogFiles(selected) {
  document.querySelectorAll(".media-catalog-check").forEach(el => { el.checked = selected; });
  updateCatalogSelection();
}

async function loadMoreMediaCatalog() { await loadMediaCatalog(false); }

async function approveMediaFile(index, decision) {
  const f = catalogFiles[index];
  if (!f) return;
  mediaActionBusy++;
  const btn = document.querySelector(`[data-media-index="${index}"][data-media-action="${decision}"]`);
  if (btn) btnBusy(btn, true, decision === "approve" ? "Проверяю…" : decision === "retry" ? "Загружаю…" : "Сохраняю…");
  try {
    const payload = {account_id: f.account_id, chat_id: f.chat_id, msg_id: f.msg_id, source: f.record_state};
    const r = decision === "dismiss"
      ? await j("/api/media/dismiss", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)})
      : await j(decision === "retry" ? "/api/media/retry" : "/api/media/approval", {method: "POST", headers: {"Content-Type": "application/json"},
          body: JSON.stringify({...payload, ...(decision === "retry" ? {} : {decision: decision === "approve" ? "approved" : "rejected"})})});
    toast(decision === "dismiss" ? "Запись убрана из списка" : decision === "retry" ? "Файл дозагружен" : decision === "approve" ? (r.downloaded ? "Файл подтверждён и сохранён" : "Решение сохранено") : "Файл отклонён");
    await loadMediaCatalog(true);
    refreshPendingMediaCount();
  } catch (e) {
    toast(e.message || "Не удалось выполнить действие", "err");
    await loadMediaCatalog(true);
    refreshPendingMediaCount();
  }
  finally { mediaActionBusy--; if (btn) btnBusy(btn, false); }
}

async function deleteCatalogFiles(el) {
  const chosen = [...document.querySelectorAll(".media-catalog-check:checked")]
    .map(cb => catalogFiles[Number(cb.dataset.index)]).filter(Boolean);
  if (!chosen.length) return;
  if (!await askDeleteConfirmation(`Удалить ${chosen.length} ${pl(chosen.length, "вложение", "вложения", "вложений")} из локального архива? Файлы будут удалены с диска. Текст сообщений сохранится.`)) return;
  mediaActionBusy++;
  btnBusy(el, true, "Удаляю…");
  const summary = {detached: 0, files: 0, failed: 0, protected: 0};
  try {
    const groups = new Map();
    for (const f of chosen) {
      if (!groups.has(f.account_id)) groups.set(f.account_id, []);
      groups.get(f.account_id).push({chat_id: f.chat_id, msg_id: f.msg_id, source: f.record_state});
    }
    for (const [account_id, items] of groups) {
      const result = await j("/api/media/delete", {method: "POST", headers: {"Content-Type": "application/json"},
        body: JSON.stringify({account_id, items})});
      for (const key of Object.keys(summary)) summary[key] += Number(result[key]) || 0;
    }
    toast(`Удалено вложений: ${summary.detached}` +
      (summary.failed ? ` · не удалось удалить с диска: ${summary.failed}` : "") +
      (summary.protected ? ` · общие файлы сохранены: ${summary.protected}` : ""), summary.failed ? "err" : "");
    loadStorageStats(true);
    await loadMediaCatalog(true);
  } catch (e) {
    toast(`Удалено вложений: ${summary.detached}. ${e.message || "Удаление остальных файлов не завершено"}`, "err");
    await loadMediaCatalog(true); loadStorageStats(true);
  }
  finally { mediaActionBusy--; btnBusy(el, false); }
}

async function openMediaContext(index) {
  const f = catalogFiles[index];
  if (!f) return;
  clearTimeout(mediaFocusTimer);
  document.querySelectorAll(".message-focus").forEach(row => row.classList.remove("message-focus"));
  await openChats(f.account_id, f.account_label);
  const chat = chatsForAccount.find(c => Number(c.chat_id) === Number(f.chat_id));
  await showFeed(f.chat_id, chat?.title || f.chat_title || "Чат", "", f.msg_id);
  const row = document.querySelector(`[data-message-id="${f.msg_id}"]`);
  if (row) {
    const attachment = row.querySelector(".ph, video, audio, .fchip, .att");
    (attachment || row).scrollIntoView({behavior: "smooth", block: "center"});
    row.classList.add("message-focus");
    mediaFocusTimer = setTimeout(() => row.classList.remove("message-focus"), 3000);
  }
}

async function loadCleanupFiles() {
  const filters = cleanupFilters();
  const status = $("cl-files-status");
  if (!filters.account_id) { status.textContent = "Сначала выбери аккаунт."; return false; }
  if (!filters.from || !filters.to) { status.textContent = "Чтобы просмотреть файлы, укажи обе даты."; return false; }
  if (filters.from > filters.to) { status.textContent = "Начальная дата позже конечной."; return false; }
  resetCleanupFiles("Загружаю список файлов…");
  const seq = cleanupFileFetchSeq;
  status.textContent = "Загружаю список файлов…";
  try {
    const qs = new URLSearchParams({account_id: filters.account_id, chat_id: filters.chat_id,
      from_date: filters.from, to_date: filters.to, limit: 500, q: $("cl-file-search").value.trim()});
    const data = await j(`/api/media?${qs}`);
    if (seq !== cleanupFileFetchSeq) return false;
    cleanupFiles = data.items || [];
    status.textContent = cleanupFiles.length
      ? `Найдено файлов: ${cleanupFiles.length}${data.more ? " · показаны первые 500, уточни фильтр для остальных" : ""}. Удаление необратимо.`
      : "Файлов с такими фильтрами не найдено.";
    $("cl-files").innerHTML = cleanupFiles.map((f, i) => `
      <div class="cleanup-file">
        <label class="cleanup-file-lbl"><input type="checkbox" class="cl-file-check" data-index="${i}">
          <span class="cleanup-file-main"><b>${esc(f.file_name || f.media_type || "Файл")}</b>
            <span>${esc(f.chat_title || "Чат")} · ${fmtDate(f.date)}${f.file_size ? " · " + formatBytes(f.file_size) : ""}</span>
            ${f.text ? `<small>${esc(f.text.slice(0, 140))}</small>` : ""}</span>
        </label>
        ${f.file_path ? `<button class="file-view-btn" data-action="reveal-file"
          data-file-path="/${esc(f.file_path)}" title="Открыть папку с файлом">${SVG_EYE}</button>` : ""}
      </div>`).join("");
    updateCleanupFileButton();
    return true;
  } catch (e) { if (seq !== cleanupFileFetchSeq) return false; cleanupFiles = []; updateCleanupFileButton(); status.textContent = "Не удалось получить список файлов."; return false; }
}

function selectCleanupFiles(selected) {
  if (!cleanupFiles.length) return;
  document.querySelectorAll(".cl-file-check").forEach(el => { el.checked = selected; });
  updateCleanupFileButton();
}

function resetCleanupFiles(message = "Фильтры изменились. Покажи список файлов ещё раз.") {
  ++cleanupFileFetchSeq;
  cleanupFiles = [];
  $("cl-files").innerHTML = "";
  $("cl-files-status").textContent = message;
  $("cl-delete-files").style.display = "none";
  $("cl-select-all").disabled = true;
  $("cl-clear-selection").disabled = true;
}

function updateCleanupFileButton() {
  const hasFiles = cleanupFiles.length > 0;
  $("cl-select-all").disabled = !hasFiles;
  $("cl-clear-selection").disabled = !hasFiles;
  const n = document.querySelectorAll(".cl-file-check:checked").length;
  const btn = $("cl-delete-files");
  btn.style.display = n ? "" : "none";
  btn.textContent = `Удалить выбранные файлы (${n})`;
}

async function deleteCleanupFiles(el) {
  const chosen = [...document.querySelectorAll(".cl-file-check:checked")]
    .map(cb => cleanupFiles[Number(cb.dataset.index)]).filter(Boolean);
  if (!chosen.length) return;
  if (!await askDeleteConfirmation(`«Да» безвозвратно удалит ${chosen.length} выбранных ${pl(chosen.length, "файл", "файла", "файлов")} из локального хранилища TG Monitor. Сообщения останутся в архиве, а сообщения и файлы в Telegram не изменятся.`)) return;
  btnBusy(el, true, "Удаляю…");
  try {
    const r = await j("/api/media/delete", {method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({account_id: cleanupFilters().account_id,
        items: chosen.map(f => ({chat_id: f.chat_id, msg_id: f.msg_id}))})});
    const summary = `Удалено файлов: ${r.files} · сообщений с отвязанным вложением: ${r.detached}` +
      (r.protected ? ` · общие файлы оставлены: ${r.protected}` : "") +
      (r.failed ? ` · файлы остались на диске из-за ошибки доступа: ${r.failed}` : "") + ". Сообщения сохранены.";
    resetCleanupFiles(summary);
    const refreshed = await loadCleanupFiles();
    $("cl-files-status").textContent = summary + (refreshed ? "" : " Список не удалось обновить.");
  } catch (e) { $("cl-files-status").textContent = `Не удалось удалить выбранные файлы: ${e.message || "ошибка сервера"}.`; }
  btnBusy(el, false);
}

// ---------- навигация ----------

function openGlobalSearch() {
  const panel = $("global-search-panel");
  if (!panel.classList.contains("is-open")) {
    searchReturnView = currentView === "search" ? searchReturnView
      : currentView === "chats" ? "accounts" : currentView;
    panel.classList.add("is-open");
    panel.setAttribute("aria-hidden", "false");
    $("search-toggle").setAttribute("aria-expanded", "true");
  }
  if (currentView !== "search") switchView("search");
  $("q").focus();
}

function closeGlobalSearch() {
  const panel = $("global-search-panel");
  panel.classList.remove("is-open");
  panel.setAttribute("aria-hidden", "true");
  $("search-toggle").setAttribute("aria-expanded", "false");
  clearSearch(false);
  const returnView = searchReturnView === "search" || searchReturnView === "chats" ? "accounts" : searchReturnView;
  if (currentView === "search") switchView(returnView);
  $("search-toggle").focus();
}

function toggleGlobalSearch() {
  if ($("global-search-panel").classList.contains("is-open")) closeGlobalSearch();
  else openGlobalSearch();
}

function returnFromChats() {
  if (chatReturnView === "search") {
    const origin = searchReturnView;
    openGlobalSearch();
    searchReturnView = origin;
    doSearch();
  } else switchView(chatReturnView);
}

function switchView(v) {
  if (v === "chats" && currentView !== "chats") {
    chatReturnView = currentView;
    const labels = {accounts: "аккаунты", archive: "архив", files: "файлы", search: "результаты поиска", cleanup: "очистка"};
    $("chats-back").textContent = "← " + (labels[chatReturnView] || "аккаунты");
  }
  if (["accounts", "archive", "files", "cleanup"].includes(v) && location.hash !== "#" + v) {
    history.pushState(null, "", "#" + v);
  }
  const searchPanel = $("global-search-panel");
  if (v !== "search" && searchPanel.classList.contains("is-open")) {
    searchPanel.classList.remove("is-open");
    searchPanel.setAttribute("aria-hidden", "true");
    $("search-toggle").setAttribute("aria-expanded", "false");
    if (v !== "chats") { clearSearch(false); searchReturnView = v; }
  }
  if (v !== currentView) window.scrollTo({top: 0, behavior: "instant"});
  currentView = v;
  if (v !== "search") searchRequestSeq++;
  if (v !== "chats") feedRequestSeq++;
  for (const s of ["accounts", "search", "archive", "chats", "cleanup", "files"])
    $("view-" + s).style.display = s === v ? "block" : "none";
  // в чатах страница превращается в полноэкранное «окно» (класс прячет главную панель)
  document.body.classList.toggle("in-chat", v === "chats");
  document.querySelectorAll(".tab").forEach(t =>
    { t.classList.toggle("active", t.dataset.view === v);
      if (t.dataset.view === v) t.setAttribute("aria-current", "page"); else t.removeAttribute("aria-current"); });
  $("search-toggle").classList.toggle("active", v === "search");
  if (v === "accounts" || v === "archive") loadAccounts();
  if (v === "files") loadMediaCatalog(true);
  if (v === "cleanup") {
    loadStorageStats();
    if (!accountList.length) loadAccounts(false).then(() => refreshCleanupAccounts());
    else refreshCleanupAccounts();
  }
}

// Dynamic Telegram data stays in escaped data attributes, never in executable
// inline handlers. The delegated listener also covers cards rendered later.
document.addEventListener("click", e => {
  const el = e.target.closest("[data-action]");
  if (!el) return;
  const {action} = el.dataset;
  if (action === "open-chats") {
    openChats(Number(el.dataset.accountId), el.dataset.accountName);
  } else if (action === "open-feed") {
    showFeed(Number(el.dataset.chatId), el.dataset.chatTitle);
  } else if (action === "reveal-file") {
    revealFile(el.dataset.filePath);
  } else if (action === "open-search-result") {
    openChats(Number(el.dataset.accountId), el.dataset.accountName).then(() =>
      showFeed(Number(el.dataset.chatId), el.dataset.chatTitle, el.dataset.searchQuery || ""));
  } else if (action === "open-chat-message-result") {
    currentAccount = Number(el.dataset.accountId);
    switchView("chats");
    showFeed(Number(el.dataset.chatId), el.dataset.chatTitle, el.dataset.searchQuery || "");
  }
});
document.addEventListener("click", e => {
  const el = e.target.closest("[data-media-action]");
  if (!el) return;
  const index = Number(el.dataset.mediaIndex);
  if (el.dataset.mediaAction === "context") openMediaContext(index);
  else approveMediaFile(index, el.dataset.mediaAction);
});

// ---------- запуск ----------

$("qr-img").onload = () => $("qr-img").classList.add("ready");
$("qr-modal").addEventListener("click", e => { if (e.target.id === "qr-modal") closeQr(); });
$("cl-account").addEventListener("change", () => { resetCleanupFiles(); loadCleanupChats(); });
$("cl-chat").addEventListener("change", () => { resetCleanupFiles(); updateCleanupPreview(); updateFullCleanupControls(); });
$("cl-delete-account").addEventListener("change", () => updateFullCleanupControls("account"));
$("cl-clear-chat").addEventListener("change", () => updateFullCleanupControls("chat"));
$("delete-confirm-modal").addEventListener("click", e => {
  if (e.target.id === "delete-confirm-modal") answerDeleteConfirm(false);
});
$("cl-from").addEventListener("change", () => { resetCleanupFiles("Укажи обе даты, затем снова покажи файлы."); updateCleanupPreview(); });
$("cl-to").addEventListener("change", () => { resetCleanupFiles("Укажи обе даты, затем снова покажи файлы."); updateCleanupPreview(); });
$("cl-files").addEventListener("change", updateCleanupFileButton);
$("media-catalog-list").addEventListener("change", updateCatalogSelection);
$("media-filter").addEventListener("change", () => loadMediaCatalog(true));
$("media-sort").addEventListener("change", () => { updateMediaSortLabels(); loadMediaCatalog(true); });
$("media-direction").addEventListener("change", () => loadMediaCatalog(true));
$("chat-q").addEventListener("keydown", e => {
  if (e.key === "Escape" && $("chat-q").value) clearChatsSearch();
});
$("feed").addEventListener("scroll", () => {
  if ($("feed").scrollTop < 80) loadOlderMessages();
});
document.addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
    if ($("qr-modal").style.display === "flex" || $("login-modal").style.display === "flex") return;
    e.preventDefault();
    openGlobalSearch();
  }
  if (e.key === "Escape") {
    if ($("delete-confirm-modal").style.display === "flex") answerDeleteConfirm(false);
    else if ($("qr-modal").style.display === "flex") closeQr();
    else if (currentView === "search" && $("q").value) clearSearch();
    else if (currentView === "search") closeGlobalSearch();
  }
});
$("q-account").addEventListener("change", doSearch);

loadAccounts().then(() => {
  refreshPendingMediaCount();
  loadStorageStats();
  const initialView = location.hash.slice(1);
  if (["cleanup", "files", "archive"].includes(initialView)) switchView(initialView);
});
setInterval(() => {          // тихое обновление: только когда список/архив видно, и без анимаций
  if ((currentView === "accounts" || currentView === "archive")
      && $("qr-modal").style.display !== "flex") loadAccounts(false);
}, 15000);
setInterval(() => {
  refreshPendingMediaCount();
  if (currentView === "files" && !mediaActionBusy && !document.querySelector(".media-catalog-check:checked")) loadMediaCatalog(true);
}, 30000);
setInterval(() => loadStorageStats(), 30000);

function updateMediaSortLabels() {
  const labels = {date: ["Сначала старые", "Сначала новые"], size: ["Сначала маленькие", "Сначала большие"], name: ["А → Я", "Я → А"]};
  for (const option of $("media-direction").options) option.textContent = labels[$("media-sort").value][option.value === "asc" ? 0 : 1];
}
updateMediaSortLabels();
document.addEventListener("keydown", e => {
  if (e.key !== "Tab") return;
  const modal = ["delete-confirm-modal", "qr-modal", "login-modal"].map($).find(m => m.style.display === "flex");
  if (!modal) return;
  const focusable = [...modal.querySelectorAll("button:not(:disabled), input:not(:disabled), select:not(:disabled), [tabindex='0']")].filter(el => el.getClientRects().length);
  const first = focusable[0], last = focusable.at(-1);
  if (!modal.contains(document.activeElement)) { e.preventDefault(); (e.shiftKey ? last : first)?.focus(); return; }
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); }
});

$("media-search").addEventListener("input", () => {
  clearTimeout(catalogSearchTimer);
  ++catalogFetchSeq;
  catalogFiles = []; catalogOffset = 0; catalogMore = false;
  renderMediaCatalog(true);
  $("media-catalog-status").textContent = "Ищу файлы…";
  catalogSearchTimer = setTimeout(() => loadMediaCatalog(true), 300);
});
$("cl-file-search").addEventListener("input", () => {
  clearTimeout(cleanupSearchTimer);
  resetCleanupFiles("Ищу файлы…");
  cleanupSearchTimer = setTimeout(loadCleanupFiles, 300);
});

window.addEventListener("popstate", () => {
  const view = location.hash.slice(1) || "accounts";
  if (["accounts", "archive", "files", "cleanup"].includes(view) && view !== currentView) switchView(view);
});

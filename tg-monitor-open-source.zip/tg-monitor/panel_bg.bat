@echo off
rem Start with the project-local Python environment, without machine-specific paths.
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_monitor.ps1" -NoBrowser >> "%~dp0run.log" 2>&1

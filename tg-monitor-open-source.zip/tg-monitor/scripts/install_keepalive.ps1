param([string]$TaskName)
# Optional restart on login and every five minutes, for the current Windows user.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$launcher = Join-Path $projectRoot 'panel_bg.bat'
if (-not $TaskName) {
    $hash = [Security.Cryptography.SHA256]::Create()
    try { $bytes = $hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($projectRoot.ToLowerInvariant())) }
    finally { $hash.Dispose() }
    $TaskName = 'TG_Monitor_' + [BitConverter]::ToString($bytes).Replace('-', '').Substring(0, 12)
}
if (-not (Test-Path -LiteralPath $launcher)) { throw 'panel_bg.bat not found' }
$action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument ('/d /c ""{0}""' -f $launcher) -WorkingDirectory $projectRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$repeat = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Seconds 0)
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger @($trigger, $repeat) -Settings $settings -Force | Out-Null
Start-ScheduledTask -TaskName $TaskName
Write-Output "TG Monitor scheduled task installed for the current user: $TaskName"

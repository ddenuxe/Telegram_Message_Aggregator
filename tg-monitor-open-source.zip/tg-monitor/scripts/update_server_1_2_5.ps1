# Dedicated updater for the existing inst-hub.space Windows installation.
# Downloads only the published release; never replaces the existing data directory.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = 'C:\Users\Administrator\Documents\tg-monitor'
$release = 'C:\ProgramData\TGMonitorReleases\1.2.5-verified-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
$watchdog = Join-Path $root 'scripts\server_keepalive.ps1'
$proxy = 'C:\ProgramData\TGMonitorProxy\Caddyfile'
$control = 'C:\ProgramData\TGMonitorOperations\control-token.txt'
$taskName = 'TGMonitor-KeepAlive'
$expectedArchiveSha = '9a6ac887189defb7cb068d946ef59ee5501cdb6f8282ce89061deede7b22e333'
$installation = '37df3171b591a32ab47b2014'
$baseUrl = 'https://github.com/ddenuxe/Telegram_Message_Aggregator/releases/download/v1.2.5'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run PowerShell as Administrator.' }
foreach ($path in @($watchdog,$proxy,$control,(Join-Path $root 'config.ini'),(Join-Path $root 'monitor.db'))) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Required existing file missing: $path" }
}
$task = Get-ScheduledTask -TaskName $taskName
if ($task.State -eq 'Disabled') { throw 'Keepalive was disabled before the update; investigate first.' }
$oldHealth = Invoke-RestMethod 'http://127.0.0.1:8090/api/health' -TimeoutSec 10
if (-not $oldHealth.ok -or $oldHealth.installation -ne $installation -or $oldHealth.version -ne '1.2.4') { throw 'Existing version/installation differs from the expected 1.2.4. No application stopped.' }
$oldWatchdog = Get-Content -LiteralPath $watchdog -Raw
$oldListener = Get-NetTCPConnection -State Listen -LocalPort 8090 | Select-Object -First 1
$oldExe = (Get-Process -Id $oldListener.OwningProcess).Path
if (-not $oldExe.StartsWith('C:\ProgramData\TGMonitorReleases\',[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($oldExe) -ne 'TG Monitor.exe') { throw 'Unexpected existing executable; no application stopped.' }
$newExe = Join-Path $release 'TGMonitor-Windows-x64\TG Monitor.exe'
if (-not $oldWatchdog.Contains($oldExe) -or -not (Test-Path -LiteralPath $oldExe)) { throw 'Unexpected keepalive executable. No application stopped.' }
$newWatchdog = $oldWatchdog.Replace($oldExe,$newExe)
$auditPython = @((Join-Path $root '.runtime\python\python.exe'),(Join-Path $root '.venv\Scripts\python.exe')) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (-not $auditPython) { throw 'Existing Python for read-only SQLite checks is missing. No application stopped.' }
function Read-TGDataState {
    $auditCode = @'
import sqlite3,json,sys,pathlib
p=pathlib.Path(sys.argv[1])/'monitor.db'
c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True,timeout=30)
result={'integrity':c.execute('PRAGMA quick_check').fetchone()[0],
        'messages':c.execute('SELECT COUNT(*) FROM messages WHERE chat_id != 777000').fetchone()[0],
        'accounts':c.execute("SELECT COUNT(*) FROM accounts WHERE status != 'linking'").fetchone()[0]}
c.close()
print(json.dumps(result))
'@
    $stateJson = $auditCode | & $auditPython - $root
    if ($LASTEXITCODE -ne 0) { throw 'Read-only SQLite audit failed.' }
    $state = $stateJson | ConvertFrom-Json
    if ($state.integrity -ne 'ok') { throw 'SQLite integrity check failed; no database replaced.' }
    return $state
}
$configHash = (Get-FileHash -LiteralPath (Join-Path $root 'config.ini')).Hash
$proxyHash = (Get-FileHash -LiteralPath $proxy).Hash
$token = (Get-Content -LiteralPath $control -Raw).Trim()
if (-not $token) { throw 'Existing shutdown token is missing.' }

# Stage and verify everything while the old application is still running.
if (Test-Path -LiteralPath $release) { throw 'Release directory already exists; do not overwrite an earlier attempt. Inspect it first.' }
New-Item -ItemType Directory -Path $release | Out-Null
$archive = Join-Path $release 'TGMonitor-Windows-x64.zip'
Invoke-WebRequest -UseBasicParsing -Uri ($baseUrl+'/TGMonitor-Windows-x64.zip') -OutFile $archive
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne $expectedArchiveSha) { throw 'Release checksum mismatch. Old application is still running.' }
Expand-Archive -LiteralPath $archive -DestinationPath $release
if (-not (Test-Path -LiteralPath $newExe -PathType Leaf)) { throw 'Release executable missing.' }
$forbidden = Get-ChildItem -LiteralPath (Join-Path $release 'TGMonitor-Windows-x64') -Recurse -File | Where-Object { $_.Name -in @('config.ini','app-defaults.ini') -or $_.Name -like 'monitor.db*' -or $_.Name -like '*.session*' }
if ($forbidden) { throw 'Release unexpectedly contains application data.' }

function Wait-TGHealth([string]$version) {
    $deadline = (Get-Date).AddSeconds(90)
    do {
        try {
            $result = Invoke-RestMethod 'http://127.0.0.1:8090/api/health' -TimeoutSec 3
            if ($result.ok -and $result.version -eq $version -and $result.installation -eq $installation) { return $result }
        } catch { }
        Start-Sleep -Seconds 2
    } while ((Get-Date) -lt $deadline)
    throw "Version $version did not become healthy."
}
function Stop-TGGracefully {
    $listener = Get-NetTCPConnection -State Listen -LocalPort 8090 -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $listener) { return }
    $appProcessId = $listener.OwningProcess
    $reply = Invoke-RestMethod 'http://127.0.0.1:8090/api/runtime/stop' -Method Post -Headers @{Authorization=('Bearer '+$token)} -TimeoutSec 10
    if (-not $reply.ok) { throw 'Application rejected graceful stop.' }
    $deadline = (Get-Date).AddSeconds(60)
    while (Get-Process -Id $appProcessId -ErrorAction SilentlyContinue) {
        if ((Get-Date) -gt $deadline) { throw 'Application is still stopping. No data replaced.' }
        Start-Sleep -Seconds 1
    }
}
$backup = 'C:\ProgramData\TGMonitorBackups\before-1.2.5-verified-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
New-Item -ItemType Directory -Path $backup | Out-Null
& icacls.exe $backup /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Could not protect the backup directory.' }
Export-ScheduledTask -TaskName $taskName | Set-Content -LiteralPath (Join-Path $backup 'task.xml') -Encoding Unicode
Copy-Item -LiteralPath $watchdog -Destination (Join-Path $backup 'server_keepalive.ps1')
$watchdogChanged = $false
try {
    Disable-ScheduledTask -TaskName $taskName | Out-Null
    Stop-TGGracefully
    Stop-ScheduledTask -TaskName $taskName
    if (Get-NetTCPConnection -State Listen -LocalPort 8090 -ErrorAction SilentlyContinue) { throw 'Another process is using the panel port.' }
    $beforeData = Read-TGDataState
    # The application is now closed, so database and sessions form a consistent backup.
    foreach ($name in @('config.ini','sessions')) {
        $path = Join-Path $root $name
        if (Test-Path -LiteralPath $path) { Copy-Item -LiteralPath $path -Destination $backup -Recurse }
    }
    Get-ChildItem -LiteralPath $root -Filter 'monitor.db*' -File | Copy-Item -Destination $backup
    # Media are not copied or replaced: record a manifest in the protected backup.
    Get-ChildItem -LiteralPath (Join-Path $root 'media') -Recurse -File | Select-Object FullName,Length,LastWriteTimeUtc | Export-Csv -LiteralPath (Join-Path $backup 'media-manifest.csv') -NoTypeInformation -Encoding UTF8
    if ((Get-FileHash -LiteralPath (Join-Path $root 'config.ini')).Hash -ne $configHash) { throw 'Config changed during staging; stopped before switching versions.' }
    Set-Content -LiteralPath $watchdog -Value $newWatchdog -Encoding UTF8
    $watchdogChanged = $true
    Enable-ScheduledTask -TaskName $taskName | Out-Null
    Start-ScheduledTask -TaskName $taskName
    $health = Wait-TGHealth '1.2.5'
    if ((Get-FileHash -LiteralPath (Join-Path $root 'config.ini')).Hash -ne $configHash -or (Get-FileHash -LiteralPath $proxy).Hash -ne $proxyHash) { throw 'Configuration hash changed.' }
    $ui = (Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8090/static/app.js?v=73' -TimeoutSec 10).Content
    if (-not $ui.Contains('catalog-file') -or -not $ui.Contains('/avatar?entity_id=') -or -not $ui.Contains('wait_until')) { throw 'New frontend verification failed.' }
    $listener = Get-NetTCPConnection -State Listen -LocalPort 8090 | Select-Object -First 1
    if ($listener.LocalAddress -ne '127.0.0.1') { throw 'Unexpected panel bind address.' }
    $processPath = (Get-Process -Id $listener.OwningProcess).Path
    if ($processPath -ne $newExe) { throw 'Unexpected application executable.' }
    $afterData = Read-TGDataState
    if ($afterData.messages -lt $beforeData.messages -or $afterData.accounts -ne $beforeData.accounts) { throw 'Archive counts changed unexpectedly; inspect the protected backup.' }
    $report = [ordered]@{ok=$true;health=$health;backup=$backup;executable=$processPath;configUnchanged=$true;proxyUnchanged=$true;mediaReplaced=$false;before=$beforeData;after=$afterData}
    $report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backup 'deployment.json') -Encoding UTF8
    $report | ConvertTo-Json -Depth 5
    Write-Host 'Update complete locally. External HTTPS panel still needs verification.'
} catch {
    $failure = $_.Exception.Message
    if ($watchdogChanged) {
        Disable-ScheduledTask -TaskName $taskName | Out-Null
        try {
            Stop-TGGracefully
            Stop-ScheduledTask -TaskName $taskName
            Set-Content -LiteralPath $watchdog -Value $oldWatchdog -Encoding UTF8
        } catch {
            throw ('Update failed: '+$failure+'. Rollback could not stop the new process safely: '+$_.Exception.Message+'. No data restored or deleted. Backup: '+$backup)
        }
    }
    Enable-ScheduledTask -TaskName $taskName | Out-Null
    Start-ScheduledTask -TaskName $taskName
    try { Wait-TGHealth '1.2.4' | Out-Null } catch { Write-Warning 'Old version restart needs inspection.' }
    throw ('Update failed: '+$failure+'. Data directory retained. Backup: '+$backup)
}



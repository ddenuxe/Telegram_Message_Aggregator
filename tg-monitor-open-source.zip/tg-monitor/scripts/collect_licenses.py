"""Collect original license texts from the exact installed build dependencies.

This developer utility does not access Telegram, credentials or archive data.
"""
import importlib.metadata as metadata
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parent.parent


def collect():
    output = ROOT / "third_party_licenses"
    output.mkdir(exist_ok=True)
    rows = []
    for requirements, scope in (("requirements.lock", "Runtime"), ("requirements-build.txt", "Build only")):
        for line in (ROOT / requirements).read_text(encoding="utf-8").splitlines():
            if not line.strip() or line.startswith("#"):
                continue
            name, version = line.strip().split("==", 1)
            dist = metadata.distribution(name)
            if dist.version != version:
                raise RuntimeError(f"{name}: expected {version}, installed {dist.version}")
            slug = re.sub(r"[^a-z0-9.-]", "-", name.lower())
            folder = output / slug
            folder.mkdir(exist_ok=True)
            texts = []
            for relative in dist.files or []:
                basename = Path(str(relative)).name.lower()
                if basename.startswith(("license", "copying", "notice", "authors")) and not basename.endswith((".py", ".pyc")):
                    original = Path(dist.locate_file(relative))
                    if original.is_file():
                        target = folder / original.name
                        shutil.copy2(original, target)
                        texts.append(target.relative_to(ROOT).as_posix())
            if not texts:
                raise RuntimeError(f"No original license text found for {name}")
            license_name = dist.metadata.get("License-Expression") or dist.metadata.get("License")
            if not license_name:
                license_name = "; ".join(c.removeprefix("License :: ") for c in dist.metadata.get_all("Classifier", []) if c.startswith("License ::"))
            license_name = str(license_name or "See original license").replace("\n", " ").replace("|", "/")
            links = ", ".join(f"[{Path(t).name}](../{t})" for t in sorted(set(texts)))
            rows.append(f"| {name} | {version} | {scope} | {license_name} | {links} |")
    python_root = Path(sys.base_prefix)
    shutil.copy2(python_root / "LICENSE.txt", output / "Python-LICENSE.txt")
    intro = """# Third-party components

TG Monitor's own code is licensed under MIT (LICENSE). The following components
retain their original licenses; MIT does not replace their terms. License texts
are copied from the pinned packages installed in the build environment.

The Windows bundle includes Python 3.14.6, Tcl/Tk, SQLite and OpenSSL.
Python's license and bundled notices: [Python](../third_party_licenses/Python-LICENSE.txt).
Other runtime notices: [Tcl](../third_party_licenses/Tcl-license.terms),
[Tk](../third_party_licenses/Tk-license.terms),
[SQLite](../third_party_licenses/SQLite.txt),
[OpenSSL](../third_party_licenses/OpenSSL-LICENSE.txt).
PyInstaller's license includes a bootloader distribution exception; retain its original text.
Build tools are listed for transparency and are not needed to run TG Monitor.

| Component | Version | Used for | License metadata | Original notices |
| --- | --- | --- | --- | --- |
"""
    (ROOT / "docs" / "THIRD_PARTY_NOTICES.md").write_text(intro + "\n".join(rows) + "\n", encoding="utf-8")
    print(f"Collected licenses for {len(rows)} pinned packages")


if __name__ == "__main__":
    collect()

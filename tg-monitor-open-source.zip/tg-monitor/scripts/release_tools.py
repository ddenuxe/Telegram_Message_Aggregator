"""Release helpers: split the Windows ZIP for transport and derive the next server updater.

The server updater has been verified in production; this tool never changes its
logic. It copies the previous updater and replaces only release-specific values:
versions, checksums, transport parts and the frontend cache key. Every replacement
must match exactly once, otherwise nothing is written.

    python scripts/release_tools.py split dist/publish-1.2.22/TGMonitor-Windows-x64.zip
    python scripts/release_tools.py updater --previous scripts/update_server_1_2_21.ps1 \
        --zip dist/publish-1.2.22/TGMonitor-Windows-x64.zip --accept-from 1.2.21
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1]
VERSION = re.compile(r"^\d+\.\d+\.\d+$")


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def source_version():
    text = (SOURCE / "app.py").read_text(encoding="utf-8")
    return re.search(r'^APP_VERSION = "([0-9.]+)"$', text, re.M).group(1)


def part_paths(archive):
    return sorted(archive.parent.glob(archive.name + ".part[0-9][0-9]"))


def split(archive, parts):
    archive = Path(archive).resolve()
    if not 1 <= parts <= 99:
        raise SystemExit("parts must be between 1 and 99")
    if part_paths(archive):
        raise SystemExit(f"Transport parts already exist next to {archive.name}; inspect them first.")
    data_size = archive.stat().st_size
    size = -(-data_size // parts)
    written = []
    with open(archive, "rb") as source:
        for number in range(1, parts + 1):
            chunk = source.read(size)
            if not chunk:
                break
            target = archive.with_name(f"{archive.name}.part{number:02d}")
            with open(target, "xb") as output:
                output.write(chunk)
            written.append(target)
    combined = hashlib.sha256()
    for path in written:
        combined.update(path.read_bytes())
    if combined.hexdigest().upper() != sha256(archive):
        raise SystemExit("Reassembled parts differ from the archive.")
    return {"archive": archive.name, "sha256": sha256(archive),
            "parts": [{"name": p.name, "sha256": sha256(p), "bytes": p.stat().st_size} for p in written]}


def replace_once(text, pattern, replacement, label):
    result, count = re.subn(pattern, lambda _match: replacement, text, flags=re.M)
    if count != 1:
        raise SystemExit(f"Previous updater: expected exactly one {label}, found {count}. Nothing written.")
    return result


def make_updater(previous, archive, version, accept_from, output=None):
    previous = Path(previous).resolve()
    archive = Path(archive).resolve()
    if not VERSION.match(version) or not all(VERSION.match(v) for v in accept_from):
        raise SystemExit("Versions must look like 1.2.22.")
    if version != source_version():
        raise SystemExit(f"app.py reports {source_version()}, not {version}.")
    if version in accept_from:
        raise SystemExit("The updater cannot accept its own target version as the old version.")
    # The version inside the EXE cannot be read here; a ZIP older than app.py is a
    # leftover build and would only be noticed on the server after stopping 1.2.x.
    if archive.stat().st_mtime < (SOURCE / "app.py").stat().st_mtime:
        raise SystemExit(f"{archive.name} is older than app.py; build and verify the EXE again.")
    old = re.search(r"TGMonitorReleases\\(\d+\.\d+\.\d+)-verified-", previous.read_text(encoding="utf-8-sig"))
    if not old:
        raise SystemExit("Previous updater has no release path.")
    old_version = old.group(1)
    parts = part_paths(archive)
    if not parts:
        raise SystemExit("No transport parts found; run the split command first.")
    combined = hashlib.sha256()
    for path in parts:
        combined.update(path.read_bytes())
    archive_sha = sha256(archive)
    if combined.hexdigest().upper() != archive_sha:
        raise SystemExit("Transport parts do not reassemble into the archive.")
    cache_key = re.search(r'/static/app\.js\?v=(\d+)', (SOURCE / "frontend" / "index.html").read_text(encoding="utf-8"))
    if not cache_key:
        raise SystemExit("frontend/index.html has no app.js cache key.")

    raw = previous.read_bytes()
    bom = raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig").replace("\r\n", "\n")
    esc = re.escape(old_version)
    text = replace_once(text, r"(?<=TGMonitorReleases\\)" + esc + r"(?=-verified-)", version, "release path")
    text = replace_once(text, r"(?<=TGMonitorBackups\\before-)" + esc + r"(?=-verified-)", version, "backup path")
    text = replace_once(text, r"(?<=/releases/download/v)" + esc + r"(?=')", version, "release URL")
    text = replace_once(text, r"(?<=Wait-TGHealth ')" + esc + r"(?=')", version, "health wait")
    text = replace_once(text, r"(?<=^\$expectedArchiveSha = ')[0-9A-F]{64}(?=')", archive_sha, "archive checksum")
    text = replace_once(text, r"(?<=/static/app\.js\?v=)\d+(?=')", cache_key.group(1), "frontend cache key")
    accepted = ",".join(f"'{v}'" for v in accept_from)
    names = " or ".join(accept_from)
    text = replace_once(
        text, r"^if \(-not \$oldHealth\.ok .*$",
        f"if (-not $oldHealth.ok -or $oldHealth.installation -ne $installation -or $oldHealth.version -notin @({accepted})) "
        f"{{ throw 'Existing version/installation differs from the expected {names}. No application stopped.' }}",
        "old version check")
    entries = ",\n".join(f"    @{{name='{p.name}';sha='{sha256(p)}'}}" for p in parts)
    text = replace_once(text, r"^\$transportParts = @\(\n(?:    @\{name='[^']+';sha='[0-9A-F]{64}'\},?\n)+\)$",
                        "$transportParts = @(\n" + entries + "\n)", "transport part list")
    leftovers = [line for line in text.splitlines() if old_version in line and "$oldHealth.version -notin" not in line]
    if leftovers:
        raise SystemExit("Old version still referenced:\n" + "\n".join(leftovers))

    target = Path(output) if output else SOURCE / "scripts" / f"update_server_{version.replace('.', '_')}.ps1"
    if target.exists():
        raise SystemExit(f"{target} already exists; a published updater is never replaced.")
    data = ("﻿" if bom else "") + text.replace("\n", "\r\n")
    with open(target, "x", encoding="utf-8", newline="") as result:
        result.write(data)
    return {"updater": str(target), "sha256": sha256(target), "version": version,
            "accepts": accept_from, "archive_sha256": archive_sha, "parts": len(parts)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    split_cmd = commands.add_parser("split", help="split the Windows ZIP into transport parts")
    split_cmd.add_argument("archive")
    split_cmd.add_argument("--parts", type=int, default=8)
    updater_cmd = commands.add_parser("updater", help="create the next server updater")
    updater_cmd.add_argument("--previous", required=True)
    updater_cmd.add_argument("--zip", required=True)
    updater_cmd.add_argument("--version", default=None, help="defaults to APP_VERSION in app.py")
    updater_cmd.add_argument("--accept-from", required=True, nargs="+",
                             help="versions that may be running on the server before the update")
    updater_cmd.add_argument("--output")
    args = parser.parse_args(argv)
    if args.command == "split":
        result = split(args.archive, args.parts)
    else:
        result = make_updater(args.previous, args.zip, args.version or source_version(),
                              args.accept_from, args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Compare panel queries on synthetic data in a disposable SQLite archive."""
import asyncio
import json
from pathlib import Path
import statistics
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tests'))
from test_reliable_ingest import ReliableIngestTests


async def main():
    fixture = ReliableIngestTests()
    await fixture.asyncSetUp()
    app = fixture.app
    try:
        with app.db() as c:
            c.executemany("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,?,?,'group')",
                          [(i, f'Chat {i}') for i in range(1, 101)])
            c.executemany('INSERT INTO messages(account_id,chat_id,msg_id,date,text) VALUES(1,?,?,?,?)',
                          [(chat, msg, f'2026-10-13T{msg % 24:02}:{msg % 60:02}:00', 'synthetic')
                           for chat in range(1, 101) for msg in range(1, 1001)])
            c.executemany("INSERT INTO events(account_id,time,kind) VALUES(?,?,'login')",
                          [(i % 50 + 1, '2026-10-13') for i in range(10000)])
            for name in ('idx_msg_account_date','idx_msg_chat_date','idx_events_account_id'):
                c.execute(f'DROP INDEX {name}')
        def measure():
            result = {}
            for name, function in [('accounts', app.api_accounts), ('chats', lambda: app.api_chats(1))]:
                samples = []
                for _ in range(7):
                    start = time.perf_counter()
                    function()
                    samples.append((time.perf_counter() - start) * 1000)
                result[name] = round(statistics.median(samples), 2)
            return result
        before = measure()
        app.init_db()
        after = measure()
        print(json.dumps({'synthetic_messages': 100000, 'chats': 100,
                          'before_ms': before, 'after_ms': after,
                          'speedup': {k: round(before[k] / max(after[k], 0.01), 2) for k in before}}, indent=2))
    finally:
        await fixture.asyncTearDown()


if __name__ == '__main__':
    asyncio.run(main())

"""Smoke-test the actual EXE after moving it, with a separate empty archive."""
import hashlib
import configparser
from contextlib import closing
import json
import os
from pathlib import Path
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request


def verify(bundle, first_run=False):
    with tempfile.TemporaryDirectory(prefix="tg-bundle-check-") as temp:
        root = Path(temp)
        moved = root / "Другая папка приложения"
        shutil.copytree(bundle, moved)
        home = moved / "data"
        home.mkdir()
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        if not first_run:
            (home / "config.ini").write_text("[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
                                            f"\n[server]\nhost=127.0.0.1\nport={port}\n", encoding="utf-8")
        token = "local-bundle-test-token"
        env = os.environ.copy()
        env["TG_MONITOR_CONTROL_TOKEN"] = token
        env["TG_MONITOR_PORT"] = str(port)
        if first_run:
            defaults_path=moved / "_internal" / "app-defaults.ini"
            defaults=configparser.ConfigParser(interpolation=None)
            defaults.read(defaults_path,encoding="utf-8")
            defaults["server"]={"port":str(port)}
            with defaults_path.open("w",encoding="utf-8") as output:
                defaults.write(output)
            env.pop("TG_MONITOR_PORT",None)
        env.pop("TG_MONITOR_HOME", None)
        # Default data location must follow the EXE, regardless of working directory.
        process = subprocess.Popen([str(moved / "TG Monitor.exe"), "--headless"], cwd=root,
                                   env=env, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        url = f"http://127.0.0.1:{port}"

        def get(path):
            with urllib.request.urlopen(url + path, timeout=2) as response:
                return response.read()

        try:
            deadline = time.monotonic() + 90
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError((home / "run.log").read_text(encoding="utf-8") if (home / "run.log").exists() else "EXE stopped before startup")
                try:
                    report = json.loads(get("/api/health"))
                    break
                except (urllib.error.URLError, TimeoutError):
                    time.sleep(.5)
            else:
                raise RuntimeError("EXE startup timed out")
            assert report["installation"] == hashlib.sha256(str(home).casefold().encode()).hexdigest()[:24]
            assert report["version"] == "1.2.18"
            assert report["crypto_backend"] == "cryptg"
            assert (home / "config.ini").is_file()
            assert json.loads(get("/api/accounts")) == []
            assert json.loads(get("/api/media/catalog"))["total"] == 0
            assert b'id="view-files"' in get("/")
            assert b"function switchView" in get("/static/app.js")
            assert b"--blue" in get("/static/style.css")
            assert json.loads(get("/api/storage"))["media_bytes"] == 0
            with closing(sqlite3.connect(home / "monitor.db")) as c:
                assert c.execute("PRAGMA quick_check").fetchone()[0] == "ok"
                assert c.execute("SELECT count(*) FROM accounts").fetchone()[0] == 0
                assert c.execute("SELECT COUNT(*) FROM history_pending").fetchone()[0] == 0
                assert "history_cursor" in {row[1] for row in c.execute("PRAGMA table_info(chats)")}
                assert "capture_order" in {row[1] for row in c.execute("PRAGMA table_info(messages)")}
            second = subprocess.Popen([str(moved / "TG Monitor.exe"), "--headless"],cwd=root,
                                      env=env,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            try:
                assert second.wait(timeout=20) != 0
                assert json.loads(get("/api/health"))["ok"]
            finally:
                if second.poll() is None:
                    second.terminate()
                    second.wait(timeout=10)
            # Exercise the frozen writer with synthetic receipts, without a Telegram connection.
            with closing(sqlite3.connect(home / "monitor.db")) as c:
                c.execute("INSERT INTO accounts(id,name,status) VALUES(1,'EXE smoke','paused')")
                c.commit()
            spool = home / "pending-ingest"
            spool.mkdir(exist_ok=True)
            receipt = spool / (("1" * 32) + ".json")
            temporary = receipt.with_suffix(".tmp")
            temporary.write_text(json.dumps(dict(account_id=1,chat_id=100,msg_id=1,
                date="2026-10-21T00:00:00+00:00",source_version="2026-10-21T00:00:00+00:00",
                capture_order=1,sender_id=None,out=0,text="Frozen writer receipt",title="EXE smoke",
                type="user",media_type=None,file_size=None,media_id=None,token="1"*32)),encoding="utf-8")
            temporary.replace(receipt)
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                accounts = json.loads(get("/api/accounts"))
                if accounts and accounts[0]["n"] == 1 and not receipt.exists():
                    break
                time.sleep(0.2)
            else:
                raise AssertionError("Frozen writer did not replay the synthetic receipt")
            # No anonymous control of the running application.
            try:
                urllib.request.urlopen(urllib.request.Request(url + "/api/runtime/stop", data=b""), timeout=2)
                raise AssertionError("Unauthenticated shutdown was accepted")
            except urllib.error.HTTPError as error:
                assert error.code == 403
            request = urllib.request.Request(url + "/api/runtime/stop", data=b"",
                                             headers={"Authorization": "Bearer " + token})
            with urllib.request.urlopen(request, timeout=2) as response:
                assert json.load(response)["ok"]
            assert process.wait(timeout=20) == 0
            assert (home / "media").is_dir() and (home / "sessions").is_dir()
            with closing(sqlite3.connect(home / "monitor.db")) as c:
                assert c.execute("PRAGMA quick_check").fetchone()[0] == "ok"
                assert c.execute("SELECT text FROM messages WHERE account_id=1").fetchone()[0] == "Frozen writer receipt"
            print("PASS: version 1.2.18, native cryptg, moved EXE, Unicode path, unrelated cwd, frozen writer replay, data after graceful exit, static UI, storage, second server blocked, protected control")
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=10)


if __name__ == "__main__":
    verify(Path(sys.argv[1]).resolve(), first_run="--first-run" in sys.argv[2:])

﻿param([switch]$SourceOnly, [string]$OutputName, [string]$BuildPython)
$ErrorActionPreference = 'Stop'
$source = Split-Path -Parent $PSScriptRoot
if (-not $OutputName) { $OutputName = 'tg-monitor-source-' + (Get-Date -Format 'yyyyMMdd-HHmmss') }
if ($OutputName -notmatch '^[A-Za-z0-9_-]+$') { throw 'OutputName must be a folder name, without path separators.' }
$target = Join-Path $source "dist\$OutputName"
if (Test-Path -LiteralPath $target) { throw "Output already exists: $target" }
$files = @('app.py','launcher.py','TGMonitor.spec','requirements.txt','requirements.lock',
    'requirements-build.txt','scripts/verify_bundle.py','TG Monitor.bat','config.example.ini','.gitignore','start_monitor.bat','start_monitor.ps1',
    'panel_bg.bat','scripts/install_keepalive.ps1','scripts/build_portable.ps1','README.md','docs/deploy.md','docs/AUDIT.md',
    'LICENSE','docs/CONTRIBUTING.md','docs/THIRD_PARTY_NOTICES.md','scripts/collect_licenses.py','.gitattributes')
New-Item -ItemType Directory -Path (Join-Path $target 'frontend') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $target 'tests') -Force | Out-Null
foreach ($file in $files) {
    New-Item -ItemType Directory -Path (Split-Path -Parent (Join-Path $target $file)) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $source $file) -Destination (Join-Path $target $file)
}
foreach ($file in @('index.html','app.js','style.css')) {
    Copy-Item -LiteralPath (Join-Path $source "frontend\$file") -Destination (Join-Path $target "frontend\$file")
}
Get-ChildItem -LiteralPath (Join-Path $source 'tests') -Filter 'test_*' | Where-Object { $_.Extension -in @('.py','.cjs') } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $target 'tests')
}
Copy-Item -LiteralPath (Join-Path $source 'third_party_licenses') -Destination $target -Recurse
Write-Output "Clean source package: $target"
if ($SourceOnly) { exit 0 }
$python = if ($BuildPython) { (Resolve-Path -LiteralPath $BuildPython).Path } else { Join-Path $source '.venv\Scripts\python.exe' }
if (-not (Test-Path -LiteralPath $python)) { throw 'Build needs .venv. Install requirements.lock and requirements-build.txt in it first.' }
$binary = Join-Path $source 'dist\TGMonitor-Windows-x64'
if (Test-Path -LiteralPath $binary) { throw "Binary output already exists: $binary. Rename it before rebuilding." }
Push-Location -LiteralPath $source
try {
    & $python -c 'import tkinter,sys; tkinter.Tcl(); sys.exit(0 if sys.maxsize>2**32 else 1)'
    if ($LASTEXITCODE -ne 0) { throw 'Build needs working Tcl/Tk and x64 Python. Check the build process can read its runtime resources.' }
    & $python -m PyInstaller --clean --noconfirm TGMonitor.spec
    if ($LASTEXITCODE -ne 0) { throw 'PyInstaller build failed.' }
    Copy-Item -LiteralPath (Join-Path $source 'README.md') -Destination $binary
    Copy-Item -LiteralPath (Join-Path $source 'docs') -Destination $binary -Recurse
    Copy-Item -LiteralPath (Join-Path $source 'config.example.ini') -Destination $binary
    Copy-Item -LiteralPath (Join-Path $source 'LICENSE') -Destination $binary
    Copy-Item -LiteralPath (Join-Path $source 'third_party_licenses') -Destination $binary -Recurse
    $zip = "$binary.zip"
    if (Test-Path -LiteralPath $zip) { throw "ZIP already exists: $zip" }
    Compress-Archive -LiteralPath $binary -DestinationPath $zip -CompressionLevel Optimal
    Get-FileHash -LiteralPath $zip -Algorithm SHA256 | Format-List
    Write-Output "Windows application: $zip"
} finally { Pop-Location }

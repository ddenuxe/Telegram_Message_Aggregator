# -*- coding: utf-8 -*-
"""
TG Monitor — мультисчётный архив Telegram с веб-панелью.

Один процесс держит все аккаунты (Telethon, отдельная сессия на аккаунт),
пишет всё в общую базу monitor.db, отдаёт веб-панель на http://host:port.

Подключение нового аккаунта: кнопка в панели -> QR -> телефон сканирует.
Запуск:  python app.py   (или start_monitor.bat)
"""
import asyncio
import configparser
import hashlib
import io
import json
import mimetypes
import os
import re
import secrets
import shutil
import sqlite3
import sys
import time
import unicodedata
from collections import OrderedDict
from datetime import date
from pathlib import Path

# On some Windows installations Python's MIME registry scan stalls for minutes.
# Telethon initializes mimetypes during import; the built-in MIME table is enough here.
if sys.platform == "win32":
    _read_registry = mimetypes.MimeTypes.read_windows_registry
    try:
        mimetypes.MimeTypes.read_windows_registry = lambda self, strict=True: None
        mimetypes.init()
    finally:
        mimetypes.MimeTypes.read_windows_registry = _read_registry

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response, FileResponse
from fastapi.staticfiles import StaticFiles
from telethon import TelegramClient, events
from telethon.errors import FloodWaitError, SessionPasswordNeededError, PasswordHashInvalidError
import qrcode

RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
DEFAULT_HOME = Path(sys.executable).resolve().parent / "data" if getattr(sys, "frozen", False) else RESOURCE_ROOT
BASE = Path(os.environ.get("TG_MONITOR_HOME", DEFAULT_HOME)).expanduser().resolve()
BASE.mkdir(parents=True, exist_ok=True)
_cfg = configparser.ConfigParser(interpolation=None)
if not _cfg.read(BASE / "config.ini", encoding="utf-8"):
    raise SystemExit("Не найден config.ini. Запустите start_monitor.bat для настройки.")
API_ID = _cfg.get("telegram", "api_id", fallback="").strip()
API_HASH = _cfg.get("telegram", "api_hash", fallback="").strip()
if not API_ID.isdecimal() or int(API_ID or 0) <= 0 or not re.fullmatch(r"[0-9a-fA-F]{32}", API_HASH):
    raise SystemExit("Укажите корректные Telegram api_id и api_hash в config.ini.")
HOST = _cfg.get("server", "host", fallback="127.0.0.1")
PORT = _cfg.getint("server", "port", fallback=8090)
MAX_MB = _cfg.getint("archive", "max_media_mb", fallback=1024)
LARGE_MEDIA_APPROVAL_BYTES = 1024 ** 3
MIN_FREE_MEDIA_SPACE_BYTES = 1024 ** 3
MAX_CONCURRENT_MEDIA_DOWNLOADS = 3
PANEL_PASSWORD = _cfg.get("security", "panel_password", fallback="").strip()

DB_PATH = BASE / "monitor.db"
SESSIONS = BASE / "sessions"; SESSIONS.mkdir(exist_ok=True)
MEDIA = BASE / "media"; MEDIA.mkdir(exist_ok=True)
FRONTEND = RESOURCE_ROOT / "frontend"

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

EXT_FALLBACK = {"photo": ".jpg", "voice": ".ogg", "video": ".mp4",
                "audio": ".mp3", "document": ".bin"}


# ---------- база ----------

from contextlib import contextmanager


@contextmanager
def db(timeout=30):
    """Соединение с авто-коммитом и гарантированным закрытием
    (штатный контекст sqlite3 не закрывает соединение — от него база локалась)."""
    c = sqlite3.connect(DB_PATH, timeout=timeout)
    c.row_factory = sqlite3.Row
    c.create_function("path_basename", 1, lambda value: Path(value).name if value else "")
    c.create_function("contains_fold", 2, lambda value, needle: int(str(needle).casefold() in str(value or "").casefold()), deterministic=True)
    try:
        yield c
        c.commit()
    finally:
        c.close()


def init_db():
    with db() as c:
        c.execute("PRAGMA journal_mode=WAL")   # один раз при старте, не на каждое соединение
        c.executescript("""
        CREATE TABLE IF NOT EXISTS accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_user_id INTEGER,
            name TEXT DEFAULT 'Новый аккаунт',
            username TEXT,
            phone TEXT,
            status TEXT DEFAULT 'linking',   -- linking|recording|paused|reconnecting|error
            added_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS chats(
            account_id INTEGER NOT NULL,
            chat_id INTEGER NOT NULL,
            title TEXT,
            type TEXT,
            max_msg_id INTEGER DEFAULT 0,
            min_msg_id INTEGER DEFAULT 0,
            deep_done INTEGER DEFAULT 0,
            clear_through_msg_id INTEGER DEFAULT 0,
            PRIMARY KEY(account_id, chat_id)
        );
        CREATE TABLE IF NOT EXISTS messages(
            account_id INTEGER NOT NULL,
            chat_id INTEGER NOT NULL,
            msg_id INTEGER NOT NULL,
            date TEXT,
            sender_id INTEGER,
            out INTEGER,
            text TEXT,
            media_type TEXT,
            file_path TEXT,
            file_size INTEGER,
            media_approval TEXT,
            media_id INTEGER,
            media_status TEXT,
            media_error TEXT,
            PRIMARY KEY(account_id, chat_id, msg_id)
        );
        CREATE TABLE IF NOT EXISTS participants(
            account_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            username TEXT,
            phone TEXT,
            display_name TEXT,
            title TEXT,
            kind TEXT,
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            PRIMARY KEY(account_id, user_id)
        );
        CREATE INDEX IF NOT EXISTS idx_participants_username
            ON participants(account_id, username);
        CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER,
            time TEXT,
            kind TEXT,     -- login | logout | revoked
            note TEXT
        );
        CREATE TABLE IF NOT EXISTS deleted(   -- «корзина»: удалённые вручную сообщения
            account_id INTEGER NOT NULL,      -- хранятся ЦЕЛИКОМ (текст, медиа-путь);
            chat_id INTEGER NOT NULL,         -- авто-догонка их обходит, «Восстановить»
            msg_id INTEGER NOT NULL,          -- возвращает из корзины + подтягивает из TG
            date TEXT,
            sender_id INTEGER,
            out INTEGER,
            text TEXT,
            media_type TEXT,
            file_path TEXT,
            file_size INTEGER,
            media_approval TEXT,
            media_id INTEGER,
            media_status TEXT,
            media_error TEXT,
            PRIMARY KEY(account_id, chat_id, msg_id)
        );
        CREATE INDEX IF NOT EXISTS idx_msg_date ON messages(date);
        CREATE INDEX IF NOT EXISTS idx_msg_account ON messages(account_id);
        CREATE TABLE IF NOT EXISTS archive_jobs(
            account_id INTEGER NOT NULL, chat_id INTEGER NOT NULL, msg_id INTEGER NOT NULL,
            token TEXT NOT NULL, payload TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
            next_attempt REAL NOT NULL DEFAULT 0, error TEXT,
            PRIMARY KEY(account_id,chat_id,msg_id)
        );
        CREATE INDEX IF NOT EXISTS idx_archive_jobs_due ON archive_jobs(next_attempt);
        """)
        # миграция старой базы: добавляем колонки инкрементальности, если их нет
        for col in ("min_msg_id INTEGER DEFAULT 0", "deep_done INTEGER DEFAULT 0",
                    "clear_through_msg_id INTEGER DEFAULT 0", "history_cursor INTEGER DEFAULT 0"):
            try:
                c.execute(f"ALTER TABLE chats ADD COLUMN {col}")
            except Exception:
                pass  # колонка уже есть
        for table in ("messages", "deleted"):
            cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
            if "media_approval" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_approval TEXT")
            if "media_id" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_id INTEGER")
            if "media_status" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_status TEXT")
            if "media_error" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_error TEXT")
        account_cols = [r[1] for r in c.execute("PRAGMA table_info(accounts)")]
        if "username" not in account_cols:
            c.execute("ALTER TABLE accounts ADD COLUMN username TEXT")
        # миграция старой версии корзины (без текста/медиа) — пересоздать, если пустая
        cols = [r[1] for r in c.execute("PRAGMA table_info(deleted)")]
        if len(cols) < 10 and not c.execute("SELECT COUNT(*) FROM deleted").fetchone()[0]:
            c.execute("DROP TABLE deleted")
            c.execute("""CREATE TABLE deleted(
                account_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
                msg_id INTEGER NOT NULL, date TEXT, sender_id INTEGER, out INTEGER,
                text TEXT, media_type TEXT, file_path TEXT, file_size INTEGER,
                PRIMARY KEY(account_id, chat_id, msg_id))""")
        if "media_approval" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_approval TEXT")
        if "media_id" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_id INTEGER")
        if "media_status" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_status TEXT")
        if "media_error" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_error TEXT")
        for table in ("messages", "deleted"):
            if "source_version" not in {r[1] for r in c.execute(f"PRAGMA table_info({table})")}:
                c.execute(f"ALTER TABLE {table} ADD COLUMN source_version TEXT")
            if "capture_order" not in {r[1] for r in c.execute(f"PRAGMA table_info({table})")}:
                c.execute(f"ALTER TABLE {table} ADD COLUMN capture_order INTEGER DEFAULT 0")
        c.execute("""CREATE TABLE IF NOT EXISTS media_suppression(
            account_id INTEGER NOT NULL,chat_id INTEGER NOT NULL,msg_id INTEGER NOT NULL,
            PRIMARY KEY(account_id,chat_id,msg_id))""")
        # (второй ряд с тем же tg_user_id база просто не примет)
        try:
            c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_accounts_tg"
                      " ON accounts(tg_user_id)")
        except Exception as e:
            print(f"[init] unique index на accounts.tg_user_id не создан: {e}")


def set_status(account_id, status, name=None, username=None, phone=None, tg_user_id=None):
    with db() as c:
        sets = ["status = ?"]
        vals = [status]
        if name is not None:
            sets.append("name = ?"); vals.append(name)
        if username is not None:
            sets.append("username = ?"); vals.append(username)
            ACCOUNT_DIRS.clear()
        if phone is not None:
            sets.append("phone = ?"); vals.append(phone)
            ACCOUNT_DIRS.clear()
        if tg_user_id is not None:
            sets.append("tg_user_id = ?"); vals.append(tg_user_id)
        vals.append(account_id)
        c.execute(f"UPDATE accounts SET {', '.join(sets)} WHERE id = ?", vals)
    if username is not None or phone is not None:
        ensure_account_dir(account_id)
        ensure_known_chat_dirs(account_id)


def restore_cached_identities():
    """Берёт уже известные Telegram usernames из локальных Telethon-сессий."""
    with db() as c:
        accounts = c.execute("SELECT id,tg_user_id,username,phone,name FROM accounts").fetchall()
    with db() as c:
        for account in accounts:
            session = SESSIONS / f"account_{account['id']}.session"
            if not session.exists() or not account["tg_user_id"]:
                continue
            try:
                uri = f"file:{session.as_posix()}?mode=ro"
                with sqlite3.connect(uri, uri=True, timeout=2) as cache:
                    cache.row_factory = sqlite3.Row
                    cols = {r[1] for r in cache.execute("PRAGMA table_info(entities)")}
                    if not {"id", "username", "phone", "name"} <= cols:
                        continue
                    me = cache.execute("SELECT username,phone,name FROM entities WHERE id=?",
                                      (account["tg_user_id"],)).fetchone()
                    if me:
                        c.execute("UPDATE accounts SET username=?, phone=?, name=? WHERE id=?",
                                  (me["username"] or account["username"] or "",
                                   ("+" + str(me["phone"])) if me["phone"] else account["phone"],
                                   me["name"] or account["name"], account["id"]))
                    entities = {r["id"]: r for r in cache.execute(
                        "SELECT id,username,phone,name FROM entities")}
                    for peer_id, ent in entities.items():
                        if not any((ent["username"], ent["phone"], ent["name"])):
                            continue
                        c.execute("""INSERT OR IGNORE INTO participants
                                     (account_id,user_id,username,phone,display_name)
                                     VALUES(?,?,?,?,?)""",
                                  (account["id"], peer_id, ent["username"],
                                   ("+" + str(ent["phone"])) if ent["phone"] else None,
                                   ent["name"]))
                    chats = c.execute("SELECT chat_id,title,type FROM chats WHERE account_id=?",
                                      (account["id"],)).fetchall()
                    for chat in chats:
                        ent = entities.get(chat["chat_id"])
                        if not ent:
                            continue
                        title = chat["title"] or ""
                        username = ent["username"]
                        if chat["type"] == "user":
                            identity = ("@" + username if username else
                                        ("+" + str(ent["phone"]) if ent["phone"] else "Неизвестно"))
                            display_name = ent["name"] or ""
                            updated = f"{display_name} ({identity})" if display_name and display_name != identity else identity
                        elif username:
                            base = re.sub(r"\s+\(@[^)]+\)$", "", title)
                            updated = f"{base} (@{username})"
                        else:
                            continue
                        if updated != title:
                            c.execute("UPDATE chats SET title=? WHERE account_id=? AND chat_id=?",
                                      (updated, account["id"], chat["chat_id"]))
            except (OSError, sqlite3.Error):
                continue
    ACCOUNT_DIRS.clear()


LOGGED = set()   # account_id с живой авторизацией в этом прогоне панели

def add_event(account_id, kind, note=""):
    """Журнал сеансов: подключение/отключение устройства, отзыв авторизации."""
    from datetime import datetime, timezone
    with db() as c:
        c.execute("INSERT INTO events(account_id, time, kind, note) VALUES(?,?,?,?)",
                  (account_id,
                   datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00"),
                   kind, note))


# ---------- сообщения и медиа ----------

def media_kind(m):
    if m.voice: return "voice"
    if m.video: return "video"
    if m.photo: return "photo"
    if m.audio: return "audio"
    if m.document: return "document"
    return None


SENDER_LOCKS = [asyncio.Lock() for _ in range(64)]
SENDER_RESOLVED = set()  # (account_id, sender_id) checked during this process
SENDER_LOOKUP_FAILED = set()  # retried by the historical author pass, not for every message
SENDER_PROFILE_CACHE = {}  # avoids one SQLite lookup for every message by the same author


def _participant_fields(sender):
    username = getattr(sender, "username", None) or None
    raw_phone = getattr(sender, "phone", None)
    phone = ("+" + str(raw_phone).lstrip("+") if raw_phone else None)
    first = (getattr(sender, "first_name", None) or "").strip()
    last = (getattr(sender, "last_name", None) or "").strip()
    display_name = " ".join(part for part in (first, last) if part) or None
    title = getattr(sender, "title", None) or None
    kind = "user" if hasattr(sender, "first_name") else ("chat" if title else None)
    return username, phone, display_name, title, kind


def _save_participant(account_id, sender_id, sender):
    username, phone, display_name, title, kind = _participant_fields(sender)
    if not any((username, phone, display_name, title)):
        return None
    with db() as c:
        c.execute("""INSERT INTO participants
                     (account_id,user_id,username,phone,display_name,title,kind,updated_at)
                     VALUES(?,?,?,?,?,?,?,datetime('now'))
                     ON CONFLICT(account_id,user_id) DO UPDATE SET
                     username=excluded.username, phone=excluded.phone,
                     display_name=excluded.display_name, title=excluded.title,
                     kind=excluded.kind, updated_at=datetime('now')""",
                  (account_id, sender_id, username, phone, display_name, title, kind))
        row = c.execute("SELECT * FROM participants WHERE account_id=? AND user_id=?",
                        (account_id, sender_id)).fetchone()
        return dict(row) if row else None


def participant_label(sender_id, profile):
    profile = profile or {}
    display_name = (profile.get("display_name") or "").strip()
    username = (profile.get("username") or "").strip().lstrip("@")
    phone = (profile.get("phone") or "").strip()
    title = (profile.get("title") or "").strip()
    identity = "@" + username if username else phone
    if display_name:
        return f"{display_name} ({identity})" if identity else display_name
    return identity or title or (f"Участник · {sender_id}" if sender_id is not None else "Участник")


async def cache_message_sender(client, account_id, msg):
    sender_id = getattr(msg, "sender_id", None)
    if sender_id is None:
        return None
    key = (account_id, sender_id)
    lock = SENDER_LOCKS[hash(key) % len(SENDER_LOCKS)]
    async with lock:
        if key in SENDER_RESOLVED:
            return SENDER_PROFILE_CACHE.get(key)
        if key in SENDER_LOOKUP_FAILED:
            return None
        profile = None
        try:
            sender = getattr(msg, "sender", None)
        except Exception:
            sender = None
        if sender is None:
            with db() as c:
                row = c.execute("SELECT * FROM participants WHERE account_id=? AND user_id=?",
                                key).fetchone()
            if row:
                profile = dict(row)
                SENDER_RESOLVED.add(key)
        else:
            profile = await write_call(_save_participant,account_id,sender_id,sender)
        if profile is None and key not in SENDER_RESOLVED:
            try:
                sender = await msg.get_sender()
            except Exception:
                sender = None
            if sender is not None:
                profile = await write_call(_save_participant,account_id,sender_id,sender)
        if profile:
            SENDER_RESOLVED.add(key)
            SENDER_LOOKUP_FAILED.discard(key)
        else:
            SENDER_LOOKUP_FAILED.add(key)
        SENDER_PROFILE_CACHE[key] = profile
        return profile


def should_scan_dialog(dialog):
    """Include private groups and megagroups, while leaving broadcast channels out."""
    return (getattr(dialog, "is_user", False) or getattr(dialog, "is_group", False)) \
        and not getattr(dialog.entity, "bot", False) \
        and dialog.id != SERVICE_CHAT


async def hydrate_chat_participants(client, account_id, chat_id):
    """Resolve distinct historical authors once, including messages already in the archive."""
    with db() as c:
        sender_ids = [r[0] for r in c.execute("""SELECT DISTINCT m.sender_id
                          FROM messages m LEFT JOIN participants p
                            ON p.account_id=m.account_id AND p.user_id=m.sender_id
                          WHERE m.account_id=? AND m.chat_id=? AND m.sender_id IS NOT NULL
                            AND p.user_id IS NULL""", (account_id, chat_id))]
    for sender_id in sender_ids:
        key = (account_id, sender_id)
        if key in SENDER_RESOLVED:
            continue
        lock = SENDER_LOCKS[hash(key) % len(SENDER_LOCKS)]
        async with lock:
            if key in SENDER_RESOLVED:
                continue
            try:
                sender = await client.get_entity(sender_id)
            except FloodWaitError:
                raise
            except Exception:
                sender = None
            if sender is not None:
                profile = _save_participant(account_id, sender_id, sender)
                if profile:
                    SENDER_RESOLVED.add(key)
                    SENDER_PROFILE_CACHE[key] = profile
                    SENDER_LOOKUP_FAILED.discard(key)
            # On a later backfill, failed lookups are retried if no profile was saved.
            else:
                SENDER_LOOKUP_FAILED.add(key)


def media_file_name(msg, ext, chat_type="user", sender_id=None, sender_username=None):
    """Stable date-based name; group media also records the sender's username or ID."""
    dt = msg.date.astimezone() if msg.date else None
    stamp = dt.strftime("%Y-%m-%d %H-%M") if dt else f"msg-{msg.id}"
    if chat_type == "group":
        author = "@" + sender_username if sender_username else (
            f"user-{sender_id}" if sender_id is not None else "unknown")
        return f"{stamp} [{_safe_name(author)}]"
    return f"{dt.strftime('%d-%m-%Y %H-%M') if dt else stamp} ({ext.lstrip('.')})"


def render_text(msg):
    """Текст сообщения + зашитые в слова ссылки в виде «слово(ссылка)».
    Обычные видимые ссылки и так остаются в тексте как есть."""
    from telethon.tl.types import MessageEntityTextUrl
    text = msg.message or ""
    links = [e for e in (msg.entities or []) if isinstance(e, MessageEntityTextUrl)]
    if not links:
        return text

    def to_py(off):                     # offsets у Telegram в UTF-16, у Python — символы
        i = u = 0
        for ch in text:
            if u >= off:
                return i
            u += 2 if ord(ch) > 0xFFFF else 1
            i += 1
        return len(text)

    for e in sorted(links, key=lambda e: -e.offset):   # с конца, чтобы не съезжали индексы
        s, t = to_py(e.offset), to_py(e.offset + e.length)
        word = text[s:t]
        text = text[:s] + f"{word}({e.url})" + text[t:]
    return text


SERVICE_CHAT = 777000   # служебный «Telegram» (коды входа и пр.) — не архивируем


def _safe_name(s):
    """Нормализует подпись до безопасного и стабильного имени Windows-папки."""
    s = unicodedata.normalize("NFC", s or "")
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", s).strip().rstrip(". ")
    s = s[:40].strip().rstrip(". ") or "без_названия"
    if s.split(".", 1)[0].upper() in {
        "CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }:
        s = "_" + s
    return s


ACCOUNT_DIRS = {}   # account_id -> папка вида "1_имя_аккаунта"


def account_dir(account_id):
    d = ACCOUNT_DIRS.get(account_id)
    if not d:
        with db() as c:
            r = c.execute("SELECT username, phone FROM accounts WHERE id=?", (account_id,)).fetchone()
        if r and r["username"]:
            label = "@" + r["username"].lstrip("@")
        elif r and r["phone"]:
            label = r["phone"]
        else:
            label = f"Неизвестный аккаунт {account_id}"
        safe_label = _safe_name(label)
        with db() as c:
            accounts = c.execute("SELECT id, username, phone FROM accounts WHERE id!=?", (account_id,)).fetchall()
        collision = False
        for other in accounts:
            if other["username"]:
                other_label = "@" + other["username"].lstrip("@")
            elif other["phone"]:
                other_label = other["phone"]
            else:
                other_label = f"Неизвестный аккаунт {other['id']}"
            if _safe_name(other_label).casefold() == safe_label.casefold():
                collision = True
                break
        d = f"{safe_label[:30]} ({account_id})" if collision else safe_label
        ACCOUNT_DIRS[account_id] = d
    return d


def ensure_account_dir(account_id):
    folder = MEDIA / account_dir(account_id)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def chat_dir_name(account_id, chat_id, title):
    label = _safe_name(title or "Неизвестный чат")
    with db() as c:
        others = c.execute("SELECT chat_id,title FROM chats WHERE account_id=? AND chat_id!=?",
                           (account_id, chat_id)).fetchall()
    duplicate = any(_safe_name(row["title"] or "Неизвестный чат").casefold() == label.casefold()
                    for row in others)
    return f"{label[:30]} ({chat_id})" if duplicate else label


def ensure_chat_dir(account_id, chat_id, title):
    folder = ensure_account_dir(account_id) / chat_dir_name(account_id, chat_id, title)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def ensure_known_chat_dirs(account_id=None):
    with db() as c:
        if account_id is None:
            chats = c.execute("SELECT account_id,chat_id,title FROM chats").fetchall()
        else:
            chats = c.execute("SELECT account_id,chat_id,title FROM chats WHERE account_id=?",
                              (account_id,)).fetchall()
    for chat in chats:
        ensure_chat_dir(chat["account_id"], chat["chat_id"], chat["title"])


def migrate_media_paths(account_id=None, only_chat_id=None):
    """Переносит медиа в папки с новыми понятными названиями и обновляет БД."""
    with db() as c:
        where = " WHERE a.id=?" if account_id is not None else ""
        args = (account_id,) if account_id is not None else ()
        rows = c.execute("""SELECT 'messages' AS source_table,m.account_id,m.chat_id,m.msg_id,
                                  m.file_path,ch.title,ch.type
                           FROM messages m JOIN accounts a ON a.id=m.account_id
                           JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id"""
                         + where, args).fetchall()
        deleted = c.execute("""SELECT 'deleted' AS source_table,m.account_id,m.chat_id,m.msg_id,
                                     m.file_path,ch.title,ch.type
                              FROM deleted m JOIN accounts a ON a.id=m.account_id
                              JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id"""
                            + where, args).fetchall()
    for r in [*rows, *deleted]:
        if only_chat_id is not None and r["chat_id"] != only_chat_id:
            continue
        old = r["file_path"]
        if not old:
            continue
        try:
            src = safe_media_path(old)
        except (ValueError, OSError):
            continue
        new = MEDIA / account_dir(r["account_id"]) / chat_dir_name(
            r["account_id"], r["chat_id"], r["title"])
        target_name = src.name
        if r["type"] == "group":
            source_stem, source_suffix = src.stem, src.suffix
            repeated_id = f" [{r['msg_id']}] [{r['msg_id']}]"
            if source_stem.endswith(repeated_id):
                target_name = source_stem[:-len(f" [{r['msg_id']}]")] + source_suffix
        dst = new / target_name
        if not src.is_file():
            # Завершает обновление БД после прерванного переноса, если файл уже на месте.
            if dst.is_file():
                rel = str(dst.relative_to(BASE)).replace("\\", "/")
                _update_media_path(r, old, rel)
            continue
        if src != dst:
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                # Никогда не затираем файл назначения.
                n = 2
                while True:
                    candidate = dst.with_name(f"{dst.stem} [{r['msg_id']}-{n}]{dst.suffix}")
                    if not candidate.exists():
                        dst = candidate
                        break
                    n += 1
            src.replace(dst)
        rel = str(dst.relative_to(BASE)).replace("\\", "/")
        if rel != old:
            if not _update_media_path(r, old, rel) and not src.exists():
                # Путь в БД изменился параллельно: откатываем перенос, если можем.
                src.parent.mkdir(parents=True, exist_ok=True)
                dst.replace(src)
    # Удаляем оставшиеся пустыми каталоги со старыми названиями; файлы не трогаем.
    for folder in sorted(MEDIA.rglob("*"), key=lambda p: len(p.parts), reverse=True):
        if folder.is_dir():
            try:
                folder.rmdir()
            except OSError:
                pass


def media_file_matches(stored_path, expected_size):
    """Only regard a media path as archived when its file matches Telegram's size."""
    try:
        path = safe_media_path(stored_path)
        if not path.is_file():
            return False
        return not expected_size or path.stat().st_size == expected_size
    except (OSError, ValueError):
        return False


def reset_incomplete_media_chats():
    """Queue chats for another history pass when their linked media is missing or truncated."""
    with db() as c:
        rows = c.execute("""SELECT m.account_id,m.chat_id,m.file_path,m.file_size
                            FROM messages m
                            WHERE m.media_type IS NOT NULL
                              AND COALESCE(m.media_status,'') NOT IN ('unavailable','dismissed')
                              AND (coalesce(m.file_size,0) <= ?
                                   OR (m.media_approval='approved' AND coalesce(m.file_size,0) > ?))""",
                         (MAX_MB * 1024 * 1024, MAX_MB * 1024 * 1024)).fetchall()
    affected = set()
    for row in rows:
        if not media_file_matches(row["file_path"], row["file_size"]):
            affected.add((row["account_id"], row["chat_id"]))
    if affected:
        with db() as c:
            c.executemany("""UPDATE chats SET min_msg_id=0,deep_done=0
                              WHERE account_id=? AND chat_id=?""", sorted(affected))
        print(f"[media-check] {len(affected)} чатов поставлено на восстановление медиа")
    return len(affected)


def incomplete_chat_media_count(account_id, chat_id):
    with db() as c:
        rows = c.execute("""SELECT file_path,file_size FROM messages
                        WHERE account_id=? AND chat_id=? AND media_type IS NOT NULL
                              AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed')
                              AND (coalesce(file_size,0) <= ?
                                   OR (media_approval='approved' AND coalesce(file_size,0) > ?))""",
                         (account_id, chat_id, MAX_MB * 1024 * 1024,
                          MAX_MB * 1024 * 1024)).fetchall()
    return sum(not media_file_matches(row["file_path"], row["file_size"]) for row in rows)


def _update_media_path(row, old, new):
    """Обновляет только исходную строку, не затрагивая одноимённое сообщение из другой таблицы."""
    with db() as c:
        cur = c.execute(
            f"UPDATE {row['source_table']} SET file_path=? WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path=?",
            (new, row["account_id"], row["chat_id"], row["msg_id"], old),
        )
        return cur.rowcount == 1


MESSAGE_LOCKS = [asyncio.Lock() for _ in range(64)]
MEDIA_DOWNLOAD_SEM = asyncio.Semaphore(MAX_CONCURRENT_MEDIA_DOWNLOADS)
DB_WRITE_LOCK = asyncio.Lock()
INGEST_QUEUE = None
INGEST_TASK = None
ARCHIVE_WORKERS = []
ARCHIVE_BUSY = set()
LIVE_MESSAGES = OrderedDict()
INGEST_ERRORS = {}
INGEST_SPOOL = BASE / "pending-ingest"


async def thread_call(func, *args):
    """Wait for a disk operation even on cancellation; never leave a late writer behind."""
    task = asyncio.create_task(asyncio.to_thread(func, *args))
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        await task
        raise


async def write_call(func, *args):
    async with DB_WRITE_LOCK:
        for attempt in range(3):
            try:
                return await thread_call(func, *args)
            except sqlite3.OperationalError:
                if attempt == 2:
                    raise
                await asyncio.sleep(0.2 * (attempt + 1))


def message_version(msg):
    dt = getattr(msg, "edit_date", None) or msg.date
    return dt.isoformat() if dt else ""


def live_snapshot(account_id, msg, chat_id, title, ctype):
    kind = media_kind(msg)
    file = getattr(msg, "file", None)
    try:
        sender = getattr(msg, "sender", None)
    except Exception:
        sender = None
    return dict(account_id=account_id, chat_id=chat_id, msg_id=msg.id,
                date=msg.date.isoformat() if msg.date else None,
                source_version=message_version(msg), capture_order=time.time_ns(), sender_id=msg.sender_id,
                out=int(bool(msg.out)), text=render_text(msg), title=title, type=ctype,
                media_type=kind, file_size=getattr(file, "size", None) if kind else None,
                media_id=getattr(file, "id", None) if kind else None,
                profile=list(_participant_fields(sender)) if sender is not None else None,
                token=secrets.token_hex(16))


def persist_live_batch(batch):
    """Commit text and its durable follow-up job together, with one transaction per batch."""
    accepted = []
    with db(timeout=1) as c:
        for s in batch:
            key = s["account_id"], s["chat_id"], s["msg_id"]
            account = c.execute("SELECT 1 FROM accounts WHERE id=?", key[:1]).fetchone()
            chat = c.execute("SELECT clear_through_msg_id FROM chats WHERE account_id=? AND chat_id=?", key[:2]).fetchone()
            deleted = c.execute("SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=?", key).fetchone()
            if not account or deleted or (chat and key[2] <= (chat[0] or 0)):
                accepted.append(False)
                continue
            previous = c.execute("SELECT media_type FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone()
            suppressed = c.execute("SELECT 1 FROM media_suppression WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone()
            s["process_media"] = bool(not suppressed and (s["media_type"] or (previous and previous[0])))
            if suppressed:
                s["media_type"] = s["file_size"] = s["media_id"] = None
            changed = c.execute("""INSERT INTO messages
                (account_id,chat_id,msg_id,date,sender_id,out,text,media_type,file_size,media_id,media_status,source_version,capture_order)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(account_id,chat_id,msg_id) DO UPDATE SET
                date=excluded.date,sender_id=excluded.sender_id,out=excluded.out,text=excluded.text,
                source_version=excluded.source_version,capture_order=excluded.capture_order
                WHERE COALESCE(messages.source_version,messages.date,'')<excluded.source_version
                OR (COALESCE(messages.source_version,messages.date,'')=excluded.source_version
                    AND COALESCE(messages.capture_order,0)<excluded.capture_order)""",
                (*key,s["date"],s["sender_id"],s["out"],s["text"],s["media_type"],
                 s["file_size"],s["media_id"],"queued" if s["media_type"] else None,s["source_version"],s.get("capture_order",0))).rowcount
            if not changed:
                accepted.append(False)
                continue
            c.execute("""INSERT INTO chats(account_id,chat_id,title,type,max_msg_id) VALUES(?,?,?,?,?)
                ON CONFLICT(account_id,chat_id) DO UPDATE SET
                title=CASE WHEN excluded.title!='?' THEN excluded.title ELSE chats.title END,
                type=excluded.type,max_msg_id=MAX(chats.max_msg_id,excluded.max_msg_id)""",
                (key[0],key[1],s["title"],s["type"],key[2]))
            profile = s.get("profile")
            if s["sender_id"] is not None and profile and any(profile[:4]):
                c.execute("""INSERT INTO participants
                    (account_id,user_id,username,phone,display_name,title,kind) VALUES(?,?,?,?,?,?,?)
                    ON CONFLICT(account_id,user_id) DO UPDATE SET
                    username=excluded.username,phone=excluded.phone,display_name=excluded.display_name,
                    title=excluded.title,kind=excluded.kind,updated_at=datetime('now')""",
                    (key[0],s["sender_id"],*profile))
            missing_profile = s["sender_id"] is not None and not c.execute(
                "SELECT 1 FROM participants WHERE account_id=? AND user_id=?", (key[0],s["sender_id"])).fetchone()
            if s["process_media"] or missing_profile:
                c.execute("""INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt)
                    VALUES(?,?,?,?,?,?) ON CONFLICT(account_id,chat_id,msg_id) DO UPDATE SET
                    token=excluded.token,payload=excluded.payload,attempts=0,next_attempt=excluded.next_attempt,error=NULL""",
                    (*key,s["token"],json.dumps(s,ensure_ascii=False),time.time()))
            else:
                c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?", key)
            accepted.append(True)
    return accepted


def spool_live_batch(batch):
    """Emergency receipt if SQLite is temporarily unavailable; replayed after restart."""
    INGEST_SPOOL.mkdir(exist_ok=True)
    for s in batch:
        path = INGEST_SPOOL / (s["token"] + ".json")
        tmp = path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        tmp.replace(path)


async def ingest_loop():
    while True:
        entries = [await INGEST_QUEUE.get()]
        await asyncio.sleep(0.01)  # amortize commits during simultaneous account updates
        while len(entries) < 100 and not INGEST_QUEUE.empty():
            entries.append(INGEST_QUEUE.get_nowait())
        batch = [s for s, _future in entries]
        error = None
        try:
            accepted = await write_call(persist_live_batch, batch)
            for s in batch:
                INGEST_ERRORS.pop(s["account_id"], None)
        except Exception as exc:
            accepted = [False] * len(batch)
            for s in batch:
                INGEST_ERRORS[s["account_id"]] = str(exc)[:200]
            try:
                await thread_call(spool_live_batch, batch)
            except Exception as spool_error:
                error = spool_error
            print(f"[ingest] SQL deferred: {type(exc).__name__}: {exc}")
        finally:
            for (_s, future), ok in zip(entries, accepted):
                if not future.done():
                    if error:
                        future.set_exception(error)
                    else:
                        future.set_result(ok)
                INGEST_QUEUE.task_done()


async def capture_live_message(client, account_id, msg, chat_id, title, ctype):
    """Fast durable receipt; downloads and profile lookups never delay text capture."""
    global INGEST_QUEUE, INGEST_TASK
    if chat_id == SERVICE_CHAT or getattr(msg, "action", None):
        return
    if INGEST_TASK is None or INGEST_TASK.done():
        INGEST_QUEUE = asyncio.Queue(maxsize=256)
        INGEST_TASK = asyncio.create_task(ingest_loop())
    snapshot = live_snapshot(account_id,msg,chat_id,title,ctype)
    future = asyncio.get_running_loop().create_future()
    await INGEST_QUEUE.put((snapshot,future))
    accepted = await asyncio.shield(future)
    if accepted:
        LIVE_MESSAGES[snapshot["token"]] = msg
        while len(LIVE_MESSAGES) > 256:
            LIVE_MESSAGES.popitem(last=False)


def next_archive_job():
    active = tuple(account_id for account_id,client in CLIENTS.items() if client.is_connected())
    if not active:
        return None
    with db(timeout=1) as c:
        c.execute("DELETE FROM archive_jobs WHERE account_id NOT IN (SELECT id FROM accounts)")
        rows = c.execute(f"""SELECT * FROM archive_jobs WHERE next_attempt<=?
            AND account_id IN ({','.join('?' for _ in active)})
            AND account_id IN (SELECT id FROM accounts WHERE status NOT IN ('paused','disconnected','linking'))
            ORDER BY next_attempt LIMIT 100""",
            (time.time(),*active)).fetchall()
    for row in rows:
        key = row["account_id"],row["chat_id"],row["msg_id"]
        if key not in ARCHIVE_BUSY:
            return dict(row)
    return None


def finish_archive_job(job, error=None):
    key = job["account_id"],job["chat_id"],job["msg_id"]
    with db(timeout=1) as c:
        if error is None:
            state = c.execute("SELECT media_status FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone()
            if state and state[0] in ("incomplete","storage_full","downloading"):
                error = "Вложение ещё не сохранено целиком"
        if error:
            delay = min(300, 5 * 2 ** min(job["attempts"],6))
            if isinstance(error,FloodWaitError):
                delay = max(delay,error.seconds+2)
            c.execute("""UPDATE archive_jobs SET attempts=attempts+1,next_attempt=?,error=?
                WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?""",
                (time.time()+delay,str(error)[:200],*key,job["token"]))
        else:
            c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?",(*key,job["token"]))


async def archive_job_worker():
    while True:
        job = None
        try:
            # Claim selection is serialized so two workers never process the same receipt.
            async with DB_WRITE_LOCK:
                job = await thread_call(next_archive_job)
                if job:
                    key = job["account_id"],job["chat_id"],job["msg_id"]
                    ARCHIVE_BUSY.add(key)
            if job is None:
                await asyncio.sleep(1)
                continue
            s = json.loads(job["payload"])
            client = CLIENTS.get(job["account_id"])
            if client is None or not client.is_connected():
                await asyncio.sleep(1)
                continue
            msg = LIVE_MESSAGES.get(job["token"])
            if msg is None:
                msg = await asyncio.wait_for(client.get_messages(job["chat_id"],ids=job["msg_id"]),45)
            if msg is not None:
                if s.get("process_media",s["media_type"]):
                    await asyncio.wait_for(store_message(client,job["account_id"],msg,job["chat_id"],
                        s["title"],s["type"],expected_job_token=job["token"]),BACKFILL_MESSAGE_TIMEOUT)
                else:
                    await cache_message_sender(client,job["account_id"],msg)
            else:
                def mark_unavailable():
                    with db(timeout=1) as c:
                        c.execute("""UPDATE messages SET media_status='unavailable',
                            media_error='Сообщение больше недоступно в Telegram.'
                            WHERE account_id=? AND chat_id=? AND msg_id=? AND media_type IS NOT NULL
                            AND EXISTS(SELECT 1 FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?)""",
                            (*key,*key,job["token"]))
                await write_call(mark_unavailable)
            await write_call(finish_archive_job,job)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"[archive-queue] {type(exc).__name__}: {exc}")
            if job:
                try:
                    await write_call(finish_archive_job,job,exc)
                except Exception:
                    pass  # durable receipt remains in SQL for the next attempt
            await asyncio.sleep(1)
        finally:
            if job:
                ARCHIVE_BUSY.discard((job["account_id"],job["chat_id"],job["msg_id"]))
                LIVE_MESSAGES.pop(job["token"],None)


def replay_ingest_spool():
    if not INGEST_SPOOL.is_dir():
        return
    paths = []
    for path in INGEST_SPOOL.glob("*.json"):
        paths.append(path)
        if len(paths) >= 100:
            break
    if not paths:
        return
    readable = []
    snapshots = []
    for path in paths:
        try:
            snapshot = json.loads(path.read_text(encoding="utf-8"))
            required = {"account_id","chat_id","msg_id","token","text","source_version",
                        "date","sender_id","out","title","type","media_type","file_size","media_id"}
            if not isinstance(snapshot,dict) or not required <= snapshot.keys():
                raise ValueError("Неверный формат сохранённого задания")
            for field in ("account_id", "chat_id", "msg_id"):
                if type(snapshot[field]) is not int:
                    raise ValueError("Неверный тип идентификатора")
            if snapshot["account_id"] <= 0 or snapshot["msg_id"] <= 0:
                raise ValueError("Неверный идентификатор")
            for field in ("token", "text", "source_version", "title", "type"):
                if not isinstance(snapshot[field],str):
                    raise ValueError("Неверный тип текстового поля")
            if type(snapshot.get("capture_order",0)) is not int:
                raise ValueError("Неверный порядок версии")
            profile = snapshot.get("profile")
            if profile is not None and (not isinstance(profile,list) or len(profile)!=5
                    or any(v is not None and not isinstance(v,str) for v in profile)):
                raise ValueError("Неверный профиль отправителя")
            for field in ("sender_id", "file_size", "media_id"):
                if snapshot[field] is not None and type(snapshot[field]) is not int:
                    raise ValueError("Неверный тип метаданных")
            if snapshot["date"] is not None and not isinstance(snapshot["date"],str):
                raise ValueError("Неверная дата")
            if type(snapshot["out"]) is not int or snapshot["out"] not in (0,1):
                raise ValueError("Неверное направление сообщения")
            if snapshot["media_type"] is not None and (not isinstance(snapshot["media_type"],str)
                    or snapshot["media_type"] not in EXT_FALLBACK):
                raise ValueError("Неверный тип медиа")
            snapshots.append(snapshot)
            readable.append(path)
        except (ValueError,OSError) as exc:
            print(f"[ingest-replay] damaged receipt {path.name}: {exc}")
            # A damaged receipt must not occupy the next batch's recovery slots.
            quarantine = INGEST_SPOOL / "quarantine"
            quarantine.mkdir(exist_ok=True)
            path.replace(quarantine / (path.stem + "-" + secrets.token_hex(4) + ".json"))
    if snapshots:
        persist_live_batch(snapshots)
        for snapshot in snapshots:
            INGEST_ERRORS.pop(snapshot["account_id"],None)
    for path in readable:
        path.unlink()


async def ingest_maintenance():
    while True:
        try:
            await write_call(replay_ingest_spool)
            with db() as c:
                active = {r[0] for r in c.execute("SELECT id FROM accounts WHERE status NOT IN ('paused','disconnected','linking')")}
            for account_id,state in list(BACKFILL.items()):
                if (account_id in active and state.get("state") in ("partial","error")
                        and state.get("retry_at",float("inf")) <= time.time()
                        and account_id in CLIENTS and CLIENTS[account_id].is_connected()):
                    start_backfill(account_id)
        except Exception as exc:
            print(f"[ingest-replay] {type(exc).__name__}: {exc}")
        await asyncio.sleep(5)


async def stop_ingest():
    global INGEST_TASK
    if INGEST_TASK and not INGEST_TASK.done():
        await INGEST_QUEUE.join()  # accepted updates are committed or spooled before exit
        INGEST_TASK.cancel()
        await asyncio.gather(INGEST_TASK,return_exceptions=True)
    INGEST_TASK = None


async def store_message(client, account_id, msg, chat_id, title, ctype, expected_job_token=None):
    """Пишет сообщение + скачивает медиа. Молча пропускает служебные
    и вручную удалённые (чтобы авто-догонка не возвращала почищенное)."""
    if chat_id == SERVICE_CHAT or getattr(msg, "action", None):
        return
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg.id)) % len(MESSAGE_LOCKS)]
    async with lock:
        await _store_message_locked(client, account_id, msg, chat_id, title, ctype, expected_job_token)


async def _store_message_locked(client, account_id, msg, chat_id, title, ctype, expected_job_token=None):
    def load_state():
        with db(timeout=1) as c:
            if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
                return False,None
            watermark = c.execute("SELECT clear_through_msg_id FROM chats WHERE account_id=? AND chat_id=?",
                                  (account_id,chat_id)).fetchone()
            in_bin = c.execute("SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=?",
                               (account_id,chat_id,msg.id)).fetchone()
            if in_bin or (watermark and msg.id <= (watermark[0] or 0)):
                return False,None
            previous = c.execute("SELECT * FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                                 (account_id,chat_id,msg.id)).fetchone()
            if previous and (previous["source_version"] or previous["date"] or "") > message_version(msg):
                return False,None
            return True,dict(previous) if previous else None
    allowed,previous = await thread_call(load_state)
    if not allowed:
        return
    key = account_id,chat_id,msg.id
    with db() as c:
        suppressed = bool(c.execute("SELECT 1 FROM media_suppression WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone())
        if expected_job_token is not None and not c.execute(
                "SELECT 1 FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?",
                (*key,expected_job_token)).fetchone():
            return
    sender_profile = await cache_message_sender(client, account_id, msg)
    kind = None if suppressed else media_kind(msg)
    fp = fs = None
    approval = None
    media_status = None
    media_error = None
    stale_media_path = None
    media_id = None
    pending_publish = None
    download_error = None
    def _persist_message_sync():
        """Persist the text and media state, rechecking concurrent cleanup before writing."""
        with db(timeout=1) as c:
            c.execute("BEGIN IMMEDIATE")
            if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
                return False
            watermark = c.execute("SELECT clear_through_msg_id FROM chats WHERE account_id=? AND chat_id=?",
                                  (account_id, chat_id)).fetchone()
            in_bin = c.execute("SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=?",
                               (account_id, chat_id, msg.id)).fetchone()
            if (watermark and msg.id <= (watermark[0] or 0)) or in_bin:
                return False
            version = c.execute("SELECT source_version,date,capture_order,text FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                                (account_id,chat_id,msg.id)).fetchone()
            if version and (version["source_version"] or version["date"] or "") > message_version(msg):
                return False
            if version and (version["capture_order"] or 0) != (previous["capture_order"] or 0 if previous else 0):
                return False
            now_suppressed = bool(c.execute("SELECT 1 FROM media_suppression WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone())
            if now_suppressed != suppressed:
                return False
            if expected_job_token is not None and not c.execute(
                    "SELECT 1 FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?",
                    (account_id,chat_id,msg.id,expected_job_token)).fetchone():
                return False
            # The SQL write lock protects the final generation check and publication.
            # Stale workers cannot promote a file before this generation check.
            if pending_publish:
                candidate_path,destination = pending_publish
                if candidate_path.is_file():
                    candidate_path.replace(destination)
                elif not destination.is_file() or (fs and destination.stat().st_size != fs):
                    raise OSError("Файл исчез до фиксации загрузки")
            saved_text = (version["text"] if version and
                (version["source_version"] or version["date"] or "") == message_version(msg)
                else render_text(msg))
            c.execute(
                "INSERT OR REPLACE INTO messages "
                "(account_id,chat_id,msg_id,date,sender_id,out,text,media_type,file_path,file_size,"
                "media_approval,media_id,media_status,media_error,source_version,capture_order) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (account_id, chat_id, msg.id,
                 msg.date.isoformat() if msg.date else None,
                 msg.sender_id, 1 if msg.out else 0, saved_text,
                 kind, fp, fs, approval, media_id, media_status, media_error,message_version(msg),
                 version["capture_order"] if version else 0))
            c.execute(
                """INSERT INTO chats (account_id, chat_id, title, type, max_msg_id)
                   VALUES (?,?,?,?,?)
                   ON CONFLICT(account_id, chat_id) DO UPDATE SET
                   title = CASE WHEN excluded.title != '?' THEN excluded.title ELSE chats.title END,
                   max_msg_id = MAX(chats.max_msg_id, excluded.max_msg_id)""",
                (account_id, chat_id, title, ctype, msg.id))
        return True

    def persist_message_sync():
        try:
            return _persist_message_sync()
        except Exception:
            # If SQL rolls back after promotion, restore the recoverable candidate.
            if pending_publish:
                candidate_path,destination = pending_publish
                if destination.is_file() and not candidate_path.exists():
                    with db() as c:
                        rel = str(destination.relative_to(BASE)).replace("\\", "/")
                        referenced = c.execute("SELECT 1 FROM messages WHERE file_path=? UNION ALL SELECT 1 FROM deleted WHERE file_path=? LIMIT 1",(rel,rel)).fetchone()
                    if not referenced:
                        destination.replace(candidate_path)
            raise

    async def persist_message():
        return await write_call(persist_message_sync)

    if kind:
        fs = msg.file.size if msg.file and msg.file.size else 0
        media_id = getattr(msg.file, "id", None) if msg.file else None
        same_media = bool(previous and previous["file_size"] == fs and
                          previous["media_type"] == kind and previous["media_id"] == media_id)
        if same_media:
            approval = previous["media_approval"]
            if previous["media_status"] == "dismissed":
                media_status = "dismissed"
                fp = previous["file_path"]
        elif previous and previous["file_path"]:
            stale_media_path = previous["file_path"]
        over_large_threshold = fs > LARGE_MEDIA_APPROVAL_BYTES
        if over_large_threshold and approval not in ("approved", "rejected"):
            approval = "pending"
        if media_status != "dismissed" and ((over_large_threshold and approval == "approved") or
                (not over_large_threshold and fs <= MAX_MB * 1024 * 1024)):
            ext = (msg.file.ext if msg.file and msg.file.ext else EXT_FALLBACK[kind])
            name = getattr(msg.file, "name", None) if msg.file else None
            if kind == "document" and name:      # настоящее расширение из имени файла
                dot = name.rfind(".")
                if 0 < dot and len(name) - dot <= 10:
                    ext = name[dot:]
            if not re.fullmatch(r"\.[A-Za-z0-9]{1,9}", ext or ""):
                ext = EXT_FALLBACK[kind]
            # Уже скачанный файл повторно не качаем; неполную часть держим отдельно
            # и сохраняем до успешной замены полной копией.
            previous_path = None
            if same_media and previous["file_path"]:
                try:
                    previous_path = safe_media_path(previous["file_path"])
                except (ValueError, OSError):
                    previous_path = None
            if previous_path and media_file_matches(previous["file_path"], fs):
                fp = previous["file_path"]
            else:
                folder = await thread_call(lambda: MEDIA / account_dir(account_id) / chat_dir_name(account_id,chat_id,title))
                base = media_file_name(msg, ext, ctype, msg.sender_id,
                                       sender_profile.get("username") if sender_profile else None)
                # ID сообщения стабилен внутри чата и исключает гонку за именем.
                preferred_target = folder / f"{base} [{msg.id}]{ext}"
                # Keep a legacy/incomplete path stable so older database rows
                # are repaired in place. New partials use a distinct suffix.
                if previous_path and not previous_path.name.endswith(".partial"):
                    target = previous_path
                    partial_target = previous_path
                else:
                    target = preferred_target
                    partial_target = (previous_path if previous_path else
                                      target.with_name(target.name + ".partial"))
                # First transfer streams straight into the stable partial path so
                # a process stop cannot orphan it. Retries use scratch space to
                # avoid overwriting a more complete partial until it improves.
                tmp = (partial_target if not partial_target.is_file() else
                       target.with_name(f".{target.name}.{secrets.token_hex(6)}.part"))
                media_status = "downloading"
                media_error = None
                # Save a stable partial path before starting. If the process exits,
                # the database still points to the recoverable part of this message.
                fp = str(partial_target.relative_to(BASE)).replace("\\", "/")
                if not await persist_message():
                    return
                candidate = tmp

                def preserve_partial():
                    """Keep the largest available partial file under a stable path."""
                    try:
                        if not candidate.is_file() or candidate.stat().st_size <= 0:
                            return partial_target if partial_target.is_file() else None
                        candidate_size = candidate.stat().st_size
                        existing_size = partial_target.stat().st_size if partial_target.is_file() else 0
                        if existing_size >= candidate_size:
                            if candidate != partial_target:
                                candidate.unlink(missing_ok=True)
                            return partial_target
                        if candidate.resolve() != partial_target.resolve():
                            candidate.replace(partial_target)
                        return partial_target
                    except OSError:
                        return partial_target if partial_target.is_file() else None

                try:
                    async with MEDIA_DOWNLOAD_SEM:
                        free = shutil.disk_usage(BASE).free
                        if free < MIN_FREE_MEDIA_SPACE_BYTES or (
                                fs and free - fs < MIN_FREE_MEDIA_SPACE_BYTES):
                            raise OSError(
                                f"Недостаточно места: свободно {free / 1024**3:.2f} ГБ; "
                                f"после загрузки нужно оставить не менее "
                                f"{MIN_FREE_MEDIA_SPACE_BYTES / 1024**3:.0f} ГБ")
                        target.parent.mkdir(parents=True, exist_ok=True)
                        downloaded = await msg.download_media(file=str(tmp))
                        candidate = Path(downloaded) if downloaded else tmp
                        if not candidate.is_file():
                            raise OSError("Telegram не вернул файл медиа")
                        actual_size = candidate.stat().st_size
                        if fs and actual_size != fs:
                            raise OSError(f"Неполный файл: получено {actual_size} из {fs} байт")
                        pending_publish = (candidate,target)
                        if previous_path and previous_path.name.endswith(".partial"):
                            stale_media_path = str(previous_path.relative_to(BASE)).replace("\\", "/")
                        media_status = None
                        fp = str(target.relative_to(BASE)).replace("\\", "/")
                except asyncio.CancelledError:
                    preserve_partial()
                    media_status = "incomplete"
                    media_error = "Загрузка прервана до завершения файла. Можно повторить позже."
                    fp = (str(partial_target.relative_to(BASE)).replace("\\", "/")
                          if partial_target.is_file() else None)
                    await persist_message()
                    raise
                except Exception as exc:
                    if isinstance(exc,FloodWaitError):
                        download_error = exc
                    media_status = "storage_full" if (str(exc).startswith("Недостаточно места") or
                        getattr(exc, "winerror", None) == 112 or getattr(exc, "errno", None) == 28) else "incomplete"
                    media_error = f"{type(exc).__name__}: {exc}"[:300]
                    preserve_partial()
                    fp = (str(partial_target.relative_to(BASE)).replace("\\", "/")
                          if partial_target.is_file() else None)
                    try:
                        if client is not None and client.is_connected():
                            still_exists = await client.get_messages(chat_id, ids=msg.id)
                            if still_exists is None:
                                media_status = "unavailable"
                                media_error = "Сообщение с файлом удалено или больше недоступно в Telegram."
                    except Exception:
                        pass
                finally:
                    if candidate != partial_target and not pending_publish:
                        tmp.unlink(missing_ok=True)
    elif previous and previous["file_path"]:
        stale_media_path = previous["file_path"]
    if not await persist_message():
        if pending_publish:
            rel = str(partial_target.relative_to(BASE)).replace("\\", "/")
            with db() as c:
                referenced = c.execute("SELECT 1 FROM messages WHERE file_path=? UNION ALL SELECT 1 FROM deleted WHERE file_path=? LIMIT 1",(rel,rel)).fetchone()
            if referenced:
                preserve_partial()
            else:
                candidate.unlink(missing_ok=True)
                partial_target.unlink(missing_ok=True)
        return
    if pending_publish and partial_target != target and partial_target.is_file():
        stale_media_path = str(partial_target.relative_to(BASE)).replace("\\", "/")
    if pending_publish:
        MEDIA_BYTES[account_id] = MEDIA_BYTES.get(account_id,0) + target.stat().st_size
    await thread_call(ensure_chat_dir,account_id,chat_id,title)
    if stale_media_path:
        with db() as c:
            refs = c.execute("""SELECT 1 FROM messages WHERE file_path=?
                                UNION ALL SELECT 1 FROM deleted WHERE file_path=? LIMIT 1""",
                             (stale_media_path, stale_media_path)).fetchone()
        if not refs:
            try:
                safe_media_path(stale_media_path).unlink(missing_ok=True)
            except (ValueError, OSError):
                pass

    if download_error is not None:
        raise download_error


def classify(ent):
    from telethon.tl.types import Channel, Chat
    if isinstance(ent, Channel):
        kind = "group" if ent.megagroup else "channel"
        title = getattr(ent, "title", None) or "Неизвестный чат"
        username = getattr(ent, "username", None)
        return kind, f"{title} (@{username})" if username else title
    if isinstance(ent, Chat):
        return "group", (getattr(ent, "title", None) or "Неизвестный чат")
    name = " ".join(p for p in (getattr(ent, "first_name", None),
                                getattr(ent, "last_name", None)) if p).strip()
    username = getattr(ent, "username", None)
    phone = getattr(ent, "phone", None)
    identity = "@" + username if username else ("+" + phone if phone else "Неизвестно")
    return "user", f"{name} ({identity})" if name else identity


# ---------- запись одного аккаунта ----------

REC = {}      # account_id -> {"task": asyncio.Task}
FLOWS = {}    # fid -> {"client", "qr", "state", "account_id"}
CLIENTS = {}  # account_id -> TelegramClient (один клиент на аккаунт)
BACKFILL = {} # account_id -> {"task", "state", "total", "done", "msgs", "bytes", "note"}
MEDIA_BYTES = {}  # account_id -> скачано медиа за текущий прогон истории (байт)


async def recorder(account_id, client=None):
    """Живёт, пока аккаунт подключён: ловит новые сообщения и пишет их."""
    if client is None:
        client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                                int(API_ID), API_HASH, catch_up=True)
    CLIENTS[account_id] = client
    while True:
        on_new = None
        try:
            with db() as c:
                chat_info = {row["chat_id"]: (row["type"], row["title"])
                             for row in c.execute(
                                 "SELECT chat_id,type,title FROM chats WHERE account_id=?",
                                 (account_id,)).fetchall()}

            async def on_new(ev):
                try:
                    info = chat_info.get(ev.chat_id)
                    if info is None:
                        entity = getattr(ev,"chat",None)
                        if entity is not None:
                            if getattr(entity,"bot",False):
                                return
                            kind,title = classify(entity)
                        else:
                            if ev.is_channel and not ev.is_group:
                                return
                            kind,title = ("group" if ev.is_group else "user"),"?"
                        info = chat_info[ev.chat_id] = (kind, title)
                    kind, title = info
                    if kind == "channel":
                        return
                    await capture_live_message(client, account_id, ev.message,
                                               ev.chat_id, title, kind)
                except Exception as e:
                    print(f"[acct {account_id}] {type(e).__name__}: {e}")

            client.add_event_handler(on_new, events.NewMessage())
            client.add_event_handler(on_new, events.MessageEdited())
            await client.connect()
            if not await client.is_user_authorized():
                # авторизации нет: ключ отозван (сеанс завершён из Telegram) или умер
                if account_id in LOGGED:
                    LOGGED.discard(account_id)
                    add_event(account_id, "revoked", "сеанс завершён из Telegram")
                elif (SESSIONS / f"account_{account_id}.session").exists():
                    add_event(account_id, "revoked", "авторизация недействительна")
                set_status(account_id, "error")
                CLIENTS.pop(account_id, None)
                return
            me = await client.get_me()
            # этот аккаунт уже есть в панели (отключён / на паузе / ошибка / дубль)?
            # продолжаем его архив под старым id — догонка пойдёт от последнего сообщения
            with db() as c:
                old = c.execute("""SELECT id FROM accounts
                                   WHERE tg_user_id=? AND id!=?""",
                                (me.id, account_id)).fetchone()
            if old:
                old_id = old["id"]
                try:
                    await client.disconnect()
                except Exception:
                    pass
                CLIENTS.pop(account_id, None)
                stop_recorder(old_id)         # если старый вариант ещё писал — глушим
                moved = False
                for _ in range(3):            # файлы могут отпустить не сразу
                    try:
                        dst = SESSIONS / f"account_{old_id}.session"
                        dst.unlink(missing_ok=True)   # старый ключ заменяем свежим
                        (SESSIONS / f"account_{account_id}.session").rename(dst)
                        moved = True
                        break
                    except OSError:
                        await asyncio.sleep(1)
                if not moved:
                    # сессию не удалось перенести на старый id — обрываем вход начисто,
                    # иначе тот же аккаунт запишется под новым id и задублирует архив
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                    CLIENTS.pop(account_id, None)
                    (SESSIONS / f"account_{account_id}.session").unlink(missing_ok=True)
                    with db() as c:
                        c.execute("DELETE FROM accounts WHERE id=?", (account_id,))
                    print(f"[acct {account_id}] перенос сессии на id {old_id} не удался — "
                          f"вход прерван, чтобы не задублировать архив")
                    return
                if moved:
                    with db() as c:
                        c.execute("DELETE FROM accounts WHERE id=?", (account_id,))
                    account_id = old_id
                set_status(account_id, "recording", name=" ".join(
                               p for p in (me.first_name, me.last_name) if p),
                           username=getattr(me, "username", None) or "",
                           phone="+" + str(me.phone) if getattr(me, "phone", None) else None,
                           tg_user_id=me.id)
                await asyncio.to_thread(migrate_media_paths, account_id)
                start_recorder(account_id)    # свежий клиент на старом session-файле
                return
            set_status(account_id, "recording", name=" ".join(
                           p for p in (me.first_name, me.last_name) if p),
                       username=getattr(me, "username", None) or "",
                       phone="+" + str(me.phone) if getattr(me, "phone", None) else None,
                       tg_user_id=me.id)
            await asyncio.to_thread(migrate_media_paths, account_id)
            if account_id not in LOGGED:      # устройство появилось в активных сеансах ТГ
                LOGGED.add(account_id)
                add_event(account_id, "login", "устройство подключилось")
            # при каждом (пере)подключении тихо догоняем всё, что случилось без нас:
            # пауза, обрыв связи, упавшая панель — окно пропуска закрывается само
            start_backfill(account_id)
            await client.catch_up()
            await client.run_until_disconnected()
            set_status(account_id, "reconnecting")
        except Exception as e:
            print(f"[acct {account_id}] rec error: {type(e).__name__}: {e}")
            set_status(account_id, "reconnecting")
        finally:
            if on_new is not None:
                client.remove_event_handler(on_new)
        await asyncio.sleep(10)


def stop_recorder(account_id):
    """Останавливает запись И отключает клиент — иначе после пауз плодились
    зомби-соединения на одну сессию, и Telegram мог слать события не тому клиенту."""
    rec = REC.pop(account_id, None)
    cl = CLIENTS.pop(account_id, None)
    if rec:
        rec["task"].cancel()
    if cl is not None:
        async def _disc():
            try:
                await cl.disconnect()
            except Exception:
                pass
        try:
            asyncio.get_running_loop().create_task(_disc())
        except RuntimeError:
            pass


def start_recorder(account_id, client=None):
    if account_id in REC:
        return
    entry = {"task": asyncio.create_task(recorder(account_id, client))}
    REC[account_id] = entry
    def clear_finished(done):
        if REC.get(account_id) is entry:
            REC.pop(account_id, None)
    entry["task"].add_done_callback(clear_finished)


# ---------- подключение по QR ----------

async def start_flow():
    with db() as c:
        account_id = c.execute(
            "INSERT INTO accounts(name, status) VALUES('Ожидает скана QR', 'linking')"
        ).lastrowid
    client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                            int(API_ID), API_HASH)
    qr = None
    for attempt in range(2):          # повтор при кратковременном обрыве соединения
        try:
            await client.connect()
            qr = await client.qr_login()
            break
        except Exception:
            if attempt == 1:
                # флоу не стартовал — убираем за собой заготовку полностью
                try:
                    await client.disconnect()
                except Exception:
                    pass
                try:
                    client.session.close()
                    (SESSIONS / f"account_{account_id}.session").unlink(missing_ok=True)
                except Exception:
                    pass
                with db() as c:
                    c.execute("DELETE FROM accounts WHERE id=? AND status='linking'",
                              (account_id,))
                raise
            await asyncio.sleep(3)
    fid = str(account_id)
    FLOWS[fid] = {"client": client, "qr": qr, "state": "waiting",
                  "account_id": account_id}

    f = FLOWS[fid]

    async def waiter():
        try:
            while f["state"] == "waiting":
                try:
                    await asyncio.wait_for(f["qr"].wait(), timeout=25)
                except asyncio.TimeoutError:
                    if f["state"] != "waiting":
                        break
                    try:
                        await f["qr"].recreate()
                    except Exception:
                        f["qr"] = await f["client"].qr_login()
                    continue
                except SessionPasswordNeededError:
                    f["state"] = "pwd"
                    return
                authorized = await f["client"].is_user_authorized()
                if FLOWS.get(fid) is not f or f["state"] != "waiting":
                    return
                if authorized:
                    f["state"] = "authorized"
                    start_recorder(f["account_id"], f["client"])
                    return
        except Exception as e:
            f["state"] = "error"
            print(f"[flow {fid}] {type(e).__name__}: {e}")

    asyncio.create_task(waiter())
    return fid


async def finish_pwd(fid, password):
    f = FLOWS.get(fid)
    if not f or f["state"] != "pwd":
        return False
    try:
        await f["client"].sign_in(password=password)
    except PasswordHashInvalidError:
        return False
    if FLOWS.get(fid) is not f or f["state"] != "pwd":
        return False
    f["state"] = "authorized"
    start_recorder(f["account_id"], f["client"])
    return True


# ---------- загрузка истории аккаунта ----------

BACKFILL_SEM = asyncio.Semaphore(3)   # не больше трёх догонок одновременно (запас на много аккаунтов)
BACKFILL_FETCH_TIMEOUT = 45  # не позволяем одному запросу истории зависнуть навсегда
BACKFILL_MESSAGE_TIMEOUT = 180  # ограничиваем и загрузку отдельного сообщения с медиа


async def iter_messages_with_timeout(client, *args, **kwargs):
    """Итерирует историю с таймаутом на каждый запрос следующей страницы."""
    iterator = client.iter_messages(*args, **kwargs).__aiter__()
    while True:
        try:
            message = await asyncio.wait_for(
                iterator.__anext__(), timeout=BACKFILL_FETCH_TIMEOUT)
        except StopAsyncIteration:
            return
        yield message


def start_backfill(account_id):
    """Запускает догонку истории, если она уже не идёт. True = запустили."""
    st = BACKFILL.get(account_id)
    if st and st.get("state") == "running":
        return False
    state = {"task": None, "state": "running", "total": 0, "done": 0,
             "msgs": 0, "bytes": 0, "note": "", "current_chat": "",
             "current_message": 0, "current_media_size": 0}
    BACKFILL[account_id] = state
    state["task"] = asyncio.create_task(run_backfill(account_id, state))
    return True


async def run_backfill(account_id, state):
    try:
        async with BACKFILL_SEM:
            await _run_backfill_inner(account_id, state)
    except asyncio.CancelledError:
        if state.get("state") == "running":
            state["state"] = "stopped"
        raise
    except Exception as e:
        state.update(state="error", note=f"{type(e).__name__}: {e}")


async def _run_backfill_inner(account_id, st):
    """Полная история аккаунта: входящие+исходящие, чаты и группы.
    Broadcast-каналы и боты пропускаются. Пишет туда же, куда и live."""
    from telethon.errors import FloodWaitError
    client = CLIENTS.get(account_id)
    own = False
    if client is None:
        client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                                int(API_ID), API_HASH)
        own = True
    try:
        await client.connect()
        if not await client.is_user_authorized():
            st.update(state="error", note="нужен повторный вход по QR")
            return
        st.update(state="running", note="", total=0, done=0, msgs=0,
                  bytes=0, current_chat="", current_message=0,
                  current_media_size=0, media_failure_chats=0)
        dialogs = [d async for d in client.iter_dialogs() if should_scan_dialog(d)]
        st["total"] = len(dialogs)
        for i, d in enumerate(dialogs, 1):
            if st.get("state") != "running":        # остановлен кнопкой
                return
            ok = False
            ctype, ctitle = classify(d.entity) if d.entity else ("user", "Неизвестный чат")
            title = ctitle or "Неизвестный чат"
            st["current_chat"] = title
            for _attempt in range(3):
                try:
                    with db() as c:
                        r = c.execute("""SELECT max_msg_id, min_msg_id, deep_done, history_cursor, title, type
                                         FROM chats WHERE account_id=? AND chat_id=?""",
                                      (account_id, d.id)).fetchone()
                        if r and (r["title"] != title or r["type"] != ctype):
                            c.execute("UPDATE chats SET title=?, type=? WHERE account_id=? AND chat_id=?",
                                      (title, ctype, account_id, d.id))
                    ensure_chat_dir(account_id, d.id, title)
                    await asyncio.to_thread(migrate_media_paths, account_id, d.id)
                    max_id = (r["history_cursor"] or 0) if r else 0
                    min_id = (r["min_msg_id"] or 0) if r else 0
                    deep_done = (r["deep_done"] or 0) if r else 0

                    # History checkpoint is independent of concurrently arriving live messages.
                    recovered_id = max_id
                    async for msg in iter_messages_with_timeout(
                            client, d, reverse=True, offset_id=max_id):
                        st["current_message"] = msg.id
                        st["current_media_size"] = getattr(
                            getattr(msg, "file", None), "size", 0) or 0
                        await asyncio.wait_for(
                            store_message(client, account_id, msg, d.id, title, ctype),
                            timeout=BACKFILL_MESSAGE_TIMEOUT)
                        st["msgs"] += 1
                        recovered_id = max(recovered_id,msg.id)
                    # Advance only after the entire range has been read successfully.
                    with db() as c:
                        c.execute("UPDATE chats SET history_cursor=MAX(history_cursor,?) WHERE account_id=? AND chat_id=?",
                                  (recovered_id,account_id,d.id))

                    # Reconcile edits made during downtime within a bounded recent window.
                    if deep_done:
                        async for msg in iter_messages_with_timeout(client,d,limit=100):
                            await asyncio.wait_for(store_message(client,account_id,msg,d.id,title,ctype),
                                                   timeout=BACKFILL_MESSAGE_TIMEOUT)

                    # 2) докапываемся вглубь истории, если ещё не дошли до её начала
                    if not deep_done:
                        seen = 0
                        async for msg in iter_messages_with_timeout(
                                client, d, offset_id=min_id, limit=None):
                            st["current_message"] = msg.id
                            st["current_media_size"] = getattr(
                                getattr(msg, "file", None), "size", 0) or 0
                            await asyncio.wait_for(
                                store_message(client, account_id, msg, d.id, title, ctype),
                                timeout=BACKFILL_MESSAGE_TIMEOUT)
                            st["msgs"] += 1
                            seen += 1
                            min_id = msg.id if not min_id else min(min_id, msg.id)
                            if seen % 25 == 0:   # частый чекпоинт: обрыв не перечитывает чат заново
                                with db() as c:
                                    c.execute("""UPDATE chats SET min_msg_id=?
                                                 WHERE account_id=? AND chat_id=?""",
                                              (min_id, account_id, d.id))
                        # итератор исчерпался = дошли до самого начала истории чата
                        with db() as c:
                            c.execute("""UPDATE chats SET min_msg_id=?, deep_done=1
                                         WHERE account_id=? AND chat_id=?""",
                                      (min_id, account_id, d.id))
                    if ctype == "group":
                        await hydrate_chat_participants(client, account_id, d.id)
                    incomplete = await asyncio.to_thread(
                        incomplete_chat_media_count, account_id, d.id)
                    if incomplete:
                        # Не маркируем историю завершённой, если Telegram не
                        # вернул исходный файл целиком; оставляем чат на повтор.
                        with db() as c:
                            c.execute("""UPDATE chats SET min_msg_id=0,deep_done=0
                                         WHERE account_id=? AND chat_id=?""",
                                      (account_id, d.id))
                        st["media_failure_chats"] = st.get("media_failure_chats", 0) + 1
                        ok = True
                        break
                    ok = True
                    st["note"] = ""
                    break
                except FloodWaitError as e:
                    await asyncio.sleep(e.seconds + 2)
                except Exception as e:
                    # связь у него рвётся — чат нельзя молча пропускать: повторяем
                    print(f"[backfill {account_id}] «{d.name}»: {type(e).__name__}: {e}"
                          f" (попытка {_attempt + 1}/3)")
                    st["note"] = (f"ожидаю ответ от «{title}»; "
                                  f"повтор {_attempt + 1}/3")
                    if _attempt < 2:
                        await asyncio.sleep(4 + 6 * _attempt)
            if not ok:
                st["errs"] = st.get("errs", 0) + 1
            st["done"] = i
            st["current_chat"] = ""
            st["current_message"] = 0
            st["current_media_size"] = 0
            await asyncio.sleep(0.3)
        st["state"] = "done"
        notes = []
        if st.get("errs"):
            notes.append(f"не удалось дочитать {st['errs']} чатов — связь рвалась")
        if st.get("media_failure_chats"):
            notes.append(f"медиа не удалось восстановить в {st['media_failure_chats']} чатах; "
                         "они останутся на повторную проверку")
        if notes:
            st["state"] = "partial"
            st["retry_at"] = time.time()+60
            st["note"] = "; ".join(notes) + " — автоматический повтор через минуту"
        # Повторный вызов во время активной догонки не запускает цикл новых
        # полных проходов. Следующий проход можно запустить вручную после этого.
    except Exception as e:
        st.update(state="error", retry_at=time.time()+60, note=f"{type(e).__name__}: {e}")
    finally:
        if own:
            await client.disconnect()


# ---------- веб-панель ----------

ARCHIVE_LOCK = None


def acquire_archive_lock():
    """One server per data folder, regardless of launcher or TCP port."""
    global ARCHIVE_LOCK
    handle = (BASE / ".archive.lock").open("a+b")
    try:
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if sys.platform == "win32":
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError as exc:
        handle.close()
        raise RuntimeError("Этот архив уже открыт другим сервером TG Monitor") from exc
    ARCHIVE_LOCK = handle


def release_archive_lock():
    global ARCHIVE_LOCK
    if ARCHIVE_LOCK is not None:
        ARCHIVE_LOCK.close()
        ARCHIVE_LOCK = None


app = FastAPI(title="TG Monitor")
app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
app.mount("/media", StaticFiles(directory=MEDIA), name="media")

# ---------- пароль панели ----------

COOKIE_NAME = "panel_key"
COOKIE_VALUE = (hashlib.sha256(PANEL_PASSWORD.encode()).hexdigest()
                if PANEL_PASSWORD else "")
LOGIN_FAILS = {"n": 0, "until": 0.0}       # простая защита от перебора


@app.middleware("http")
async def auth_middleware(request, call_next):
    if PANEL_PASSWORD:
        p = request.url.path
        # без пароля доступны только сама страница входа, её статика и /api/login
        if not (p == "/" or p.startswith("/static") or p in ("/api/login", "/api/health", "/api/runtime/stop")):
            if request.cookies.get(COOKIE_NAME) != COOKIE_VALUE:
                if p.startswith("/api"):
                    return JSONResponse({"ok": False, "reason": "нужен пароль"},
                                        status_code=401)
                return Response(status_code=401)
    return await call_next(request)


@app.post("/api/login")
async def api_login(request: Request):
    body = await request.json()
    pwd = (body or {}).get("password", "")
    if time.time() < LOGIN_FAILS["until"]:
        return JSONResponse({"ok": False, "reason": "слишком много попыток — подожди минуту"},
                            status_code=429)
    if pwd and secrets.compare_digest(pwd, PANEL_PASSWORD):
        LOGIN_FAILS["n"], LOGIN_FAILS["until"] = 0, 0.0
        resp = JSONResponse({"ok": True})
        resp.set_cookie(COOKIE_NAME, COOKIE_VALUE, max_age=30 * 24 * 3600,
                        httponly=True, samesite="strict")
        return resp
    LOGIN_FAILS["n"] += 1
    if LOGIN_FAILS["n"] >= 5:
        LOGIN_FAILS["until"] = time.time() + 60
        LOGIN_FAILS["n"] = 0
    return JSONResponse({"ok": False, "reason": "неверный пароль"}, status_code=401)


@app.get("/")
def index():
    return FileResponse(FRONTEND / "index.html")


@app.get("/api/health")
def api_health():
    return {"ok": True, "application": "TG Monitor", "version": "1.2.1",
            "installation": hashlib.sha256(str(BASE).casefold().encode()).hexdigest()[:24]}


@app.post("/api/runtime/stop")
async def api_runtime_stop(request: Request):
    token = os.environ.get("TG_MONITOR_CONTROL_TOKEN", "")
    supplied = request.headers.get("authorization", "")
    if not token or not secrets.compare_digest(supplied, "Bearer " + token):
        return JSONResponse({"ok": False, "reason": "нет доступа"}, status_code=403)
    server = globals().get("RUNTIME_SERVER")
    if server is None:
        return JSONResponse({"ok": False, "reason": "этот запуск не управляется приложением"}, status_code=409)
    server.should_exit = True
    return {"ok": True}


@app.get("/api/accounts")
def api_accounts():
    with db() as c:
        pending = {r["account_id"]:dict(r) for r in c.execute("""SELECT account_id,
            COUNT(*) pending,SUM(attempts>0) retrying FROM archive_jobs GROUP BY account_id""")}
        rows = c.execute("""
            SELECT a.*,
                   (SELECT COUNT(*) FROM messages m WHERE m.account_id = a.id) AS n,
                   (SELECT MAX(date) FROM messages m WHERE m.account_id = a.id) AS last,
                   (SELECT kind FROM events e WHERE e.account_id = a.id
                     ORDER BY e.id DESC LIMIT 1) AS last_ev_kind,
                   (SELECT time FROM events e WHERE e.account_id = a.id
                     ORDER BY e.id DESC LIMIT 1) AS last_ev_time
            FROM accounts a ORDER BY a.id""").fetchall()
        out = []
        for r in rows:
            d = dict(r)
            st = BACKFILL.get(r["id"])
            d["bf"] = ({k: v for k, v in st.items() if k != "task"} if st else None)
            d["ingest"] = pending.get(r["id"],{"pending":0,"retrying":0})
            d["ingest"]["storage_error"] = bool(INGEST_ERRORS.get(r["id"]))
            out.append(d)
        return out


@app.post("/api/accounts/{account_id}/backfill")
async def api_backfill(account_id: int):
    with db() as c:
        account = c.execute("SELECT status FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
    if account["status"] == "disconnected":
        return JSONResponse({"ok": False, "reason": "сначала подключи аккаунт"}, status_code=409)
    return {"ok": start_backfill(account_id)}


@app.post("/api/accounts/{account_id}/backfill/stop")
async def api_backfill_stop(account_id: int):
    st = BACKFILL.get(account_id)
    if st and st.get("state") == "running" and st.get("task"):
        st["task"].cancel()
        return {"ok": True}
    return {"ok": False}


@app.post("/api/accounts/add")
async def api_add_account():
    try:
        fid = await start_flow()
        return {"ok": True, "fid": fid}
    except Exception as e:
        # ошибку отдаём обычным JSON-ом, чтобы панель показала причину и кнопку повтора
        return {"ok": False, "reason": f"Telegram не ответил ({type(e).__name__}) — жми «Повторить»"}


@app.get("/api/qr/{fid}.png")
async def api_qr_png(fid: str):
    f = FLOWS.get(fid)
    if not f:
        return Response(status_code=404)
    box = qrcode.QRCode(border=2)
    box.add_data(f["qr"].url)
    box.make(fit=True)
    buf = io.BytesIO()
    box.make_image().save(buf, format="PNG")
    return Response(content=buf.getvalue(), media_type="image/png")


@app.get("/api/qr/{fid}/status")
def api_qr_status(fid: str):
    f = FLOWS.get(fid)
    if not f:
        return {"state": "unknown"}
    return {"state": f["state"], "account_id": f["account_id"]}


@app.post("/api/qr/{fid}/password")
async def api_qr_password(fid: str, request: Request):
    body = await request.json()
    ok = await finish_pwd(fid, body.get("password", ""))
    return {"ok": ok}


@app.post("/api/qr/{fid}/cancel")
async def api_qr_cancel(fid: str):
    """Отмена до скана: отключаем клиент и убираем «заготовку» аккаунта."""
    f = FLOWS.pop(fid, None)
    if not f:
        return {"ok": False}
    if f["state"] != "authorized":
        f["state"] = "cancelled"
        try:
            await f["client"].disconnect()
        except Exception:
            pass
        try:
            f["client"].session.close()     # отпускаем файл сессии для удаления
        except Exception:
            pass
        for _ in range(3):
            try:
                (SESSIONS / f"account_{f['account_id']}.session").unlink(missing_ok=True)
                break
            except OSError:
                await asyncio.sleep(1)
        with db() as c:
            c.execute("DELETE FROM accounts WHERE id=? AND status='linking'",
                      (f["account_id"],))
    return {"ok": True}


# ---------- подключение по номеру телефона (код + 2FA) ----------

PHONE_FLOWS = {}   # fid -> {"client", "account_id", "phone", "state": code|pwd, "note"}


def _finish_phone(f):
    if PHONE_FLOWS.get(str(f["account_id"])) is not f:
        return {"ok": False, "state": "dead", "reason": "Подключение отменено — начните заново"}
    PHONE_FLOWS.pop(str(f["account_id"]), None)
    f["state"] = "ok"
    start_recorder(f["account_id"], f["client"])
    return {"ok": True, "state": "ok"}


@app.post("/api/accounts/add-phone")
async def api_add_phone(request: Request):
    body = await request.json()
    phone = (body.get("phone") or "").strip()
    if not phone or not phone.lstrip("+").isdigit() or len(phone.lstrip("+")) < 7:
        return {"ok": False, "reason": "укажи телефон в формате +380XXXXXXXXX"}
    with db() as c:
        account_id = c.execute(
            "INSERT INTO accounts(name, phone, status) VALUES(?,?,'linking')",
            ("Ожидает код", phone)).lastrowid
    client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                            int(API_ID), API_HASH)
    fid = str(account_id)
    try:
        await client.connect()
        await client.send_code_request(phone)
    except Exception as e:
        try:
            await client.disconnect()
        except Exception:
            pass
        try:
            client.session.close()
            (SESSIONS / f"account_{account_id}.session").unlink(missing_ok=True)
        except Exception:
            pass
        with db() as c:
            c.execute("DELETE FROM accounts WHERE id=? AND status='linking'",
                      (account_id,))
        return {"ok": False, "reason": f"не удалось отправить код ({type(e).__name__})"}
    PHONE_FLOWS[fid] = {"client": client, "account_id": account_id,
                        "phone": phone, "state": "code", "note": ""}
    return {"ok": True, "fid": fid}


@app.post("/api/phone/{fid}/code")
async def api_phone_code(fid: str, request: Request):
    body = await request.json()
    code = (body.get("code") or "").strip()
    f = PHONE_FLOWS.get(fid)
    if not f or f["state"] != "code":
        return {"ok": False, "state": "dead", "reason": "запрос устарел — начни заново"}
    if not code:
        return {"ok": False, "state": "code", "reason": "введи код из сообщения"}
    try:
        await f["client"].sign_in(f["phone"], code)
    except SessionPasswordNeededError:
        if PHONE_FLOWS.get(fid) is not f:
            return {"ok": False, "state": "dead", "reason": "Подключение отменено"}
        f["state"] = "pwd"
        return {"ok": False, "state": "pwd", "reason": "нужен пароль 2FA"}
    except Exception as e:
        return {"ok": False, "state": "code",
                "reason": f"код не принят ({type(e).__name__}), попробуй ещё раз"}
    return _finish_phone(f)


@app.post("/api/phone/{fid}/password")
async def api_phone_password(fid: str, request: Request):
    body = await request.json()
    f = PHONE_FLOWS.get(fid)
    if not f or f["state"] != "pwd":
        return {"ok": False, "state": "dead", "reason": "запрос устарел — начни заново"}
    try:
        await f["client"].sign_in(password=body.get("password", ""))
    except Exception:
        return {"ok": False, "state": "pwd", "reason": "пароль не принят, попробуй ещё раз"}
    return _finish_phone(f)


@app.post("/api/phone/{fid}/cancel")
async def api_phone_cancel(fid: str):
    f = PHONE_FLOWS.pop(fid, None)
    if not f:
        return {"ok": False}
    f["state"] = "cancelled"
    try:
        await f["client"].disconnect()
    except Exception:
        pass
    try:
        f["client"].session.close()         # отпускаем файл сессии для удаления
    except Exception:
        pass
    for _ in range(3):
        try:
            (SESSIONS / f"account_{f['account_id']}.session").unlink(missing_ok=True)
            break
        except OSError:
            await asyncio.sleep(1)
    with db() as c:
        c.execute("DELETE FROM accounts WHERE id=? AND status='linking'",
                  (f["account_id"],))
    return {"ok": True}


@app.post("/api/accounts/{account_id}/pause")
async def api_pause(account_id: int):
    stop_recorder(account_id)
    st = BACKFILL.get(account_id)
    if st and st.get("state") == "running" and st.get("task"):
        st["task"].cancel()
    set_status(account_id, "paused")
    return {"ok": True}


@app.post("/api/accounts/{account_id}/resume")
async def api_resume(account_id: int):
    # статус меняем сразу, чтобы панель отозвалась на первый же клик;
    # если подключение не выйдет, рекордер сам перезапишет на error/reconnecting
    set_status(account_id, "recording")
    start_recorder(account_id)
    return {"ok": True}


@app.post("/api/accounts/{account_id}/disconnect")
async def api_disconnect(account_id: int):
    """Отключить аккаунт по-настоящему: отзываем авторизацию в Telegram
    (устройство исчезает из активных сеансов), удаляем ключ локально,
    но весь архив (сообщения, чаты, медиа) сохраняется целиком."""
    rec = REC.pop(account_id, None)
    if rec:
        rec["task"].cancel()
    bf = BACKFILL.pop(account_id, None)
    if bf and bf.get("task"):
        bf["task"].cancel()
    cl = CLIENTS.pop(account_id, None)
    sess = SESSIONS / f"account_{account_id}.session"
    if cl is None and sess.exists():
        cl = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                            int(API_ID), API_HASH)   # пауза — поднимаем клиента для отзыва
    revoked = False
    if cl is not None:
        try:
            await cl.connect()
            if await cl.is_user_authorized():
                await cl.log_out()          # в Telegram устройство пропадает из сеансов
                revoked = True
        except Exception as e:
            print(f"[disconnect {account_id}] log_out: {type(e).__name__}: {e}")
        try:
            await cl.disconnect()
        except Exception:
            pass
        try:
            cl.session.close()   # иначе Windows держит файл сессии открытым и unlink падает
        except Exception:
            pass
    for _ in range(3):           # файл может отпустить с задержкой
        try:
            sess.unlink(missing_ok=True)
            break
        except OSError:
            await asyncio.sleep(1)
    LOGGED.discard(account_id)
    add_event(account_id, "logout",
              "устройство отключено" + ("" if revoked else " (не удалось отозвать в Telegram)"))
    set_status(account_id, "disconnected")
    return {"ok": True}


def safe_media_path(stored_path):
    """Resolve a database path only inside this installation's media directory."""
    if not isinstance(stored_path, str) or not stored_path:
        raise ValueError("пустой путь медиа")
    full = (BASE / stored_path).resolve()
    media_root = MEDIA.resolve()
    try:
        full.relative_to(media_root)
    except ValueError as exc:
        raise ValueError("путь вложения вне каталога медиа") from exc
    if full == media_root:
        raise ValueError("путь вложения указывает на каталог медиа")
    return full


def recover_orphaned_media_parts():
    """Associate a download scratch file with its message after a process stop."""
    recovered = 0
    pattern = re.compile(r"^\.(?P<target>.+ \[(?P<msg_id>\d+)\]\.[A-Za-z0-9]{1,9})\.[0-9a-f]{12}\.part$", re.I)
    for part in MEDIA.rglob(".*.part"):
        match = pattern.fullmatch(part.name)
        if not match:
            continue
        try:
            size = part.stat().st_size
            if size <= 0:
                continue
            msg_id = int(match.group("msg_id"))
            target = part.with_name(match.group("target"))
            with db() as c:
                candidates = []
                for table in ("messages", "deleted"):
                    candidates.extend((table, row) for row in c.execute(
                        f"""SELECT m.account_id,m.chat_id,m.file_size,m.file_path,m.media_status,
                                   ch.title,a.username,a.phone
                            FROM {table} m
                            LEFT JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
                            LEFT JOIN accounts a ON a.id=m.account_id
                            WHERE m.msg_id=? AND m.media_type IS NOT NULL AND m.file_size>=?""",
                        (msg_id, size)).fetchall())

            parts = part.relative_to(MEDIA).parts
            if len(parts) < 3:
                continue
            match_row = None
            for table, row in candidates:
                account_labels = [row["phone"], "@" + row["username"] if row["username"] else None,
                                  f"Неизвестный аккаунт {row['account_id']}"]
                account_names = {_safe_name(label) for label in account_labels if label}
                account_names.update(f"{name[:30]} ({row['account_id']})" for name in tuple(account_names))
                chat_label = _safe_name(row["title"] or "Неизвестный чат")
                with db() as c:
                    duplicate = c.execute(
                        "SELECT 1 FROM chats WHERE account_id=? AND chat_id!=? AND lower(title)=lower(?) LIMIT 1",
                        (row["account_id"], row["chat_id"], row["title"])).fetchone()
                chat_names = {chat_label}
                if duplicate:
                    chat_names.add(f"{chat_label[:30]} ({row['chat_id']})")
                if parts[0].casefold() in {name.casefold() for name in account_names} and \
                        parts[1].casefold() in {name.casefold() for name in chat_names}:
                    match_row = table, row
                    break
            if not match_row:
                continue

            table, row = match_row
            expected_size = row["file_size"] or 0
            if size == expected_size and not target.exists():
                destination = target
                status = None
                error = None
            else:
                destination = target.with_name(target.name + ".partial")
                if destination.is_file() and destination.stat().st_size >= size:
                    # Preserve both copies when there is already a better partial.
                    continue
                status = "dismissed" if row["media_status"] == "dismissed" else "incomplete"
                error = row["media_status"] == "dismissed"
            if part.resolve() != destination.resolve():
                if destination.exists():
                    destination.unlink()
                part.replace(destination)
            relative = str(destination.relative_to(BASE)).replace("\\", "/")
            with db() as c:
                if status is None:
                    c.execute(f"UPDATE {table} SET file_path=?,media_status=NULL,media_error=NULL "
                              "WHERE account_id=? AND chat_id=? AND msg_id=?",
                              (relative, row["account_id"], row["chat_id"], msg_id))
                else:
                    c.execute(f"UPDATE {table} SET file_path=?,media_status=?,media_error="
                              "CASE WHEN ? THEN media_error ELSE COALESCE(media_error,?) END "
                              "WHERE account_id=? AND chat_id=? AND msg_id=?",
                              (relative, status, error,
                               "Загрузка была прервана остановкой приложения.",
                               row["account_id"], row["chat_id"], msg_id))
            recovered += 1
        except (OSError, ValueError, sqlite3.Error):
            continue
    return recovered


def scoped_media_paths(c, account_id, chat_id=0):
    """All file references in active messages and the recycle bin for one scope."""
    where = "account_id=?" + (" AND chat_id=?" if chat_id else "")
    args = (account_id, chat_id) if chat_id else (account_id,)
    paths = set()
    for table in ("messages", "deleted"):
        paths.update(r[0] for r in c.execute(
            f"SELECT DISTINCT file_path FROM {table} WHERE {where}"
            " AND file_path IS NOT NULL AND file_path!=''", args))
    return paths


def unreferenced_media_paths(c, candidates):
    """Never remove a file still referenced by another message or account."""
    if not candidates:
        return [], 0
    remaining = set()
    for r in c.execute("""SELECT file_path FROM messages WHERE file_path IS NOT NULL
                          UNION SELECT file_path FROM deleted WHERE file_path IS NOT NULL"""):
        try:
            remaining.add(safe_media_path(r[0]))
        except (ValueError, OSError):
            continue
    removable = sorted(path for path in candidates if path not in remaining)
    return removable, len(candidates) - len(removable)


def remove_media_files(paths):
    removed = failed = 0
    for path in paths:
        try:
            existed = path.is_file()
            if existed:
                path.unlink()
                removed += 1
        except OSError:
            failed += 1
    return removed, failed


def cleanup_scope_error(c, scope, account_id, chat_id):
    account = c.execute("SELECT status FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
    if account["status"] == "linking":
        return JSONResponse({"ok": False, "reason": "дождись завершения подключения аккаунта"}, status_code=409)
    if scope == "chat" and not c.execute(
            "SELECT 1 FROM chats WHERE account_id=? AND chat_id=?", (account_id, chat_id)
    ).fetchone():
        return JSONResponse({"ok": False, "reason": "чат не найден в этом аккаунте"}, status_code=404)
    return None


@app.get("/api/cleanup/full/preview")
def api_cleanup_full_preview(scope: str, account_id: int, chat_id: int = 0):
    if account_id <= 0 or scope not in ("account", "chat") or (scope == "chat") != (chat_id != 0):
        return JSONResponse({"ok": False, "reason": "выбери один аккаунт или один чат"}, status_code=422)
    with db() as c:
        error = cleanup_scope_error(c, scope, account_id, chat_id)
        if error:
            return error
        where = "account_id=?" + (" AND chat_id=?" if scope == "chat" else "")
        args = (account_id, chat_id) if scope == "chat" else (account_id,)
        messages = c.execute(f"SELECT COUNT(*) FROM messages WHERE {where}", args).fetchone()[0]
        deleted = c.execute(f"SELECT COUNT(*) FROM deleted WHERE {where}", args).fetchone()[0]
        paths = scoped_media_paths(c, account_id, chat_id if scope == "chat" else 0)
    return {"messages": messages, "deleted": deleted, "files": len(paths)}


@app.post("/api/cleanup/full")
async def api_cleanup_full(request: Request):
    """Permanently remove one local account or one chat without a date filter."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "reason": "неверный JSON"}, status_code=422)
    if not isinstance(body, dict):
        return JSONResponse({"ok": False, "reason": "ожидается объект параметров"}, status_code=422)
    scope = body.get("scope")
    account_id, chat_id = body.get("account_id"), body.get("chat_id", 0)
    if (scope not in ("account", "chat") or type(account_id) is not int or account_id <= 0
            or type(chat_id) is not int or (scope == "chat") != (chat_id != 0)
            or body.get("confirmation") != ("DELETE_ACCOUNT" if scope == "account" else "CLEAR_CHAT")
            or any(key in body for key in ("from", "to", "with_media", "mode"))):
        return JSONResponse({"ok": False, "reason": "нужно явно подтвердить удаление одного аккаунта или чата без дат"},
                            status_code=422)

    with db() as c:
        error = cleanup_scope_error(c, scope, account_id, chat_id)
        if error:
            return error
        try:
            for rel in scoped_media_paths(c, account_id, chat_id if scope == "chat" else 0):
                safe_media_path(rel)
        except (ValueError, OSError):
            return JSONResponse({"ok": False, "reason": "найден путь вложения вне media; удаление отменено"},
                                status_code=409)

    bf = BACKFILL.pop(account_id, None)
    tasks = []
    if bf and bf.get("task"):
        bf["task"].cancel()
        tasks.append(bf["task"])
    client = None
    if scope == "account":
        rec = REC.pop(account_id, None)
        if rec:
            rec["task"].cancel()
            tasks.append(rec["task"])
        client = CLIENTS.pop(account_id, None)
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    if client is not None:
        try:
            await client.disconnect()
            client.session.close()
        except Exception:
            pass

    with db() as c:
        error = cleanup_scope_error(c, scope, account_id, chat_id)
        if error:
            return error
        rel_paths = scoped_media_paths(c, account_id, chat_id if scope == "chat" else 0)
        try:
            candidates = {safe_media_path(rel) for rel in rel_paths}
        except (ValueError, OSError):
            return JSONResponse({"ok": False, "reason": "найден путь вложения вне media; удаление отменено"},
                                status_code=409)
        where = "account_id=?" + (" AND chat_id=?" if scope == "chat" else "")
        args = (account_id, chat_id) if scope == "chat" else (account_id,)
        messages = c.execute(f"SELECT COUNT(*) FROM messages WHERE {where}", args).fetchone()[0]
        deleted = c.execute(f"SELECT COUNT(*) FROM deleted WHERE {where}", args).fetchone()[0]
        if scope == "chat":
            old_max = c.execute("SELECT max_msg_id FROM chats WHERE account_id=? AND chat_id=?",
                                args).fetchone()[0] or 0
            newest = c.execute(f"""SELECT MAX(msg_id) FROM (
                                   SELECT msg_id FROM messages WHERE {where}
                                   UNION ALL SELECT msg_id FROM deleted WHERE {where})""",
                               (*args, *args)).fetchone()[0] or 0
            watermark = max(old_max, newest)
            c.execute("DELETE FROM messages WHERE account_id=? AND chat_id=?", args)
            c.execute("DELETE FROM deleted WHERE account_id=? AND chat_id=?", args)
            c.execute("""UPDATE chats SET max_msg_id=?, min_msg_id=0, deep_done=1,
                         clear_through_msg_id=? WHERE account_id=? AND chat_id=?""",
                      (watermark, watermark, account_id, chat_id))
        else:
            c.execute("DELETE FROM messages WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM deleted WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM chats WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM participants WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM archive_jobs WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM media_suppression WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM events WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM accounts WHERE id=?", (account_id,))
        files_to_remove, protected = unreferenced_media_paths(c, candidates)

    files, failed = remove_media_files(files_to_remove)
    session_failed = 0
    if scope == "account":
        for suffix in ("", "-wal", "-shm", "-journal"):
            path = SESSIONS / f"account_{account_id}.session{suffix}"
            try:
                path.unlink(missing_ok=True)
            except OSError:
                session_failed += 1
        ACCOUNT_DIRS.pop(account_id, None)
        MEDIA_BYTES.pop(account_id, None)
        SENDER_RESOLVED.difference_update([k for k in SENDER_RESOLVED if k[0] == account_id])
        SENDER_LOOKUP_FAILED.difference_update([k for k in SENDER_LOOKUP_FAILED if k[0] == account_id])
        for key in [k for k in SENDER_PROFILE_CACHE if k[0] == account_id]:
            SENDER_PROFILE_CACHE.pop(key, None)
        LOGGED.discard(account_id)
    return {"ok": True, "messages": messages, "deleted": deleted,
            "files": files, "protected": protected, "failed": failed,
            "session_failed": session_failed}


@app.post("/api/cleanup")
async def api_cleanup(request: Request):
    """Очистка истории из морды: удалить сообщения (и медиа) за период/чат
    или снять удаление и вытянуть переписку из Telegram заново."""
    body = await request.json()
    if not isinstance(body, dict):
        return JSONResponse({"ok": False, "reason": "ожидается объект параметров"}, status_code=422)
    try:
        account_id = int(body.get("account_id", 0) or 0)
        chat_id = int(body.get("chat_id", 0) or 0)
    except (TypeError, ValueError):
        return JSONResponse({"ok": False, "reason": "неверный аккаунт или чат"}, status_code=422)
    raw_from, raw_to = body.get("from", ""), body.get("to", "")
    if not isinstance(raw_from, str) or not isinstance(raw_to, str):
        return JSONResponse({"ok": False, "reason": "даты должны быть строками"}, status_code=422)
    frm, to = raw_from.strip(), raw_to.strip()    # YYYY-MM-DD (необязательно)
    with_media = body.get("with_media", False)
    mode = body.get("mode", "delete")
    if account_id <= 0:
        return JSONResponse({"ok": False, "reason": "не указан аккаунт"}, status_code=422)
    if mode not in ("delete", "restore"):
        return JSONResponse({"ok": False, "reason": "неизвестный режим очистки"}, status_code=422)
    if not isinstance(with_media, bool):
        return JSONResponse({"ok": False, "reason": "with_media должен быть true или false"}, status_code=422)
    try:
        parsed_from = date.fromisoformat(frm) if frm else None
        parsed_to = date.fromisoformat(to) if to else None
    except ValueError:
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if (parsed_from and parsed_from.isoformat() != frm) or (parsed_to and parsed_to.isoformat() != to):
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if parsed_from and parsed_to and parsed_from > parsed_to:
        return JSONResponse({"ok": False, "reason": "начальная дата позже конечной"}, status_code=422)
    if mode == "delete" and (not parsed_from or not parsed_to):
        return JSONResponse({"ok": False, "reason": "для удаления обязательно укажи начало и конец периода"}, status_code=422)
    with db() as c:
        exists = c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not exists:
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        if chat_id and not c.execute(
                "SELECT 1 FROM chats WHERE account_id=? AND chat_id=?", (account_id, chat_id)
        ).fetchone():
            return JSONResponse({"ok": False, "reason": "чат не найден в этом аккаунте"}, status_code=404)
    where, args = "WHERE account_id=?", [account_id]
    if chat_id:
        where += " AND chat_id=?"; args.append(chat_id)
    if frm:
        where += " AND substr(date,1,10)>=?"; args.append(frm)
    if to:
        where += " AND substr(date,1,10)<=?"; args.append(to)
    if mode == "delete":
        files_to_remove, protected = [], 0
        with db() as c:
            rows = c.execute(
                f"SELECT chat_id, msg_id, file_path FROM messages {where}", args).fetchall()
            try:
                candidates = {safe_media_path(r["file_path"]) for r in rows if r["file_path"]} if with_media else set()
            except (ValueError, OSError):
                return JSONResponse({"ok": False, "reason": "найден путь вложения вне media; удаление отменено"},
                                    status_code=409)
            c.execute(f"INSERT OR IGNORE INTO deleted SELECT * FROM messages {where}", args)
            c.execute(f"DELETE FROM messages {where}", args)
            if with_media:
                for r in rows:
                    if r["file_path"]:
                        c.execute("""UPDATE deleted SET file_path=NULL
                                     WHERE account_id=? AND chat_id=? AND msg_id=?""",
                                  (account_id, r["chat_id"], r["msg_id"]))
                    c.execute("""UPDATE deleted SET media_approval=NULL
                                 WHERE account_id=? AND chat_id=? AND msg_id=?""",
                              (account_id, r["chat_id"], r["msg_id"]))
                files_to_remove, protected = unreferenced_media_paths(c, candidates)
                for r in rows:
                    if r["file_path"] and safe_media_path(r["file_path"]) not in files_to_remove:
                        c.execute("""UPDATE deleted SET file_path=?
                                     WHERE account_id=? AND chat_id=? AND msg_id=?""",
                                  (r["file_path"], account_id, r["chat_id"], r["msg_id"]))
            # пересчёт max_msg_id затронутых чатов, чтобы догонка знала новую вершину
            for ch in {r["chat_id"] for r in rows}:
                mx = c.execute("""SELECT MAX(msg_id) AS m FROM messages
                                  WHERE account_id=? AND chat_id=?""",
                               (account_id, ch)).fetchone()["m"] or 0
                c.execute("""UPDATE chats SET max_msg_id=?
                             WHERE account_id=? AND chat_id=?""", (mx, account_id, ch))
        files, failed = remove_media_files(files_to_remove)
        return {"ok": True, "deleted": len(rows),
                "files": files if with_media else None,
                "protected": protected, "failed": failed}
    with db() as c:
        # restore: вернуть из корзины + подтянуть недостающее из Telegram
        dw, dargs = "WHERE account_id=?", [account_id]
        if chat_id:
            dw += " AND chat_id=?"; dargs.append(chat_id)
        if frm:
            dw += " AND substr(date,1,10)>=?"; dargs.append(frm)
        if to:
            dw += " AND substr(date,1,10)<=?"; dargs.append(to)
        restored = c.execute(f"INSERT OR IGNORE INTO messages SELECT * FROM deleted {dw}",
                             dargs).rowcount
        c.execute(f"DELETE FROM deleted {dw}", dargs)
        chats = {r["chat_id"] for r in c.execute(
            "SELECT DISTINCT chat_id FROM chats WHERE account_id=?", (account_id,))}
        if chat_id:
            chats &= {chat_id}
        cleared = c.execute("""SELECT COUNT(*) FROM chats WHERE account_id=?
                               AND (?=0 OR chat_id=?) AND clear_through_msg_id>0""",
                            (account_id, chat_id, chat_id)).fetchone()[0]
        for ch in chats:
            c.execute("""UPDATE chats SET min_msg_id=0, deep_done=0,
                         clear_through_msg_id=0
                         WHERE account_id=? AND chat_id=?""", (account_id, ch))
    sync_started = bool(restored or cleared)
    if sync_started:
        start_backfill(account_id)      # и заодно дотянуть то, что появилось в Telegram
    return {"ok": True, "restored": restored, "sync_started": sync_started}


@app.get("/api/cleanup/preview")
def api_cleanup_preview(account_id: int, chat_id: int = 0,
                        from_date: str = "", to_date: str = ""):
    """Предварительный подсчёт перед удалением; диапазон всегда ограничен двумя датами."""
    if account_id <= 0 or not from_date or not to_date:
        return JSONResponse({"ok": False, "reason": "выбери аккаунт и обе даты"}, status_code=422)
    try:
        start, end = date.fromisoformat(from_date), date.fromisoformat(to_date)
    except ValueError:
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if start.isoformat() != from_date or end.isoformat() != to_date or start > end:
        return JSONResponse({"ok": False, "reason": "неверный диапазон дат"}, status_code=422)
    where, args = ["account_id=?", "substr(date,1,10)>=?", "substr(date,1,10)<=?"], [account_id, from_date, to_date]
    if chat_id:
        where.append("chat_id=?"); args.append(chat_id)
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        if chat_id and not c.execute("SELECT 1 FROM chats WHERE account_id=? AND chat_id=?",
                                     (account_id, chat_id)).fetchone():
            return JSONResponse({"ok": False, "reason": "чат не найден в этом аккаунте"}, status_code=404)
        row = c.execute(f"""SELECT COUNT(*) AS messages,
                                  SUM(CASE WHEN file_path IS NOT NULL AND file_path!='' THEN 1 ELSE 0 END) AS files
                           FROM messages WHERE {' AND '.join(where)}""", args).fetchone()
    return {"messages": row["messages"], "files": row["files"] or 0}


@app.get("/api/media")
def api_media(account_id: int, chat_id: int = 0, from_date: str = "",
              to_date: str = "", limit: int = 200, q: str = ""):
    """Список сохранённых медиа: file_path нужен кнопке просмотра файла.
    Удаление по-прежнему принимает только account_id+chat_id+msg_id — пути с клиента не приходят."""
    if account_id <= 0 or limit < 1 or limit > 500:
        return JSONResponse({"ok": False, "reason": "неверный аккаунт или размер списка"}, status_code=422)
    try:
        start = date.fromisoformat(from_date) if from_date else None
        end = date.fromisoformat(to_date) if to_date else None
    except ValueError:
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if ((start and start.isoformat() != from_date) or (end and end.isoformat() != to_date)
            or (start and end and start > end)):
        return JSONResponse({"ok": False, "reason": "неверный диапазон дат"}, status_code=422)
    where, args = ["m.account_id=?", "m.file_path IS NOT NULL", "m.file_path != ''"], [account_id]
    if q.strip():
        where.append("(contains_fold(path_basename(m.file_path),?) OR contains_fold(ch.title,?))")
        args.extend([q.strip(), q.strip()])
    if chat_id:
        where.append("m.chat_id=?"); args.append(chat_id)
    if from_date:
        where.append("substr(m.date,1,10)>=?"); args.append(from_date)
    if to_date:
        where.append("substr(m.date,1,10)<=?"); args.append(to_date)
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        rows = c.execute(f"""
            SELECT m.chat_id, m.msg_id, m.date, m.text, m.media_type, m.file_path,
                   m.file_size, path_basename(m.file_path) AS file_name, COALESCE(ch.title, 'Чат') AS chat_title
            FROM messages m LEFT JOIN chats ch
              ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
            WHERE {' AND '.join(where)}
            ORDER BY m.date DESC, m.msg_id DESC LIMIT ?""", (*args, limit + 1)).fetchall()
    return {"items": [dict(r) for r in rows[:limit]], "more": len(rows) > limit}


@app.get("/api/media/catalog")
def api_media_catalog(sort: str = "date", direction: str = "desc",
                      offset: int = 0, limit: int = 100, pending_only: bool = False, q: str = ""):
    """Global media index, paged in SQLite so large archives stay bounded in memory."""
    if sort not in ("date", "size", "name") or direction not in ("asc", "desc"):
        return JSONResponse({"ok": False, "reason": "неизвестная сортировка"}, status_code=422)
    if offset < 0 or not 1 <= limit <= 200:
        return JSONResponse({"ok": False, "reason": "неверная страница списка"}, status_code=422)
    with db() as c:
        pending_count = c.execute("""SELECT
            (SELECT COUNT(*) FROM messages WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed'))+
            (SELECT COUNT(*) FROM deleted WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed'))""",
                                 (LARGE_MEDIA_APPROVAL_BYTES, LARGE_MEDIA_APPROVAL_BYTES)).fetchone()[0]
        order_sql = {
            "date": f"date {direction.upper()}, msg_id {direction.upper()}, account_id ASC, chat_id ASC",
            "size": f"file_size {direction.upper()}, msg_id {direction.upper()}, account_id ASC, chat_id ASC",
            "name": f"file_name COLLATE NOCASE {direction.upper()}, account_id ASC, chat_id ASC, msg_id ASC",
        }[sort]
        union = """
            SELECT m.account_id,m.chat_id,m.msg_id,m.date,m.media_type,m.file_path,m.file_size,
                   m.media_approval,m.media_status,m.media_error,m.text,
                   ch.title AS chat_title,'{state}' AS record_state,
                   COALESCE(NULLIF(a.name,''),'Неизвестный аккаунт') ||
                   CASE WHEN COALESCE(a.phone,'')!='' AND a.phone!=COALESCE(a.name,'') THEN ' ('||a.phone||')'
                        WHEN COALESCE(a.username,'')!='' THEN ' (@'||a.username||')' ELSE '' END AS account_label,
                   CASE WHEN COALESCE(m.file_path,'')!=''
                        THEN path_basename(m.file_path)
                        ELSE 'Файл '||m.msg_id END AS file_name
            FROM {table} m
            LEFT JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
            LEFT JOIN accounts a ON a.id=m.account_id
            WHERE m.media_type IS NOT NULL AND COALESCE(m.media_status,'')!='dismissed'
              AND (?=0 OR (m.file_path IS NULL AND m.file_size>? AND
                  COALESCE(m.media_approval,'') NOT IN ('approved','rejected') AND
                  COALESCE(m.media_status,'') NOT IN ('unavailable','dismissed')))
        """
        cte = ("WITH catalog AS (" + union.format(state="messages", table="messages") +
               " UNION ALL " + union.format(state="deleted", table="deleted") + ") ")
        search = " WHERE contains_fold(file_name,?) OR contains_fold(chat_title,?) OR contains_fold(account_label,?)" if q.strip() else ""
        params = (int(pending_only), LARGE_MEDIA_APPROVAL_BYTES,
                  int(pending_only), LARGE_MEDIA_APPROVAL_BYTES)
        if q.strip():
            params += (q.strip(),) * 3
        count = c.execute(cte + "SELECT COUNT(*) FROM catalog" + search, params).fetchone()[0]
        rows = c.execute(cte + "SELECT * FROM catalog" + search +
                         f" ORDER BY {order_sql} LIMIT ? OFFSET ?", (*params, limit, offset)).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["file_exists"] = False
        item["partial_exists"] = False
        item["stored_size"] = 0
        if item["file_path"]:
            try:
                stored_file = safe_media_path(item["file_path"])
                item["file_exists"] = media_file_matches(item["file_path"], item["file_size"])
                if stored_file.is_file():
                    item["stored_size"] = stored_file.stat().st_size
                    item["partial_exists"] = not item["file_exists"]
                if not item["file_exists"] and not item["media_status"]:
                    item["media_status"] = "incomplete"
                    item["media_error"] = "Файл отсутствует или имеет неполный размер на диске."
            except (OSError, ValueError):
                pass
        item["file_name"] = Path(item["file_path"]).name if item["file_path"] else f"Файл {item['msg_id']}"
        if item["file_name"].endswith(".partial"):
            item["file_name"] = item["file_name"][:-len(".partial")]
        item["approval_status"] = ("deleted" if item["record_state"] == "deleted" else
                                    "saved" if item["file_exists"] else
                                    "pending" if (item["file_size"] or 0) > LARGE_MEDIA_APPROVAL_BYTES
                                    and item["media_approval"] not in ("approved", "rejected")
                                    else item["media_approval"] or "not_saved")
        items.append(item)
    return {"items": items, "more": offset + len(items) < count,
            "total": count, "pending": pending_count}


_storage_snapshot = None
_storage_snapshot_at = 0.0


def _directory_bytes(root: Path) -> int:
    """Sum regular files without following symlinks; tolerate files changing during a scan."""
    total = 0
    pending = [root]
    while pending:
        current = pending.pop()
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            pending.append(Path(entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            total += entry.stat(follow_symlinks=False).st_size
                    except OSError:
                        continue
        except OSError:
            continue
    return total


def _file_bytes(paths) -> int:
    total = 0
    for path in paths:
        try:
            if path.is_file():
                total += path.stat().st_size
        except OSError:
            continue
    return total


@app.get("/api/storage")
def api_storage(force: bool = False):
    """Disk capacity and the on-disk footprint of TG Monitor's stored data."""
    global _storage_snapshot, _storage_snapshot_at
    disk = shutil.disk_usage(BASE)
    now = time.monotonic()
    # A media archive can contain many files, so refresh its recursive size once per minute.
    if force or _storage_snapshot is None or now - _storage_snapshot_at >= 60:
        database = _file_bytes((DB_PATH, Path(str(DB_PATH) + "-wal"), Path(str(DB_PATH) + "-shm")))
        database_backups = _file_bytes(DB_PATH.parent.glob(DB_PATH.name + ".*.bak"))
        media = _directory_bytes(MEDIA)
        sessions = _directory_bytes(SESSIONS)
        _storage_snapshot = {"database_bytes": database,
                             "database_backups_bytes": database_backups,
                             "media_bytes": media,
                             "sessions_bytes": sessions,
                             "archive_bytes": database + database_backups + media + sessions}
        _storage_snapshot_at = now
    return {"disk_total_bytes": disk.total, "disk_used_bytes": disk.used,
            "disk_free_bytes": disk.free, "disk_root": str(Path(BASE.anchor)),
            "disk_warning_level": ("critical" if disk.free <= max(1024 ** 3, disk.total * 0.01)
                                   else "low" if disk.free <= max(5 * 1024 ** 3, disk.total * 0.05)
                                   else None),
            **_storage_snapshot}


@app.get("/api/media/pending/count")
def api_pending_media_count():
    with db() as c:
        count = c.execute("""SELECT
            (SELECT COUNT(*) FROM messages WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed'))+
            (SELECT COUNT(*) FROM deleted WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed'))""",
                          (LARGE_MEDIA_APPROVAL_BYTES, LARGE_MEDIA_APPROVAL_BYTES)).fetchone()[0]
    return {"pending": count}


@app.post("/api/media/approval")
async def api_media_approval(request: Request):
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        chat_id = int(body.get("chat_id", 0))
        msg_id = int(body.get("msg_id", 0))
        decision = body.get("decision")
        source = body.get("source", "messages")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if (account_id <= 0 or not chat_id or msg_id <= 0 or
            decision not in ("approved", "rejected") or source not in ("messages", "deleted")):
        return JSONResponse({"ok": False, "reason": "неверное решение или идентификатор файла"}, status_code=422)
    client = CLIENTS.get(account_id)
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg_id)) % len(MESSAGE_LOCKS)]
    async with lock:
        with db() as c:
            row = c.execute(f"""SELECT file_size,media_approval FROM {source}
                                WHERE account_id=? AND chat_id=? AND msg_id=? AND media_type IS NOT NULL""",
                            (account_id, chat_id, msg_id)).fetchone()
            if not row:
                return JSONResponse({"ok": False, "reason": "запись файла не найдена"}, status_code=404)
            if (row["file_size"] or 0) <= LARGE_MEDIA_APPROVAL_BYTES:
                return JSONResponse({"ok": False, "reason": "подтверждение требуется только для файлов больше 1 ГБ"}, status_code=422)
        if decision == "rejected":
            with db() as c:
                c.execute(f"UPDATE {source} SET media_approval='rejected' WHERE account_id=? AND chat_id=? AND msg_id=?",
                          (account_id, chat_id, msg_id))
            return {"ok": True, "decision": decision, "downloaded": False}
        telegram_message = None
        chat = None
        if client is None or not client.is_connected():
            return JSONResponse({"ok": False, "reason": "Нельзя проверить файл: аккаунт Telegram сейчас не подключён. Подключи его и повтори одобрение."}, status_code=409)
        try:
            if source == "messages":
                with db() as c:
                    chat = c.execute("SELECT title,type FROM chats WHERE account_id=? AND chat_id=?",
                                     (account_id, chat_id)).fetchone()
            telegram_message = await client.get_messages(chat_id, ids=msg_id)
        except Exception as exc:
            return JSONResponse({"ok": False, "reason": f"Не удалось проверить сообщение в Telegram: {type(exc).__name__}. Решение не сохранено."}, status_code=502)
        if telegram_message is None:
            with db() as c:
                c.execute(f"""UPDATE {source} SET media_status='unavailable',
                            media_error='Сообщение с файлом удалено или больше недоступно в Telegram.'
                            WHERE account_id=? AND chat_id=? AND msg_id=?""",
                          (account_id, chat_id, msg_id))
            return JSONResponse({"ok": False, "reason": "Файл уже удалён или недоступен в Telegram. Одобрить загрузку нельзя; запись можно убрать крестиком."}, status_code=410)
        if source == "deleted":
            return JSONResponse({"ok": False, "reason": "Запись находится в локальной корзине. Восстанови её перед одобрением файла."}, status_code=409)
        with db() as c:
            c.execute(f"UPDATE {source} SET media_approval='approved',media_status=NULL,media_error=NULL WHERE account_id=? AND chat_id=? AND msg_id=?",
                      (account_id, chat_id, msg_id))
        if source == "messages" and telegram_message and chat:
            await _store_message_locked(client, account_id, telegram_message, chat_id,
                                        chat["title"] or "Чат", chat["type"] or "user")
        with db() as c:
            saved = c.execute(f"SELECT file_path,media_status,media_error FROM {source} WHERE account_id=? AND chat_id=? AND msg_id=?",
                              (account_id, chat_id, msg_id)).fetchone()
        if source == "messages" and not (saved and saved["file_path"]):
            if saved and saved["media_status"] == "storage_full":
                return JSONResponse({"ok": False, "reason": saved["media_error"] or "Мало свободного места на диске. Освободи место и повтори."}, status_code=507)
            if saved and saved["media_status"] == "unavailable":
                return JSONResponse({"ok": False, "reason": saved["media_error"] or "Файл удалён или недоступен в Telegram."}, status_code=410)
            return JSONResponse({"ok": False, "reason": saved["media_error"] if saved else "Загрузка не завершилась."}, status_code=502)
        return {"ok": True, "decision": decision, "downloaded": bool(saved and saved["file_path"])}


@app.post("/api/media/retry")
async def api_media_retry(request: Request):
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        chat_id = int(body.get("chat_id", 0))
        msg_id = int(body.get("msg_id", 0))
        source = body.get("source", "messages")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if account_id <= 0 or not chat_id or msg_id <= 0 or source not in ("messages", "deleted"):
        return JSONResponse({"ok": False, "reason": "неверный идентификатор файла"}, status_code=422)
    if source == "deleted":
        return JSONResponse({"ok": False, "reason": "Сначала восстанови сообщение из локальной корзины."}, status_code=409)
    client = CLIENTS.get(account_id)
    if client is None or not client.is_connected():
        return JSONResponse({"ok": False, "reason": "Аккаунт Telegram отключён. Подключи его и повтори загрузку."}, status_code=409)
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg_id)) % len(MESSAGE_LOCKS)]
    async with lock:
        with db() as c:
            row = c.execute("SELECT media_type FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                            (account_id, chat_id, msg_id)).fetchone()
            chat = c.execute("SELECT title,type FROM chats WHERE account_id=? AND chat_id=?",
                             (account_id, chat_id)).fetchone()
        if not row or not row["media_type"] or not chat:
            return JSONResponse({"ok": False, "reason": "Запись медиа больше не найдена."}, status_code=404)
        try:
            telegram_message = await client.get_messages(chat_id, ids=msg_id)
        except Exception as exc:
            return JSONResponse({"ok": False, "reason": f"Не удалось проверить сообщение в Telegram: {type(exc).__name__}."}, status_code=502)
        if telegram_message is None:
            with db() as c:
                c.execute("""UPDATE messages SET media_status='unavailable',
                            media_error='Сообщение с файлом удалено или больше недоступно в Telegram.'
                            WHERE account_id=? AND chat_id=? AND msg_id=?""",
                          (account_id, chat_id, msg_id))
            return JSONResponse({"ok": False, "reason": "Сообщение с файлом удалено или недоступно в Telegram. Запись можно убрать крестиком."}, status_code=410)
        with db() as c:
            c.execute("UPDATE messages SET media_status=NULL,media_error=NULL WHERE account_id=? AND chat_id=? AND msg_id=? AND media_status='dismissed'",
                      (account_id,chat_id,msg_id))
        await _store_message_locked(client, account_id, telegram_message, chat_id,
                                    chat["title"] or "Чат", chat["type"] or "user")
        with db() as c:
            result = c.execute("SELECT file_path,media_status,media_error,file_size FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                               (account_id, chat_id, msg_id)).fetchone()
        if result and result["file_path"] and media_file_matches(result["file_path"], result["file_size"]):
            return {"ok": True, "downloaded": True}
        if result and result["media_status"] == "storage_full":
            return JSONResponse({"ok": False, "reason": result["media_error"] or "Мало свободного места на диске."}, status_code=507)
        return JSONResponse({"ok": False, "reason": result["media_error"] if result else "Загрузка не завершилась."}, status_code=502)


@app.post("/api/media/dismiss")
async def api_media_dismiss(request: Request):
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        chat_id = int(body.get("chat_id", 0))
        msg_id = int(body.get("msg_id", 0))
        source = body.get("source", "messages")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if account_id <= 0 or not chat_id or msg_id <= 0 or source not in ("messages", "deleted"):
        return JSONResponse({"ok": False, "reason": "неверный идентификатор файла"}, status_code=422)
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg_id)) % len(MESSAGE_LOCKS)]
    async with lock:
        with db() as c:
            cur = c.execute(f"""UPDATE {source} SET media_status='dismissed',
                         media_approval=CASE WHEN coalesce(file_size,0)>? THEN 'rejected' ELSE media_approval END
                         WHERE account_id=? AND chat_id=? AND msg_id=? AND media_type IS NOT NULL""",
                            (LARGE_MEDIA_APPROVAL_BYTES, account_id, chat_id, msg_id))
        if not cur.rowcount:
            return JSONResponse({"ok": False, "reason": "Запись медиа не найдена."}, status_code=404)
        with db() as c:
            c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?",(account_id,chat_id,msg_id))
    return {"ok": True}


@app.post("/api/media/delete")
async def api_media_delete(request: Request):
    """Удалить выбранные медиа, сохранив сообщения; клиент не задаёт пути на диске."""
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        items = body.get("items")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if account_id <= 0 or not isinstance(items, list) or not 1 <= len(items) <= 500:
        return JSONResponse({"ok": False, "reason": "выбери от 1 до 500 файлов"}, status_code=422)
    selected = []
    try:
        for item in items:
            if not isinstance(item, dict):
                raise ValueError
            chat_id, msg_id = int(item["chat_id"]), int(item["msg_id"])
            source = item.get("source", "messages")
            if msg_id <= 0 or source not in ("messages", "deleted"):
                raise ValueError
            selected.append((chat_id, msg_id, source))
    except (KeyError, ValueError, TypeError):
        return JSONResponse({"ok": False, "reason": "неверный идентификатор файла"}, status_code=422)
    if len(set(selected)) != len(selected):
        return JSONResponse({"ok": False, "reason": "в запросе есть повторяющиеся файлы"}, status_code=422)

    files_removed = detached = failed = 0
    media_root = MEDIA.resolve()
    paths_to_remove = []
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        rows = []
        for chat_id, msg_id, source in selected:
            row = c.execute(f"""SELECT file_path,media_type FROM {source}
                               WHERE account_id=? AND chat_id=? AND msg_id=?""",
                            (account_id, chat_id, msg_id)).fetchone()
            if not row or not row["media_type"]:
                return JSONResponse({"ok": False, "reason": "одно из вложений уже удалено или не найдено"}, status_code=404)
            full = None
            if row["file_path"]:
                try:
                    full = safe_media_path(row["file_path"])
                    full.relative_to(media_root)
                except (ValueError, OSError):
                    return JSONResponse({"ok": False, "reason": "путь вложения вне каталога медиа"}, status_code=409)
            rows.append((source, chat_id, msg_id, row["file_path"], full))

        selected_keys = {(source, account_id, chat_id, msg_id) for chat_id, msg_id, source in selected}
        by_path = {}
        for source, chat_id, msg_id, rel_path, full in rows:
            if rel_path:
                by_path.setdefault(rel_path, {"full": full, "selected": set()})["selected"].add(
                    (source, account_id, chat_id, msg_id))
        safe_to_remove = set()
        for rel_path, info in by_path.items():
            refs = c.execute("""SELECT 'messages' AS source,account_id,chat_id,msg_id FROM messages WHERE file_path=?
                               UNION ALL
                               SELECT 'deleted' AS source,account_id,chat_id,msg_id FROM deleted WHERE file_path=?""",
                             (rel_path, rel_path)).fetchall()
            if all((r["source"], r["account_id"], r["chat_id"], r["msg_id"]) in selected_keys for r in refs):
                safe_to_remove.add(rel_path)

        # Сначала фиксируем отвязку в БД. Если транзакция не сохранится,
        # физические файлы останутся нетронутыми.
        for rel_path in safe_to_remove:
            paths_to_remove.append((rel_path, by_path[rel_path]["full"]))
        for source, chat_id, msg_id, rel_path, _ in rows:
            c.execute("INSERT OR IGNORE INTO media_suppression VALUES(?,?,?)",(account_id,chat_id,msg_id))
            c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?",(account_id,chat_id,msg_id))
            cur = c.execute(f"""UPDATE {source} SET file_path=NULL,media_type=NULL,file_size=NULL,media_approval=NULL,
                                media_id=NULL,media_status=NULL,media_error=NULL
                                WHERE account_id=? AND chat_id=? AND msg_id=?""",
                            (account_id, chat_id, msg_id))
            detached += cur.rowcount

    # После успешного коммита можно удалять физические файлы. Ошибка диска
    # отражается как частичный результат, а не как общий сбой после удаления.
    for _, full in paths_to_remove:
        try:
            existed = full.is_file()
            full.unlink(missing_ok=True)
            files_removed += int(existed)
        except OSError:
            failed += 1
    protected = sum(1 for _, _, _, rel_path, _ in rows if rel_path and rel_path not in safe_to_remove)
    return {"ok": True, "files": files_removed, "detached": detached,
            "protected": protected, "failed": failed}


@app.get("/api/reveal")
def api_reveal(path: str):
    """Показать файл в Проводнике (документы в чате). Только внутри media/."""
    path = (path or "").lstrip("/\\")        # браузер шлёт путь с ведущим слэшем
    try:
        full = (BASE / path).resolve()
        full.relative_to(MEDIA.resolve())      # путь вне хранилища — отказ
    except (ValueError, OSError):
        return {"ok": False, "reason": "путь вне хранилища"}
    if not full.exists():
        return {"ok": False, "reason": "файл не найден на диске"}
    try:
        if sys.platform != "win32":
            return {"ok": False, "reason": "открытие папки доступно только на Windows-панели"}

        # SHOpenFolderAndSelectItems opens/activates the containing folder and
        # selects the exact file. Explorer's command-line /select handling can
        # reuse a background window and silently skip the selection.
        import ctypes
        from ctypes import wintypes

        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        ole32 = ctypes.WinDLL("ole32", use_last_error=True)
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        shell32.SHParseDisplayName.argtypes = [
            wintypes.LPCWSTR, ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_void_p), wintypes.DWORD,
            ctypes.POINTER(wintypes.DWORD),
        ]
        shell32.SHParseDisplayName.restype = ctypes.c_long
        shell32.ILFindLastID.argtypes = [ctypes.c_void_p]
        shell32.ILFindLastID.restype = ctypes.c_void_p
        shell32.SHOpenFolderAndSelectItems.argtypes = [
            ctypes.c_void_p, wintypes.UINT,
            ctypes.POINTER(ctypes.c_void_p), wintypes.DWORD,
        ]
        shell32.SHOpenFolderAndSelectItems.restype = ctypes.c_long
        shell32.ShellExecuteW.argtypes = [
            wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR,
            wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.c_int,
        ]
        shell32.ShellExecuteW.restype = ctypes.c_void_p
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        ole32.CoTaskMemFree.restype = None
        ole32.CoInitializeEx.argtypes = [ctypes.c_void_p, wintypes.DWORD]
        ole32.CoInitializeEx.restype = ctypes.c_long
        ole32.CoUninitialize.argtypes = []
        ole32.CoUninitialize.restype = None
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetClassNameW.restype = ctypes.c_int
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.ShowWindow.restype = wintypes.BOOL
        user32.IsZoomed.argtypes = [wintypes.HWND]
        user32.IsZoomed.restype = wintypes.BOOL
        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        user32.SetForegroundWindow.restype = wintypes.BOOL
        user32.BringWindowToTop.argtypes = [wintypes.HWND]
        user32.BringWindowToTop.restype = wintypes.BOOL
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetWindowTextW.restype = ctypes.c_int
        user32.IsWindowVisible.argtypes = [wintypes.HWND]
        user32.IsWindowVisible.restype = wintypes.BOOL
        enum_windows_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows.argtypes = [enum_windows_proc, wintypes.LPARAM]
        user32.EnumWindows.restype = wintypes.BOOL
        user32.SetActiveWindow.argtypes = [wintypes.HWND]
        user32.SetActiveWindow.restype = wintypes.HWND
        user32.SetFocus.argtypes = [wintypes.HWND]
        user32.SetFocus.restype = wintypes.HWND
        user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        user32.AttachThreadInput.restype = wintypes.BOOL
        user32.SwitchToThisWindow.argtypes = [wintypes.HWND, wintypes.BOOL]
        user32.SwitchToThisWindow.restype = None
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetCurrentThreadId.restype = wintypes.DWORD
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD

        # FastAPI runs sync handlers on worker threads. Initialize COM on the
        # current thread before calling the Shell namespace APIs.
        co_hr = ole32.CoInitializeEx(None, 2)  # COINIT_APARTMENTTHREADED
        com_initialized_here = co_hr in (0, 1)  # S_OK / S_FALSE
        if co_hr < 0 and co_hr != -2147417850:  # RPC_E_CHANGED_MODE: already initialized
            raise OSError(f"Не удалось инициализировать Windows Shell (HRESULT {co_hr:#x})")
        try:
            folder_pidl = ctypes.c_void_p()
            file_pidl = ctypes.c_void_p()
            hr = shell32.SHParseDisplayName(str(full.parent), None, ctypes.byref(folder_pidl), 0, None)
            if hr < 0:
                raise OSError(f"Не удалось открыть папку (HRESULT {hr:#x})")
            try:
                hr = shell32.SHParseDisplayName(str(full), None, ctypes.byref(file_pidl), 0, None)
                if hr < 0:
                    raise OSError(f"Не удалось найти файл (HRESULT {hr:#x})")
                try:
                    child_pidl = shell32.ILFindLastID(file_pidl)
                    child_items = (ctypes.c_void_p * 1)(child_pidl)
                    hr = shell32.SHOpenFolderAndSelectItems(folder_pidl, 1, child_items, 0)
                    if hr < 0:
                        raise OSError(f"Проводник не смог выделить файл (HRESULT {hr:#x})")
                finally:
                    ole32.CoTaskMemFree(file_pidl)
            finally:
                ole32.CoTaskMemFree(folder_pidl)
        finally:
            if com_initialized_here:
                ole32.CoUninitialize()

        # Prefer the activated Explorer frame. If Windows opened it without
        # activating it, find the frame for this folder by its window title.
        hwnd = None
        for _ in range(15):
            candidate = user32.GetForegroundWindow()
            class_name = ctypes.create_unicode_buffer(64)
            title = ctypes.create_unicode_buffer(512)
            if candidate and user32.GetClassNameW(candidate, class_name, len(class_name)) \
                    and class_name.value in {"CabinetWClass", "ExploreWClass"}:
                user32.GetWindowTextW(candidate, title, len(title))
            if (candidate and class_name.value in {"CabinetWClass", "ExploreWClass"}
                    and title.value.casefold().startswith(full.parent.name.casefold())):
                hwnd = candidate
                break
            matches = []
            @enum_windows_proc
            def collect_explorer(window, _):
                window_class = ctypes.create_unicode_buffer(64)
                title = ctypes.create_unicode_buffer(512)
                user32.GetClassNameW(window, window_class, len(window_class))
                user32.GetWindowTextW(window, title, len(title))
                if (user32.IsWindowVisible(window)
                        and window_class.value in {"CabinetWClass", "ExploreWClass"}
                        and title.value.casefold().startswith(full.parent.name.casefold())):
                    matches.append(window)
                return True
            user32.EnumWindows(collect_explorer, 0)
            if matches:
                hwnd = matches[-1]
                break
            time.sleep(0.1)
        if not hwnd:
            # Some Windows builds acknowledge SHOpenFolderAndSelectItems but
            # leave the requester's Explorer frame in the background. Launch
            # a maximized selection request through the shell as a fallback.
            args = f'/n,/select,"{full}"'
            result = shell32.ShellExecuteW(None, "open", "explorer.exe", args, str(full.parent), 3)
            if not result or result <= 32:
                raise OSError(f"Windows не смог запустить Проводник (код {result or 0})")
            for _ in range(25):
                candidate = user32.GetForegroundWindow()
                class_name = ctypes.create_unicode_buffer(64)
                title = ctypes.create_unicode_buffer(512)
                if candidate and user32.GetClassNameW(candidate, class_name, len(class_name)) \
                        and class_name.value in {"CabinetWClass", "ExploreWClass"}:
                    user32.GetWindowTextW(candidate, title, len(title))
                    if title.value.casefold().startswith(full.parent.name.casefold()):
                        hwnd = candidate
                        break
                matches = []
                @enum_windows_proc
                def collect_shell_window(window, _):
                    window_class = ctypes.create_unicode_buffer(64)
                    title = ctypes.create_unicode_buffer(512)
                    user32.GetClassNameW(window, window_class, len(window_class))
                    user32.GetWindowTextW(window, title, len(title))
                    if (user32.IsWindowVisible(window)
                            and window_class.value in {"CabinetWClass", "ExploreWClass"}
                            and title.value.casefold().startswith(full.parent.name.casefold())):
                        matches.append(window)
                    return True
                user32.EnumWindows(collect_shell_window, 0)
                if matches:
                    hwnd = matches[-1]
                    break
                time.sleep(0.1)
        foreground = False
        maximized = False
        if hwnd:
            user32.BringWindowToTop(hwnd)
            current_thread = kernel32.GetCurrentThreadId()
            active_window = user32.GetForegroundWindow()
            active_thread = user32.GetWindowThreadProcessId(active_window, None) if active_window else 0
            attached = bool(active_thread and active_thread != current_thread
                            and user32.AttachThreadInput(current_thread, active_thread, True))
            try:
                user32.SetForegroundWindow(hwnd)
                user32.SetActiveWindow(hwnd)
                user32.SetFocus(hwnd)
                user32.SwitchToThisWindow(hwnd, True)
            finally:
                if attached:
                    user32.AttachThreadInput(current_thread, active_thread, False)
            for _ in range(8):
                user32.ShowWindow(hwnd, 3)  # SW_SHOWMAXIMIZED, after activation
                if user32.IsZoomed(hwnd):
                    break
                time.sleep(0.1)
            for _ in range(10):
                if user32.GetForegroundWindow() == hwnd:
                    foreground = True
                    break
                time.sleep(0.05)
            maximized = bool(user32.IsZoomed(hwnd))
        if not foreground or not maximized:
            # Explorer is an out-of-process shell window. A short-lived
            # PowerShell helper running in the same interactive session can
            # activate and maximize it even when the API worker has no input
            # queue attached to the user's foreground desktop.
            import base64
            import subprocess
            title_b64 = base64.b64encode(full.parent.name.encode("utf-8")).decode("ascii")
            ps = f'''
$title = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{title_b64}'))
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class TgMonitorExplorerActivation {{
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern void SwitchToThisWindow(IntPtr h, bool altTab);
}}
'@
$target = Get-Process explorer -ErrorAction SilentlyContinue | Where-Object {{
  $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle.StartsWith($title, [StringComparison]::OrdinalIgnoreCase)
}} | Select-Object -Last 1
if (-not $target) {{ exit 2 }}
[void][TgMonitorExplorerActivation]::ShowWindow($target.MainWindowHandle, 3)
[void][TgMonitorExplorerActivation]::BringWindowToTop($target.MainWindowHandle)
[void][TgMonitorExplorerActivation]::SetForegroundWindow($target.MainWindowHandle)
[TgMonitorExplorerActivation]::SwitchToThisWindow($target.MainWindowHandle, $true)
Start-Sleep -Milliseconds 150
if ([TgMonitorExplorerActivation]::IsZoomed($target.MainWindowHandle) -and
    [TgMonitorExplorerActivation]::GetForegroundWindow() -eq $target.MainWindowHandle) {{ exit 0 }}
if ([TgMonitorExplorerActivation]::IsZoomed($target.MainWindowHandle)) {{ exit 4 }}
exit 3
'''
            encoded_ps = base64.b64encode(ps.encode("utf-16le")).decode("ascii")
            try:
                helper = subprocess.run(
                    ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive",
                     "-WindowStyle", "Hidden", "-EncodedCommand", encoded_ps],
                    capture_output=True, timeout=8,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if helper.returncode == 0:
                    foreground = maximized = True
                elif helper.returncode == 4:
                    maximized = True
            except (OSError, subprocess.TimeoutExpired):
                pass
        return {"ok": True, "foreground": foreground, "maximized": maximized}
    except Exception as exc:
        return {"ok": False, "reason": f"Не удалось открыть файл в Проводнике: {exc}"}


@app.get("/api/chats")
def api_chats(account_id: int):
    with db() as c:
        rows = c.execute("""
            SELECT ch.chat_id, ch.title, ch.type, COUNT(m.msg_id) AS n, MAX(m.date) AS last,
                   (SELECT CASE WHEN COALESCE(latest.text,'') != ''
                                THEN substr(latest.text,1,60)
                                WHEN COALESCE(latest.media_type,'') != ''
                                THEN '[' || latest.media_type || ']'
                                ELSE '' END
                    FROM messages latest
                    WHERE latest.account_id=ch.account_id AND latest.chat_id=ch.chat_id
                    ORDER BY latest.date DESC, latest.msg_id DESC LIMIT 1) AS preview
            FROM chats ch JOIN messages m ON m.account_id = ch.account_id
                         AND m.chat_id = ch.chat_id
            WHERE ch.account_id = ?
            GROUP BY ch.chat_id ORDER BY last DESC""", (account_id,)).fetchall()
        return [dict(r) for r in rows]


@app.get("/api/cleanup/chats")
def api_cleanup_chats(account_id: int):
    """All known chats, including empty ones that can be restored after full cleanup."""
    if account_id <= 0:
        return JSONResponse({"ok": False, "reason": "неверный аккаунт"}, status_code=422)
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        rows = c.execute("""SELECT ch.chat_id, ch.title, COUNT(m.msg_id) AS n
                            FROM chats ch LEFT JOIN messages m
                              ON m.account_id=ch.account_id AND m.chat_id=ch.chat_id
                            WHERE ch.account_id=? GROUP BY ch.chat_id,ch.title
                            ORDER BY ch.title""", (account_id,)).fetchall()
        return [dict(r) for r in rows]


@app.get("/api/messages")
def api_messages(account_id: int, chat_id: int, limit: int = 200,
                 q: str = "", before_msg_id: int = 0, around_msg_id: int = 0):
    if account_id <= 0 or not 1 <= limit <= 1000 or before_msg_id < 0 or around_msg_id < 0:
        return JSONResponse({"ok": False, "reason": "неверный account_id, limit или курсор"}, status_code=422)
    q = q.strip()
    if len(q) > 200:
        return JSONResponse({"ok": False, "reason": "поисковый запрос слишком длинный"}, status_code=422)
    sql = """SELECT m.msg_id,m.date,m.sender_id,m.out,m.text,m.media_type,m.file_path,
                    m.media_status,m.media_error,
                    ch.type AS chat_type,p.username AS sender_username,p.phone AS sender_phone,
                    p.display_name AS sender_display_name,p.title AS sender_title
             FROM messages m
             LEFT JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
             LEFT JOIN participants p ON p.account_id=m.account_id AND p.user_id=m.sender_id
             WHERE m.account_id=? AND m.chat_id=?"""
    params = [account_id, chat_id]
    if before_msg_id:
        sql += " AND m.msg_id < ?"
        params.append(before_msg_id)
    if q:                               # поиск по буквальному фрагменту текста
        literal = q.replace("!", "!!").replace("%", "!%").replace("_", "!_")
        sql += " AND m.text LIKE ? ESCAPE '!'"
        params.append(f"%{literal}%")
    sql += " ORDER BY m.msg_id DESC LIMIT ?"
    params.append(min(limit, 1000))
    with db() as c:
        if around_msg_id:
            base = sql.rsplit(" ORDER BY", 1)[0]
            base_params = params[:-1]
            before = c.execute(base + " AND m.msg_id<=? ORDER BY m.msg_id DESC LIMIT 100",
                               (*base_params, around_msg_id)).fetchall()
            after = c.execute(base + " AND m.msg_id>? ORDER BY m.msg_id ASC LIMIT 100",
                              (*base_params, around_msg_id)).fetchall()
            rows = sorted([*before, *after], key=lambda r: r["msg_id"])
        else:
            rows = c.execute(sql, params).fetchall()
        result = []
        for row in (rows if around_msg_id else reversed(rows)):
            item = dict(row)
            profile = {
                "username": item.pop("sender_username"),
                "phone": item.pop("sender_phone"),
                "display_name": item.pop("sender_display_name"),
                "title": item.pop("sender_title"),
            }
            if any(profile.values()):
                item["sender_label"] = participant_label(item["sender_id"], profile)
            else:
                item["sender_label"] = None
            result.append(item)
        return result


@app.get("/api/search")
def api_search(q: str, account_id: int = 0):
    q = q.strip()
    if not 2 <= len(q) <= 200 or account_id < 0:
        return JSONResponse({"ok": False, "reason": "запрос должен быть длиной 2–200 символов"}, status_code=422)
    literal = q.replace("!", "!!").replace("%", "!%").replace("_", "!_")
    needle = f"%{literal}%"
    sql = """SELECT m.account_id, m.chat_id, m.msg_id, m.date, m.out, m.text,
                    m.media_type, ch.title AS chat,
                    COALESCE(NULLIF(a.name,''),'Неизвестный аккаунт') ||
                    CASE WHEN COALESCE(a.phone,'')!='' AND a.phone!=COALESCE(a.name,'') THEN ' ('||a.phone||')'
                         WHEN COALESCE(a.username,'')!='' THEN ' (@'||a.username||')' ELSE '' END AS account
             FROM messages m
             JOIN chats ch ON ch.account_id = m.account_id AND ch.chat_id = m.chat_id
             JOIN accounts a ON a.id = m.account_id
             WHERE m.text LIKE ? ESCAPE '!' """
    params = [needle]
    if account_id:
        sql += "AND m.account_id = ? "
        params.append(account_id)
    sql += "ORDER BY m.date DESC LIMIT 50"
    with db() as c:
        return [dict(r) for r in c.execute(sql, params).fetchall()]


@app.on_event("startup")
async def on_startup():
    acquire_archive_lock()
    init_db()
    with db() as c:   # служебный чат Telegram не храним никогда
        c.execute("DELETE FROM messages WHERE chat_id=?", (SERVICE_CHAT,))
        c.execute("DELETE FROM chats WHERE chat_id=?", (SERVICE_CHAT,))
        # линковки, оборвавшиеся с прошлым прогоном панели, — убираем с сессиями
        pending = c.execute("SELECT id FROM accounts WHERE status='linking'").fetchall()
        for r in pending:
            (SESSIONS / f"account_{r['id']}.session").unlink(missing_ok=True)
            c.execute("DELETE FROM participants WHERE account_id=?", (r["id"],))
        c.execute("DELETE FROM accounts WHERE status='linking'")
    restore_cached_identities()
    with db() as c:
        for table in ("messages", "deleted"):
            c.execute(f"""UPDATE {table} SET media_status='incomplete',
                       media_error='Загрузка была прервана остановкой приложения.'
                       WHERE media_status='downloading'""")
    # Существующие пути обновляем до запуска записывателей, чтобы файлы не дублировались.
    await asyncio.to_thread(migrate_media_paths)
    await asyncio.to_thread(ensure_known_chat_dirs)
    # Link legacy temporary downloads to their message records instead of leaving
    # them as untracked files after an abrupt stop.
    await asyncio.to_thread(recover_orphaned_media_parts)
    # Не считаем сканирование завершённым, пока связанное с сообщениями медиа
    # отсутствует на диске или явно оборвано по размеру.
    await asyncio.to_thread(reset_incomplete_media_chats)
    try:
        await write_call(replay_ingest_spool)
    except Exception as exc:
        print(f"[ingest-replay] startup deferred: {exc}")
    ARCHIVE_WORKERS.extend(asyncio.create_task(archive_job_worker()) for _ in range(3))
    ARCHIVE_WORKERS.append(asyncio.create_task(ingest_maintenance()))
    # поднимаем записыватели всех активных аккаунтов (спящие и отключённые не трогаем)
    with db() as c:
        ids = [r["id"] for r in c.execute(
            "SELECT id FROM accounts WHERE status NOT IN ('paused','disconnected','linking')"
        ).fetchall()]
    for account_id in ids:
        start_recorder(account_id)
    print(f"TG Monitor: http://{HOST}:{PORT}  |  аккаунтов поднято: {len(ids)}")


@app.on_event("shutdown")
async def on_shutdown():
    # Cancel transfers before closing sessions so partial downloads keep their SQL paths.
    tasks = set(ARCHIVE_WORKERS) | {state["task"] for collection in (REC, BACKFILL) for state in collection.values()
             if state.get("task") and not state["task"].done()}
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    ARCHIVE_WORKERS.clear()
    clients = set(CLIENTS.values())
    clients.update(flow["client"] for collection in (FLOWS, PHONE_FLOWS)
                   for flow in collection.values() if flow.get("client"))
    for client in clients:
        try:
            await client.disconnect()
            client.session.close()
        except Exception:
            pass
    await stop_ingest()
    with db() as c:
        c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    release_archive_lock()


if __name__ == "__main__":
    uvicorn.run(app, host=HOST, port=PORT, log_level="warning")

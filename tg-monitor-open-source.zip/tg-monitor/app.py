# -*- coding: utf-8 -*-
"""
TG Monitor — мультисчётный архив Telegram с веб-панелью.

Один процесс держит все аккаунты (Telethon, отдельная сессия на аккаунт),
пишет всё в общую базу monitor.db, отдаёт веб-панель на http://host:port.

Подключение нового аккаунта: кнопка в панели -> QR -> телефон сканирует.
Запуск:  python app.py   (или start_monitor.bat)
"""
import asyncio
import configparser
import hashlib
import io
import json
import mimetypes
import os
import re
import secrets
import shutil
import sqlite3
import sys
import time
import threading
import unicodedata
from collections import OrderedDict, deque
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timezone
from pathlib import Path
from types import SimpleNamespace

# On some Windows installations Python's MIME registry scan stalls for minutes.
# Telethon initializes mimetypes during import; the built-in MIME table is enough here.
if sys.platform == "win32":
    _read_registry = mimetypes.MimeTypes.read_windows_registry
    try:
        mimetypes.MimeTypes.read_windows_registry = lambda self, strict=True: None
        mimetypes.init()
    finally:
        mimetypes.MimeTypes.read_windows_registry = _read_registry

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response, FileResponse
from fastapi.staticfiles import StaticFiles
from telethon import TelegramClient, events
from telethon.errors import FloodWaitError, SessionPasswordNeededError, PasswordHashInvalidError
from telethon.errors import UnauthorizedError, AuthKeyDuplicatedError
from telethon.tl.functions.auth import CancelCodeRequest, ResendCodeRequest
from telethon.tl import types as tg_types
from telethon.tl.custom.file import File as TelethonFile
from telethon import utils as tg_utils
from telethon.crypto import aes as telegram_aes

# Telethon asks Telegram for 128 KB at a time for files up to 100 MB, so a file costs one
# round trip per 128 KB. 512 KB, the largest part Telegram serves, needs four times fewer.
tg_utils.get_appropriated_part_size = lambda file_size: 512
import qrcode

APP_VERSION = "1.2.30"
RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
DEFAULT_HOME = Path(sys.executable).resolve().parent / "data" if getattr(sys, "frozen", False) else RESOURCE_ROOT
BASE = Path(os.environ.get("TG_MONITOR_HOME", DEFAULT_HOME)).expanduser().resolve()
BASE.mkdir(parents=True, exist_ok=True)
_cfg = configparser.ConfigParser(interpolation=None)
if not _cfg.read(BASE / "config.ini", encoding="utf-8"):
    raise SystemExit("Не найден config.ini. Запустите start_monitor.bat для настройки.")
API_ID = _cfg.get("telegram", "api_id", fallback="").strip()
API_HASH = _cfg.get("telegram", "api_hash", fallback="").strip()
if not API_ID.isdecimal() or int(API_ID or 0) <= 0 or not re.fullmatch(r"[0-9a-fA-F]{32}", API_HASH):
    raise SystemExit("Укажите корректные Telegram api_id и api_hash в config.ini.")
HOST = _cfg.get("server", "host", fallback="127.0.0.1")
PORT = _cfg.getint("server", "port", fallback=8090)
MAX_MB = _cfg.getint("archive", "max_media_mb", fallback=1024)
LARGE_MEDIA_APPROVAL_BYTES = 1024 ** 3
MIN_FREE_MEDIA_SPACE_BYTES = 1024 ** 3
# A file is fetched part after part, each part a round trip to Telegram, so throughput
# comes from several files at once rather than from bandwidth.
MAX_CONCURRENT_MEDIA_DOWNLOADS = 12
MAX_MEDIA_DOWNLOADS_PER_ACCOUNT = 6
PANEL_PASSWORD = _cfg.get("security", "panel_password", fallback="").strip()

DB_PATH = BASE / "monitor.db"
SESSIONS = BASE / "sessions"; SESSIONS.mkdir(exist_ok=True)
MEDIA = BASE / "media"; MEDIA.mkdir(exist_ok=True)
FRONTEND = RESOURCE_ROOT / "frontend"

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

EXT_FALLBACK = {"photo": ".jpg", "voice": ".ogg", "video": ".mp4",
                "audio": ".mp3", "document": ".bin"}


# ---------- база ----------

from contextlib import closing, contextmanager, asynccontextmanager

_DB_WRITER_LOCAL = threading.local()
_DB_EXECUTOR = None


def _open_db(timeout):
    c = sqlite3.connect(DB_PATH, timeout=timeout, cached_statements=256)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA recursive_triggers=ON')
    c.create_function("path_basename", 1, lambda value: Path(value).name if value else "")
    c.create_function("contains_fold", 2, lambda value, needle: int(str(needle).casefold() in str(value or "").casefold()), deterministic=True)
    return c


@contextmanager
def db(timeout=30):
    """Only the dedicated writer reuses a thread-owned connection; readers close theirs."""
    persistent = bool(getattr(_DB_WRITER_LOCAL, "enabled", False)
                      and not getattr(_DB_WRITER_LOCAL, "depth", 0))
    if persistent:
        c = getattr(_DB_WRITER_LOCAL, "connection", None)
        if c is not None and _DB_WRITER_LOCAL.path != str(DB_PATH):
            c.close()
            c = None
            _DB_WRITER_LOCAL.connection = None
        if c is None:
            c = _open_db(timeout)
            c.execute("PRAGMA synchronous=FULL")
            _DB_WRITER_LOCAL.connection = c
            _DB_WRITER_LOCAL.timeout = timeout
            _DB_WRITER_LOCAL.path = str(DB_PATH)
        elif _DB_WRITER_LOCAL.timeout != timeout:
            c.execute(f"PRAGMA busy_timeout={max(0, int(timeout * 1000))}")
            _DB_WRITER_LOCAL.timeout = timeout
        _DB_WRITER_LOCAL.depth = 1
    else:
        c = _open_db(timeout)
    try:
        yield c
        c.commit()
    except BaseException:
        try:
            c.rollback()
        except Exception:
            if persistent:
                _DB_WRITER_LOCAL.connection = None
                c.close()
        raise
    finally:
        if persistent:
            _DB_WRITER_LOCAL.depth = 0
        else:
            c.close()


def init_db():
    with db() as c:
        c.execute("PRAGMA journal_mode=WAL")   # один раз при старте, не на каждое соединение
        c.executescript("""
        CREATE TABLE IF NOT EXISTS accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_user_id INTEGER,
            name TEXT DEFAULT 'Новый аккаунт',
            username TEXT,
            phone TEXT,
            status TEXT DEFAULT 'linking',   -- linking|recording|paused|reconnecting|error
            added_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS chats(
            account_id INTEGER NOT NULL,
            chat_id INTEGER NOT NULL,
            title TEXT,
            type TEXT,
            max_msg_id INTEGER DEFAULT 0,
            min_msg_id INTEGER DEFAULT 0,
            deep_done INTEGER DEFAULT 0,
            clear_through_msg_id INTEGER DEFAULT 0,
            PRIMARY KEY(account_id, chat_id)
        );
        CREATE TABLE IF NOT EXISTS messages(
            account_id INTEGER NOT NULL,
            chat_id INTEGER NOT NULL,
            msg_id INTEGER NOT NULL,
            date TEXT,
            sender_id INTEGER,
            out INTEGER,
            text TEXT,
            media_type TEXT,
            file_path TEXT,
            file_size INTEGER,
            media_approval TEXT,
            media_id INTEGER,
            media_status TEXT,
            media_error TEXT,
            PRIMARY KEY(account_id, chat_id, msg_id)
        );
        CREATE TABLE IF NOT EXISTS participants(
            account_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            username TEXT,
            phone TEXT,
            display_name TEXT,
            title TEXT,
            kind TEXT,
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            PRIMARY KEY(account_id, user_id)
        );
        CREATE INDEX IF NOT EXISTS idx_participants_username
            ON participants(account_id, username);
        CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER,
            time TEXT,
            kind TEXT,     -- login | logout | revoked
            note TEXT
        );
        CREATE TABLE IF NOT EXISTS deleted(   -- «корзина»: удалённые вручную сообщения
            account_id INTEGER NOT NULL,      -- хранятся ЦЕЛИКОМ (текст, медиа-путь);
            chat_id INTEGER NOT NULL,         -- авто-догонка их обходит, «Восстановить»
            msg_id INTEGER NOT NULL,          -- возвращает из корзины + подтягивает из TG
            date TEXT,
            sender_id INTEGER,
            out INTEGER,
            text TEXT,
            media_type TEXT,
            file_path TEXT,
            file_size INTEGER,
            media_approval TEXT,
            media_id INTEGER,
            media_status TEXT,
            media_error TEXT,
            PRIMARY KEY(account_id, chat_id, msg_id)
        );
        CREATE INDEX IF NOT EXISTS idx_msg_date ON messages(date);
        CREATE INDEX IF NOT EXISTS idx_msg_account ON messages(account_id);
        CREATE TABLE IF NOT EXISTS archive_jobs(
            account_id INTEGER NOT NULL, chat_id INTEGER NOT NULL, msg_id INTEGER NOT NULL,
            token TEXT NOT NULL, payload TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
            next_attempt REAL NOT NULL DEFAULT 0, error TEXT,
            PRIMARY KEY(account_id,chat_id,msg_id)
        );
        CREATE INDEX IF NOT EXISTS idx_archive_jobs_due ON archive_jobs(next_attempt);
        CREATE INDEX IF NOT EXISTS idx_archive_jobs_account_due ON archive_jobs(account_id,next_attempt);
        CREATE INDEX IF NOT EXISTS idx_archive_jobs_stats ON archive_jobs(account_id,attempts);
        CREATE TABLE IF NOT EXISTS history_pending(
            account_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
            title TEXT NOT NULL, type TEXT NOT NULL,
            forward_only INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(account_id,chat_id)
        );
        """)
        # Small durable progress metadata; never recount the archive during polling.
        c.executescript("""
        CREATE TABLE IF NOT EXISTS history_progress(
            account_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
            total INTEGER, saved INTEGER, complete INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(account_id,chat_id));
        CREATE TABLE IF NOT EXISTS history_progress_plan(
            account_id INTEGER PRIMARY KEY, discovered INTEGER NOT NULL DEFAULT 0);
        CREATE TRIGGER IF NOT EXISTS tg_history_progress_insert AFTER INSERT ON messages BEGIN
            UPDATE history_progress SET saved=saved+1,total=CASE WHEN complete=1 THEN total+1 ELSE total END
            WHERE account_id=NEW.account_id AND chat_id=NEW.chat_id AND saved IS NOT NULL;
        END;
        CREATE TRIGGER IF NOT EXISTS tg_history_progress_delete AFTER DELETE ON messages BEGIN
            UPDATE history_progress SET saved=MAX(0,saved-1),
                total=CASE WHEN complete=1 THEN MAX(0,total-1) ELSE total END
            WHERE account_id=OLD.account_id AND chat_id=OLD.chat_id AND saved IS NOT NULL;
        END;
        """)
        # миграция старой базы: добавляем колонки инкрементальности, если их нет
        for col in ("min_msg_id INTEGER DEFAULT 0", "deep_done INTEGER DEFAULT 0",
                    "clear_through_msg_id INTEGER DEFAULT 0", "history_cursor INTEGER DEFAULT 0"):
            try:
                c.execute(f"ALTER TABLE chats ADD COLUMN {col}")
            except sqlite3.OperationalError as exc:
                if "duplicate column" not in str(exc):
                    raise
                # колонка уже есть
        for table in ("messages", "deleted"):
            cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
            if "media_approval" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_approval TEXT")
            if "media_id" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_id INTEGER")
            if "media_status" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_status TEXT")
            if "media_error" not in cols:
                c.execute(f"ALTER TABLE {table} ADD COLUMN media_error TEXT")
        account_cols = [r[1] for r in c.execute("PRAGMA table_info(accounts)")]
        if "username" not in account_cols:
            c.execute("ALTER TABLE accounts ADD COLUMN username TEXT")
        # миграция старой версии корзины (без текста/медиа) — пересоздать, если пустая
        cols = [r[1] for r in c.execute("PRAGMA table_info(deleted)")]
        if len(cols) < 10 and not c.execute("SELECT COUNT(*) FROM deleted").fetchone()[0]:
            c.execute("DROP TABLE deleted")
            c.execute("""CREATE TABLE deleted(
                account_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
                msg_id INTEGER NOT NULL, date TEXT, sender_id INTEGER, out INTEGER,
                text TEXT, media_type TEXT, file_path TEXT, file_size INTEGER,
                PRIMARY KEY(account_id, chat_id, msg_id))""")
        if "media_approval" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_approval TEXT")
        if "media_id" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_id INTEGER")
        if "media_status" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_status TEXT")
        if "media_error" not in {r[1] for r in c.execute("PRAGMA table_info(deleted)")}:
            c.execute("ALTER TABLE deleted ADD COLUMN media_error TEXT")
        for table in ("messages", "deleted"):
            if "source_version" not in {r[1] for r in c.execute(f"PRAGMA table_info({table})")}:
                c.execute(f"ALTER TABLE {table} ADD COLUMN source_version TEXT")
            if "capture_order" not in {r[1] for r in c.execute(f"PRAGMA table_info({table})")}:
                c.execute(f"ALTER TABLE {table} ADD COLUMN capture_order INTEGER DEFAULT 0")
        c.execute("""CREATE TABLE IF NOT EXISTS media_suppression(
            account_id INTEGER NOT NULL,chat_id INTEGER NOT NULL,msg_id INTEGER NOT NULL,
            PRIMARY KEY(account_id,chat_id,msg_id))""")
        # Ordered lookups avoid scanning/sorting every message on panel refresh.
        c.execute("CREATE INDEX IF NOT EXISTS idx_msg_account_date ON messages(account_id,date)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_msg_chat_date ON messages(account_id,chat_id,date DESC,msg_id DESC)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_events_account_id ON events(account_id,id DESC)")
        # (второй ряд с тем же tg_user_id база просто не примет)
        try:
            c.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_accounts_tg"
                      " ON accounts(tg_user_id)")
        except Exception as e:
            print(f"[init] unique index на accounts.tg_user_id не создан: {e}")
        c.commit()
        c.execute("BEGIN IMMEDIATE")
        c.execute("CREATE TABLE IF NOT EXISTS account_counts(account_id INTEGER PRIMARY KEY,messages INTEGER NOT NULL DEFAULT 0,pending INTEGER NOT NULL DEFAULT 0,retrying INTEGER NOT NULL DEFAULT 0)")
        c.execute("CREATE TABLE IF NOT EXISTS tg_schema_versions(name TEXT PRIMARY KEY)")
        if not c.execute("SELECT 1 FROM tg_schema_versions WHERE name='account_counts_v1'").fetchone():
            c.execute("DELETE FROM account_counts")
            c.execute("INSERT INTO account_counts(account_id,messages) SELECT account_id,COUNT(*) FROM messages GROUP BY account_id")
            c.execute("""INSERT INTO account_counts(account_id,pending,retrying)
                SELECT account_id,COUNT(*),SUM(attempts>0) FROM archive_jobs GROUP BY account_id
                ON CONFLICT(account_id) DO UPDATE SET pending=excluded.pending,retrying=excluded.retrying""")
            for table, amounts in (("messages", {"messages":"1"}),
                                   ("archive_jobs", {"pending":"1", "retrying":"(NEW.attempts>0)"})):
                cols = ','.join(amounts)
                values = ','.join(amounts.values())
                increments = ','.join(f'{col}={col}+excluded.{col}' for col in amounts)
                decrements = ','.join(f'{col}={col}-({expr.replace("NEW.","OLD.")})' for col,expr in amounts.items())
                c.execute(f"""CREATE TRIGGER tg_counts_{table}_insert AFTER INSERT ON {table} BEGIN
                    INSERT INTO account_counts(account_id,{cols}) VALUES(NEW.account_id,{values})
                    ON CONFLICT(account_id) DO UPDATE SET {increments}; END""")
                c.execute(f"""CREATE TRIGGER tg_counts_{table}_delete AFTER DELETE ON {table} BEGIN
                    UPDATE account_counts SET {decrements} WHERE account_id=OLD.account_id; END""")
                c.execute(f"""CREATE TRIGGER tg_counts_{table}_move AFTER UPDATE OF account_id ON {table}
                    WHEN OLD.account_id!=NEW.account_id BEGIN
                    UPDATE account_counts SET {decrements} WHERE account_id=OLD.account_id;
                    INSERT INTO account_counts(account_id,{cols}) VALUES(NEW.account_id,{values})
                    ON CONFLICT(account_id) DO UPDATE SET {increments}; END""")
            c.execute("""CREATE TRIGGER tg_counts_retry AFTER UPDATE OF attempts ON archive_jobs
                WHEN OLD.account_id=NEW.account_id BEGIN UPDATE account_counts
                SET retrying=retrying+(NEW.attempts>0)-(OLD.attempts>0) WHERE account_id=NEW.account_id; END""")
            c.execute("INSERT INTO tg_schema_versions VALUES('account_counts_v1')")
        if 'priority' not in {r[1] for r in c.execute('PRAGMA table_info(archive_jobs)')}:
            c.execute('ALTER TABLE archive_jobs ADD COLUMN priority INTEGER NOT NULL DEFAULT 1')
        c.execute('CREATE INDEX IF NOT EXISTS idx_archive_jobs_priority ON archive_jobs(account_id,priority,next_attempt)')
        c.execute('CREATE TABLE IF NOT EXISTS chat_directory_versions(account_id INTEGER PRIMARY KEY,version INTEGER NOT NULL DEFAULT 0)')
        for event, ref in (('INSERT','NEW'),('DELETE','OLD')):
            c.execute(f"""CREATE TRIGGER IF NOT EXISTS tg_chat_directory_{event.lower()} AFTER {event} ON chats
                BEGIN INSERT INTO chat_directory_versions VALUES({ref}.account_id,1)
                ON CONFLICT(account_id) DO UPDATE SET version=version+1; END""")
        c.execute("""CREATE TRIGGER IF NOT EXISTS tg_chat_directory_update AFTER UPDATE OF title,account_id ON chats
            WHEN OLD.title IS NOT NEW.title OR OLD.account_id!=NEW.account_id BEGIN
            INSERT INTO chat_directory_versions VALUES(OLD.account_id,1)
            ON CONFLICT(account_id) DO UPDATE SET version=version+1;
            INSERT INTO chat_directory_versions VALUES(NEW.account_id,1)
            ON CONFLICT(account_id) DO UPDATE SET version=version+1; END""")
        init_search_index(c)


# ---------- поисковый индекс сообщений ----------
# Contentless trigram FTS5 keeps only the index, not a second copy of every text;
# detail=none stores no positions, so it finds candidate rows and contains_fold
# confirms the exact substring.
# Triggers index new/changed rows; rows that existed before the index are added
# in small background portions. Until then search uses the previous full scan.
SEARCH_INDEX = {"available": False, "ready": False}
SEARCH_INDEX_BATCH = 500  # ~40 ms of writer time per portion
SEARCH_HITS_FIRST_LIMIT = 5000
SEARCH_INDEX_MERGE_PAGES = 200


def search_index_query(q):
    """FTS5 expression: every 3-character piece of q must occur in the message."""
    grams = [q[i:i + 3] for i in range(0, len(q) - 2, 3)]
    if (len(q) - 3) % 3:
        grams.append(q[-3:])
    return " AND ".join('"' + g.replace('"', '""') + '"' for g in dict.fromkeys(grams))


def _drop_search_index_triggers(c):
    for event in ("insert", "delete", "update"):
        c.execute(f"DROP TRIGGER IF EXISTS tg_messages_fts_{event}")


def init_search_index(c):
    SEARCH_INDEX.update(available=False, ready=False)
    try:
        c.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
            text, content='', contentless_delete=1, detail=none, tokenize='trigram')""")
        # IF NOT EXISTS skips loading the module for an existing table; this probe
        # fails when this SQLite lacks FTS5, trigram or contentless_delete.
        c.execute("SELECT 1 FROM messages_fts WHERE rowid=0").fetchall()
    except sqlite3.OperationalError as exc:
        print(f"[search-index] unavailable, using full scan: {exc}")
        # Triggers left by a build with FTS5 would otherwise make message writes fail.
        _drop_search_index_triggers(c)
        return
    # Segment merges run in the background worker instead of inside message
    # transactions; FTS5 crisis merges still bound the number of segments.
    c.execute("INSERT INTO messages_fts(messages_fts, rank) VALUES('automerge', 0)")
    c.execute("""CREATE TRIGGER IF NOT EXISTS tg_messages_fts_insert AFTER INSERT ON messages
        WHEN COALESCE(NEW.text,'')!='' BEGIN
        INSERT OR REPLACE INTO messages_fts(rowid,text) VALUES(NEW.rowid,NEW.text); END""")
    c.execute("""CREATE TRIGGER IF NOT EXISTS tg_messages_fts_delete AFTER DELETE ON messages BEGIN
        DELETE FROM messages_fts WHERE rowid=OLD.rowid; END""")
    c.execute("""CREATE TRIGGER IF NOT EXISTS tg_messages_fts_update AFTER UPDATE OF text ON messages
        WHEN OLD.text IS NOT NEW.text BEGIN
        DELETE FROM messages_fts WHERE rowid=OLD.rowid;
        INSERT OR REPLACE INTO messages_fts(rowid,text)
            SELECT NEW.rowid,NEW.text WHERE COALESCE(NEW.text,'')!=''; END""")
    c.execute("""CREATE TABLE IF NOT EXISTS search_index_state(
        id INTEGER PRIMARY KEY CHECK(id=1), next_rowid INTEGER NOT NULL, target_rowid INTEGER NOT NULL)""")
    # Rows above target_rowid are written after the triggers exist and are indexed by them.
    c.execute("""INSERT OR IGNORE INTO search_index_state(id,next_rowid,target_rowid)
        SELECT 1,1,COALESCE(MAX(rowid),0) FROM messages""")
    state = c.execute("SELECT next_rowid,target_rowid FROM search_index_state WHERE id=1").fetchone()
    SEARCH_INDEX.update(available=True, ready=state[0] > state[1])


def search_index_backfill_step(limit=SEARCH_INDEX_BATCH):
    """Index one bounded rowid range of pre-existing messages; returns rows indexed."""
    if not SEARCH_INDEX["available"] or SEARCH_INDEX["ready"]:
        return 0
    with db(timeout=1) as c:
        state = c.execute("SELECT next_rowid,target_rowid FROM search_index_state WHERE id=1").fetchone()
        if state is None:
            return 0
        start, target = state
        if start > target:
            SEARCH_INDEX["ready"] = True
            return 0
        end = min(target, start + limit - 1)
        indexed = c.execute("""INSERT OR REPLACE INTO messages_fts(rowid,text)
            SELECT rowid,text FROM messages WHERE rowid BETWEEN ? AND ? AND COALESCE(text,'')!=''""",
            (start, end)).rowcount
        c.execute("UPDATE search_index_state SET next_rowid=? WHERE id=1", (end + 1,))
    if end >= target:
        SEARCH_INDEX["ready"] = True
        print("[search-index] existing messages indexed")
    return max(indexed, 0)


def search_index_merge_step(pages=SEARCH_INDEX_MERGE_PAGES):
    """Bounded FTS5 segment merge; does nothing while fewer than four segments share a level."""
    if not SEARCH_INDEX["available"]:
        return
    with db(timeout=1) as c:
        c.execute("INSERT INTO messages_fts(messages_fts, rank) VALUES('merge', ?)", (pages,))


async def search_index_worker():
    """Index the existing archive, then keep merging index segments in the background."""
    while SEARCH_INDEX["available"]:
        backfilling = not SEARCH_INDEX["ready"]
        await BACKGROUND_LOAD.wait_turn()
        try:
            if backfilling:
                await write_call(search_index_backfill_step, _write_priority=2)
            await write_call(search_index_merge_step, _write_priority=2)
        except sqlite3.Error as exc:
            print(f"[search-index] deferred: {type(exc).__name__}: {exc}")
            await asyncio.sleep(30)
            continue
        await asyncio.sleep(0.05 if backfilling else 20)


def set_status(account_id, status, name=None, username=None, phone=None, tg_user_id=None):
    with db(timeout=1) as c:
        previous = c.execute("SELECT username,phone FROM accounts WHERE id=?", (account_id,)).fetchone()
        identity_changed = bool(previous and (
            (username is not None and username != previous["username"])
            or (phone is not None and phone != previous["phone"])))
        sets = ["status = ?"]
        vals = [status]
        if name is not None:
            sets.append("name = ?"); vals.append(name)
        if username is not None:
            sets.append("username = ?"); vals.append(username)
        if phone is not None:
            sets.append("phone = ?"); vals.append(phone)
        if tg_user_id is not None:
            sets.append("tg_user_id = ?"); vals.append(tg_user_id)
        vals.append(account_id)
        c.execute(f"UPDATE accounts SET {', '.join(sets)} WHERE id = ?", vals)
    if identity_changed:
        ACCOUNT_DIRS.clear()
    # Filesystem walks must never hold the database writer.
    return identity_changed


def restore_cached_identities():
    """Берёт уже известные Telegram usernames из локальных Telethon-сессий."""
    with db() as c:
        accounts = c.execute("SELECT id,tg_user_id,username,phone,name FROM accounts").fetchall()
    with db() as c:
        for account in accounts:
            session = SESSIONS / f"account_{account['id']}.session"
            if not session.exists() or not account["tg_user_id"]:
                continue
            try:
                uri = f"file:{session.as_posix()}?mode=ro"
                # closing(): sqlite3's own "with" only commits; an open file would block
                # replacing this session on a new login.
                with closing(sqlite3.connect(uri, uri=True, timeout=2)) as cache:
                    cache.row_factory = sqlite3.Row
                    cols = {r[1] for r in cache.execute("PRAGMA table_info(entities)")}
                    if not {"id", "username", "phone", "name"} <= cols:
                        continue
                    me = cache.execute("SELECT username,phone,name FROM entities WHERE id=?",
                                      (account["tg_user_id"],)).fetchone()
                    if me:
                        c.execute("UPDATE accounts SET username=?, phone=?, name=? WHERE id=?",
                                  (me["username"] or account["username"] or "",
                                   ("+" + str(me["phone"])) if me["phone"] else account["phone"],
                                   me["name"] or account["name"], account["id"]))
                    entities = {r["id"]: r for r in cache.execute(
                        "SELECT id,username,phone,name FROM entities")}
                    for peer_id, ent in entities.items():
                        if not any((ent["username"], ent["phone"], ent["name"])):
                            continue
                        c.execute("""INSERT OR IGNORE INTO participants
                                     (account_id,user_id,username,phone,display_name)
                                     VALUES(?,?,?,?,?)""",
                                  (account["id"], peer_id, ent["username"],
                                   ("+" + str(ent["phone"])) if ent["phone"] else None,
                                   ent["name"]))
                    chats = c.execute("SELECT chat_id,title,type FROM chats WHERE account_id=?",
                                      (account["id"],)).fetchall()
                    for chat in chats:
                        ent = entities.get(chat["chat_id"])
                        if not ent:
                            continue
                        title = chat["title"] or ""
                        username = ent["username"]
                        if chat["type"] == "user":
                            identity = ("@" + username if username else
                                        ("+" + str(ent["phone"]) if ent["phone"] else "Неизвестно"))
                            display_name = ent["name"] or ""
                            updated = f"{display_name} ({identity})" if display_name and display_name != identity else identity
                        elif username:
                            base = re.sub(r"\s+\(@[^)]+\)$", "", title)
                            updated = f"{base} (@{username})"
                        else:
                            continue
                        if updated != title:
                            c.execute("UPDATE chats SET title=? WHERE account_id=? AND chat_id=?",
                                      (updated, account["id"], chat["chat_id"]))
            except (OSError, sqlite3.Error):
                continue
    ACCOUNT_DIRS.clear()


LOGGED = set()   # account_id с живой авторизацией в этом прогоне панели

def add_event(account_id, kind, note=""):
    """Журнал сеансов: подключение/отключение устройства, отзыв авторизации."""
    from datetime import datetime, timezone
    with db(timeout=1) as c:
        c.execute("INSERT INTO events(account_id, time, kind, note) VALUES(?,?,?,?)",
                  (account_id,
                   datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00"),
                   kind, note))


# ---------- сообщения и медиа ----------

def media_kind(m):
    if m.voice: return "voice"
    if m.video: return "video"
    if m.photo: return "photo"
    if m.audio: return "audio"
    if m.document: return "document"
    return None


def skips_video_download(m):
    """Ordinary videos keep their message but no file; round video messages are downloaded."""
    return media_kind(m) == "video" and not getattr(m, "video_note", None)


def photo_transfer_spec(msg):
    """Use the same JPEG variant for expected size and download.

    File.size includes a reconstructed stripped preview; download_media ranks
    that preview by its compressed bytes. For tiny photos these describe
    different files. Prefer a photo over a preview and exclude video variants.
    Only for a message archived as a photo: a link preview may also carry a
    document, and that document is what gets archived then.
    """
    photo = getattr(msg, "photo", None)
    if not isinstance(photo, tg_types.Photo) or media_kind(msg) != "photo":
        return None, None
    photos, previews = [], []
    for size in photo.sizes:
        if isinstance(size, tg_types.PhotoSize):
            length = size.size
        elif isinstance(size, tg_types.PhotoSizeProgressive):
            length = max(size.sizes, default=0)
        elif isinstance(size, tg_types.PhotoCachedSize):
            length = len(size.bytes)
        elif isinstance(size, tg_types.PhotoStrippedSize):
            previews.append((size.type, len(tg_utils.stripped_photo_to_jpg(size.bytes))))
            continue
        else:
            continue
        if length > 0:
            photos.append((size.w * size.h, length, size.type))
    if photos:
        _, length, variant = max(photos)
        return variant, length
    return max(previews, key=lambda item: item[1]) if previews else (None, None)


def media_expected_size(msg):
    _, length = photo_transfer_spec(msg)
    if length is not None:
        return length
    # msg.file describes the preview photo first, even when the document is archived.
    size = getattr(getattr(msg, "document", None), "size", None)
    if media_kind(msg) != "photo" and isinstance(size, int):
        return size
    return getattr(getattr(msg, "file", None), "size", None)


def media_file_info(msg, kind):
    """Size, id, extension and name of the archived file (msg.file prefers a preview photo)."""
    document = getattr(msg, "document", None)
    if (kind != "photo" and isinstance(getattr(msg, "media", None), tg_types.MessageMediaWebPage)
            and isinstance(document, tg_types.Document)):
        return TelethonFile(document)
    return getattr(msg, "file", None)


def media_source(msg, kind):
    """What to download: the photo or the document this message is archived as.

    message.download_media() picks a link preview's document over its photo, so a
    preview photo is fetched directly; everything else keeps the message (Telethon
    then refreshes an expired file reference during long downloads).
    """
    if kind == "photo" and isinstance(getattr(msg, "media", None), tg_types.MessageMediaWebPage):
        return msg.photo
    return msg


def validate_photo_file(path, size_confirmed=False):
    """Reject a non-JPEG or broken download.

    size_confirmed: the byte count equals what Telegram declared. Some photos are
    stored by Telegram without the last few bytes (PIL: "image file is truncated");
    such a file is exactly Telegram's copy and still opens, so it is kept.
    """
    from PIL import Image
    with Image.open(path) as image:
        if image.format != "JPEG":
            raise OSError("Telegram вернул фотографию не в формате JPEG")
        try:
            image.load()
        except OSError as exc:
            if not (size_confirmed and "truncated" in str(exc)):
                raise


SENDER_LOCKS = [asyncio.Lock() for _ in range(64)]
SENDER_RESOLVED = set()  # (account_id, sender_id) checked during this process
SENDER_LOOKUP_FAILED = set()  # retried by the historical author pass, not for every message
SENDER_PROFILE_CACHE = {}  # avoids one SQLite lookup for every message by the same author


def _participant_fields(sender):
    username = getattr(sender, "username", None) or None
    raw_phone = getattr(sender, "phone", None)
    phone = ("+" + str(raw_phone).lstrip("+") if raw_phone else None)
    first = (getattr(sender, "first_name", None) or "").strip()
    last = (getattr(sender, "last_name", None) or "").strip()
    display_name = " ".join(part for part in (first, last) if part) or None
    title = getattr(sender, "title", None) or None
    kind = "user" if hasattr(sender, "first_name") else ("chat" if title else None)
    return username, phone, display_name, title, kind


def _save_participant(account_id, sender_id, sender):
    username, phone, display_name, title, kind = _participant_fields(sender)
    if not any((username, phone, display_name, title)):
        return None
    with db() as c:
        c.execute("""INSERT INTO participants
                     (account_id,user_id,username,phone,display_name,title,kind,updated_at)
                     VALUES(?,?,?,?,?,?,?,datetime('now'))
                     ON CONFLICT(account_id,user_id) DO UPDATE SET
                     username=excluded.username, phone=excluded.phone,
                     display_name=excluded.display_name, title=excluded.title,
                     kind=excluded.kind, updated_at=datetime('now')""",
                  (account_id, sender_id, username, phone, display_name, title, kind))
        row = c.execute("SELECT * FROM participants WHERE account_id=? AND user_id=?",
                        (account_id, sender_id)).fetchone()
        return dict(row) if row else None


def participant_label(sender_id, profile):
    profile = profile or {}
    display_name = (profile.get("display_name") or "").strip()
    username = (profile.get("username") or "").strip().lstrip("@")
    phone = (profile.get("phone") or "").strip()
    title = (profile.get("title") or "").strip()
    identity = "@" + username if username else phone
    if display_name:
        return f"{display_name} ({identity})" if identity else display_name
    return identity or title or (f"Участник · {sender_id}" if sender_id is not None else "Участник")


async def cache_message_sender(client, account_id, msg):
    sender_id = getattr(msg, "sender_id", None)
    if sender_id is None:
        return None
    key = (account_id, sender_id)
    lock = SENDER_LOCKS[hash(key) % len(SENDER_LOCKS)]
    async with lock:
        if key in SENDER_RESOLVED:
            return SENDER_PROFILE_CACHE.get(key)
        if key in SENDER_LOOKUP_FAILED:
            return None
        profile = None
        try:
            sender = getattr(msg, "sender", None)
        except Exception:
            sender = None
        if sender is None:
            with db() as c:
                row = c.execute("SELECT * FROM participants WHERE account_id=? AND user_id=?",
                                key).fetchone()
            if row:
                profile = dict(row)
                SENDER_RESOLVED.add(key)
        else:
            profile = await write_call(_save_participant,account_id,sender_id,sender)
        if profile is None and key not in SENDER_RESOLVED:
            try:
                sender = await msg.get_sender()
            except Exception:
                sender = None
            if sender is not None:
                profile = await write_call(_save_participant,account_id,sender_id,sender)
        if profile:
            SENDER_RESOLVED.add(key)
            SENDER_LOOKUP_FAILED.discard(key)
        else:
            SENDER_LOOKUP_FAILED.add(key)
        SENDER_PROFILE_CACHE[key] = profile
        return profile


def should_scan_dialog(dialog):
    """Include private chats (including bots), private groups and megagroups."""
    return (getattr(dialog, "is_user", False) or getattr(dialog, "is_group", False)) \
        and dialog.id != SERVICE_CHAT


async def hydrate_chat_participants(client, account_id, chat_id):
    """Resolve distinct historical authors once, including messages already in the archive."""
    with db() as c:
        sender_ids = [r[0] for r in c.execute("""SELECT DISTINCT m.sender_id
                          FROM messages m LEFT JOIN participants p
                            ON p.account_id=m.account_id AND p.user_id=m.sender_id
                          WHERE m.account_id=? AND m.chat_id=? AND m.sender_id IS NOT NULL
                            AND p.user_id IS NULL""", (account_id, chat_id))]
    for sender_id in sender_ids:
        key = (account_id, sender_id)
        if key in SENDER_RESOLVED:
            continue
        lock = SENDER_LOCKS[hash(key) % len(SENDER_LOCKS)]
        async with lock:
            if key in SENDER_RESOLVED:
                continue
            try:
                sender = await client.get_entity(sender_id)
            except FloodWaitError:
                raise
            except Exception:
                sender = None
            if sender is not None:
                profile = _save_participant(account_id, sender_id, sender)
                if profile:
                    SENDER_RESOLVED.add(key)
                    SENDER_PROFILE_CACHE[key] = profile
                    SENDER_LOOKUP_FAILED.discard(key)
            # On a later backfill, failed lookups are retried if no profile was saved.
            else:
                SENDER_LOOKUP_FAILED.add(key)


def media_file_name(msg, ext, chat_type="user", sender_id=None, sender_username=None):
    """Stable date-based name; group media also records the sender's username or ID."""
    dt = msg.date.astimezone() if msg.date else None
    stamp = dt.strftime("%Y-%m-%d %H-%M") if dt else f"msg-{msg.id}"
    if chat_type == "group":
        author = "@" + sender_username if sender_username else (
            f"user-{sender_id}" if sender_id is not None else "unknown")
        return f"{stamp} [{_safe_name(author)}]"
    return f"{dt.strftime('%d-%m-%Y %H-%M') if dt else stamp} ({ext.lstrip('.')})"


def render_text(msg):
    """Текст сообщения + зашитые в слова ссылки в виде «слово(ссылка)».
    Обычные видимые ссылки и так остаются в тексте как есть."""
    from telethon.tl.types import MessageEntityTextUrl
    text = msg.message or ""
    links = [e for e in (msg.entities or []) if isinstance(e, MessageEntityTextUrl)]
    if not links:
        return text

    def to_py(off):                     # offsets у Telegram в UTF-16, у Python — символы
        i = u = 0
        for ch in text:
            if u >= off:
                return i
            u += 2 if ord(ch) > 0xFFFF else 1
            i += 1
        return len(text)

    for e in sorted(links, key=lambda e: -e.offset):   # с конца, чтобы не съезжали индексы
        s, t = to_py(e.offset), to_py(e.offset + e.length)
        word = text[s:t]
        text = text[:s] + f"{word}({e.url})" + text[t:]
    return text


SERVICE_CHAT = 777000   # служебный «Telegram» (коды входа и пр.) — не архивируем


def _safe_name(s):
    """Нормализует подпись до безопасного и стабильного имени Windows-папки."""
    s = unicodedata.normalize("NFC", s or "")
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", s).strip().rstrip(". ")
    s = s[:40].strip().rstrip(". ") or "без_названия"
    if s.split(".", 1)[0].upper() in {
        "CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }:
        s = "_" + s
    return s


ACCOUNT_DIRS = {}   # account_id -> папка вида "1_имя_аккаунта"
CHAT_DIRECTORY_CACHE = {}  # committed directory revision -> normalized chat labels


def account_dir(account_id):
    d = ACCOUNT_DIRS.get(account_id)
    if not d:
        with db() as c:
            r = c.execute("SELECT username, phone FROM accounts WHERE id=?", (account_id,)).fetchone()
        if r and r["username"]:
            label = "@" + r["username"].lstrip("@")
        elif r and r["phone"]:
            label = r["phone"]
        else:
            label = f"Неизвестный аккаунт {account_id}"
        safe_label = _safe_name(label)
        with db() as c:
            accounts = c.execute("SELECT id, username, phone FROM accounts WHERE id!=?", (account_id,)).fetchall()
        collision = False
        for other in accounts:
            if other["username"]:
                other_label = "@" + other["username"].lstrip("@")
            elif other["phone"]:
                other_label = other["phone"]
            else:
                other_label = f"Неизвестный аккаунт {other['id']}"
            if _safe_name(other_label).casefold() == safe_label.casefold():
                collision = True
                break
        d = f"{safe_label[:30]} ({account_id})" if collision else safe_label
        ACCOUNT_DIRS[account_id] = d
    return d


def ensure_account_dir(account_id):
    folder = MEDIA / account_dir(account_id)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def chat_dir_name(account_id, chat_id, title):
    label = _safe_name(title or "Неизвестный чат")
    with db() as c:
        # Revision and titles come from one read snapshot. A rename committed by
        # another writer cannot be paired with a stale revision in this cache.
        if not c.in_transaction:
            c.execute('BEGIN')
        row = c.execute('SELECT version FROM chat_directory_versions WHERE account_id=?',(account_id,)).fetchone()
        revision = (str(DB_PATH), row[0] if row else 0)
        cached = CHAT_DIRECTORY_CACHE.get(account_id)
        if cached is None or cached[0] != revision:
            labels = {r['chat_id']:_safe_name(r['title'] or 'Неизвестный чат').casefold()
                      for r in c.execute('SELECT chat_id,title FROM chats WHERE account_id=?',(account_id,))}
            counts = {}
            for value in labels.values():
                counts[value] = counts.get(value,0)+1
            cached = (revision,labels,counts)
            CHAT_DIRECTORY_CACHE[account_id] = cached
    own = cached[1].get(chat_id) == label.casefold()
    duplicate = cached[2].get(label.casefold(),0) > int(own)
    return f"{label[:30]} ({chat_id})" if duplicate else label


def ensure_chat_dir(account_id, chat_id, title):
    folder = ensure_account_dir(account_id) / chat_dir_name(account_id, chat_id, title)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def ensure_known_chat_dirs(account_id=None):
    with db() as c:
        if account_id is None:
            chats = c.execute("SELECT account_id,chat_id,title FROM chats").fetchall()
        else:
            chats = c.execute("SELECT account_id,chat_id,title FROM chats WHERE account_id=?",
                              (account_id,)).fetchall()
    for chat in chats:
        ensure_chat_dir(chat["account_id"], chat["chat_id"], chat["title"])


def migrate_media_paths(account_id=None, only_chat_id=None, write=None):
    """Переносит медиа в папки с новыми понятными названиями и обновляет БД.

    write(func, *args) runs a database change; at startup it is the shared writer,
    so this long pass never competes with ingestion for the SQLite write lock.
    """
    write = write or (lambda func, *args: func(*args))
    with db() as c:
        conditions = ["m.file_path IS NOT NULL", "m.file_path!=''"]
        args = []
        if account_id is not None:
            conditions.append("m.account_id=?")
            args.append(account_id)
        if only_chat_id is not None:
            conditions.append("m.chat_id=?")
            args.append(only_chat_id)
        where = " WHERE " + " AND ".join(conditions)
        rows = c.execute("""SELECT 'messages' AS source_table,m.account_id,m.chat_id,m.msg_id,
                                  m.file_path,ch.title,ch.type
                           FROM messages m JOIN accounts a ON a.id=m.account_id
                           JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id"""
                         + where, args).fetchall()
        deleted = c.execute("""SELECT 'deleted' AS source_table,m.account_id,m.chat_id,m.msg_id,
                                     m.file_path,ch.title,ch.type
                              FROM deleted m JOIN accounts a ON a.id=m.account_id
                              JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id"""
                            + where, args).fetchall()
    cleanup_dirs = set()
    # One directory lookup per chat, rather than per file in the archive.
    destinations = {}
    for r in [*rows, *deleted]:
        if MAINTENANCE_STOP.is_set():
            break                      # every file is consistent between iterations
        old = r["file_path"]
        if not old:
            continue
        if (r["account_id"], r["chat_id"], r["msg_id"]) in ARCHIVE_BUSY:
            continue                   # being downloaded right now; moved on the next pass
        try:
            src = safe_media_path(old)
        except (ValueError, OSError):
            continue
        key = r["account_id"], r["chat_id"], r["title"]
        if key not in destinations:
            destinations[key] = MEDIA / account_dir(key[0]) / chat_dir_name(*key)
        new = destinations[key]
        target_name = src.name
        if r["type"] == "group":
            source_stem, source_suffix = src.stem, src.suffix
            repeated_id = f" [{r['msg_id']}] [{r['msg_id']}]"
            if source_stem.endswith(repeated_id):
                target_name = source_stem[:-len(f" [{r['msg_id']}]")] + source_suffix
        dst = new / target_name
        if not src.is_file():
            # Завершает обновление БД после прерванного переноса, если файл уже на месте.
            if dst.is_file():
                rel = str(dst.relative_to(BASE)).replace("\\", "/")
                write(_update_media_path, dict(r), old, rel)
            continue
        if src != dst:
            parent = src.parent
            while parent != MEDIA and parent.is_relative_to(MEDIA):
                cleanup_dirs.add(parent)
                parent = parent.parent
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                # Никогда не затираем файл назначения.
                n = 2
                while True:
                    candidate = dst.with_name(f"{dst.stem} [{r['msg_id']}-{n}]{dst.suffix}")
                    if not candidate.exists():
                        dst = candidate
                        break
                    n += 1
            try:
                src.replace(dst)
            except OSError:
                continue               # held open by a download; the next pass moves it
        rel = str(dst.relative_to(BASE)).replace("\\", "/")
        if rel != old:
            if not write(_update_media_path, dict(r), old, rel) and not src.exists():
                # Путь в БД изменился параллельно: откатываем перенос, если можем.
                src.parent.mkdir(parents=True, exist_ok=True)
                dst.replace(src)
    # Удаляем оставшиеся пустыми каталоги со старыми названиями; файлы не трогаем.
    # Only old source folders can have become empty; don't rescan the entire archive per chat.
    for folder in sorted(cleanup_dirs, key=lambda p: len(p.parts), reverse=True):
        if folder.is_dir():
            try:
                folder.rmdir()
            except OSError:
                pass


def media_file_matches(stored_path, expected_size):
    """Only regard a media path as archived when its file matches Telegram's size."""
    try:
        path = safe_media_path(stored_path)
        if not path.is_file():
            return False
        return not expected_size or path.stat().st_size == expected_size
    except (OSError, ValueError):
        return False


def _insert_media_jobs(jobs):
    with db() as c:
        c.executemany("""INSERT OR IGNORE INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt)
            VALUES(?,?,?,?,?,?)""",jobs)


def stop_on_shutdown(c):
    """Let a long read-only scan end promptly when the application stops."""
    c.set_progress_handler(lambda: 1 if MAINTENANCE_STOP.is_set() else 0, 100000)


def recover_missing_media_jobs(write=None):
    """Recover individual files without invalidating completed message history."""
    write = write or (lambda func, *args: func(*args))
    with db() as c:
        stop_on_shutdown(c)
        rows = c.execute("""SELECT m.*,ch.title,ch.type
                            FROM messages m JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
                            WHERE m.media_type IS NOT NULL
                              AND COALESCE(m.media_status,'') NOT IN ('unavailable','dismissed','skipped','failed')
                              AND COALESCE(m.media_approval,'') NOT IN ('pending','rejected')
                              AND NOT EXISTS (SELECT 1 FROM archive_jobs j WHERE j.account_id=m.account_id AND j.chat_id=m.chat_id AND j.msg_id=m.msg_id)
                              AND (coalesce(m.file_size,0) <= ?
                                   OR (m.media_approval='approved' AND coalesce(m.file_size,0) > ?))""",
                         (MAX_MB * 1024 * 1024, MAX_MB * 1024 * 1024)).fetchall()
    jobs = []
    for row in rows:
        if MAINTENANCE_STOP.is_set():
            return 0
        if not media_file_matches(row["file_path"], row["file_size"]):
            payload = dict(row)
            payload.update(process_media=True, token=secrets.token_hex(16))
            jobs.append((row['account_id'],row['chat_id'],row['msg_id'],payload['token'],
                         json.dumps(payload,ensure_ascii=False),time.time()))
    for start in range(0, len(jobs), 500):
        write(_insert_media_jobs, jobs[start:start + 500])
    if jobs:
        print(f"[media-check] {len(jobs)} файлов поставлено на восстановление")
    return len(jobs)


def incomplete_chat_media_count(account_id, chat_id):
    with db() as c:
        rows = c.execute("""SELECT file_path,file_size FROM messages
                        WHERE account_id=? AND chat_id=? AND media_type IS NOT NULL
                              AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed','skipped','failed')
                              AND (coalesce(file_size,0) <= ?
                                   OR (media_approval='approved' AND coalesce(file_size,0) > ?))""",
                         (account_id, chat_id, MAX_MB * 1024 * 1024,
                          MAX_MB * 1024 * 1024)).fetchall()
    return sum(not media_file_matches(row["file_path"], row["file_size"]) for row in rows)


def _update_media_path(row, old, new):
    """Обновляет только исходную строку, не затрагивая одноимённое сообщение из другой таблицы."""
    with db() as c:
        cur = c.execute(
            f"UPDATE {row['source_table']} SET file_path=? WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path=?",
            (new, row["account_id"], row["chat_id"], row["msg_id"], old),
        )
        return cur.rowcount == 1


class SystemCpuSampler:
    """Whole-machine busy time, sampled without spawning WMI/PowerShell processes."""
    def __init__(self, read_times=None):
        self._read_times = read_times or self._system_times
        self._previous = None

    @staticmethod
    def _system_times():
        if sys.platform == 'win32':
            import ctypes
            from ctypes import wintypes
            idle, kernel, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
            if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)):
                raise OSError('GetSystemTimes failed')
            def ticks(value): return (value.dwHighDateTime << 32) | value.dwLowDateTime
            # Windows kernel time includes idle time.
            return ticks(idle), ticks(kernel)+ticks(user)
        with open('/proc/stat',encoding='ascii') as source:
            fields=[int(n) for n in source.readline().split()[1:9]]
        return fields[3]+fields[4],sum(fields)

    def percent(self):
        try:
            current=self._read_times()
            previous=self._previous
            self._previous=current
            if previous is None:
                return None
            idle,total=current[0]-previous[0],current[1]-previous[1]
            if total <= 0 or idle < 0 or idle > total:
                return None
            return 100*(total-idle)/total
        except (OSError,ValueError,IndexError):
            self._previous=None
            return None


CPU_TARGET_PERCENT = 80    # background pacing slows down above this and resumes below it
CPU_CEILING_PERCENT = 90   # a nearly saturated machine pauses background work
CPU_SLOT_GROW_BELOW = 70   # history page slots are added while CPU is below this


class CpuBudget:
    """Pace background work only when the machine is saturated; live receipts never wait.

    A one-second whole-system measurement includes other programs (antivirus,
    indexing). Ingestion speed comes first, so background units are admitted up to
    CPU_CEILING_PERCENT and resume at CPU_TARGET_PERCENT. The gate only protects
    the panel and live receipts from a fully saturated machine; it is not an OS cap.
    """
    def __init__(self, sample=None, clock=None, sleep=None):
        self._sample=sample or SystemCpuSampler().percent
        self._clock=clock or time.monotonic
        self._sleep=sleep or asyncio.sleep
        self._lock=asyncio.Lock()
        self._sample_at=-float('inf')
        self._next_at=0.0
        self._cpu=None
        self._paused=False
        self._delay=0.02

    def snapshot(self):
        return {'cpu_percent':round(self._cpu,1) if self._cpu is not None else None,
                'target_percent':CPU_TARGET_PERCENT,'ceiling_percent':CPU_CEILING_PERCENT,
                'paused':self._paused}

    async def wait_turn(self):
        # FIFO lock means a busy account cannot repeatedly overtake waiting ones.
        async with self._lock:
            while True:
                now=self._clock()
                if now-self._sample_at >= 1:
                    self._sample_at=now
                    value=self._sample()
                    self._cpu=value if value is not None and 0 <= value <= 100 else None
                    if self._cpu is None:
                        self._paused=False
                        self._delay=max(0.25,self._delay)
                    else:
                        if self._cpu >= CPU_CEILING_PERCENT: self._paused=True
                        elif self._cpu <= CPU_TARGET_PERCENT: self._paused=False
                        if self._cpu > CPU_TARGET_PERCENT:
                            self._delay=min(1.0,self._delay*1.5+0.01)
                        elif self._cpu < CPU_TARGET_PERCENT-5:
                            self._delay=max(0.002,self._delay*0.75)
                if self._paused:
                    await self._sleep(0.25)
                    continue
                wait=self._next_at-now
                if wait > 0:
                    await self._sleep(min(wait,0.25))
                    continue
                self._next_at=now+self._delay
                return


BACKGROUND_LOAD = CpuBudget()


class AdaptiveSlots:
    """FIFO slots for Telegram history pages whose number follows system CPU.

    Starts at the previous fixed two slots. While whole-system CPU stays below
    CPU_SLOT_GROW_BELOW and the CPU gate is open, one slot is added every few seconds,
    up to the maximum; above CPU_TARGET_PERCENT (or while paused) one is removed. Live receipts never
    use these slots. Telegram limits requests per account, so extra slots let more
    accounts read history at the same time rather than one account read faster.
    """
    def __init__(self, minimum=2, maximum=8, load=None, clock=None, interval=5.0):
        self.minimum, self.maximum, self.interval = minimum, maximum, interval
        self._load = load
        self._clock = clock or time.monotonic
        self.limit = minimum
        self.active = 0
        self._waiters = deque()
        self._adjusted_at = self._clock()

    def _adjust(self):
        now = self._clock()
        if now - self._adjusted_at < self.interval:
            return
        self._adjusted_at = now
        snapshot = (self._load or BACKGROUND_LOAD).snapshot()
        cpu = snapshot.get("cpu_percent")
        if cpu is None:
            return
        if snapshot.get("paused") or cpu > CPU_TARGET_PERCENT:
            self.limit = max(self.minimum, self.limit - 1)
        elif cpu < CPU_SLOT_GROW_BELOW and (self.active >= self.limit or self._waiters):
            self.limit = min(self.maximum, self.limit + 1)

    def _wake(self):
        while self._waiters and self.active < self.limit:
            future = self._waiters.popleft()
            if not future.done():
                self.active += 1
                future.set_result(None)

    async def acquire(self):
        self._adjust()
        if self.active < self.limit and not self._waiters:
            self.active += 1
            return
        future = asyncio.get_running_loop().create_future()
        self._waiters.append(future)
        try:
            await future
        except BaseException:
            if future.done() and not future.cancelled():
                self.release()          # granted just before cancellation
            else:
                future.cancel()
            raise

    def release(self):
        self.active -= 1
        self._adjust()
        self._wake()

    def snapshot(self):
        return {"history_slots": self.limit, "history_slots_busy": self.active}

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self, *_args):
        self.release()


async def pace_media_download(received, total):
    # Telethon awaits async progress callbacks between chunks. A large file must
    # respond to CPU pressure too, rather than running unthrottled until its end.
    await BACKGROUND_LOAD.wait_turn()


MESSAGE_LOCKS = [asyncio.Lock() for _ in range(64)]
MEDIA_DOWNLOAD_SEM = asyncio.Semaphore(MAX_CONCURRENT_MEDIA_DOWNLOADS)
class DatabaseWriteLock:
    """One transaction at a time; favor messages without starving background work."""
    def __init__(self):
        self._locked = False
        self._waiters = [deque(),deque(),deque()]
        self._message_run = 0
        self._background_turn = 1

    def locked(self):
        return self._locked

    def _wake_next(self):
        if self._locked:
            return
        for queue in self._waiters:
            while queue and queue[0].done():
                queue.popleft()
        messages,normal,maintenance = self._waiters
        if messages and (self._message_run < 8 or not (normal or maintenance)):
            priority = 0
            self._message_run = min(8,self._message_run + 1)
        elif normal or maintenance:
            priority = self._background_turn
            if not self._waiters[priority]:
                priority = 3-priority
            self._background_turn = 3-priority
            self._message_run = 0
        else:
            return
        self._locked = True
        self._waiters[priority].popleft().set_result(None)

    async def acquire(self,priority=1):
        if priority not in (0,1,2):
            raise ValueError('Unknown database write priority')
        future = asyncio.get_running_loop().create_future()
        self._waiters[priority].append(future)
        self._wake_next()
        try:
            await future
        except BaseException:
            if future.done() and not future.cancelled():
                self.release()  # cancelled after being granted ownership
            else:
                future.cancel()
                try:
                    self._waiters[priority].remove(future)
                except ValueError:
                    pass  # release already skipped this cancelled waiter
            raise
        return True

    def release(self):
        if not self._locked:
            raise RuntimeError('Database writer is not locked')
        self._locked = False
        self._wake_next()

    @asynccontextmanager
    async def at(self,priority):
        await self.acquire(priority)
        try:
            yield
        finally:
            self.release()

    async def __aenter__(self):
        await self.acquire()
        return self

    async def __aexit__(self,*_args):
        self.release()


DB_WRITE_LOCK = DatabaseWriteLock()
ARCHIVE_CLAIM_LOCK = asyncio.Lock()
ARCHIVE_LAST_ACCOUNT = 0
ARCHIVE_CANDIDATE_LIMIT = 100
INGEST_QUEUE = None
INGEST_TASK = None
ARCHIVE_WORKERS = []
MAINTENANCE_STOP = threading.Event()   # ends startup media maintenance when the app stops
STARTUP_MAINTENANCE = {"state": "pending", "step": None}
ARCHIVE_BUSY = set()
ARCHIVE_ACCOUNT_WAIT = {}   # account_id -> time.time() until which Telegram asked it to wait
ARCHIVE_LIVE_STREAK = {}
ARCHIVE_WAKE = asyncio.Event()
ARCHIVE_JOB_TASKS = {}  # message key -> cancellable processing task
LIVE_MESSAGES = OrderedDict()
INGEST_ERRORS = {}
INGEST_SPOOL = BASE / "pending-ingest"


async def thread_call(func, *args, **kwargs):
    """Wait for a disk operation even on cancellation; never leave a late writer behind."""
    task = asyncio.create_task(asyncio.to_thread(func, *args, **kwargs))
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        await task
        raise


async def write_call(func, *args, _write_priority=1, **kwargs):
    global _DB_EXECUTOR
    queued = time.monotonic()
    async with DB_WRITE_LOCK.at(_write_priority):
        started = time.monotonic()
        try:
            for attempt in range(3):
                try:
                    if _DB_EXECUTOR is None:
                        _DB_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="tg-db")
                    future = asyncio.get_running_loop().run_in_executor(
                        _DB_EXECUTOR, _run_db_write, func, args, kwargs)
                    return await _drain_db_future(future)
                except sqlite3.OperationalError:
                    if attempt == 2:
                        raise
                    await asyncio.sleep(0.2 * (attempt + 1))
        finally:
            finished = time.monotonic()
            if finished - queued >= 2:
                print(f"[{datetime.now(timezone.utc).isoformat()}] [db-write] {func.__name__} "
                      f"wait={started-queued:.3f}s run={finished-started:.3f}s")


def _run_db_write(func, args, kwargs):
    _DB_WRITER_LOCAL.enabled = True
    try:
        return func(*args, **kwargs)
    finally:
        _DB_WRITER_LOCAL.enabled = False


async def _drain_db_future(future):
    # A second cancellation must not release the writer while its transaction still runs.
    cancelled = False
    while True:
        try:
            result = await asyncio.shield(future)
            break
        except asyncio.CancelledError:
            cancelled = True
        except BaseException:
            if cancelled:
                raise asyncio.CancelledError from None
            raise
    if cancelled:
        raise asyncio.CancelledError
    return result


def _close_db_writer():
    c = getattr(_DB_WRITER_LOCAL, "connection", None)
    if c is not None:
        try:
            c.rollback()
        finally:
            c.close()
            _DB_WRITER_LOCAL.connection = None


async def stop_db_writer():
    global _DB_EXECUTOR
    async with DB_WRITE_LOCK:
        executor = _DB_EXECUTOR
        if executor is None:
            return
        await _drain_db_future(asyncio.get_running_loop().run_in_executor(executor, _close_db_writer))
        executor.shutdown(wait=True)
        _DB_EXECUTOR = None


def sql_rows(sql, params=()):
    with db(timeout=1) as c:
        return [dict(row) for row in c.execute(sql, params).fetchall()]


def sql_write(sql, params=()):
    with db(timeout=1) as c:
        return c.execute(sql, params).lastrowid


def message_version(msg):
    dt = getattr(msg, "edit_date", None) or msg.date
    return dt.isoformat() if dt else ""


def live_snapshot(account_id, msg, chat_id, title, ctype):
    kind = media_kind(msg)
    file = media_file_info(msg, kind)
    try:
        sender = getattr(msg, "sender", None)
    except Exception:
        sender = None
    return dict(account_id=account_id, chat_id=chat_id, msg_id=msg.id,
                date=msg.date.isoformat() if msg.date else None,
                source_version=message_version(msg), capture_order=time.time_ns(), sender_id=msg.sender_id,
                out=int(bool(msg.out)), text=render_text(msg), title=title, type=ctype,
                media_type=kind, file_size=media_expected_size(msg) if kind else None,
                media_id=getattr(file, "id", None) if kind else None,
                media_skipped=skips_video_download(msg),
                profile=list(_participant_fields(sender)) if sender is not None else None,
                token=secrets.token_hex(16))


def persist_live_batch(batch, history=False, checkpoint=None):
    """Commit text and its durable follow-up job together, with one transaction per batch."""
    accepted = []
    with db(timeout=1) as c:
        c.execute("BEGIN IMMEDIATE")
        accounts, chats, chat_updates = {}, {}, {}
        profiles_written, profiles_known = {}, {}

        def missing_sender_profile(s):
            if s["sender_id"] is None:
                return False
            pkey = s["account_id"], s["sender_id"]
            profile = s.get("profile")
            if profile and any(profile[:4]):
                fields = tuple(profile)
                if profiles_written.get(pkey) != fields:
                    c.execute("""INSERT INTO participants(account_id,user_id,username,phone,display_name,title,kind)
                        VALUES(?,?,?,?,?,?,?) ON CONFLICT(account_id,user_id) DO UPDATE SET
                        username=excluded.username,phone=excluded.phone,display_name=excluded.display_name,
                        title=excluded.title,kind=excluded.kind,updated_at=datetime('now')""",(*pkey,*fields))
                    profiles_written[pkey] = fields
                profiles_known[pkey] = True
            if pkey not in profiles_known:
                profiles_known[pkey] = c.execute(
                    "SELECT 1 FROM participants WHERE account_id=? AND user_id=?",pkey).fetchone() is not None
            return not profiles_known[pkey]

        for s in batch:
            key = s["account_id"], s["chat_id"], s["msg_id"]
            if key[0] not in accounts:
                accounts[key[0]] = c.execute("SELECT 1 FROM accounts WHERE id=?",key[:1]).fetchone()
            if key[:2] not in chats:
                chats[key[:2]] = c.execute("SELECT clear_through_msg_id FROM chats WHERE account_id=? AND chat_id=?",key[:2]).fetchone()
            account, chat = accounts[key[0]], chats[key[:2]]
            deleted = c.execute("SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=?", key).fetchone()
            if not account or deleted or (chat and key[2] <= (chat[0] or 0)):
                accepted.append(False)
                continue
            previous = c.execute("SELECT * FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone()
            suppressed = c.execute("SELECT 1 FROM media_suppression WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone()
            s["process_media"] = bool(not suppressed and (s["media_type"] or (previous and previous["media_type"])))
            # An ordinary video needs no download job unless it replaces other media of this message.
            skipped = bool(not suppressed and s.get("media_skipped"))
            if skipped and not (previous and previous["media_type"] and previous["media_id"] != s["media_id"]):
                s["process_media"] = False
            if suppressed:
                s["media_type"] = s["file_size"] = s["media_id"] = None
            if history and previous and (previous["source_version"] or previous["date"] or "") >= s["source_version"]:
                if (previous["source_version"] or previous["date"] or "") > s["source_version"]:
                    accepted.append(False)
                    continue
                # Reading the same history again must not invalidate an active
                # download, reset its retry delay or redownload a complete file.
                missing_profile = missing_sender_profile(s)
                s["process_media"]=bool(not suppressed and s["media_type"]
                    and not (skipped and previous["media_id"] == s["media_id"])
                    and previous["media_status"] not in ("unavailable","dismissed","failed")
                    and previous["media_approval"] not in ("pending","rejected")
                    and (previous["media_type"] != s["media_type"] or previous["media_id"] != s["media_id"]
                         or previous["file_size"] != s["file_size"] or not previous["file_path"]
                         or not media_file_matches(previous["file_path"],s["file_size"])))
                if s["process_media"] or missing_profile:
                    c.execute("""INSERT OR IGNORE INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt)
                        VALUES(?,?,?,?,?,?)""",(*key,s["token"],json.dumps(s,ensure_ascii=False),time.time()))
                if skipped and not s["process_media"]:
                    c.execute("""UPDATE messages SET media_status='skipped',media_error=NULL
                        WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path IS NULL
                        AND COALESCE(media_status,'') IN ('','queued')""",key)
                accepted.append(True)
                continue
            changed = c.execute("""INSERT INTO messages
                (account_id,chat_id,msg_id,date,sender_id,out,text,media_type,file_size,media_id,media_status,source_version,capture_order)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(account_id,chat_id,msg_id) DO UPDATE SET
                date=excluded.date,sender_id=excluded.sender_id,out=excluded.out,text=excluded.text,
                source_version=excluded.source_version,capture_order=excluded.capture_order
                WHERE COALESCE(messages.source_version,messages.date,'')<excluded.source_version
                OR (COALESCE(messages.source_version,messages.date,'')=excluded.source_version
                    AND COALESCE(messages.capture_order,0)<excluded.capture_order)""",
                (*key,s["date"],s["sender_id"],s["out"],s["text"],s["media_type"],
                 s["file_size"],s["media_id"],"skipped" if skipped else "queued" if s["media_type"] else None,
                 s["source_version"],s.get("capture_order",0))).rowcount
            if not changed:
                accepted.append(False)
                continue
            if skipped and not s["process_media"]:
                # An edited message keeps its row; a video still waiting for a download stops waiting.
                c.execute("""UPDATE messages SET media_status='skipped',media_error=NULL
                    WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path IS NULL
                    AND COALESCE(media_status,'') IN ('','queued')""",key)
            update = chat_updates.get(key[:2])
            if update is None:
                chat_updates[key[:2]] = [s["title"],s["type"],key[2]]
            else:
                if s["title"] is not None and s["title"] != '?':
                    update[0] = s["title"]
                update[1] = s["type"]
                update[2] = max(update[2],key[2])
            missing_profile = missing_sender_profile(s)
            if s["process_media"] or missing_profile:
                c.execute("""INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt,priority)
                    VALUES(?,?,?,?,?,?,?) ON CONFLICT(account_id,chat_id,msg_id) DO UPDATE SET
                    token=excluded.token,payload=excluded.payload,attempts=0,next_attempt=excluded.next_attempt,
                    error=NULL,priority=MIN(archive_jobs.priority,excluded.priority)""",
                    (*key,s["token"],json.dumps(s,ensure_ascii=False),time.time(),int(history)))
            else:
                c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?", key)
            accepted.append(True)
        for (aid,cid),values in chat_updates.items():
            c.execute("""INSERT INTO chats(account_id,chat_id,title,type,max_msg_id) VALUES(?,?,?,?,?)
                ON CONFLICT(account_id,chat_id) DO UPDATE SET
                title=CASE WHEN excluded.title!='?' THEN excluded.title ELSE chats.title END,
                type=excluded.type,max_msg_id=MAX(chats.max_msg_id,excluded.max_msg_id)""",(aid,cid,*values))
        if checkpoint is not None:
            account_id, chat_id, direction, msg_id = checkpoint
            if direction == 'forward':
                c.execute("UPDATE chats SET history_cursor=MAX(history_cursor,?) WHERE account_id=? AND chat_id=?",
                          (msg_id, account_id, chat_id))
            elif direction == 'older':
                c.execute("UPDATE chats SET min_msg_id=? WHERE account_id=? AND chat_id=?",
                          (msg_id, account_id, chat_id))
            else:
                raise ValueError('Invalid history checkpoint direction')
    return accepted


def spool_live_batch(batch):
    """Emergency receipt if SQLite is temporarily unavailable; replayed after restart."""
    INGEST_SPOOL.mkdir(exist_ok=True)
    for s in batch:
        path = INGEST_SPOOL / (s["token"] + ".json")
        tmp = path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        tmp.replace(path)


async def ingest_loop():
    while True:
        entries = [await INGEST_QUEUE.get()]
        await asyncio.sleep(0.01)  # amortize commits during simultaneous account updates
        while len(entries) < 100 and not INGEST_QUEUE.empty():
            entries.append(INGEST_QUEUE.get_nowait())
        batch = [s for s, _future in entries]
        error = None
        try:
            accepted = await write_call(persist_live_batch, batch, _write_priority=0)
            for s in batch:
                INGEST_ERRORS.pop(s["account_id"], None)
        except Exception as exc:
            accepted = [False] * len(batch)
            for s in batch:
                INGEST_ERRORS[s["account_id"]] = str(exc)[:200]
            try:
                await thread_call(spool_live_batch, batch)
            except Exception as spool_error:
                error = spool_error
            print(f"[ingest] SQL deferred: {type(exc).__name__}: {exc}")
        finally:
            for (_s, future), ok in zip(entries, accepted):
                if not future.done():
                    if error:
                        future.set_exception(error)
                    else:
                        future.set_result(ok)
                INGEST_QUEUE.task_done()


async def capture_live_message(client, account_id, msg, chat_id, title, ctype):
    """Fast durable receipt; downloads and profile lookups never delay text capture."""
    global INGEST_QUEUE, INGEST_TASK
    if chat_id == SERVICE_CHAT or getattr(msg, "action", None):
        return
    if INGEST_TASK is None or INGEST_TASK.done():
        INGEST_QUEUE = asyncio.Queue(maxsize=256)
        INGEST_TASK = asyncio.create_task(ingest_loop())
    snapshot = live_snapshot(account_id,msg,chat_id,title,ctype)
    future = asyncio.get_running_loop().create_future()
    await INGEST_QUEUE.put((snapshot,future))
    accepted = await asyncio.shield(future)
    if accepted:
        LIVE_MESSAGES[snapshot["token"]] = msg
        ARCHIVE_WAKE.set()
        while len(LIVE_MESSAGES) > 256:
            LIVE_MESSAGES.popitem(last=False)


def next_archive_job():
    """FIFO window per account; prioritize small/untried jobs only within that window.

    Never sort/join the entire archive or read every JSON payload to claim one job.
    A delayed retry is excluded by the due index; accounts rotate fairly.
    """
    global ARCHIVE_LAST_ACCOUNT
    busy = tuple(ARCHIVE_BUSY)
    busy_accounts = {key[0] for key in busy
                     if sum(k[0] == key[0] for k in busy) >= MAX_MEDIA_DOWNLOADS_PER_ACCOUNT}
    # Telegram's FloodWait applies to the whole account, not only to the file that hit it.
    now = time.time()
    active = sorted(account_id for account_id,client in tuple(CLIENTS.items())
                   if client.is_connected() and account_id not in busy_accounts
                   and ARCHIVE_ACCOUNT_WAIT.get(account_id,0) <= now)
    if not active:
        return None
    active = [i for i in active if i > ARCHIVE_LAST_ACCOUNT] + [i for i in active if i <= ARCHIVE_LAST_ACCOUNT]
    with db(timeout=1) as c:
        now = time.time()
        for account_id in active:
            account = c.execute("SELECT status FROM accounts WHERE id=?", (account_id,)).fetchone()
            if not account or account[0] in ('paused','disconnected','linking','error'):
                continue
            # Eight live files, then one history file: new messages stay responsive
            # and an ongoing stream cannot starve the historical archive.
            streak = ARCHIVE_LIVE_STREAK.get(account_id,0)
            priorities = (1,0) if streak >= 8 else (0,1)
            row = None
            for priority in priorities:
                rows = c.execute("""WITH candidates AS MATERIALIZED (
                SELECT account_id,chat_id,msg_id,attempts,next_attempt
                FROM archive_jobs INDEXED BY idx_archive_jobs_priority
                WHERE account_id=? AND priority=? AND next_attempt<=?
                ORDER BY next_attempt LIMIT ?)
                SELECT j.account_id,j.chat_id,j.msg_id FROM candidates j
                LEFT JOIN messages m ON m.account_id=j.account_id AND m.chat_id=j.chat_id AND m.msg_id=j.msg_id
                ORDER BY j.attempts,COALESCE(m.file_size,0),j.next_attempt,j.chat_id,j.msg_id""",
                (account_id,priority,now,ARCHIVE_CANDIDATE_LIMIT)).fetchall()
                row = next((r for r in rows if tuple(r) not in busy),None)
                if row:
                    ARCHIVE_LIVE_STREAK[account_id] = streak+1 if priority == 0 else 0
                    break
            if row:
                job = c.execute("SELECT * FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?",tuple(row)).fetchone()
                if job:
                    ARCHIVE_LAST_ACCOUNT = account_id
                    return dict(job)
    return None


MEDIA_MAX_ATTEMPTS = 3            # then the file is marked "failed" and leaves the queue
MEDIA_RETRY_DELAYS = (120, 1800)  # seconds before the 2nd and the 3rd attempt


def finish_archive_job(job, error=None):
    key = job["account_id"],job["chat_id"],job["msg_id"]
    with db(timeout=1) as c:
        state = c.execute("SELECT media_status FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone()
        status = state[0] if state else None
        if error is None and status in ("incomplete","storage_full","downloading"):
            error = "Вложение ещё не сохранено целиком"
        if error:
            # Telegram's rate limit and a full disk are not the file's fault: wait without counting.
            waiting = isinstance(error,FloodWaitError) or status == "storage_full"
            if not waiting and job["attempts"] + 1 >= MEDIA_MAX_ATTEMPTS:
                # The message and any partial file stay; the panel offers a manual retry.
                reason = error if isinstance(error,str) else f"{type(error).__name__}: {error}".rstrip(": ")
                c.execute("""UPDATE messages SET media_status='failed',media_error=COALESCE(media_error,?)
                    WHERE account_id=? AND chat_id=? AND msg_id=? AND media_type IS NOT NULL
                    AND COALESCE(media_status,'') IN ('','queued','incomplete','downloading')
                    AND (file_path IS NULL OR media_status IS NOT NULL)""",(reason[:300],*key))
                c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?",(*key,job["token"]))
                return
            if isinstance(error,FloodWaitError):
                delay = error.seconds+2
                # More parallel files must not keep asking while Telegram says wait.
                ARCHIVE_ACCOUNT_WAIT[job["account_id"]] = max(
                    ARCHIVE_ACCOUNT_WAIT.get(job["account_id"],0),time.time()+delay)
            elif waiting:
                delay = 300
            else:
                delay = MEDIA_RETRY_DELAYS[min(job["attempts"],len(MEDIA_RETRY_DELAYS)-1)]
            c.execute("""UPDATE archive_jobs SET attempts=attempts+?,next_attempt=?,error=?
                WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?""",
                (0 if waiting else 1,time.time()+delay,str(error)[:200],*key,job["token"]))
        else:
            c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?",(*key,job["token"]))


async def archive_job_worker():
    while True:
        job = None
        try:
            await BACKGROUND_LOAD.wait_turn()
            # Claim selection is serialized so two workers never process the same receipt.
            async with ARCHIVE_CLAIM_LOCK:
                job = await thread_call(next_archive_job)
                if job:
                    key = job["account_id"],job["chat_id"],job["msg_id"]
                    ARCHIVE_BUSY.add(key)
            if job is None:
                try:
                    await asyncio.wait_for(ARCHIVE_WAKE.wait(),1)
                except asyncio.TimeoutError:
                    pass
                ARCHIVE_WAKE.clear()
                continue
            s = json.loads(job["payload"])
            client = CLIENTS.get(job["account_id"])
            if client is None or not client.is_connected():
                await asyncio.sleep(1)
                continue
            async def process_job():
                def load_job_state():
                    with db(timeout=1) as c:
                        status = c.execute("SELECT status FROM accounts WHERE id=?", (job["account_id"],)).fetchone()
                        profile_known = s.get("sender_id") is None or c.execute(
                            "SELECT 1 FROM participants WHERE account_id=? AND user_id=?",
                            (job["account_id"],s["sender_id"])).fetchone() is not None
                        return status, profile_known
                status, profile_known = await thread_call(load_job_state)
                if not status or status[0] in ("paused", "disconnected", "linking", "error"):
                    return False
                if not s.get("process_media",s["media_type"]) and profile_known:
                    return True  # another message already supplied this sender's profile
                msg = LIVE_MESSAGES.get(job["token"])
                if msg is None:
                    msg = await asyncio.wait_for(client.get_messages(job["chat_id"],ids=job["msg_id"]),45)
                if msg is not None:
                    if s.get("process_media",s["media_type"]):
                        fs = s.get("file_size") or (getattr(msg.file, "size", 0) if msg and getattr(msg, "file", None) else 0)
                        job_timeout = max(BACKFILL_MESSAGE_TIMEOUT, int((fs or 0) / (50 * 1024)))
                        await asyncio.wait_for(store_message(client,job["account_id"],msg,job["chat_id"],
                            s["title"],s["type"],expected_job_token=job["token"]),job_timeout)
                    else:
                        await cache_message_sender(client,job["account_id"],msg)
                else:
                    def mark_unavailable():
                        with db(timeout=1) as c:
                            c.execute("""UPDATE messages SET media_status='unavailable',
                                media_error='Сообщение больше недоступно в Telegram.'
                                WHERE account_id=? AND chat_id=? AND msg_id=? AND media_type IS NOT NULL
                                AND EXISTS(SELECT 1 FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?)""",
                                (*key,*key,job["token"]))
                    await write_call(mark_unavailable)
                return True
            task = asyncio.create_task(process_job())
            ARCHIVE_JOB_TASKS[key] = task
            try:
                processed = await task
            except asyncio.CancelledError:
                if asyncio.current_task().cancelling():
                    raise
                continue  # account pause cancels the job, not the shared worker
            if not processed:
                continue
            await write_call(finish_archive_job,job)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"[archive-queue] {type(exc).__name__}: {exc}")
            if job and session_lost(exc):
                # Not the file's fault: the job keeps its attempts until the account logs in again.
                try:
                    await end_lost_session(job["account_id"])
                except Exception:
                    pass
            elif job:
                try:
                    await write_call(finish_archive_job,job,exc)
                except Exception:
                    pass  # durable receipt remains in SQL for the next attempt
            await asyncio.sleep(1)
        finally:
            if job:
                ARCHIVE_JOB_TASKS.pop((job["account_id"],job["chat_id"],job["msg_id"]), None)
                ARCHIVE_BUSY.discard((job["account_id"],job["chat_id"],job["msg_id"]))
                LIVE_MESSAGES.pop(job["token"],None)


def replay_ingest_spool():
    if not INGEST_SPOOL.is_dir():
        return
    paths = []
    for path in INGEST_SPOOL.glob("*.json"):
        paths.append(path)
        if len(paths) >= 100:
            break
    if not paths:
        return
    readable = []
    snapshots = []
    for path in paths:
        try:
            snapshot = json.loads(path.read_text(encoding="utf-8"))
            required = {"account_id","chat_id","msg_id","token","text","source_version",
                        "date","sender_id","out","title","type","media_type","file_size","media_id"}
            if not isinstance(snapshot,dict) or not required <= snapshot.keys():
                raise ValueError("Неверный формат сохранённого задания")
            for field in ("account_id", "chat_id", "msg_id"):
                if type(snapshot[field]) is not int:
                    raise ValueError("Неверный тип идентификатора")
            if snapshot["account_id"] <= 0 or snapshot["msg_id"] <= 0:
                raise ValueError("Неверный идентификатор")
            for field in ("token", "text", "source_version", "title", "type"):
                if not isinstance(snapshot[field],str):
                    raise ValueError("Неверный тип текстового поля")
            if type(snapshot.get("capture_order",0)) is not int:
                raise ValueError("Неверный порядок версии")
            profile = snapshot.get("profile")
            if profile is not None and (not isinstance(profile,list) or len(profile)!=5
                    or any(v is not None and not isinstance(v,str) for v in profile)):
                raise ValueError("Неверный профиль отправителя")
            for field in ("sender_id", "file_size", "media_id"):
                if snapshot[field] is not None and type(snapshot[field]) is not int:
                    raise ValueError("Неверный тип метаданных")
            if snapshot["date"] is not None and not isinstance(snapshot["date"],str):
                raise ValueError("Неверная дата")
            if type(snapshot["out"]) is not int or snapshot["out"] not in (0,1):
                raise ValueError("Неверное направление сообщения")
            if snapshot["media_type"] is not None and (not isinstance(snapshot["media_type"],str)
                    or snapshot["media_type"] not in EXT_FALLBACK):
                raise ValueError("Неверный тип медиа")
            snapshots.append(snapshot)
            readable.append(path)
        except (ValueError,OSError) as exc:
            print(f"[ingest-replay] damaged receipt {path.name}: {exc}")
            # A damaged receipt must not occupy the next batch's recovery slots.
            quarantine = INGEST_SPOOL / "quarantine"
            quarantine.mkdir(exist_ok=True)
            path.replace(quarantine / (path.stem + "-" + secrets.token_hex(4) + ".json"))
    if snapshots:
        persist_live_batch(snapshots)
        for snapshot in snapshots:
            INGEST_ERRORS.pop(snapshot["account_id"],None)
    for path in readable:
        path.unlink()


async def ingest_maintenance():
    while True:
        try:
            await write_call(replay_ingest_spool, _write_priority=0)
            await write_call(cleanup_orphaned_archive_jobs, _write_priority=2)
            with db() as c:
                active = {r[0] for r in c.execute("SELECT id FROM accounts WHERE status NOT IN ('paused','disconnected','linking')")}
            for account_id,state in list(BACKFILL.items()):
                if (account_id in active and state.get("state") in ("partial","error")
                        and state.get("retry_at",float("inf")) <= time.time()
                        and account_id in CLIENTS and CLIENTS[account_id].is_connected()):
                    start_backfill(account_id, retry_only=True)
        except Exception as exc:
            print(f"[ingest-replay] {type(exc).__name__}: {exc}")
        await asyncio.sleep(5)


def cleanup_orphaned_archive_jobs():
    # Seek once per account instead of scanning every queued attachment every 5s.
    # Existing account indexes suffice; bound deletion to keep the writer available.
    with db(timeout=1) as c:
        row = c.execute("""SELECT account_id FROM archive_jobs
            INDEXED BY idx_archive_jobs_account_due ORDER BY account_id LIMIT 1""").fetchone()
        while row:
            account_id = row[0]
            if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
                c.execute("BEGIN IMMEDIATE")
                # Recheck after obtaining the write lock: an account may have been
                # created since the probe. Never remove a valid account's receipts.
                return c.execute("""DELETE FROM archive_jobs WHERE rowid IN (
                    SELECT rowid FROM archive_jobs INDEXED BY idx_archive_jobs_account_due
                    WHERE account_id=? LIMIT 100)
                    AND NOT EXISTS (SELECT 1 FROM accounts WHERE id=?)""",
                    (account_id,account_id)).rowcount
            row = c.execute("""SELECT account_id FROM archive_jobs
                INDEXED BY idx_archive_jobs_account_due WHERE account_id>?
                ORDER BY account_id LIMIT 1""", (account_id,)).fetchone()
        return 0


def retry_mismatched_photo_jobs():
    """Give existing tiny-photo size mismatches one immediate retry on startup.

    Keep receipts, attempt counts, all other backoff schedules and original
    partial files. The worker must obtain fresh Telegram metadata and validate
    the selected JPEG before it can finish a receipt.
    """
    return retry_photo_jobs(startup_media_keys()["photos"])


def startup_media_keys():
    """One read-only pass for the startup media repairs.

    media_status has no index, so finding interrupted downloads and tiny-photo
    mismatches reads the whole archive. Reading takes no write lock: ingestion and
    the panel keep working, and only the matching keys are changed afterwards.
    """
    keys = {"messages": [], "deleted": [], "photos": []}
    with db() as c:
        stop_on_shutdown(c)
        for row in c.execute("""SELECT account_id,chat_id,msg_id,media_type,media_status,file_size,media_error
                                FROM messages WHERE media_status IN ('downloading','incomplete')"""):
            key = (row[0], row[1], row[2])
            if row["media_status"] == "downloading":
                keys["messages"].append(key)
            elif (row["media_type"] == "photo" and (row["file_size"] or 0) < 1048576
                  and "Неполный файл" in (row["media_error"] or "")):
                keys["photos"].append(key)
        keys["deleted"] = [tuple(r) for r in c.execute(
            "SELECT account_id,chat_id,msg_id FROM deleted WHERE media_status='downloading'")]
    return keys


def mark_downloads_interrupted(keys):
    with db(timeout=1) as c:
        for table in ("messages", "deleted"):
            c.executemany(f"""UPDATE {table} SET media_status='incomplete',
                media_error='Загрузка была прервана остановкой приложения.'
                WHERE account_id=? AND chat_id=? AND msg_id=? AND media_status='downloading'""", keys[table])


def retry_photo_jobs(keys):
    with db(timeout=1) as c:
        return sum(c.execute("UPDATE archive_jobs SET next_attempt=0 WHERE account_id=? AND chat_id=? AND msg_id=?",
                             key).rowcount for key in keys)


def remove_service_chat():
    """Drop the never-archived Telegram service chat using the primary-key prefix."""
    with db(timeout=1) as c:
        accounts = {r[0] for r in c.execute("SELECT DISTINCT account_id FROM chats WHERE chat_id=?", (SERVICE_CHAT,))}
        accounts.update(r[0] for r in c.execute("SELECT id FROM accounts"))
        for account_id in sorted(accounts):
            c.execute("DELETE FROM messages WHERE account_id=? AND chat_id=?", (account_id, SERVICE_CHAT))
        c.execute("DELETE FROM chats WHERE chat_id=?", (SERVICE_CHAT,))


async def stop_ingest():
    global INGEST_TASK
    if INGEST_TASK and not INGEST_TASK.done():
        await INGEST_QUEUE.join()  # accepted updates are committed or spooled before exit
        INGEST_TASK.cancel()
        await asyncio.gather(INGEST_TASK,return_exceptions=True)
    INGEST_TASK = None

    await stop_db_writer()


async def store_message(client, account_id, msg, chat_id, title, ctype, expected_job_token=None):
    """Пишет сообщение + скачивает медиа. Молча пропускает служебные
    и вручную удалённые (чтобы авто-догонка не возвращала почищенное)."""
    if chat_id == SERVICE_CHAT or getattr(msg, "action", None):
        return
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg.id)) % len(MESSAGE_LOCKS)]
    async with lock:
        await _store_message_locked(client, account_id, msg, chat_id, title, ctype, expected_job_token)


async def _store_message_locked(client, account_id, msg, chat_id, title, ctype, expected_job_token=None,
                                force_video=False):
    """force_video: a download the user asked for in the panel, so an ordinary video is fetched too."""
    def load_state():
        with db(timeout=1) as c:
            if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
                return False,None
            watermark = c.execute("SELECT clear_through_msg_id FROM chats WHERE account_id=? AND chat_id=?",
                                  (account_id,chat_id)).fetchone()
            in_bin = c.execute("SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=?",
                               (account_id,chat_id,msg.id)).fetchone()
            if in_bin or (watermark and msg.id <= (watermark[0] or 0)):
                return False,None
            previous = c.execute("SELECT * FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                                 (account_id,chat_id,msg.id)).fetchone()
            if previous and (previous["source_version"] or previous["date"] or "") > message_version(msg):
                return False,None
            return True,dict(previous) if previous else None
    allowed,previous = await thread_call(load_state)
    if not allowed:
        return
    key = account_id,chat_id,msg.id
    with db() as c:
        suppressed = bool(c.execute("SELECT 1 FROM media_suppression WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone())
        if expected_job_token is not None and not c.execute(
                "SELECT 1 FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?",
                (*key,expected_job_token)).fetchone():
            return
    sender_profile = await cache_message_sender(client, account_id, msg)
    kind = None if suppressed else media_kind(msg)
    fp = fs = None
    approval = None
    media_status = None
    media_error = None
    stale_media_path = None
    media_id = None
    pending_publish = None
    download_error = None
    file_key = reused_from = None
    def _persist_message_sync():
        """Persist the text and media state, rechecking concurrent cleanup before writing."""
        with db(timeout=1) as c:
            c.execute("BEGIN IMMEDIATE")
            if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
                return False
            watermark = c.execute("SELECT clear_through_msg_id FROM chats WHERE account_id=? AND chat_id=?",
                                  (account_id, chat_id)).fetchone()
            in_bin = c.execute("SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=?",
                               (account_id, chat_id, msg.id)).fetchone()
            if (watermark and msg.id <= (watermark[0] or 0)) or in_bin:
                return False
            version = c.execute("SELECT source_version,date,capture_order,text FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                                (account_id,chat_id,msg.id)).fetchone()
            if version and (version["source_version"] or version["date"] or "") > message_version(msg):
                return False
            if version and (version["capture_order"] or 0) != (previous["capture_order"] or 0 if previous else 0):
                return False
            now_suppressed = bool(c.execute("SELECT 1 FROM media_suppression WHERE account_id=? AND chat_id=? AND msg_id=?",key).fetchone())
            if now_suppressed != suppressed:
                return False
            if expected_job_token is not None and not c.execute(
                    "SELECT 1 FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=? AND token=?",
                    (account_id,chat_id,msg.id,expected_job_token)).fetchone():
                return False
            # The SQL write lock protects the final generation check and publication.
            # Stale workers cannot promote a file before this generation check.
            if pending_publish:
                candidate_path,destination = pending_publish
                if candidate_path.is_file():
                    candidate_path.replace(destination)
                elif not destination.is_file() or (fs and destination.stat().st_size != fs):
                    raise OSError("Файл исчез до фиксации загрузки")
            saved_text = (version["text"] if version and
                (version["source_version"] or version["date"] or "") == message_version(msg)
                else render_text(msg))
            c.execute(
                "INSERT INTO messages "
                "(account_id,chat_id,msg_id,date,sender_id,out,text,media_type,file_path,file_size,"
                "media_approval,media_id,media_status,media_error,source_version,capture_order) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(account_id,chat_id,msg_id) DO UPDATE SET "
                "date=excluded.date,sender_id=excluded.sender_id,out=excluded.out,text=excluded.text,"
                "media_type=excluded.media_type,file_path=excluded.file_path,file_size=excluded.file_size,"
                "media_approval=excluded.media_approval,media_id=excluded.media_id,media_status=excluded.media_status,"
                "media_error=excluded.media_error,source_version=excluded.source_version,capture_order=excluded.capture_order",
                (account_id, chat_id, msg.id,
                 msg.date.isoformat() if msg.date else None,
                 msg.sender_id, 1 if msg.out else 0, saved_text,
                 kind, fp, fs, approval, media_id, media_status, media_error,message_version(msg),
                 version["capture_order"] if version else 0))
            c.execute(
                """INSERT INTO chats (account_id, chat_id, title, type, max_msg_id)
                   VALUES (?,?,?,?,?)
                   ON CONFLICT(account_id, chat_id) DO UPDATE SET
                   title = CASE WHEN excluded.title != '?' THEN excluded.title ELSE chats.title END,
                   max_msg_id = MAX(chats.max_msg_id, excluded.max_msg_id)""",
                (account_id, chat_id, title, ctype, msg.id))
        return True

    def persist_message_sync():
        try:
            return _persist_message_sync()
        except Exception:
            # If SQL rolls back after promotion, restore the recoverable candidate.
            if pending_publish:
                candidate_path,destination = pending_publish
                if destination.is_file() and not candidate_path.exists():
                    rel = str(destination.relative_to(BASE)).replace("\\", "/")
                    if not media_path_referenced(account_id, chat_id, msg.id, rel):
                        destination.replace(candidate_path)
            raise

    async def persist_message():
        return await write_call(persist_message_sync)

    if kind:
        photo_variant, _ = photo_transfer_spec(msg)
        fs = media_expected_size(msg) or 0
        file_key = telegram_file_key(msg, fs, kind)
        file_info = media_file_info(msg, kind)
        media_id = getattr(file_info, "id", None) if file_info else None
        same_media = bool(previous and previous["file_size"] == fs and
                          previous["media_type"] == kind and previous["media_id"] == media_id)
        if same_media:
            approval = previous["media_approval"]
            if previous["media_status"] == "dismissed":
                media_status = "dismissed"
                fp = previous["file_path"]
        elif previous and previous["file_path"]:
            stale_media_path = previous["file_path"]
        over_large_threshold = fs > LARGE_MEDIA_APPROVAL_BYTES
        if over_large_threshold and approval not in ("approved", "rejected"):
            approval = "pending"
        if (media_status != "dismissed" and not force_video and skips_video_download(msg) and
                not (same_media and previous["file_path"] and media_file_matches(previous["file_path"], fs))):
            # Only round videos are archived. A file already on disk (even a partial one) stays referenced.
            media_status = "skipped"
            approval = previous["media_approval"] if same_media else None
            if approval == "pending":
                approval = None
            if same_media and previous["file_path"]:
                fp = previous["file_path"]
        if media_status not in ("dismissed", "skipped") and ((over_large_threshold and approval == "approved") or
                (not over_large_threshold and fs <= MAX_MB * 1024 * 1024)):
            ext = (file_info.ext if file_info and file_info.ext else EXT_FALLBACK[kind])
            name = getattr(file_info, "name", None) if file_info else None
            if kind == "document" and name:      # настоящее расширение из имени файла
                dot = name.rfind(".")
                if 0 < dot and len(name) - dot <= 10:
                    ext = name[dot:]
            if not re.fullmatch(r"\.[A-Za-z0-9]{1,9}", ext or ""):
                ext = EXT_FALLBACK[kind]
            # Уже скачанный файл повторно не качаем; неполную часть держим отдельно
            # и сохраняем до успешной замены полной копией.
            previous_path = None
            if same_media and previous["file_path"]:
                try:
                    previous_path = safe_media_path(previous["file_path"])
                except (ValueError, OSError):
                    previous_path = None
            if (previous_path and not previous_path.name.endswith(".partial")
                    and media_file_matches(previous["file_path"], fs)):
                fp = previous["file_path"]
            else:
                folder = await thread_call(lambda: MEDIA / account_dir(account_id) / chat_dir_name(account_id,chat_id,title))
                base = media_file_name(msg, ext, ctype, msg.sender_id,
                                       sender_profile.get("username") if sender_profile else None)
                # ID сообщения стабилен внутри чата и исключает гонку за именем.
                preferred_target = folder / f"{base} [{msg.id}]{ext}"
                # Keep a legacy/incomplete path stable so older database rows
                # are repaired in place. New partials use a distinct suffix.
                if previous_path and not previous_path.name.endswith(".partial"):
                    target = previous_path
                    partial_target = previous_path
                else:
                    target = preferred_target
                    partial_target = (previous_path if previous_path else
                                      target.with_name(target.name + ".partial"))
                # First transfer streams straight into the stable partial path so
                # a process stop cannot orphan it. Retries use scratch space to
                # avoid overwriting a more complete partial until it improves.
                partial_stat = partial_target.stat() if partial_target.is_file() else None
                partial_size = partial_stat.st_size if partial_stat else 0
                # Appending in place would change every hard link to the same data.
                can_resume = bool(client is not None and kind != "photo" and getattr(msg, "document", None)
                                  and fs and 0 < partial_size < fs and partial_stat.st_nlink <= 1
                                  and hasattr(client, "iter_download"))
                tmp = (partial_target if can_resume or not partial_target.is_file() else
                       target.with_name(f".{target.name}.{secrets.token_hex(6)}.part"))
                media_status = "downloading"
                media_error = None
                # Save a stable partial path before starting. If the process exits,
                # the database still points to the recoverable part of this message.
                fp = str(partial_target.relative_to(BASE)).replace("\\", "/")
                if not await persist_message():
                    return
                candidate = tmp

                def preserve_partial():
                    """Keep the largest available partial file under a stable path."""
                    try:
                        if not candidate.is_file() or candidate.stat().st_size <= 0:
                            return partial_target if partial_target.is_file() else None
                        candidate_size = candidate.stat().st_size
                        existing_size = partial_target.stat().st_size if partial_target.is_file() else 0
                        if existing_size >= candidate_size:
                            if candidate != partial_target:
                                candidate.unlink(missing_ok=True)
                            return partial_target
                        if candidate.resolve() != partial_target.resolve():
                            candidate.replace(partial_target)
                        return partial_target
                    except OSError:
                        return partial_target if partial_target.is_file() else None

                reused_from = None
                if not can_resume and not (partial_stat and partial_size == fs and fs) and not tmp.exists():
                    # The same Telegram file is already stored (another chat, account
                    # or forward): link to it instead of downloading a second copy.
                    source = await thread_call(reusable_media_file, file_key, fs)
                    if source is not None:
                        try:
                            tmp.parent.mkdir(parents=True, exist_ok=True)
                            os.link(source, tmp)
                            reused_from = source
                        except OSError:
                            reused_from = None
                try:
                    async with MEDIA_DOWNLOAD_SEM:
                        free = shutil.disk_usage(BASE).free
                        remaining = max(0, fs - partial_size) if can_resume else fs
                        if reused_from is None and (free < MIN_FREE_MEDIA_SPACE_BYTES or (
                                fs and free - remaining < MIN_FREE_MEDIA_SPACE_BYTES)):
                            raise OSError(
                                f"Недостаточно места: свободно {free / 1024**3:.2f} ГБ; "
                                f"после загрузки нужно оставить не менее "
                                f"{MIN_FREE_MEDIA_SPACE_BYTES / 1024**3:.0f} ГБ")
                        target.parent.mkdir(parents=True, exist_ok=True)
                        if reused_from is not None:
                            candidate = tmp
                        elif can_resume:
                            with tmp.open("ab") as output:
                                async for chunk in client.iter_download(msg.document, offset=partial_size):
                                    await BACKGROUND_LOAD.wait_turn()
                                    output.write(chunk)
                            candidate = tmp
                        elif partial_target.is_file() and partial_size == fs and fs:
                            candidate = partial_target
                        else:
                            photo_options = {"thumb": photo_variant} if photo_variant is not None else {}
                            source = media_source(msg, kind)
                            if source is msg:
                                downloaded = await msg.download_media(file=str(tmp), progress_callback=pace_media_download, **photo_options)
                            else:
                                downloaded = await client.download_media(source, file=str(tmp), progress_callback=pace_media_download, **photo_options)
                            candidate = Path(downloaded) if downloaded else tmp
                        if not candidate.is_file():
                            raise OSError("Telegram не вернул файл медиа")
                        actual_size = candidate.stat().st_size
                        if fs and actual_size != fs:
                            raise OSError(f"Неполный файл: получено {actual_size} из {fs} байт")
                        if photo_variant is not None:
                            await thread_call(validate_photo_file, candidate, bool(fs))
                        pending_publish = (candidate,target)
                        if previous_path and previous_path.name.endswith(".partial"):
                            stale_media_path = str(previous_path.relative_to(BASE)).replace("\\", "/")
                        media_status = None
                        fp = str(target.relative_to(BASE)).replace("\\", "/")
                except asyncio.CancelledError:
                    preserve_partial()
                    media_status = "incomplete"
                    media_error = "Загрузка прервана до завершения файла. Можно повторить позже."
                    fp = (str(partial_target.relative_to(BASE)).replace("\\", "/")
                          if partial_target.is_file() else None)
                    await persist_message()
                    raise
                except Exception as exc:
                    if isinstance(exc,FloodWaitError) or session_lost(exc):
                        download_error = exc
                    media_status = "storage_full" if (str(exc).startswith("Недостаточно места") or
                        getattr(exc, "winerror", None) == 112 or getattr(exc, "errno", None) == 28) else "incomplete"
                    media_error = f"{type(exc).__name__}: {exc}"[:300]
                    preserve_partial()
                    fp = (str(partial_target.relative_to(BASE)).replace("\\", "/")
                          if partial_target.is_file() else None)
                    try:
                        if client is not None and client.is_connected():
                            still_exists = await client.get_messages(chat_id, ids=msg.id)
                            if still_exists is None:
                                media_status = "unavailable"
                                media_error = "Сообщение с файлом удалено или больше недоступно в Telegram."
                    except Exception:
                        pass
                finally:
                    if candidate != partial_target and not pending_publish:
                        tmp.unlink(missing_ok=True)
    elif previous and previous["file_path"]:
        stale_media_path = previous["file_path"]
    if not await persist_message():
        if pending_publish:
            rel = str(partial_target.relative_to(BASE)).replace("\\", "/")
            if media_path_referenced(account_id, chat_id, msg.id, rel):
                preserve_partial()
            else:
                candidate.unlink(missing_ok=True)
                partial_target.unlink(missing_ok=True)
        return
    if pending_publish and partial_target != target and partial_target.is_file():
        stale_media_path = str(partial_target.relative_to(BASE)).replace("\\", "/")
    if pending_publish:
        MEDIA_BYTES[account_id] = MEDIA_BYTES.get(account_id,0) + target.stat().st_size
    await thread_call(ensure_chat_dir,account_id,chat_id,title)
    if stale_media_path:
        if not media_path_referenced(account_id, chat_id, msg.id, stale_media_path):
            try:
                safe_media_path(stale_media_path).unlink(missing_ok=True)
            except (ValueError, OSError):
                pass
    if pending_publish:
        # Identical content already on disk becomes one file; never fails the message.
        await thread_call(register_saved_media, target, file_key, reused_from)

    if download_error is not None:
        raise download_error


def classify(ent):
    from telethon.tl.types import Channel, Chat
    if isinstance(ent, Channel):
        kind = "group" if ent.megagroup else "channel"
        title = getattr(ent, "title", None) or "Неизвестный чат"
        username = getattr(ent, "username", None)
        return kind, f"{title} (@{username})" if username else title
    if isinstance(ent, Chat):
        return "group", (getattr(ent, "title", None) or "Неизвестный чат")
    name = " ".join(p for p in (getattr(ent, "first_name", None),
                                getattr(ent, "last_name", None)) if p).strip()
    username = getattr(ent, "username", None)
    phone = getattr(ent, "phone", None)
    identity = "@" + username if username else ("+" + phone if phone else "Неизвестно")
    return "user", f"{name} ({identity})" if name else identity


# ---------- запись одного аккаунта ----------

REC = {}      # account_id -> {"task": asyncio.Task}
FLOWS = {}    # fid -> {"client", "qr", "state", "account_id"}
CLIENTS = {}  # account_id -> TelegramClient (один клиент на аккаунт)
BACKFILL = {} # account_id -> {"task", "state", "total", "done", "msgs", "bytes", "note"}
MEDIA_BYTES = {}  # account_id -> скачано медиа за текущий прогон истории (байт)


async def recorder(account_id, client=None):
    """Живёт, пока аккаунт подключён: ловит новые сообщения и пишет их."""
    if client is None:
        # raise_last_call_error: report Telegram's own error (e.g. "No workers running",
        # FLOOD_WAIT) instead of Telethon's generic "Request was unsuccessful N time(s)".
        client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                                int(API_ID), API_HASH, catch_up=True, raise_last_call_error=True)
    CLIENTS[account_id] = client
    while True:
        on_new = None
        try:
            rows = await thread_call(sql_rows, "SELECT chat_id,type,title FROM chats WHERE account_id=?", (account_id,))
            chat_info = {row["chat_id"]: (row["type"], row["title"]) for row in rows}

            async def on_new(ev):
                try:
                    info = chat_info.get(ev.chat_id)
                    if info is None:
                        entity = getattr(ev,"chat",None)
                        if entity is not None:
                            kind,title = classify(entity)
                        else:
                            if ev.is_channel and not ev.is_group:
                                return
                            kind,title = ("group" if ev.is_group else "user"),"?"
                        info = chat_info[ev.chat_id] = (kind, title)
                    kind, title = info
                    if kind == "channel":
                        return
                    await capture_live_message(client, account_id, ev.message,
                                               ev.chat_id, title, kind)
                except Exception as e:
                    print(f"[acct {account_id}] {type(e).__name__}: {e}")

            client.add_event_handler(on_new, events.NewMessage())
            client.add_event_handler(on_new, events.MessageEdited())
            await client.connect()
            if not await client.is_user_authorized():
                # авторизации нет: ключ отозван (сеанс завершён из Telegram) или умер
                await end_lost_session(account_id)
                return
            me = await client.get_me()
            if me is None:
                # Telethon помнит первую удачную проверку входа; если сеанс завершили
                # во время работы, об этом честно говорит только пустой get_me()
                await end_lost_session(account_id)
                return
            # этот аккаунт уже есть в панели (отключён / на паузе / ошибка / дубль)?
            # продолжаем его архив под старым id — догонка пойдёт от последнего сообщения
            duplicates = await thread_call(sql_rows, "SELECT id FROM accounts WHERE tg_user_id=? AND id!=?", (me.id, account_id))
            old = duplicates[0] if duplicates else None
            if old:
                old_id = old["id"]
                await release_client(client)
                CLIENTS.pop(account_id, None)
                stop_recorder(old_id)         # если старый вариант ещё писал — глушим
                moved = False
                for _ in range(3):            # файлы могут отпустить не сразу
                    try:
                        dst = SESSIONS / f"account_{old_id}.session"
                        dst.unlink(missing_ok=True)   # старый ключ заменяем свежим
                        (SESSIONS / f"account_{account_id}.session").rename(dst)
                        moved = True
                        break
                    except OSError:
                        await asyncio.sleep(1)
                if not moved:
                    # сессию не удалось перенести на старый id — обрываем вход начисто,
                    # иначе тот же аккаунт запишется под новым id и задублирует архив
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                    CLIENTS.pop(account_id, None)
                    (SESSIONS / f"account_{account_id}.session").unlink(missing_ok=True)
                    await write_call(sql_write, "DELETE FROM accounts WHERE id=?", (account_id,))
                    print(f"[acct {account_id}] перенос сессии на id {old_id} не удался — "
                          f"вход прерван, чтобы не задублировать архив")
                    return
                if moved:
                    await write_call(sql_write, "DELETE FROM accounts WHERE id=?", (account_id,))
                    account_id = old_id
                identity_changed = await write_call(set_status, account_id, "recording", name=" ".join(
                               p for p in (me.first_name, me.last_name) if p),
                           username=getattr(me, "username", None) or "",
                           phone="+" + str(me.phone) if getattr(me, "phone", None) else None,
                           tg_user_id=me.id)
                if identity_changed:
                    await asyncio.to_thread(migrate_media_paths, account_id)
                    await asyncio.to_thread(ensure_known_chat_dirs, account_id)
                start_recorder(account_id)    # свежий клиент на старом session-файле
                return
            identity_changed = await write_call(set_status, account_id, "recording", name=" ".join(
                           p for p in (me.first_name, me.last_name) if p),
                       username=getattr(me, "username", None) or "",
                       phone="+" + str(me.phone) if getattr(me, "phone", None) else None,
                       tg_user_id=me.id)
            if identity_changed:
                await asyncio.to_thread(migrate_media_paths, account_id)
                await asyncio.to_thread(ensure_known_chat_dirs, account_id)
            if account_id not in LOGGED:      # устройство появилось в активных сеансах ТГ
                LOGGED.add(account_id)
                await write_call(add_event, account_id, "login", "устройство подключилось")
            # при каждом (пере)подключении тихо догоняем всё, что случилось без нас:
            # пауза, обрыв связи, упавшая панель — окно пропуска закрывается само
            start_backfill(account_id)
            await client.catch_up()
            await client.run_until_disconnected()
            await write_call(set_status, account_id, "reconnecting")
        except Exception as e:
            print(f"[acct {account_id}] rec error: {type(e).__name__}: {e}")
            if session_lost(e):
                await end_lost_session(account_id)
                return
            await write_call(set_status, account_id, "reconnecting")
        finally:
            if on_new is not None:
                client.remove_event_handler(on_new)
        await asyncio.sleep(10)


async def release_client(client):
    """Disconnect and close the session file even when Telethon's disconnect fails.

    Telethon closes the session only at the very end of disconnect; an error before that
    left the file open, and Windows then refused to replace it on «Подключить заново».
    """
    try:
        await client.disconnect()
    except Exception:
        pass
    try:
        client.session.close()
    except Exception:
        pass


def stop_recorder(account_id):
    """Останавливает запись И отключает клиент — иначе после пауз плодились
    зомби-соединения на одну сессию, и Telegram мог слать события не тому клиенту."""
    rec = REC.pop(account_id, None)
    cl = CLIENTS.pop(account_id, None)
    if rec:
        rec["task"].cancel()
    if cl is not None:
        try:
            asyncio.get_running_loop().create_task(release_client(cl))
        except RuntimeError:
            pass


def start_recorder(account_id, client=None):
    if account_id in REC:
        return
    entry = {"task": asyncio.create_task(recorder(account_id, client))}
    REC[account_id] = entry
    def clear_finished(done):
        if REC.get(account_id) is entry:
            REC.pop(account_id, None)
    entry["task"].add_done_callback(clear_finished)


def session_lost(exc):
    """Telegram no longer accepts this login: ended in Devices, expired, account banned.

    Only a new login helps. A network drop is not this and keeps reconnecting.
    """
    return (isinstance(exc, (UnauthorizedError, AuthKeyDuplicatedError))
            and not isinstance(exc, SessionPasswordNeededError))


LOST_SESSION_REASON = "Telegram завершил сеанс этого аккаунта. Нажмите «Подключить заново» и войдите в этот же аккаунт."


async def end_lost_session(account_id):
    """Every lost login ends the same way: «нужен повторный вход» and the client released.

    Telethon caches the first successful authorization check, so a session ended while
    running used to loop in «переподключение» and spend the attempts of queued files.
    """
    rows = await thread_call(sql_rows, "SELECT status FROM accounts WHERE id=?", (account_id,))
    if not rows or rows[0]["status"] in ("paused", "disconnected", "linking"):
        return
    if rows[0]["status"] != "error":
        if account_id in LOGGED:
            LOGGED.discard(account_id)
            await write_call(add_event, account_id, "revoked", "сеанс завершён из Telegram")
        elif (SESSIONS / f"account_{account_id}.session").exists():
            await write_call(add_event, account_id, "revoked", "авторизация недействительна")
        await write_call(set_status, account_id, "error")
    current = asyncio.current_task()
    st = BACKFILL.get(account_id)
    if st and st.get("state") in ("running", "queued") and st.get("task") not in (None, current):
        st["task"].cancel()
    for (aid, _, _), task in list(ARCHIVE_JOB_TASKS.items()):
        if aid == account_id and task is not current:
            task.cancel()
    rec = REC.pop(account_id, None)
    client = CLIENTS.pop(account_id, None)
    if rec and rec["task"] is not current:
        rec["task"].cancel()  # the recorder itself returns right after this instead
    if client is not None:
        await release_client(client)


# ---------- подключение по QR ----------

async def start_flow():
    with db() as c:
        account_id = c.execute(
            "INSERT INTO accounts(name, status) VALUES('Ожидает скана QR', 'linking')"
        ).lastrowid
    client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                            int(API_ID), API_HASH, raise_last_call_error=True)
    qr = None
    for attempt in range(2):          # повтор при кратковременном обрыве соединения
        try:
            await client.connect()
            qr = await client.qr_login()
            break
        except (Exception, asyncio.CancelledError) as exc:
            if attempt == 1 or isinstance(exc, asyncio.CancelledError):
                # флоу не стартовал — убираем за собой заготовку полностью
                try:
                    await client.disconnect()
                except Exception:
                    pass
                try:
                    client.session.close()
                    (SESSIONS / f"account_{account_id}.session").unlink(missing_ok=True)
                except Exception:
                    pass
                with db() as c:
                    c.execute("DELETE FROM accounts WHERE id=? AND status='linking'",
                              (account_id,))
                raise
            await asyncio.sleep(3)
    fid = str(account_id)
    FLOWS[fid] = {"client": client, "qr": qr, "state": "waiting",
                  "account_id": account_id}

    f = FLOWS[fid]

    async def waiter():
        try:
            while f["state"] == "waiting":
                try:
                    await asyncio.wait_for(f["qr"].wait(), timeout=25)
                except asyncio.TimeoutError:
                    if f["state"] != "waiting":
                        break
                    try:
                        await f["qr"].recreate()
                    except Exception:
                        f["qr"] = await f["client"].qr_login()
                    continue
                except SessionPasswordNeededError:
                    f["state"] = "pwd"
                    return
                authorized = await f["client"].is_user_authorized()
                if FLOWS.get(fid) is not f or f["state"] != "waiting":
                    return
                if authorized:
                    f["state"] = "authorized"
                    start_recorder(f["account_id"], f["client"])
                    return
        except Exception as e:
            f["state"] = "error"
            print(f"[flow {fid}] {type(e).__name__}: {e}")

    f["task"] = asyncio.create_task(waiter())
    async def expire_qr():
        await asyncio.sleep(900)
        if FLOWS.get(fid) is f and f["state"] != "authorized":
            await api_qr_cancel(fid)
    f["expiry_task"] = asyncio.create_task(expire_qr())
    return fid


async def finish_pwd(fid, password):
    f = FLOWS.get(fid)
    if not f or f["state"] != "pwd":
        return False
    if f.get("request_task"):
        return False
    f["request_task"] = asyncio.current_task()
    try:
        await asyncio.wait_for(f["client"].sign_in(password=password), timeout=40)
    except PasswordHashInvalidError:
        return False
    finally:
        f["request_task"] = None
    if FLOWS.get(fid) is not f or f["state"] != "pwd":
        return False
    f["state"] = "authorized"
    start_recorder(f["account_id"], f["client"])
    return True


# ---------- загрузка истории аккаунта ----------

BACKFILL_SEM = asyncio.Semaphore(1)   # only account discovery; never hold across history/FloodWait
HISTORY_PAGE_SEM = AdaptiveSlots()  # page fetches, FIFO across all accounts, 2..8 by CPU
HISTORY_COUNT_SEM = asyncio.Semaphore(1)  # at most four count-only requests/sec globally
HISTORY_BATCH_PAUSE = 0.05  # leave disk/CPU time for live receipts and the panel
HISTORY_BATCH_SIZE = 100
HISTORY_FAST_BATCHES = 0
BACKFILL_FETCH_TIMEOUT = 45  # не позволяем одному запросу истории зависнуть навсегда
BACKFILL_MESSAGE_TIMEOUT = 180  # ограничиваем и загрузку отдельного сообщения с медиа
BACKFILL_PARTICIPANTS_TIMEOUT = 45


async def store_history_batch(account_id, messages, chat_id, title, ctype, state, checkpoint=None):
    """Commit a bounded page atomically; slow disk fsync must not repeat per message."""
    global HISTORY_BATCH_SIZE, HISTORY_FAST_BATCHES
    if not messages:
        return
    state.update(current_message=messages[-1].id,current_media_size=0,
                 note="сохраняю сообщения; вложения обрабатываются отдельно")
    snapshots=[(live_snapshot(account_id,msg,chat_id,title,ctype),msg) for msg in messages
               if chat_id != SERVICE_CHAT and not getattr(msg,"action",None)]
    if not snapshots and checkpoint is None:
        return
    args = ([s for s,_ in snapshots], True)
    if checkpoint is not None:
        args += (checkpoint,)
    def persist_timed_page():
        # Measure the transaction, not time spent waiting behind other accounts.
        # Shrinking pages because of queue wait creates more commits and contention.
        started=time.monotonic()
        accepted=persist_live_batch(*args)
        return accepted,time.monotonic()-started
    try:
        accepted,elapsed=await asyncio.wait_for(write_call(persist_timed_page,_write_priority=0),BACKFILL_FETCH_TIMEOUT)
    except asyncio.TimeoutError as exc:
        raise TimeoutError("SQLite history save timed out (writer wait or commit)") from exc
    if elapsed > 0.08:
        HISTORY_BATCH_SIZE = max(25,HISTORY_BATCH_SIZE // 2)
        HISTORY_FAST_BATCHES = 0
    elif elapsed < 0.02:
        HISTORY_FAST_BATCHES += 1
        if HISTORY_FAST_BATCHES >= 3:
            HISTORY_BATCH_SIZE = min(100,HISTORY_BATCH_SIZE * 2)
            HISTORY_FAST_BATCHES = 0
    else:
        HISTORY_FAST_BATCHES = 0
    for (snapshot,msg),ok in zip(snapshots,accepted):
        if ok:
            LIVE_MESSAGES[snapshot["token"]]=msg
    while len(LIVE_MESSAGES)>256:
        LIVE_MESSAGES.popitem(last=False)
    ARCHIVE_WAKE.set()
    await asyncio.sleep(HISTORY_BATCH_PAUSE)


async def store_history_message(client, account_id, msg, chat_id, title, ctype, state, deferred):
    await store_history_batch(account_id,[msg],chat_id,title,ctype,state)


async def iter_messages_with_timeout(client, *args, **kwargs):
    """Итерирует историю с таймаутом на каждый запрос следующей страницы."""
    iterator = client.iter_messages(*args, **kwargs).__aiter__()
    while True:
        try:
            message = await asyncio.wait_for(
                iterator.__anext__(), timeout=BACKFILL_FETCH_TIMEOUT)
        except StopAsyncIteration:
            return
        except asyncio.TimeoutError as exc:
            raise TimeoutError("Telegram history fetch timed out") from exc
        yield message


async def iter_history_batches(client, *args, **kwargs):
    iterator=iter_messages_with_timeout(client,*args,**kwargs).__aiter__()
    exhausted=False
    while not exhausted:
        batch=[]
        # Release the slot before yielding: a slow commit or a cancelled consumer
        # must not strand a network slot. No account owns a slot during FloodWait.
        async with HISTORY_PAGE_SEM:
            await BACKGROUND_LOAD.wait_turn()
            while len(batch)<HISTORY_BATCH_SIZE:
                try:
                    batch.append(await anext(iterator))
                except StopAsyncIteration:
                    exhausted=True
                    break
        if not batch:
            return
        yield batch


def start_backfill(account_id, retry_only=False):
    """Запускает догонку истории, если она уже не идёт. True = запустили."""
    with db() as c:
        account = c.execute("SELECT status FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not account or account["status"] in ("paused", "disconnected", "linking"):
        return False
    st = BACKFILL.get(account_id)
    if st and st.get("state") in ("running", "queued"):
        return False
    state = {"task": None, "state": "queued", "total": 0, "done": 0,
             "msgs": 0, "bytes": 0, "note": "", "current_chat": "",
             "current_message": 0, "current_media_size": 0, "retry_only": retry_only}
    BACKFILL[account_id] = state
    state["task"] = asyncio.create_task(run_backfill(account_id, state))
    def mark_cancelled(task):
        if task.cancelled() and state.get('state') in ('queued','running'):
            state['state'] = 'stopped'
    state['task'].add_done_callback(mark_cancelled)
    return True


async def run_backfill(account_id, state):
    try:
        await _run_backfill_inner(account_id, state)
    except asyncio.CancelledError:
        if state.get("state") in ("running", "queued"):
            state["state"] = "stopped"
        raise
    except Exception as e:
        state.update(state="error", note=f"{type(e).__name__}: {e}")


def register_history_progress(account_id, chat_ids, discovered=False):
    with db(timeout=1) as c:
        c.executemany("INSERT OR IGNORE INTO history_progress(account_id,chat_id) VALUES(?,?)",
                      ((account_id, cid) for cid in chat_ids))
        c.execute("""INSERT INTO history_progress_plan VALUES(?,?) ON CONFLICT(account_id)
                     DO UPDATE SET discovered=MAX(discovered,excluded.discovered)""",
                  (account_id, int(discovered)))


def measure_history_progress_connection(c, account_id, chat_id):
    row=c.execute("SELECT saved FROM history_progress WHERE account_id=? AND chat_id=?",
                  (account_id,chat_id)).fetchone()
    if row:
        saved=row['saved']
        if saved is None:
            saved=c.execute("SELECT COUNT(*) FROM messages WHERE account_id=? AND chat_id=?",
                            (account_id,chat_id)).fetchone()[0]
        c.execute("UPDATE history_progress SET saved=?,total=?,complete=1 WHERE account_id=? AND chat_id=?",
                  (saved,saved,account_id,chat_id))


def measure_history_progress(account_id, chat_id, total=None, complete=False):
    # One indexed count when this chat is first measured, on the serialized writer.
    # Subsequent inserts/deletes maintain saved in the same transaction as messages.
    with db(timeout=1) as c:
        row=c.execute("SELECT saved,complete FROM history_progress WHERE account_id=? AND chat_id=?",
                      (account_id,chat_id)).fetchone()
        if not row or (row['complete'] and not complete):
            return
        saved=row['saved']
        if saved is None:
            saved=c.execute("SELECT COUNT(*) FROM messages WHERE account_id=? AND chat_id=?",
                            (account_id,chat_id)).fetchone()[0]
        if complete:
            total=saved
        c.execute("UPDATE history_progress SET total=?,saved=?,complete=? WHERE account_id=? AND chat_id=?",
                  (max(0,int(total)) if total is not None else None,saved,int(complete),account_id,chat_id))


async def measure_history_totals(client, account_id, dialogs):
    # Count-only Telegram requests: no message bodies or media, no historical replay.
    from telethon.errors import FloodWaitError
    for d in dialogs:
        with db() as c:
            row=c.execute("SELECT total FROM history_progress WHERE account_id=? AND chat_id=?",
                          (account_id,d.id)).fetchone()
        if row and row['total'] is not None:
            continue
        try:
            async with HISTORY_COUNT_SEM:
                await BACKGROUND_LOAD.wait_turn()
                async with HISTORY_PAGE_SEM:
                    result=await asyncio.wait_for(client.get_messages(d.id,limit=0),30)
                await asyncio.sleep(0.25)
            total=getattr(result,'total',None)
            if total is not None:
                await write_call(measure_history_progress,account_id,d.id,total)
        except FloodWaitError as e:
            await asyncio.sleep(e.seconds+2)
        except Exception:
            # Missing counts never prevent history ingestion or invent a percentage.
            continue


def history_progress_summary(c):
    return {row['account_id']:dict(row) for row in c.execute("""
        SELECT p.account_id,p.discovered,COUNT(h.chat_id) AS chats,
               COALESCE(SUM(CASE WHEN h.chat_id IS NOT NULL AND
                   (h.total IS NULL OR h.saved IS NULL) THEN 1 ELSE 0 END),0) AS unknown,
               COALESCE(SUM(h.complete),0) AS completed_chats,
               COALESCE(SUM(h.total),0) AS total,
               COALESCE(SUM(MIN(h.saved,h.total)),0) AS saved
        FROM history_progress_plan p LEFT JOIN history_progress h ON h.account_id=p.account_id
        GROUP BY p.account_id""")}


def prepare_history_chat(account_id, chat_id, title, ctype):
    """Read/update chat metadata on the serialized writer, outside the event loop."""
    with db(timeout=1) as c:
        row = c.execute("SELECT * FROM chats WHERE account_id=? AND chat_id=?",
                        (account_id, chat_id)).fetchone()
        if row and (row['title'] != title or row['type'] != ctype):
            c.execute("UPDATE chats SET title=?,type=? WHERE account_id=? AND chat_id=?",
                      (title, ctype, account_id, chat_id))
        return dict(row) if row else None


def complete_history_chat(account_id, chat_id, min_id):
    with db(timeout=1) as c:
        c.execute("UPDATE chats SET min_msg_id=?,deep_done=1 WHERE account_id=? AND chat_id=?",
                  (min_id, account_id, chat_id))
        c.execute("DELETE FROM history_pending WHERE account_id=? AND chat_id=?", (account_id, chat_id))
        measure_history_progress_connection(c, account_id, chat_id)


def queue_history_dialogs(account_id, dialogs):
    """Persist the plan before fetching any messages; never overwrite an unfinished plan."""
    with db(timeout=1) as c:
        for chat_id, title, ctype in dialogs:
            row = c.execute("SELECT history_cursor,min_msg_id FROM chats WHERE account_id=? AND chat_id=?",
                            (account_id, chat_id)).fetchone()
            forward_only = not row or not (row[0] or row[1])
            c.execute("INSERT OR IGNORE INTO history_pending VALUES(?,?,?,?,?)",
                      (account_id, chat_id, title, ctype, int(forward_only)))


def pending_history_dialogs(account_id):
    with db(timeout=1) as c:
        # Import unfinished legacy chats only. Completed chats are never inferred
        # to need retry merely because the user pressed the button.
        c.execute("""INSERT OR IGNORE INTO history_pending
            SELECT account_id,chat_id,COALESCE(title,'Неизвестный чат'),COALESCE(type,'user'),0
            FROM chats WHERE account_id=? AND COALESCE(deep_done,0)=0 AND chat_id<>?""",
                  (account_id, SERVICE_CHAT))
        return [dict(r) for r in c.execute(
            "SELECT * FROM history_pending WHERE account_id=? ORDER BY chat_id", (account_id,))]


def read_pending_history(account_id):
    with db(timeout=1) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM history_pending WHERE account_id=? ORDER BY chat_id", (account_id,))]


def first_saved_history_id(account_id, chat_id):
    with db(timeout=1) as c:
        return c.execute("SELECT MIN(msg_id) FROM messages WHERE account_id=? AND chat_id=?",
                         (account_id, chat_id)).fetchone()[0] or 0


def finish_history_dialog(account_id, chat_id):
    with db(timeout=1) as c:
        c.execute("DELETE FROM history_pending WHERE account_id=? AND chat_id=?", (account_id, chat_id))
        measure_history_progress_connection(c, account_id, chat_id)


def close_unreachable_history_chat(account_id, chat_id):
    """Telegram no longer lists this chat: keep what is saved and stop retrying it."""
    with db(timeout=1) as c:
        c.execute("UPDATE chats SET deep_done=1 WHERE account_id=? AND chat_id=?", (account_id, chat_id))
        c.execute("DELETE FROM history_pending WHERE account_id=? AND chat_id=?", (account_id, chat_id))
        measure_history_progress_connection(c, account_id, chat_id)


async def retry_history_target(client, chat_id, refreshed):
    """Input entity for a retried chat, or None when Telegram no longer lists it.

    A retry knows only the chat id; the access key comes from the session cache. When it
    is missing, the dialog list is reloaded once per pass to refill the cache. Before
    this, such a chat failed every minute forever and kept the history "not complete".
    """
    try:
        return await client.get_input_entity(chat_id)
    except ValueError:
        if refreshed.get("done"):
            return None
    refreshed["done"] = True
    await client.get_dialogs()
    try:
        return await client.get_input_entity(chat_id)
    except ValueError:
        return None


async def _run_backfill_inner(account_id, st):
    """Полная история аккаунта: входящие+исходящие, личные чаты, боты и группы.
    Broadcast-каналы пропускаются. Пишет туда же, куда и live."""
    from telethon.errors import FloodWaitError
    client = CLIENTS.get(account_id)
    own = False
    if client is None:
        client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                                int(API_ID), API_HASH, raise_last_call_error=True)
        own = True
    discovery_acquired=False
    progress_task=None
    try:
        await BACKFILL_SEM.acquire()
        discovery_acquired=True
        await BACKGROUND_LOAD.wait_turn()
        await client.connect()
        if not await client.is_user_authorized():
            st.update(state="error", note="нужен повторный вход по QR")
            return
        st.update(state="running", note="", total=0, done=0, msgs=0,
                  bytes=0, current_chat="", current_message=0,
                  current_media_size=0, media_failure_chats=0)
        retry_only = st.get("retry_only", False)
        if retry_only:
            jobs = await write_call(pending_history_dialogs, account_id)
            dialogs = [SimpleNamespace(id=j["chat_id"], name=j["title"], entity=None) for j in jobs]
        else:
            dialogs = [d async for d in client.iter_dialogs() if should_scan_dialog(d)]
            plan = []
            for d in dialogs:
                ctype, title = classify(d.entity) if d.entity else ("user", "Неизвестный чат")
                plan.append((d.id, title or "Неизвестный чат", ctype))
            await write_call(queue_history_dialogs, account_id, plan)
            jobs = await thread_call(read_pending_history, account_id)
        pending = {j["chat_id"]: j for j in jobs}
        st["total"] = len(dialogs)
        await write_call(register_history_progress,account_id,[d.id for d in dialogs],not retry_only)
        progress_task=asyncio.create_task(measure_history_totals(client,account_id,dialogs))
        BACKFILL_SEM.release()
        discovery_acquired=False
        entity_refresh = {}
        for i, d in enumerate(dialogs, 1):
            if st.get("state") != "running":        # остановлен кнопкой
                return
            ok = False
            ctype, ctitle = classify(d.entity) if d.entity else ("user", "Неизвестный чат")
            title = ctitle or "Неизвестный чат"
            job = pending.get(d.id, {})
            if retry_only:
                ctype, title = job["type"], job["title"]
            st["current_chat"] = title
            deferred = set()
            for _attempt in range(3):
                try:
                    target = await retry_history_target(client, d.id, entity_refresh) if retry_only else d
                    if target is None:
                        await write_call(close_unreachable_history_chat, account_id, d.id)
                        print(f"[backfill {account_id}] «{title}»: Telegram no longer lists this chat; "
                              f"its saved messages are kept and it is not retried")
                        ok = True
                        break
                    r = await write_call(prepare_history_chat, account_id, d.id, title, ctype)
                    await thread_call(ensure_chat_dir, account_id, d.id, title)
                    max_id = (r["history_cursor"] or 0) if r else 0
                    min_id = (r["min_msg_id"] or 0) if r else 0
                    deep_done = (r["deep_done"] or 0) if r else 0

                    # History checkpoint is independent of concurrently arriving live messages.
                    recovered_id = max_id
                    first_id = None
                    async for batch in iter_history_batches(
                            client, target, reverse=True, offset_id=max_id):
                        recovered_id = max(recovered_id,max(msg.id for msg in batch))
                        batch_min = min(msg.id for msg in batch)
                        first_id = batch_min if first_id is None else min(first_id, batch_min)
                        # The checkpoint and messages commit together. Restart resumes at the last committed page.
                        await store_history_batch(account_id,batch,d.id,title,ctype,st,
                                                  (account_id,d.id,'forward',recovered_id))
                        st["msgs"] += len(batch)

                    # A successful scan from zero already covered the oldest messages too.
                    # A persisted ascending plan also resumes without rereading older pages.
                    # Legacy unfinished scans retain the conservative older pass.
                    if not deep_done and ((max_id == 0 and min_id == 0) or job.get("forward_only")):
                        if job.get("forward_only") and r:
                            first_id = await thread_call(first_saved_history_id, account_id, d.id)
                        min_id = first_id or 0
                        await write_call(complete_history_chat, account_id, d.id, min_id)
                        deep_done = True
                        initial_scan = True
                    else:
                        initial_scan = False

                    # Reconcile edits made during downtime within a bounded recent window.
                    if deep_done and not initial_scan and not retry_only:
                        async for batch in iter_history_batches(client,target,limit=100):
                            await store_history_batch(account_id,batch,d.id,title,ctype,st)

                    # 2) докапываемся вглубь истории, если ещё не дошли до её начала
                    if not deep_done:
                        async for batch in iter_history_batches(
                                client, target, offset_id=min_id, limit=None):
                            batch_min=min(msg.id for msg in batch)
                            min_id = batch_min if not min_id else min(min_id,batch_min)
                            await store_history_batch(account_id,batch,d.id,title,ctype,st,
                                                      (account_id,d.id,'older',min_id))
                            st["msgs"] += len(batch)
                        # итератор исчерпался = дошли до самого начала истории чата
                        await write_call(complete_history_chat, account_id, d.id, min_id)
                    if deep_done and not initial_scan:
                        await write_call(finish_history_dialog, account_id, d.id)
                    ok = True
                    st["note"] = ""
                    break
                except FloodWaitError as e:
                    st["wait_until"] = time.time() + e.seconds + 2
                    st["note"] = f"Telegram ограничил частоту запросов; ожидание {e.seconds + 2} сек."
                    try:
                        await asyncio.sleep(e.seconds + 2)
                    finally:
                        st.pop("wait_until", None)
                except Exception as e:
                    if session_lost(e):
                        raise  # повторы бессмысленны: нужен новый вход в аккаунт
                    # связь у него рвётся — чат нельзя молча пропускать: повторяем
                    print(f"[{datetime.now(timezone.utc).isoformat()}] [backfill {account_id}] «{d.name}»: {type(e).__name__}: {e}"
                          f" (попытка {_attempt + 1}/3)")
                    st["note"] = (f"ожидаю ответ от «{title}»; "
                                  f"повтор {_attempt + 1}/3")
                    if _attempt < 2:
                        await asyncio.sleep(4 + 6 * _attempt)
            if not ok:
                st["errs"] = st.get("errs", 0) + 1
            st["done"] = i
            st["current_chat"] = ""
            st["current_message"] = 0
            st["current_media_size"] = 0
            await asyncio.sleep(0.3)
        st["state"] = "done"
        notes = []
        if st.get("errs"):
            notes.append(f"не удалось дочитать {st['errs']} чатов — связь рвалась")
        if notes:
            st["state"] = "partial"
            st["retry_at"] = time.time()+60
            st["note"] = "; ".join(notes) + " — автоматический повтор через минуту"
        # Повторный вызов во время активной догонки не запускает цикл новых
        # полных проходов. Следующий проход можно запустить вручную после этого.
    except Exception as e:
        if session_lost(e):
            st.update(state="error", note="нужен повторный вход")
            await end_lost_session(account_id)
        else:
            st.update(state="error", retry_at=time.time()+60, note=f"{type(e).__name__}: {e}")
    finally:
        if progress_task is not None:
            progress_task.cancel()
            await asyncio.gather(progress_task,return_exceptions=True)
        if discovery_acquired:
            BACKFILL_SEM.release()
        if own:
            await client.disconnect()


# ---------- веб-панель ----------

ARCHIVE_LOCK = None


def acquire_archive_lock():
    """One server per data folder, regardless of launcher or TCP port."""
    global ARCHIVE_LOCK
    handle = (BASE / ".archive.lock").open("a+b")
    try:
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if sys.platform == "win32":
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError as exc:
        handle.close()
        raise RuntimeError("Этот архив уже открыт другим сервером TG Monitor") from exc
    ARCHIVE_LOCK = handle


def release_archive_lock():
    global ARCHIVE_LOCK
    if ARCHIVE_LOCK is not None:
        ARCHIVE_LOCK.close()
        ARCHIVE_LOCK = None


@asynccontextmanager
async def _lifespan(_app):
    await on_startup()
    try:
        yield
    finally:
        await on_shutdown()


app = FastAPI(title="TG Monitor", lifespan=_lifespan)
app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
app.mount("/media", StaticFiles(directory=MEDIA), name="media")

# ---------- пароль панели ----------

COOKIE_NAME = "panel_key"


def panel_cookie_value(password, home=None):
    """Cookie derived from a per-installation random key and the current password.

    A copied cookie does not reveal the password to offline guessing, and changing
    the password signs every browser out. The key stays in the data folder, so
    restarts and updates keep existing sign-ins.
    """
    if not password:
        return ""
    import hmac
    path = Path(home or BASE) / "panel-secret.key"
    key, unreadable = None, False
    for attempt in range(5):
        try:
            stored = bytes.fromhex(path.read_text(encoding="ascii").strip())
            key = stored if len(stored) >= 32 else None   # short/damaged: replace
            break
        except (FileNotFoundError, ValueError):
            break                           # missing or damaged: create a new key
        except OSError:
            # Antivirus or backup may hold the file briefly; a temporary lock must
            # not sign everyone out, and an unreadable key is never overwritten.
            unreadable = attempt == 4
            if not unreadable:
                time.sleep(0.2)
    if key is None:
        key = secrets.token_bytes(32)
        if unreadable:
            print(f"[panel] {path.name} is not readable; sign-ins last until restart")
        else:
            temporary = path.with_name(f".{path.name}.{secrets.token_hex(4)}.tmp")
            try:
                temporary.write_text(key.hex(), encoding="ascii")
                os.replace(temporary, path)
            except OSError as exc:
                # The panel still starts; sign-ins last until the next restart.
                print(f"[panel] could not save {path.name}: {exc}")
                temporary.unlink(missing_ok=True)
    return hmac.new(key, b"tg-monitor-panel\0" + password.encode(), hashlib.sha256).hexdigest()


COOKIE_VALUE = panel_cookie_value(PANEL_PASSWORD)
LOGIN_FAILS = {"n": 0, "until": 0.0}       # простая защита от перебора


@app.middleware("http")
async def auth_middleware(request, call_next):
    if PANEL_PASSWORD:
        p = request.url.path
        # без пароля доступны только сама страница входа, её статика и /api/login
        if not (p == "/" or p.startswith("/static") or p in ("/api/login", "/api/health", "/api/runtime/stop")):
            if not secrets.compare_digest(request.cookies.get(COOKIE_NAME, "").encode(), COOKIE_VALUE.encode()):
                if p.startswith("/api"):
                    return JSONResponse({"ok": False, "reason": "нужен пароль"},
                                        status_code=401)
                return Response(status_code=401)
    return await call_next(request)


@app.post("/api/login")
async def api_login(request: Request):
    try:
        body = await request.json()
    except ValueError:
        body = None
    pwd = body.get("password", "") if isinstance(body, dict) else ""
    pwd = pwd if isinstance(pwd, str) else ""
    if time.time() < LOGIN_FAILS["until"]:
        return JSONResponse({"ok": False, "reason": "слишком много попыток — подожди минуту"},
                            status_code=429)
    # Bytes keep the comparison constant-time for Cyrillic passwords too.
    if pwd and secrets.compare_digest(pwd.encode(), PANEL_PASSWORD.encode()):
        LOGIN_FAILS["n"], LOGIN_FAILS["until"] = 0, 0.0
        resp = JSONResponse({"ok": True})
        resp.set_cookie(COOKIE_NAME, COOKIE_VALUE, max_age=30 * 24 * 3600,
                        httponly=True, samesite="strict")
        return resp
    LOGIN_FAILS["n"] += 1
    if LOGIN_FAILS["n"] >= 5:
        LOGIN_FAILS["until"] = time.time() + 60
        LOGIN_FAILS["n"] = 0
    return JSONResponse({"ok": False, "reason": "неверный пароль"}, status_code=401)


@app.get("/")
def index():
    # Revalidate the page itself, so a new app.js?v= reaches browsers right after an update.
    return FileResponse(FRONTEND / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/api/health")
def api_health():
    return {"ok": True, "application": "TG Monitor", "version": APP_VERSION,
            "background_load": {**BACKGROUND_LOAD.snapshot(), **HISTORY_PAGE_SEM.snapshot()},
            "startup_maintenance": STARTUP_MAINTENANCE["state"],
            "media_dedupe": dict(MEDIA_DEDUPE),
            "crypto_backend": ("cryptg" if telegram_aes.cryptg else
                               "libssl" if telegram_aes.libssl.decrypt_ige else "python"),
            "installation": hashlib.sha256(str(BASE).casefold().encode()).hexdigest()[:24]}


@app.post("/api/runtime/stop")
async def api_runtime_stop(request: Request):
    token = os.environ.get("TG_MONITOR_CONTROL_TOKEN", "")
    supplied = request.headers.get("authorization", "")
    if not token or not secrets.compare_digest(supplied.encode(), ("Bearer " + token).encode()):
        return JSONResponse({"ok": False, "reason": "нет доступа"}, status_code=403)
    server = globals().get("RUNTIME_SERVER")
    if server is None:
        return JSONResponse({"ok": False, "reason": "этот запуск не управляется приложением"}, status_code=409)
    server.should_exit = True
    return {"ok": True}


@app.get("/api/accounts")
def api_accounts():
    with db() as c:
        pending = {r["account_id"]:dict(r) for r in c.execute("SELECT account_id,pending,retrying FROM account_counts")}
        rows = c.execute("""
            SELECT a.*,
                   COALESCE((SELECT messages FROM account_counts WHERE account_id=a.id),0) AS n,
                   (SELECT MAX(date) FROM messages m WHERE m.account_id = a.id) AS last,
                   (SELECT kind FROM events e WHERE e.account_id = a.id
                     ORDER BY e.id DESC LIMIT 1) AS last_ev_kind,
                   (SELECT time FROM events e WHERE e.account_id = a.id
                     ORDER BY e.id DESC LIMIT 1) AS last_ev_time
            FROM accounts a ORDER BY a.id""").fetchall()
        progress = history_progress_summary(c)
        out = []
        for r in rows:
            d = dict(r)
            d["progress"] = progress.get(r["id"])
            st = BACKFILL.get(r["id"])
            d["bf"] = ({k: v for k, v in st.items() if k != "task"} if st else None)
            d["ingest"] = pending.get(r["id"],{"pending":0,"retrying":0})
            d["ingest"]["storage_error"] = bool(INGEST_ERRORS.get(r["id"]))
            d["ingest"]["active"] = sum(key[0] == r["id"] for key in ARCHIVE_JOB_TASKS)
            due = c.execute("SELECT MIN(next_attempt) FROM archive_jobs WHERE account_id=?",(r['id'],)).fetchone()[0]
            d["ingest"]["wait_until"] = due if due and due > time.time() else None
            flood = ARCHIVE_ACCOUNT_WAIT.get(r["id"],0)
            d["ingest"]["telegram_wait_until"] = flood if flood > time.time() else None
            out.append(d)
        return out


@app.post("/api/accounts/{account_id}/backfill")
async def api_backfill(account_id: int):
    with db() as c:
        account = c.execute("SELECT status FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
    if account["status"] in ("paused", "disconnected", "linking"):
        return JSONResponse({"ok": False, "reason": "Сначала нажмите «Продолжить» или подключите аккаунт."}, status_code=409)
    if account["status"] == "error":
        return JSONResponse({"ok": False, "reason": LOST_SESSION_REASON}, status_code=409)
    state = BACKFILL.get(account_id)
    if state and state.get("state") in ("running", "queued"):
        return {"ok": False, "reason": "Старые сообщения уже загружаются."}
    jobs = await write_call(pending_history_dialogs, account_id)
    ARCHIVE_WAKE.set()
    with db() as c:
        pending = c.execute('SELECT MIN(next_attempt) FROM archive_jobs WHERE account_id=?',(account_id,)).fetchone()[0]
    if not jobs:
        # The button is about old messages only; files are downloaded on their own.
        return {"ok": True, "started": False,
                "reason": "Старые сообщения уже все сохранены. " + (
                    "Фото и файлы скачиваются сами, нажимать ничего не нужно." if pending is not None
                    else "Новые сообщения сохраняются сами.")}
    started = start_backfill(account_id, retry_only=True)
    return {"ok": started, "started": started, "reason": "Догружаем старые сообщения."}


@app.post("/api/accounts/{account_id}/backfill/stop")
async def api_backfill_stop(account_id: int):
    st = BACKFILL.get(account_id)
    if st and st.get("state") in ("running", "queued") and st.get("task"):
        st["task"].cancel()
        return {"ok": True}
    return {"ok": False}


@app.post("/api/accounts/add")
async def api_add_account():
    try:
        fid = await asyncio.wait_for(start_flow(), timeout=45)
        return {"ok": True, "fid": fid}
    except Exception as e:
        # ошибку отдаём обычным JSON-ом, чтобы панель показала причину и кнопку повтора
        return {"ok": False, "reason": f"Telegram не ответил ({type(e).__name__}) — жми «Повторить»"}


@app.get("/api/qr/{fid}.png")
async def api_qr_png(fid: str):
    f = FLOWS.get(fid)
    if not f:
        return Response(status_code=404)
    box = qrcode.QRCode(border=2)
    box.add_data(f["qr"].url)
    box.make(fit=True)
    buf = io.BytesIO()
    box.make_image().save(buf, format="PNG")
    return Response(content=buf.getvalue(), media_type="image/png")


@app.get("/api/qr/{fid}/status")
def api_qr_status(fid: str):
    f = FLOWS.get(fid)
    if not f:
        return {"state": "unknown"}
    return {"state": f["state"], "account_id": f["account_id"]}


@app.post("/api/qr/{fid}/password")
async def api_qr_password(fid: str, request: Request):
    body = await request.json()
    try:
        ok = await finish_pwd(fid, body.get("password", ""))
    except asyncio.CancelledError:
        return {"ok": False, "reason": "Подключение отменено."}
    except Exception as exc:
        return {"ok": False, "reason": _phone_reason(exc)}
    return {"ok": ok}


@app.post("/api/qr/{fid}/cancel")
async def api_qr_cancel(fid: str):
    """Отмена до скана: отключаем клиент и убираем «заготовку» аккаунта."""
    f = FLOWS.pop(fid, None)
    if not f:
        return {"ok": False}
    if f["state"] != "authorized":
        f["state"] = "cancelled"
        tasks = [f[k] for k in ("task", "expiry_task", "request_task")
                 if f.get(k) and f[k] is not asyncio.current_task() and not f[k].done()]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        try:
            await asyncio.wait_for(f["client"].disconnect(), timeout=5)
        except Exception:
            pass
        try:
            f["client"].session.close()     # отпускаем файл сессии для удаления
        except Exception:
            pass
        for _ in range(3):
            try:
                (SESSIONS / f"account_{f['account_id']}.session").unlink(missing_ok=True)
                break
            except OSError:
                await asyncio.sleep(1)
        with db() as c:
            c.execute("DELETE FROM accounts WHERE id=? AND status='linking'",
                      (f["account_id"],))
    return {"ok": True}


# ---------- подключение по номеру телефона (код + 2FA) ----------

PHONE_FLOWS = {}   # fid -> {"client", "account_id", "phone", "state": code|pwd, "note"}
PHONE_CANCELLED = {}  # request IDs cancelled before their add request arrived
PHONE_REQUEST_TIMEOUT = 40
PHONE_FLOW_LIFETIME = 900


def _phone_reason(exc):
    if isinstance(exc, FloodWaitError):
        return f"Telegram ограничил запросы. Подождите {exc.seconds} сек."
    if isinstance(exc, asyncio.TimeoutError):
        return "Telegram не ответил вовремя. Начните подключение заново."
    return {
        "PhoneNumberInvalidError": "Telegram не принял номер. Проверьте международный формат с +.",
        "PhoneNumberBannedError": "Telegram сообщает, что этот номер заблокирован.",
        "PhoneNumberFloodError": "Слишком много запросов для этого номера. Повторите позже.",
        "PhoneCodeExpiredError": "Код истёк. Начните подключение заново.",
        "PhoneCodeInvalidError": "Неверный код. Проверьте последнее сообщение Telegram.",
        "PasswordHashInvalidError": "Неверный пароль двухэтапной защиты.",
        "ApiIdInvalidError": "Telegram не принял API ID/API hash приложения.",
        "SendCodeUnavailableError": "Telegram не предлагает больше способов доставки. Попробуйте QR-вход.",
        "EmailUnconfirmedError": "Telegram требует подтвердить почту в официальном приложении.",
        "EmailInstallMissingError": "Telegram не смог отправить код на почту. Попробуйте QR-вход.",
    }.get(type(exc).__name__, f"Ошибка связи с Telegram ({type(exc).__name__}). Повторите позже.")


def _phone_delivery(sent):
    kind = type(getattr(sent, "type", None)).__name__
    messages = {
        "SentCodeTypeApp": "Telegram отправил код в приложение Telegram на уже подключённых устройствах этого аккаунта.",
        "SentCodeTypeSms": "Telegram отправил код по SMS.",
        "SentCodeTypeSmsWord": "Telegram отправил слово-код по SMS.",
        "SentCodeTypeSmsPhrase": "Telegram отправил фразу-код по SMS.",
        "SentCodeTypeCall": "Ожидайте звонок: код будет продиктован голосом.",
        "SentCodeTypeEmailCode": "Telegram отправил код на почту, привязанную к входу в этот аккаунт.",
    }
    return kind, messages.get(kind)


def _phone_log(fid, event, **details):
    # Callers pass only event names, type names and numeric diagnostics. Never raw RPC objects.
    print(json.dumps({"time": datetime.now(timezone.utc).isoformat(),
                      "event": "phone-flow", "flow": fid, "action": event,
                      **details}, ensure_ascii=False), flush=True)


def _phone_retry_info(f):
    delay = max(0, f.get("resend_at", 0) - time.monotonic())
    return {"can_resend": bool(f.get("next_delivery")),
            "retry_after": int(delay) + (1 if delay % 1 else 0),
            "next_delivery": f.get("next_delivery")}


def _accept_phone_sent(f, sent, action):
    delivery, message = _phone_delivery(sent)
    next_type = getattr(sent, "next_type", None)
    timeout = getattr(sent, "timeout", None)
    _phone_log(f["fid"], action, response=type(sent).__name__, delivery=delivery,
               next_delivery=type(next_type).__name__ if next_type is not None else None,
               timeout=timeout, dc_id=getattr(f["client"].session, "dc_id", None))
    # Retain the newest hash for verification and cancellation, even for unsupported delivery.
    f["phone_code_hash"] = getattr(sent, "phone_code_hash", None)
    if not message or not f["phone_code_hash"]:
        raise ValueError("unsupported_delivery")
    f["next_delivery"] = type(next_type).__name__ if next_type is not None else None
    f["resend_at"] = time.monotonic() + max(0, int(timeout or 0))
    f["state"] = "code"
    return {"ok": True, "fid": f["fid"], "delivery": delivery,
            "delivery_message": message, **_phone_retry_info(f)}


async def _close_phone(f):
    timer = f.get("expiry_task")
    if timer and timer is not asyncio.current_task():
        timer.cancel()
    client = f["client"]
    if f.get("phone_code_hash"):
        try:
            await asyncio.wait_for(client(CancelCodeRequest(f["phone"], f["phone_code_hash"])), timeout=3)
        except Exception:
            pass  # Local cleanup must also work when Telegram is unreachable.
    try:
        await asyncio.wait_for(client.disconnect(), timeout=5)
    except Exception:
        pass
    try:
        client.session.close()
    except Exception:
        pass
    for _ in range(3):
        try:
            (SESSIONS / f"account_{f['account_id']}.session").unlink(missing_ok=True)
            break
        except OSError:
            await asyncio.sleep(.2)
    with db() as c:
        c.execute("DELETE FROM accounts WHERE id=? AND status='linking'", (f["account_id"],))


async def _expire_phone(fid, f):
    await asyncio.sleep(PHONE_FLOW_LIFETIME)
    if PHONE_FLOWS.get(fid) is f:
        await api_phone_cancel(fid)


def _finish_phone(f):
    fid = f.get("fid", str(f["account_id"]))
    if PHONE_FLOWS.get(fid) is not f:
        return {"ok": False, "state": "dead", "reason": "Подключение отменено — начните заново"}
    PHONE_FLOWS.pop(fid, None)
    if f.get("expiry_task"):
        f["expiry_task"].cancel()
    f["state"] = "ok"
    f["client"].flood_sleep_threshold = 60
    start_recorder(f["account_id"], f["client"])
    return {"ok": True, "state": "ok"}


@app.post("/api/accounts/add-phone")
async def api_add_phone(request: Request):
    body = await request.json()
    request_id = body.get("request_id")
    if request_id is not None and (not isinstance(request_id, str) or not re.fullmatch(r"[0-9a-f]{32}", request_id)):
        return {"ok": False, "reason": "Некорректный идентификатор попытки. Обновите страницу."}
    now = time.monotonic()
    for key, deadline in list(PHONE_CANCELLED.items()):
        if deadline < now:
            PHONE_CANCELLED.pop(key, None)
    if request_id in PHONE_CANCELLED:
        return {"ok": False, "state": "dead", "reason": "Подключение отменено."}
    if request_id in PHONE_FLOWS:
        return {"ok": False, "reason": "Эта попытка уже выполняется."}
    phone = (body.get("phone") or "").strip()
    if not re.fullmatch(r"\+[1-9][0-9]{6,14}", phone):
        return {"ok": False, "reason": "укажи телефон в формате +380XXXXXXXXX"}
    with db() as c:
        account_id = c.execute(
            "INSERT INTO accounts(name, phone, status) VALUES(?,?,'linking')",
            ("Ожидает код", phone)).lastrowid
    client = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                            int(API_ID), API_HASH, flood_sleep_threshold=0, raise_last_call_error=True)
    fid = request_id or str(account_id)
    f = {"fid": fid, "client": client, "account_id": account_id, "phone": phone,
         "state": "sending", "request_task": asyncio.current_task()}
    PHONE_FLOWS[fid] = f
    f["expiry_task"] = asyncio.create_task(_expire_phone(fid, f))
    _phone_log(fid, "send-start")
    try:
        async def send():
            await client.connect()
            return await client.send_code_request(phone)
        sent = await asyncio.wait_for(send(), timeout=PHONE_REQUEST_TIMEOUT)
        return _accept_phone_sent(f, sent, "send-accepted")
    except (Exception, asyncio.CancelledError) as exc:
        if PHONE_FLOWS.get(fid) is f:
            PHONE_FLOWS.pop(fid, None)
            await _close_phone(f)
        if isinstance(exc, asyncio.CancelledError):
            return {"ok": False, "state": "dead", "reason": "Подключение отменено."}
        _phone_log(fid, "send-failed", error=type(exc).__name__,
                   wait_seconds=getattr(exc, "seconds", None))
        reason = ("Telegram выбрал способ входа, который панель пока не поддерживает. Используйте QR-вход."
                  if isinstance(exc, ValueError) and str(exc) == "unsupported_delivery" else _phone_reason(exc))
        return {"ok": False, "reason": reason}
    finally:
        f["request_task"] = None


@app.post("/api/phone/{fid}/resend")
async def api_phone_resend(fid: str):
    f = PHONE_FLOWS.get(fid)
    if not f or f["state"] != "code":
        return {"ok": False, "state": "dead", "reason": "Запрос устарел — начните подключение заново."}
    if f.get("request_task"):
        return {"ok": False, "reason": "Предыдущий запрос ещё выполняется.", **_phone_retry_info(f)}
    info = _phone_retry_info(f)
    if not info["can_resend"]:
        return {"ok": False, "reason": "Telegram не предложил повторную отправку для этой попытки. Проверьте служебный чат Telegram или используйте QR-вход.", **info}
    if info["retry_after"]:
        return {"ok": False, "reason": f"Повторный запрос доступен через {info['retry_after']} сек.", **info}
    f["request_task"] = asyncio.current_task()
    _phone_log(fid, "resend-start")
    try:
        sent = await asyncio.wait_for(f["client"](ResendCodeRequest(
            f["phone"], f["phone_code_hash"])), timeout=PHONE_REQUEST_TIMEOUT)
        if PHONE_FLOWS.get(fid) is not f:
            return {"ok": False, "state": "dead", "reason": "Подключение отменено."}
        return _accept_phone_sent(f, sent, "resend-accepted")
    except asyncio.CancelledError:
        return {"ok": False, "state": "dead", "reason": "Подключение отменено."}
    except Exception as exc:
        _phone_log(fid, "resend-failed", error=type(exc).__name__,
                   wait_seconds=getattr(exc, "seconds", None))
        if isinstance(exc, FloodWaitError):
            f["resend_at"] = time.monotonic() + max(1, exc.seconds)
            return {"ok": False, "reason": _phone_reason(exc), **_phone_retry_info(f)}
        if type(exc).__name__ == "SendCodeUnavailableError":
            f["next_delivery"] = None
            return {"ok": False, "reason": _phone_reason(exc), **_phone_retry_info(f)}
        # A timed out resend may have changed Telegram's hash; do not verify against a stale one.
        f["request_task"] = None
        await api_phone_cancel(fid)
        reason = ("Telegram выбрал неподдерживаемый способ входа. Используйте QR-вход."
                  if isinstance(exc, ValueError) and str(exc) == "unsupported_delivery" else _phone_reason(exc))
        return {"ok": False, "state": "dead", "reason": reason}
    finally:
        f["request_task"] = None


@app.post("/api/phone/{fid}/code")
async def api_phone_code(fid: str, request: Request):
    body = await request.json()
    code = (body.get("code") or "").strip()
    f = PHONE_FLOWS.get(fid)
    if not f or f["state"] != "code":
        return {"ok": False, "state": "dead", "reason": "запрос устарел — начни заново"}
    if not code:
        return {"ok": False, "state": "code", "reason": "введи код из сообщения"}
    if f.get("request_task"):
        return {"ok": False, "state": "code", "reason": "Предыдущий запрос ещё выполняется."}
    f["request_task"] = asyncio.current_task()
    try:
        await asyncio.wait_for(f["client"].sign_in(f["phone"], code,
            phone_code_hash=f.get("phone_code_hash")), timeout=PHONE_REQUEST_TIMEOUT)
    except SessionPasswordNeededError:
        if PHONE_FLOWS.get(fid) is not f:
            return {"ok": False, "state": "dead", "reason": "Подключение отменено"}
        f["state"] = "pwd"
        return {"ok": False, "state": "pwd", "reason": "нужен пароль 2FA"}
    except asyncio.CancelledError:
        return {"ok": False, "state": "dead", "reason": "Подключение отменено."}
    except Exception as e:
        if type(e).__name__ == "PhoneCodeExpiredError" or isinstance(e, asyncio.TimeoutError):
            f["request_task"] = None
            await api_phone_cancel(fid)
            return {"ok": False, "state": "dead", "reason": _phone_reason(e)}
        return {"ok": False, "state": "code",
                "reason": _phone_reason(e)}
    finally:
        f["request_task"] = None
    return _finish_phone(f)


@app.post("/api/phone/{fid}/password")
async def api_phone_password(fid: str, request: Request):
    body = await request.json()
    f = PHONE_FLOWS.get(fid)
    if not f or f["state"] != "pwd":
        return {"ok": False, "state": "dead", "reason": "запрос устарел — начни заново"}
    if f.get("request_task"):
        return {"ok": False, "state": "pwd", "reason": "Предыдущий запрос ещё выполняется."}
    f["request_task"] = asyncio.current_task()
    try:
        await asyncio.wait_for(f["client"].sign_in(password=body.get("password", "")), timeout=PHONE_REQUEST_TIMEOUT)
    except asyncio.CancelledError:
        return {"ok": False, "state": "dead", "reason": "Подключение отменено."}
    except Exception as exc:
        if isinstance(exc, asyncio.TimeoutError):
            f["request_task"] = None
            await api_phone_cancel(fid)
            return {"ok": False, "state": "dead", "reason": _phone_reason(exc)}
        return {"ok": False, "state": "pwd", "reason": _phone_reason(exc)}
    finally:
        f["request_task"] = None
    return _finish_phone(f)


@app.post("/api/phone/{fid}/cancel")
async def api_phone_cancel(fid: str):
    if re.fullmatch(r"[0-9a-f]{32}", fid):
        # Remember early cancellation even if add-phone is still reading its body.
        if len(PHONE_CANCELLED) >= 2048:
            PHONE_CANCELLED.pop(next(iter(PHONE_CANCELLED)))
        PHONE_CANCELLED[fid] = time.monotonic() + PHONE_FLOW_LIFETIME
    f = PHONE_FLOWS.pop(fid, None)
    if not f:
        return {"ok": True}
    f["state"] = "cancelled"
    task = f.get("request_task")
    if task and task is not asyncio.current_task() and not task.done():
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
    await _close_phone(f)
    _phone_log(fid, "cancelled")
    return {"ok": True}


@app.post("/api/accounts/{account_id}/pause")
async def api_pause(account_id: int):
    # Block new queued work before cancelling the current Telegram operations.
    await write_call(set_status, account_id, "paused")
    tasks = []
    if account_id in REC:
        tasks.append(REC[account_id]["task"])
    stop_recorder(account_id)
    st = BACKFILL.get(account_id)
    if st and st.get("state") in ("running", "queued") and st.get("task"):
        st["task"].cancel()
        tasks.append(st["task"])
    for (aid, _, _), task in list(ARCHIVE_JOB_TASKS.items()):
        if aid == account_id:
            task.cancel()
            tasks.append(task)
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    return {"ok": True}


@app.post("/api/accounts/{account_id}/resume")
async def api_resume(account_id: int):
    # статус меняем сразу, чтобы панель отозвалась на первый же клик;
    # если подключение не выйдет, рекордер сам перезапишет на error/reconnecting
    await write_call(set_status, account_id, "recording")
    start_recorder(account_id)
    return {"ok": True}


@app.post("/api/accounts/{account_id}/disconnect")
async def api_disconnect(account_id: int):
    """Отключить аккаунт по-настоящему: отзываем авторизацию в Telegram
    (устройство исчезает из активных сеансов), удаляем ключ локально,
    но весь архив (сообщения, чаты, медиа) сохраняется целиком."""
    rec = REC.pop(account_id, None)
    if rec:
        rec["task"].cancel()
    bf = BACKFILL.pop(account_id, None)
    if bf and bf.get("task"):
        bf["task"].cancel()
    cl = CLIENTS.pop(account_id, None)
    sess = SESSIONS / f"account_{account_id}.session"
    if cl is None and sess.exists():
        cl = TelegramClient(str(SESSIONS / f"account_{account_id}"),
                            int(API_ID), API_HASH)   # пауза — поднимаем клиента для отзыва
    revoked = False
    if cl is not None:
        try:
            await cl.connect()
            if await cl.is_user_authorized():
                await cl.log_out()          # в Telegram устройство пропадает из сеансов
                revoked = True
        except Exception as e:
            print(f"[disconnect {account_id}] log_out: {type(e).__name__}: {e}")
        try:
            await cl.disconnect()
        except Exception:
            pass
        try:
            cl.session.close()   # иначе Windows держит файл сессии открытым и unlink падает
        except Exception:
            pass
    for _ in range(3):           # файл может отпустить с задержкой
        try:
            sess.unlink(missing_ok=True)
            break
        except OSError:
            await asyncio.sleep(1)
    LOGGED.discard(account_id)
    await write_call(add_event, account_id, "logout",
              "устройство отключено" + ("" if revoked else " (не удалось отозвать в Telegram)"))
    await write_call(set_status, account_id, "disconnected")
    return {"ok": True}


def safe_media_path(stored_path):
    """Resolve a database path only inside this installation's media directory."""
    if not isinstance(stored_path, str) or not stored_path:
        raise ValueError("пустой путь медиа")
    full = (BASE / stored_path).resolve()
    media_root = MEDIA.resolve()
    try:
        full.relative_to(media_root)
    except ValueError as exc:
        raise ValueError("путь вложения вне каталога медиа") from exc
    if full == media_root:
        raise ValueError("путь вложения указывает на каталог медиа")
    return full


def media_path_referenced(account_id, chat_id, msg_id, rel_path):
    """Whether an archived row may still use rel_path, without scanning the archive.

    There is no index on file_path, and a scan of a multi-gigabyte archive on the
    event loop stalls the panel and all ingestion for minutes. Saved files carry
    their own message id in the name, so only this message's rows (active or in
    the recycle bin) can use such a path, and those are found by primary key. A
    path without this message's id (older naming) counts as referenced: keeping a
    stale file costs disk space, removing a shared one would lose an attachment.
    """
    if not re.search(rf"\[{int(msg_id)}[\]-]", Path(rel_path).name):
        return True
    with db() as c:
        return c.execute("""SELECT 1 FROM messages WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path=?
                            UNION ALL SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path=?
                            LIMIT 1""", (account_id, chat_id, msg_id, rel_path,
                                         account_id, chat_id, msg_id, rel_path)).fetchone() is not None


# ---------- одинаковые медиафайлы: один файл на диске ----------
# Identical attachments (the same photo in two chats, or forwarded between
# accounts) are stored once: further copies become NTFS hard links to the same
# data. Every message keeps its own path, so monitor.db is never changed and the
# panel opens each file as before. Removing one message's file removes only its
# link. File hashes and Telegram file identities live in a separate media-index.db.
MEDIA_DEDUPE_MIN_BYTES = 32 * 1024     # smaller files save next to nothing
MEDIA_INDEX_PATH = BASE / "media-index.db"
_MEDIA_INDEX_LOCK = threading.Lock()
MEDIA_DEDUPE = {"state": "pending", "checked": 0, "linked": 0, "saved_bytes": 0}


def _media_index():
    c = sqlite3.connect(MEDIA_INDEX_PATH, timeout=30)
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("""CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, size INTEGER NOT NULL,
                 mtime_ns INTEGER NOT NULL, sha256 TEXT NOT NULL)""")
    c.execute("CREATE INDEX IF NOT EXISTS idx_files_content ON files(size, sha256)")
    c.execute("CREATE TABLE IF NOT EXISTS telegram_files(key TEXT PRIMARY KEY, path TEXT NOT NULL)")
    c.execute("""CREATE TABLE IF NOT EXISTS totals(id INTEGER PRIMARY KEY CHECK(id=1),
                 linked INTEGER NOT NULL DEFAULT 0, saved_bytes INTEGER NOT NULL DEFAULT 0)""")
    c.execute("INSERT OR IGNORE INTO totals(id) VALUES(1)")
    return c


def media_index_call(func):
    """Run func(connection) on the media index; it never affects the archive itself."""
    with _MEDIA_INDEX_LOCK:
        c = _media_index()
        try:
            with c:
                return func(c)
        finally:
            c.close()


def _media_rel(path):
    return str(Path(path).relative_to(BASE)).replace("\\", "/")


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            if MAINTENANCE_STOP.is_set():
                raise InterruptedError("stopping")
            digest.update(block)
    return digest.hexdigest()


def dedupe_candidate(path):
    """Only complete, published attachments; never scratch or partial downloads."""
    name = path.name
    return not (name.startswith(".") or name.endswith((".partial", ".part", ".link", ".tmp")))


def same_content(a, b):
    """Byte-by-byte comparison; stopping the app interrupts it (InterruptedError is an OSError)."""
    with open(a, "rb") as x, open(b, "rb") as y:
        while True:
            if MAINTENANCE_STOP.is_set():
                raise InterruptedError("stopping")
            left, right = x.read(1024 * 1024), y.read(1024 * 1024)
            if left != right:
                return False
            if not left:
                return True


def link_identical(canonical, duplicate, expected):
    """Replace duplicate with a hard link to canonical if it is still exactly the file that was hashed.

    expected is (size, mtime_ns, inode) of duplicate when its hash was taken. Windows
    timestamps can miss a same-size rewrite made within one clock tick, so the bytes
    are compared again right before the swap. The link is created under a scratch
    name and moved over the duplicate in one step, so the path always holds complete
    data. Returns the bytes freed (0 if skipped).
    """
    canonical, duplicate = Path(canonical), Path(duplicate)
    k, d = os.stat(canonical), os.stat(duplicate)
    if (k.st_dev, k.st_ino) == (d.st_dev, d.st_ino) or k.st_size != d.st_size:
        return 0
    if (d.st_size, d.st_mtime_ns, d.st_ino) != tuple(expected):
        return 0
    scratch = duplicate.with_name(f".{duplicate.name}.{secrets.token_hex(6)}.link")
    try:
        os.link(canonical, scratch)
        s = os.stat(scratch)
        if (s.st_dev, s.st_ino) != (k.st_dev, k.st_ino):
            return 0
        if not same_content(canonical, duplicate):
            return 0
        now = os.stat(duplicate)
        if (now.st_size, now.st_mtime_ns, now.st_ino) != tuple(expected):
            return 0
        os.replace(scratch, duplicate)
    except OSError:
        return 0
    finally:
        scratch.unlink(missing_ok=True)
    return d.st_size if d.st_nlink == 1 else 0


def _remember_file(c, rel, st, sha):
    c.execute("INSERT OR REPLACE INTO files(path,size,mtime_ns,sha256) VALUES(?,?,?,?)",
              (rel, st.st_size, st.st_mtime_ns, sha))


def _count_link(c, freed):
    c.execute("UPDATE totals SET linked=linked+1, saved_bytes=saved_bytes+? WHERE id=1", (freed,))
    MEDIA_DEDUPE["linked"] += 1
    MEDIA_DEDUPE["saved_bytes"] += freed


def telegram_file_key(msg, size, kind=None):
    """Telegram's own identity of a file, the same for every account and forward."""
    document, photo = getattr(msg, "document", None), getattr(msg, "photo", None)
    if kind != "photo" and document is not None and getattr(document, "id", None):
        return f"d{document.id}:{size}"
    if photo is not None and getattr(photo, "id", None):
        return f"p{photo.id}:{size}"
    return None


def reusable_media_file(key, size):
    """An already saved complete file with the same Telegram identity and size, if any."""
    if not key or size < MEDIA_DEDUPE_MIN_BYTES:
        return None
    row = media_index_call(lambda c: c.execute(
        "SELECT path FROM telegram_files WHERE key=?", (key,)).fetchone())
    if not row:
        return None
    try:
        path = safe_media_path(row[0])
        if dedupe_candidate(path) and path.is_file() and path.stat().st_size == size:
            return path
    except (ValueError, OSError):
        pass
    return None


def register_saved_media(target, key, reused_from=None):
    """After a file is published: link it to an identical stored file and remember it.

    A file linked from reused_from already shares its data, so its known hash is
    reused instead of reading the file again.
    """
    try:
        target = Path(target)
        st = os.stat(target)
        if st.st_size < MEDIA_DEDUPE_MIN_BYTES or not dedupe_candidate(target):
            return
        rel = _media_rel(target)
        sha = None
        if reused_from is not None:
            row = media_index_call(lambda c: c.execute(
                "SELECT sha256,size FROM files WHERE path=?", (_media_rel(reused_from),)).fetchone())
            if row and row[1] == st.st_size and os.stat(reused_from).st_ino == st.st_ino:
                sha = row[0]
        sha = sha or file_sha256(target)

        def update(c):
            st_now = os.stat(target)
            for (other,) in c.execute("SELECT path FROM files WHERE size=? AND sha256=? AND path!=?",
                                      (st.st_size, sha, rel)).fetchall():
                try:
                    source = safe_media_path(other)
                    o = os.stat(source)
                    if o.st_size != st.st_size or (o.st_dev, o.st_ino) == (st_now.st_dev, st_now.st_ino):
                        continue
                except (ValueError, OSError):
                    continue
                freed = link_identical(source, target, (st.st_size, st.st_mtime_ns, st.st_ino))
                if freed or os.stat(target).st_ino == o.st_ino:
                    if freed:
                        _count_link(c, freed)
                    break
            _remember_file(c, rel, os.stat(target), sha)
            if key:
                c.execute("INSERT OR REPLACE INTO telegram_files(key,path) VALUES(?,?)", (key, rel))
        media_index_call(update)
    except (OSError, ValueError, InterruptedError, sqlite3.Error) as exc:
        print(f"[media-dedupe] {Path(target).name}: {type(exc).__name__}: {exc}")


def _media_files(min_size):
    for folder, _, names in os.walk(MEDIA):
        for name in names:
            path = Path(folder) / name
            if not dedupe_candidate(path):
                continue
            try:
                st = path.stat()
            except OSError:
                continue
            if st.st_size >= min_size:
                yield path, st


def _media_size_groups():
    """Sizes shared by at least two files; two cheap passes instead of keeping every path."""
    counts = {}
    for _, st in _media_files(MEDIA_DEDUPE_MIN_BYTES):
        counts[st.st_size] = counts.get(st.st_size, 0) + 1
        if MAINTENANCE_STOP.is_set():
            return {}
    groups = {}
    for path, st in _media_files(MEDIA_DEDUPE_MIN_BYTES):
        if counts.get(st.st_size, 0) > 1:
            groups.setdefault(st.st_size, []).append(path)
        if MAINTENANCE_STOP.is_set():
            return {}
    return groups


def dedupe_size_group(paths):
    """Hash files of one size (reusing stored hashes) and link identical ones together."""
    rels = [_media_rel(p) for p in paths]

    def load(c):
        known = {}
        for start in range(0, len(rels), 500):
            part = rels[start:start + 500]
            known.update((r[0], (r[1], r[2])) for r in c.execute(
                "SELECT path,mtime_ns,sha256 FROM files WHERE path IN (%s)" % ",".join("?" * len(part)), part))
        return known
    cached = media_index_call(load)
    by_hash = {}
    for path in paths:
        if MAINTENANCE_STOP.is_set():
            return
        try:
            st = os.stat(path)
            rel = _media_rel(path)
            known = cached.get(rel)
            sha = known[1] if known and known[0] == st.st_mtime_ns else file_sha256(path)
            if not known or known[1] != sha or known[0] != st.st_mtime_ns:
                media_index_call(lambda c: _remember_file(c, rel, st, sha))
            by_hash.setdefault(sha, []).append((path, st))
            MEDIA_DEDUPE["checked"] += 1
        except (OSError, ValueError, InterruptedError):
            continue
    for sha, files in by_hash.items():
        if len(files) < 2:
            continue
        # Keep the file that already has the most links; others become links to it.
        files.sort(key=lambda item: (-item[1].st_nlink, str(item[0])))
        canonical, k = files[0]
        for path, st in files[1:]:
            if MAINTENANCE_STOP.is_set():
                return
            if (st.st_dev, st.st_ino) == (k.st_dev, k.st_ino):
                continue
            freed = link_identical(canonical, path, (st.st_size, st.st_mtime_ns, st.st_ino))
            if freed or os.stat(path).st_ino == k.st_ino:
                def record(c, path=path, freed=freed):
                    if freed:
                        _count_link(c, freed)
                    _remember_file(c, _media_rel(path), os.stat(path), sha)
                media_index_call(record)


async def media_dedupe_worker():
    """Merge identical files that were downloaded before this version, in the background."""
    while STARTUP_MAINTENANCE["state"] in ("pending", "running"):
        await asyncio.sleep(5)           # folder moves of the startup checks come first
    if MAINTENANCE_STOP.is_set():
        return
    try:
        totals = await thread_call(media_index_call, lambda c: c.execute(
            "SELECT linked,saved_bytes FROM totals WHERE id=1").fetchone())
        MEDIA_DEDUPE.update(linked=totals[0], saved_bytes=totals[1], state="scanning")
        groups = await thread_call(_media_size_groups)
        MEDIA_DEDUPE["state"] = "running"
        # Largest files first: the most space for the least hashing.
        for size in sorted(groups, reverse=True):
            if MAINTENANCE_STOP.is_set():
                return
            await BACKGROUND_LOAD.wait_turn()
            await thread_call(dedupe_size_group, groups[size])
        MEDIA_DEDUPE["state"] = "done"
        print(f"[media-dedupe] checked {MEDIA_DEDUPE['checked']} files; "
              f"{MEDIA_DEDUPE['linked']} copies linked, {MEDIA_DEDUPE['saved_bytes'] / 1024**3:.1f} GB freed in total")
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        MEDIA_DEDUPE["state"] = "error"
        print(f"[media-dedupe] stopped: {type(exc).__name__}: {exc}")


def _attach_recovered_part(table, relative, status, error, account_id, chat_id, msg_id):
    with db() as c:
        if status is None:
            c.execute(f"UPDATE {table} SET file_path=?,media_status=NULL,media_error=NULL "
                      "WHERE account_id=? AND chat_id=? AND msg_id=?",
                      (relative, account_id, chat_id, msg_id))
        else:
            c.execute(f"UPDATE {table} SET file_path=?,media_status=?,media_error="
                      "CASE WHEN ? THEN media_error ELSE COALESCE(media_error,?) END "
                      "WHERE account_id=? AND chat_id=? AND msg_id=?",
                      (relative, status, error,
                       "Загрузка была прервана остановкой приложения.",
                       account_id, chat_id, msg_id))


def recover_orphaned_media_parts(write=None):
    """Associate a download scratch file with its message after a process stop."""
    write = write or (lambda func, *args: func(*args))
    recovered = 0
    pattern = re.compile(r"^\.(?P<target>.+ \[(?P<msg_id>\d+)\]\.[A-Za-z0-9]{1,9})\.[0-9a-f]{12}\.part$", re.I)
    for part in MEDIA.rglob(".*.part"):
        if MAINTENANCE_STOP.is_set():
            break
        match = pattern.fullmatch(part.name)
        if not match:
            continue
        try:
            size = part.stat().st_size
            if size <= 0:
                continue
            msg_id = int(match.group("msg_id"))
            if any(key[2] == msg_id for key in tuple(ARCHIVE_BUSY)):
                continue               # the scratch file of a download running right now
            target = part.with_name(match.group("target"))
            with db() as c:
                candidates = []
                for table in ("messages", "deleted"):
                    candidates.extend((table, row) for row in c.execute(
                        f"""SELECT m.account_id,m.chat_id,m.file_size,m.file_path,m.media_status,
                                   ch.title,a.username,a.phone
                            FROM {table} m
                            LEFT JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
                            LEFT JOIN accounts a ON a.id=m.account_id
                            WHERE m.msg_id=? AND m.media_type IS NOT NULL AND m.file_size>=?""",
                        (msg_id, size)).fetchall())

            parts = part.relative_to(MEDIA).parts
            if len(parts) < 3:
                continue
            match_row = None
            for table, row in candidates:
                account_labels = [row["phone"], "@" + row["username"] if row["username"] else None,
                                  f"Неизвестный аккаунт {row['account_id']}"]
                account_names = {_safe_name(label) for label in account_labels if label}
                account_names.update(f"{name[:30]} ({row['account_id']})" for name in tuple(account_names))
                chat_label = _safe_name(row["title"] or "Неизвестный чат")
                with db() as c:
                    duplicate = c.execute(
                        "SELECT 1 FROM chats WHERE account_id=? AND chat_id!=? AND lower(title)=lower(?) LIMIT 1",
                        (row["account_id"], row["chat_id"], row["title"])).fetchone()
                chat_names = {chat_label}
                if duplicate:
                    chat_names.add(f"{chat_label[:30]} ({row['chat_id']})")
                if parts[0].casefold() in {name.casefold() for name in account_names} and \
                        parts[1].casefold() in {name.casefold() for name in chat_names}:
                    match_row = table, row
                    break
            if not match_row:
                continue

            table, row = match_row
            expected_size = row["file_size"] or 0
            if size == expected_size and not target.exists():
                destination = target
                status = None
                error = None
            else:
                destination = target.with_name(target.name + ".partial")
                if destination.is_file() and destination.stat().st_size >= size:
                    # Preserve both copies when there is already a better partial.
                    continue
                status = "dismissed" if row["media_status"] == "dismissed" else "incomplete"
                error = row["media_status"] == "dismissed"
            if part.resolve() != destination.resolve():
                if destination.exists():
                    destination.unlink()
                part.replace(destination)
            relative = str(destination.relative_to(BASE)).replace("\\", "/")
            write(_attach_recovered_part, table, relative, status, error,
                  row["account_id"], row["chat_id"], msg_id)
            recovered += 1
        except (OSError, ValueError, sqlite3.Error):
            continue
    return recovered


def scoped_media_paths(c, account_id, chat_id=0):
    """All file references in active messages and the recycle bin for one scope."""
    where = "account_id=?" + (" AND chat_id=?" if chat_id else "")
    args = (account_id, chat_id) if chat_id else (account_id,)
    paths = set()
    for table in ("messages", "deleted"):
        paths.update(r[0] for r in c.execute(
            f"SELECT DISTINCT file_path FROM {table} WHERE {where}"
            " AND file_path IS NOT NULL AND file_path!=''", args))
    return paths


def unreferenced_media_paths(c, candidates):
    """Never remove a file still referenced by another message or account."""
    if not candidates:
        return [], 0
    remaining = set()
    for r in c.execute("""SELECT file_path FROM messages WHERE file_path IS NOT NULL
                          UNION SELECT file_path FROM deleted WHERE file_path IS NOT NULL"""):
        try:
            remaining.add(safe_media_path(r[0]))
        except (ValueError, OSError):
            continue
    removable = sorted(path for path in candidates if path not in remaining)
    return removable, len(candidates) - len(removable)


def remove_media_files(paths):
    removed = failed = 0
    for path in paths:
        try:
            existed = path.is_file()
            if existed:
                path.unlink()
                removed += 1
        except OSError:
            failed += 1
    return removed, failed


def cleanup_scope_error(c, scope, account_id, chat_id):
    account = c.execute("SELECT status FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not account:
        return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
    if account["status"] == "linking":
        return JSONResponse({"ok": False, "reason": "дождись завершения подключения аккаунта"}, status_code=409)
    if scope == "chat" and not c.execute(
            "SELECT 1 FROM chats WHERE account_id=? AND chat_id=?", (account_id, chat_id)
    ).fetchone():
        return JSONResponse({"ok": False, "reason": "чат не найден в этом аккаунте"}, status_code=404)
    return None


@app.get("/api/cleanup/full/preview")
def api_cleanup_full_preview(scope: str, account_id: int, chat_id: int = 0):
    if account_id <= 0 or scope not in ("account", "chat") or (scope == "chat") != (chat_id != 0):
        return JSONResponse({"ok": False, "reason": "выбери один аккаунт или один чат"}, status_code=422)
    with db() as c:
        error = cleanup_scope_error(c, scope, account_id, chat_id)
        if error:
            return error
        where = "account_id=?" + (" AND chat_id=?" if scope == "chat" else "")
        args = (account_id, chat_id) if scope == "chat" else (account_id,)
        messages = c.execute(f"SELECT COUNT(*) FROM messages WHERE {where}", args).fetchone()[0]
        deleted = c.execute(f"SELECT COUNT(*) FROM deleted WHERE {where}", args).fetchone()[0]
        paths = scoped_media_paths(c, account_id, chat_id if scope == "chat" else 0)
    return {"messages": messages, "deleted": deleted, "files": len(paths)}


@app.post("/api/cleanup/full")
async def api_cleanup_full(request: Request):
    """Permanently remove one local account or one chat without a date filter."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "reason": "неверный JSON"}, status_code=422)
    if not isinstance(body, dict):
        return JSONResponse({"ok": False, "reason": "ожидается объект параметров"}, status_code=422)
    scope = body.get("scope")
    account_id, chat_id = body.get("account_id"), body.get("chat_id", 0)
    if (scope not in ("account", "chat") or type(account_id) is not int or account_id <= 0
            or type(chat_id) is not int or (scope == "chat") != (chat_id != 0)
            or body.get("confirmation") != ("DELETE_ACCOUNT" if scope == "account" else "CLEAR_CHAT")
            or any(key in body for key in ("from", "to", "with_media", "mode"))):
        return JSONResponse({"ok": False, "reason": "нужно явно подтвердить удаление одного аккаунта или чата без дат"},
                            status_code=422)

    with db() as c:
        error = cleanup_scope_error(c, scope, account_id, chat_id)
        if error:
            return error
        try:
            for rel in scoped_media_paths(c, account_id, chat_id if scope == "chat" else 0):
                safe_media_path(rel)
        except (ValueError, OSError):
            return JSONResponse({"ok": False, "reason": "найден путь вложения вне media; удаление отменено"},
                                status_code=409)

    bf = BACKFILL.pop(account_id, None)
    tasks = []
    if bf and bf.get("task"):
        bf["task"].cancel()
        tasks.append(bf["task"])
    client = None
    if scope == "account":
        rec = REC.pop(account_id, None)
        if rec:
            rec["task"].cancel()
            tasks.append(rec["task"])
        client = CLIENTS.pop(account_id, None)
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    if client is not None:
        try:
            await client.disconnect()
        except Exception:
            pass
        finally:
            try:
                client.session.close()   # Windows keeps an open session file locked
            except Exception:
                pass

    with db() as c:
        error = cleanup_scope_error(c, scope, account_id, chat_id)
        if error:
            return error
        rel_paths = scoped_media_paths(c, account_id, chat_id if scope == "chat" else 0)
        try:
            candidates = {safe_media_path(rel) for rel in rel_paths}
        except (ValueError, OSError):
            return JSONResponse({"ok": False, "reason": "найден путь вложения вне media; удаление отменено"},
                                status_code=409)
        where = "account_id=?" + (" AND chat_id=?" if scope == "chat" else "")
        args = (account_id, chat_id) if scope == "chat" else (account_id,)
        c.execute(f"DELETE FROM history_pending WHERE {where}", args)
        c.execute(f"DELETE FROM history_progress WHERE {where}", args)
        if scope == "account":
            c.execute("DELETE FROM history_progress_plan WHERE account_id=?", (account_id,))
        messages = c.execute(f"SELECT COUNT(*) FROM messages WHERE {where}", args).fetchone()[0]
        deleted = c.execute(f"SELECT COUNT(*) FROM deleted WHERE {where}", args).fetchone()[0]
        if scope == "chat":
            old_max = c.execute("SELECT max_msg_id FROM chats WHERE account_id=? AND chat_id=?",
                                args).fetchone()[0] or 0
            newest = c.execute(f"""SELECT MAX(msg_id) FROM (
                                   SELECT msg_id FROM messages WHERE {where}
                                   UNION ALL SELECT msg_id FROM deleted WHERE {where})""",
                               (*args, *args)).fetchone()[0] or 0
            watermark = max(old_max, newest)
            c.execute("DELETE FROM messages WHERE account_id=? AND chat_id=?", args)
            c.execute("DELETE FROM deleted WHERE account_id=? AND chat_id=?", args)
            c.execute("""UPDATE chats SET max_msg_id=?, min_msg_id=0, deep_done=1,
                         clear_through_msg_id=? WHERE account_id=? AND chat_id=?""",
                      (watermark, watermark, account_id, chat_id))
        else:
            c.execute("DELETE FROM messages WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM deleted WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM chats WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM participants WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM archive_jobs WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM media_suppression WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM events WHERE account_id=?", (account_id,))
            c.execute("DELETE FROM accounts WHERE id=?", (account_id,))
        files_to_remove, protected = unreferenced_media_paths(c, candidates)

    files, failed = remove_media_files(files_to_remove)
    session_failed = 0
    if scope == "account":
        for suffix in ("", "-wal", "-shm", "-journal"):
            path = SESSIONS / f"account_{account_id}.session{suffix}"
            try:
                path.unlink(missing_ok=True)
            except OSError:
                session_failed += 1
        ACCOUNT_DIRS.pop(account_id, None)
        MEDIA_BYTES.pop(account_id, None)
        SENDER_RESOLVED.difference_update([k for k in SENDER_RESOLVED if k[0] == account_id])
        SENDER_LOOKUP_FAILED.difference_update([k for k in SENDER_LOOKUP_FAILED if k[0] == account_id])
        for key in [k for k in SENDER_PROFILE_CACHE if k[0] == account_id]:
            SENDER_PROFILE_CACHE.pop(key, None)
        LOGGED.discard(account_id)
    return {"ok": True, "messages": messages, "deleted": deleted,
            "files": files, "protected": protected, "failed": failed,
            "session_failed": session_failed}


@app.post("/api/cleanup")
async def api_cleanup(request: Request):
    """Очистка истории из морды: удалить сообщения (и медиа) за период/чат
    или снять удаление и вытянуть переписку из Telegram заново."""
    body = await request.json()
    if not isinstance(body, dict):
        return JSONResponse({"ok": False, "reason": "ожидается объект параметров"}, status_code=422)
    try:
        account_id = int(body.get("account_id", 0) or 0)
        chat_id = int(body.get("chat_id", 0) or 0)
    except (TypeError, ValueError):
        return JSONResponse({"ok": False, "reason": "неверный аккаунт или чат"}, status_code=422)
    raw_from, raw_to = body.get("from", ""), body.get("to", "")
    if not isinstance(raw_from, str) or not isinstance(raw_to, str):
        return JSONResponse({"ok": False, "reason": "даты должны быть строками"}, status_code=422)
    frm, to = raw_from.strip(), raw_to.strip()    # YYYY-MM-DD (необязательно)
    with_media = body.get("with_media", False)
    mode = body.get("mode", "delete")
    if account_id <= 0:
        return JSONResponse({"ok": False, "reason": "не указан аккаунт"}, status_code=422)
    if mode not in ("delete", "restore"):
        return JSONResponse({"ok": False, "reason": "неизвестный режим очистки"}, status_code=422)
    if not isinstance(with_media, bool):
        return JSONResponse({"ok": False, "reason": "with_media должен быть true или false"}, status_code=422)
    try:
        parsed_from = date.fromisoformat(frm) if frm else None
        parsed_to = date.fromisoformat(to) if to else None
    except ValueError:
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if (parsed_from and parsed_from.isoformat() != frm) or (parsed_to and parsed_to.isoformat() != to):
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if parsed_from and parsed_to and parsed_from > parsed_to:
        return JSONResponse({"ok": False, "reason": "начальная дата позже конечной"}, status_code=422)
    if mode == "delete" and (not parsed_from or not parsed_to):
        return JSONResponse({"ok": False, "reason": "для удаления обязательно укажи начало и конец периода"}, status_code=422)
    with db() as c:
        exists = c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not exists:
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        if chat_id and not c.execute(
                "SELECT 1 FROM chats WHERE account_id=? AND chat_id=?", (account_id, chat_id)
        ).fetchone():
            return JSONResponse({"ok": False, "reason": "чат не найден в этом аккаунте"}, status_code=404)
    where, args = "WHERE account_id=?", [account_id]
    if chat_id:
        where += " AND chat_id=?"; args.append(chat_id)
    if frm:
        where += " AND substr(date,1,10)>=?"; args.append(frm)
    if to:
        where += " AND substr(date,1,10)<=?"; args.append(to)
    if mode == "delete":
        files_to_remove, protected = [], 0
        with db() as c:
            rows = c.execute(
                f"SELECT chat_id, msg_id, file_path FROM messages {where}", args).fetchall()
            try:
                candidates = {safe_media_path(r["file_path"]) for r in rows if r["file_path"]} if with_media else set()
            except (ValueError, OSError):
                return JSONResponse({"ok": False, "reason": "найден путь вложения вне media; удаление отменено"},
                                    status_code=409)
            c.execute(f"INSERT OR IGNORE INTO deleted SELECT * FROM messages {where}", args)
            c.execute(f"DELETE FROM messages {where}", args)
            if with_media:
                for r in rows:
                    if r["file_path"]:
                        c.execute("""UPDATE deleted SET file_path=NULL
                                     WHERE account_id=? AND chat_id=? AND msg_id=?""",
                                  (account_id, r["chat_id"], r["msg_id"]))
                    c.execute("""UPDATE deleted SET media_approval=NULL
                                 WHERE account_id=? AND chat_id=? AND msg_id=?""",
                              (account_id, r["chat_id"], r["msg_id"]))
                files_to_remove, protected = unreferenced_media_paths(c, candidates)
                for r in rows:
                    if r["file_path"] and safe_media_path(r["file_path"]) not in files_to_remove:
                        c.execute("""UPDATE deleted SET file_path=?
                                     WHERE account_id=? AND chat_id=? AND msg_id=?""",
                                  (r["file_path"], account_id, r["chat_id"], r["msg_id"]))
            # пересчёт max_msg_id затронутых чатов, чтобы догонка знала новую вершину
            for ch in {r["chat_id"] for r in rows}:
                mx = c.execute("""SELECT MAX(msg_id) AS m FROM messages
                                  WHERE account_id=? AND chat_id=?""",
                               (account_id, ch)).fetchone()["m"] or 0
                c.execute("""UPDATE chats SET max_msg_id=?
                             WHERE account_id=? AND chat_id=?""", (mx, account_id, ch))
        files, failed = remove_media_files(files_to_remove)
        return {"ok": True, "deleted": len(rows),
                "files": files if with_media else None,
                "protected": protected, "failed": failed}
    with db() as c:
        # restore: вернуть из корзины + подтянуть недостающее из Telegram
        dw, dargs = "WHERE account_id=?", [account_id]
        if chat_id:
            dw += " AND chat_id=?"; dargs.append(chat_id)
        if frm:
            dw += " AND substr(date,1,10)>=?"; dargs.append(frm)
        if to:
            dw += " AND substr(date,1,10)<=?"; dargs.append(to)
        restored = c.execute(f"INSERT OR IGNORE INTO messages SELECT * FROM deleted {dw}",
                             dargs).rowcount
        c.execute(f"DELETE FROM deleted {dw}", dargs)
        chats = {r["chat_id"] for r in c.execute(
            "SELECT DISTINCT chat_id FROM chats WHERE account_id=?", (account_id,))}
        if chat_id:
            chats &= {chat_id}
        cleared = c.execute("""SELECT COUNT(*) FROM chats WHERE account_id=?
                               AND (?=0 OR chat_id=?) AND clear_through_msg_id>0""",
                            (account_id, chat_id, chat_id)).fetchone()[0]
        for ch in chats:
            c.execute("""UPDATE chats SET min_msg_id=0, deep_done=0,
                         clear_through_msg_id=0
                         WHERE account_id=? AND chat_id=?""", (account_id, ch))
    sync_started = bool(restored or cleared)
    if sync_started:
        start_backfill(account_id)      # и заодно дотянуть то, что появилось в Telegram
    return {"ok": True, "restored": restored, "sync_started": sync_started}


@app.get("/api/cleanup/preview")
def api_cleanup_preview(account_id: int, chat_id: int = 0,
                        from_date: str = "", to_date: str = ""):
    """Предварительный подсчёт перед удалением; диапазон всегда ограничен двумя датами."""
    if account_id <= 0 or not from_date or not to_date:
        return JSONResponse({"ok": False, "reason": "выбери аккаунт и обе даты"}, status_code=422)
    try:
        start, end = date.fromisoformat(from_date), date.fromisoformat(to_date)
    except ValueError:
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if start.isoformat() != from_date or end.isoformat() != to_date or start > end:
        return JSONResponse({"ok": False, "reason": "неверный диапазон дат"}, status_code=422)
    where, args = ["account_id=?", "substr(date,1,10)>=?", "substr(date,1,10)<=?"], [account_id, from_date, to_date]
    if chat_id:
        where.append("chat_id=?"); args.append(chat_id)
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        if chat_id and not c.execute("SELECT 1 FROM chats WHERE account_id=? AND chat_id=?",
                                     (account_id, chat_id)).fetchone():
            return JSONResponse({"ok": False, "reason": "чат не найден в этом аккаунте"}, status_code=404)
        row = c.execute(f"""SELECT COUNT(*) AS messages,
                                  SUM(CASE WHEN file_path IS NOT NULL AND file_path!='' THEN 1 ELSE 0 END) AS files
                           FROM messages WHERE {' AND '.join(where)}""", args).fetchone()
    return {"messages": row["messages"], "files": row["files"] or 0}


@app.get("/api/media")
def api_media(account_id: int, chat_id: int = 0, from_date: str = "",
              to_date: str = "", limit: int = 200, q: str = ""):
    """Список сохранённых медиа: file_path нужен кнопке просмотра файла.
    Удаление по-прежнему принимает только account_id+chat_id+msg_id — пути с клиента не приходят."""
    if account_id <= 0 or limit < 1 or limit > 500:
        return JSONResponse({"ok": False, "reason": "неверный аккаунт или размер списка"}, status_code=422)
    try:
        start = date.fromisoformat(from_date) if from_date else None
        end = date.fromisoformat(to_date) if to_date else None
    except ValueError:
        return JSONResponse({"ok": False, "reason": "дата должна быть в формате ГГГГ-ММ-ДД"}, status_code=422)
    if ((start and start.isoformat() != from_date) or (end and end.isoformat() != to_date)
            or (start and end and start > end)):
        return JSONResponse({"ok": False, "reason": "неверный диапазон дат"}, status_code=422)
    where, args = ["m.account_id=?", "m.file_path IS NOT NULL", "m.file_path != ''"], [account_id]
    if q.strip():
        where.append("(contains_fold(path_basename(m.file_path),?) OR contains_fold(ch.title,?))")
        args.extend([q.strip(), q.strip()])
    if chat_id:
        where.append("m.chat_id=?"); args.append(chat_id)
    if from_date:
        where.append("substr(m.date,1,10)>=?"); args.append(from_date)
    if to_date:
        where.append("substr(m.date,1,10)<=?"); args.append(to_date)
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        rows = c.execute(f"""
            SELECT m.chat_id, m.msg_id, m.date, m.text, m.media_type, m.file_path,
                   m.file_size, path_basename(m.file_path) AS file_name, COALESCE(ch.title, 'Чат') AS chat_title
            FROM messages m LEFT JOIN chats ch
              ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
            WHERE {' AND '.join(where)}
            ORDER BY m.date DESC, m.msg_id DESC LIMIT ?""", (*args, limit + 1)).fetchall()
    return {"items": [dict(r) for r in rows[:limit]], "more": len(rows) > limit}


@app.get("/api/media/catalog")
def api_media_catalog(sort: str = "date", direction: str = "desc",
                      offset: int = 0, limit: int = 100, pending_only: bool = False, q: str = "",
                      account_id: int = 0, chat_id: int = 0, msg_id: int = 0):
    """Global media index, paged in SQLite so large archives stay bounded in memory."""
    if sort not in ("date", "size", "name") or direction not in ("asc", "desc"):
        return JSONResponse({"ok": False, "reason": "неизвестная сортировка"}, status_code=422)
    if offset < 0 or not 1 <= limit <= 200:
        return JSONResponse({"ok": False, "reason": "неверная страница списка"}, status_code=422)
    with db() as c:
        pending_count = c.execute("""SELECT
            (SELECT COUNT(*) FROM messages WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed','skipped') AND media_type!='video')+
            (SELECT COUNT(*) FROM deleted WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed','skipped') AND media_type!='video')""",
                                 (LARGE_MEDIA_APPROVAL_BYTES, LARGE_MEDIA_APPROVAL_BYTES)).fetchone()[0]
        order_sql = {
            "date": f"date {direction.upper()}, msg_id {direction.upper()}, account_id ASC, chat_id ASC",
            "size": f"file_size {direction.upper()}, msg_id {direction.upper()}, account_id ASC, chat_id ASC",
            "name": f"file_name COLLATE NOCASE {direction.upper()}, account_id ASC, chat_id ASC, msg_id ASC",
        }[sort]
        union = """
            SELECT m.account_id,m.chat_id,m.msg_id,m.date,m.media_type,m.file_path,m.file_size,
                   m.media_approval,m.media_status,m.media_error,m.text,
                   ch.title AS chat_title,'{state}' AS record_state,
                   COALESCE(NULLIF(a.name,''),'Неизвестный аккаунт') ||
                   CASE WHEN COALESCE(a.phone,'')!='' AND a.phone!=COALESCE(a.name,'') THEN ' ('||a.phone||')'
                        WHEN COALESCE(a.username,'')!='' THEN ' (@'||a.username||')' ELSE '' END AS account_label,
                   CASE WHEN COALESCE(m.file_path,'')!=''
                        THEN path_basename(m.file_path)
                        ELSE 'Файл '||m.msg_id END AS file_name
            FROM {table} m
            LEFT JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
            LEFT JOIN accounts a ON a.id=m.account_id
            WHERE m.media_type IS NOT NULL AND COALESCE(m.media_status,'')!='dismissed'
              AND (?=0 OR (m.file_path IS NULL AND m.file_size>? AND
                  COALESCE(m.media_approval,'') NOT IN ('approved','rejected') AND
                  COALESCE(m.media_status,'') NOT IN ('unavailable','dismissed','skipped') AND m.media_type!='video'))
        """
        cte = ("WITH catalog AS (" + union.format(state="messages", table="messages") +
               " UNION ALL " + union.format(state="deleted", table="deleted") + ") ")
        search = " WHERE (contains_fold(file_name,?) OR contains_fold(chat_title,?) OR contains_fold(account_label,?))" if q.strip() else ""
        params = (int(pending_only), LARGE_MEDIA_APPROVAL_BYTES,
                  int(pending_only), LARGE_MEDIA_APPROVAL_BYTES)
        if q.strip():
            params += (q.strip(),) * 3
        if msg_id:
            if account_id <= 0 or msg_id < 0:
                return JSONResponse({"ok": False, "reason": "Неверный идентификатор файла."}, status_code=422)
            search += (" AND " if search else " WHERE ") + "account_id=? AND chat_id=? AND msg_id=?"
            params += (account_id, chat_id, msg_id)
        count = c.execute(cte + "SELECT COUNT(*) FROM catalog" + search, params).fetchone()[0]
        rows = c.execute(cte + "SELECT * FROM catalog" + search +
                         f" ORDER BY {order_sql} LIMIT ? OFFSET ?", (*params, limit, offset)).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["file_exists"] = False
        item["partial_exists"] = False
        item["stored_size"] = 0
        if item["file_path"]:
            try:
                stored_file = safe_media_path(item["file_path"])
                item["file_exists"] = media_file_matches(item["file_path"], item["file_size"])
                if stored_file.is_file():
                    item["stored_size"] = stored_file.stat().st_size
                    item["partial_exists"] = not item["file_exists"]
                if not item["file_exists"] and not item["media_status"]:
                    item["media_status"] = "incomplete"
                    item["media_error"] = "Файл отсутствует или имеет неполный размер на диске."
            except (OSError, ValueError):
                pass
        item["file_name"] = Path(item["file_path"]).name if item["file_path"] else f"Файл {item['msg_id']}"
        if item["file_name"].endswith(".partial"):
            item["file_name"] = item["file_name"][:-len(".partial")]
        item["approval_status"] = ("deleted" if item["record_state"] == "deleted" else
                                    "saved" if item["file_exists"] else
                                    "pending" if (item["file_size"] or 0) > LARGE_MEDIA_APPROVAL_BYTES
                                    and item["media_approval"] not in ("approved", "rejected")
                                    and item["media_type"] != "video"
                                    else item["media_approval"] or "not_saved")
        items.append(item)
    return {"items": items, "more": offset + len(items) < count,
            "total": count, "pending": pending_count}


STORAGE_SNAPSHOT_PATH = BASE / "storage-snapshot.json"
_storage_snapshot_at = 0.0     # monotonic time of this run's last media recount
_storage_scan_lock = threading.Lock()


def _load_saved_media_size():
    """The last media count survives a restart, so the panel never starts with blanks."""
    try:
        saved = json.loads(STORAGE_SNAPSHOT_PATH.read_text(encoding="utf-8"))
        return int(saved["media_bytes"]), float(saved["counted_at"])
    except (OSError, ValueError, KeyError, TypeError):
        return None, None


_media_size, _media_counted_at = _load_saved_media_size()


def _directory_bytes(root: Path) -> int:
    """Sum regular files without following symlinks; tolerate files changing during a scan."""
    total = 0
    pending = [root]
    while pending:
        current = pending.pop()
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            pending.append(Path(entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            total += entry.stat(follow_symlinks=False).st_size
                    except OSError:
                        continue
        except OSError:
            continue
    return total


def _file_bytes(paths) -> int:
    total = 0
    for path in paths:
        try:
            if path.is_file():
                total += path.stat().st_size
        except OSError:
            continue
    return total


def refresh_storage_snapshot():
    """Recount the media folder. A million files take minutes on a busy disk."""
    global _media_size, _media_counted_at, _storage_snapshot_at
    # Hard-linked identical files share their data: count it once.
    media = max(0, _directory_bytes(MEDIA) - MEDIA_DEDUPE["saved_bytes"])
    _media_size, _media_counted_at = media, time.time()
    _storage_snapshot_at = time.monotonic()
    try:
        tmp = STORAGE_SNAPSHOT_PATH.with_name(STORAGE_SNAPSHOT_PATH.name + ".tmp")
        tmp.write_text(json.dumps({"media_bytes": media, "counted_at": _media_counted_at}), encoding="utf-8")
        tmp.replace(STORAGE_SNAPSHOT_PATH)
    except OSError:
        pass


def _storage_scan_thread():
    try:
        refresh_storage_snapshot()
    except Exception as exc:
        print(f"[storage] {type(exc).__name__}: {exc}")
    finally:
        _storage_scan_lock.release()


@app.get("/api/storage")
def api_storage(force: bool = False):
    """Disk capacity and the on-disk footprint of TG Monitor's stored data.

    The database and session files are a handful of files and are measured on every call.
    Only the media folder is recounted, in its own thread, and no request waits for it:
    callers get the last complete count, kept across restarts, or "scanning" before the
    very first one. Waiting callers used to hold every panel worker thread for the whole
    first scan, and the panel stopped answering.
    """
    disk = shutil.disk_usage(BASE)
    # A media archive can contain many files, so refresh its recursive size once per minute.
    if force or _storage_snapshot_at == 0 or time.monotonic() - _storage_snapshot_at >= 60:
        if _storage_scan_lock.acquire(blocking=False):   # one scanner per process
            try:
                threading.Thread(target=_storage_scan_thread, name="tg-storage-scan", daemon=True).start()
            except Exception:
                _storage_scan_lock.release()
                raise
    database = _file_bytes((DB_PATH, Path(str(DB_PATH) + "-wal"), Path(str(DB_PATH) + "-shm")))
    database_backups = _file_bytes(DB_PATH.parent.glob(DB_PATH.name + ".*.bak"))
    sessions = _file_bytes(SESSIONS.glob("*"))
    media = _media_size
    sizes = {"database_bytes": database, "database_backups_bytes": database_backups,
             "sessions_bytes": sessions, "media_bytes": media, "media_counted_at": _media_counted_at,
             "archive_bytes": None if media is None else database + database_backups + sessions + media}
    return {"disk_total_bytes": disk.total, "disk_used_bytes": disk.used,
            "disk_free_bytes": disk.free, "disk_root": str(Path(BASE.anchor)),
            "disk_warning_level": ("critical" if disk.free <= max(1024 ** 3, disk.total * 0.01)
                                   else "low" if disk.free <= max(5 * 1024 ** 3, disk.total * 0.05)
                                   else None),
            "scanning": _storage_snapshot_at == 0 or _storage_scan_lock.locked(),
            **sizes}


@app.get("/api/media/pending/count")
def api_pending_media_count():
    with db() as c:
        count = c.execute("""SELECT
            (SELECT COUNT(*) FROM messages WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed','skipped') AND media_type!='video')+
            (SELECT COUNT(*) FROM deleted WHERE media_type IS NOT NULL AND file_path IS NULL
                AND file_size>? AND COALESCE(media_approval,'') NOT IN ('approved','rejected')
                AND COALESCE(media_status,'') NOT IN ('unavailable','dismissed','skipped') AND media_type!='video')""",
                          (LARGE_MEDIA_APPROVAL_BYTES, LARGE_MEDIA_APPROVAL_BYTES)).fetchone()[0]
    return {"pending": count}


@app.post("/api/media/approval")
async def api_media_approval(request: Request):
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        chat_id = int(body.get("chat_id", 0))
        msg_id = int(body.get("msg_id", 0))
        decision = body.get("decision")
        source = body.get("source", "messages")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if (account_id <= 0 or not chat_id or msg_id <= 0 or
            decision not in ("approved", "rejected") or source not in ("messages", "deleted")):
        return JSONResponse({"ok": False, "reason": "неверное решение или идентификатор файла"}, status_code=422)
    client = CLIENTS.get(account_id)
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg_id)) % len(MESSAGE_LOCKS)]
    async with lock:
        with db() as c:
            row = c.execute(f"""SELECT file_size,media_approval FROM {source}
                                WHERE account_id=? AND chat_id=? AND msg_id=? AND media_type IS NOT NULL""",
                            (account_id, chat_id, msg_id)).fetchone()
            if not row:
                return JSONResponse({"ok": False, "reason": "запись файла не найдена"}, status_code=404)
            if (row["file_size"] or 0) <= LARGE_MEDIA_APPROVAL_BYTES:
                return JSONResponse({"ok": False, "reason": "подтверждение требуется только для файлов больше 1 ГБ"}, status_code=422)
        if decision == "rejected":
            with db() as c:
                c.execute(f"UPDATE {source} SET media_approval='rejected' WHERE account_id=? AND chat_id=? AND msg_id=?",
                          (account_id, chat_id, msg_id))
            return {"ok": True, "decision": decision, "downloaded": False}
        telegram_message = None
        chat = None
        if client is None or not client.is_connected():
            return JSONResponse({"ok": False, "reason": "Нельзя проверить файл: аккаунт Telegram сейчас не подключён. Подключи его и повтори одобрение."}, status_code=409)
        try:
            if source == "messages":
                with db() as c:
                    chat = c.execute("SELECT title,type FROM chats WHERE account_id=? AND chat_id=?",
                                     (account_id, chat_id)).fetchone()
            telegram_message = await client.get_messages(chat_id, ids=msg_id)
        except Exception as exc:
            if session_lost(exc):
                await end_lost_session(account_id)
                return JSONResponse({"ok": False, "reason": LOST_SESSION_REASON + " Решение не сохранено."}, status_code=409)
            return JSONResponse({"ok": False, "reason": f"Не удалось проверить сообщение в Telegram: {type(exc).__name__}. Решение не сохранено."}, status_code=502)
        if telegram_message is None:
            with db() as c:
                c.execute(f"""UPDATE {source} SET media_status='unavailable',
                            media_error='Сообщение с файлом удалено или больше недоступно в Telegram.'
                            WHERE account_id=? AND chat_id=? AND msg_id=?""",
                          (account_id, chat_id, msg_id))
            return JSONResponse({"ok": False, "reason": "Файл уже удалён или недоступен в Telegram. Одобрить загрузку нельзя; запись можно убрать крестиком."}, status_code=410)
        if source == "deleted":
            return JSONResponse({"ok": False, "reason": "Запись находится в локальной корзине. Восстанови её перед одобрением файла."}, status_code=409)
        with db() as c:
            c.execute(f"UPDATE {source} SET media_approval='approved',media_status=NULL,media_error=NULL WHERE account_id=? AND chat_id=? AND msg_id=?",
                      (account_id, chat_id, msg_id))
        if source == "messages" and telegram_message and chat:
            try:
                await _store_message_locked(client, account_id, telegram_message, chat_id,
                                            chat["title"] or "Чат", chat["type"] or "user", force_video=True)
            except Exception as exc:
                if not session_lost(exc):
                    raise
                await end_lost_session(account_id)
                return JSONResponse({"ok": False, "reason": LOST_SESSION_REASON}, status_code=409)
        with db() as c:
            saved = c.execute(f"SELECT file_path,media_status,media_error FROM {source} WHERE account_id=? AND chat_id=? AND msg_id=?",
                              (account_id, chat_id, msg_id)).fetchone()
        if source == "messages" and not (saved and saved["file_path"]):
            if saved and saved["media_status"] == "storage_full":
                return JSONResponse({"ok": False, "reason": saved["media_error"] or "Мало свободного места на диске. Освободи место и повтори."}, status_code=507)
            if saved and saved["media_status"] == "unavailable":
                return JSONResponse({"ok": False, "reason": saved["media_error"] or "Файл удалён или недоступен в Telegram."}, status_code=410)
            return JSONResponse({"ok": False, "reason": saved["media_error"] if saved else "Загрузка не завершилась."}, status_code=502)
        return {"ok": True, "decision": decision, "downloaded": bool(saved and saved["file_path"])}


@app.post("/api/media/retry")
async def api_media_retry(request: Request):
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        chat_id = int(body.get("chat_id", 0))
        msg_id = int(body.get("msg_id", 0))
        source = body.get("source", "messages")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if account_id <= 0 or not chat_id or msg_id <= 0 or source not in ("messages", "deleted"):
        return JSONResponse({"ok": False, "reason": "неверный идентификатор файла"}, status_code=422)
    if source == "deleted":
        return JSONResponse({"ok": False, "reason": "Сначала восстанови сообщение из локальной корзины."}, status_code=409)
    client = CLIENTS.get(account_id)
    if client is None or not client.is_connected():
        return JSONResponse({"ok": False, "reason": "Аккаунт Telegram отключён. Подключи его и повтори загрузку."}, status_code=409)
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg_id)) % len(MESSAGE_LOCKS)]
    async with lock:
        with db() as c:
            row = c.execute("SELECT media_type FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                            (account_id, chat_id, msg_id)).fetchone()
            chat = c.execute("SELECT title,type FROM chats WHERE account_id=? AND chat_id=?",
                             (account_id, chat_id)).fetchone()
        if not row or not row["media_type"] or not chat:
            return JSONResponse({"ok": False, "reason": "Запись медиа больше не найдена."}, status_code=404)
        try:
            telegram_message = await client.get_messages(chat_id, ids=msg_id)
        except Exception as exc:
            if session_lost(exc):
                await end_lost_session(account_id)
                return JSONResponse({"ok": False, "reason": LOST_SESSION_REASON}, status_code=409)
            return JSONResponse({"ok": False, "reason": f"Не удалось проверить сообщение в Telegram: {type(exc).__name__}."}, status_code=502)
        if telegram_message is None:
            with db() as c:
                c.execute("""UPDATE messages SET media_status='unavailable',
                            media_error='Сообщение с файлом удалено или больше недоступно в Telegram.'
                            WHERE account_id=? AND chat_id=? AND msg_id=?""",
                          (account_id, chat_id, msg_id))
            return JSONResponse({"ok": False, "reason": "Сообщение с файлом удалено или недоступно в Telegram. Запись можно убрать крестиком."}, status_code=410)
        with db() as c:
            c.execute("UPDATE messages SET media_status=NULL,media_error=NULL WHERE account_id=? AND chat_id=? AND msg_id=? AND media_status='dismissed'",
                      (account_id,chat_id,msg_id))
        try:
            await _store_message_locked(client, account_id, telegram_message, chat_id,
                                        chat["title"] or "Чат", chat["type"] or "user", force_video=True)
        except Exception as exc:
            if not session_lost(exc):
                raise
            await end_lost_session(account_id)
            return JSONResponse({"ok": False, "reason": LOST_SESSION_REASON}, status_code=409)
        with db() as c:
            result = c.execute("SELECT file_path,media_status,media_error,file_size FROM messages WHERE account_id=? AND chat_id=? AND msg_id=?",
                               (account_id, chat_id, msg_id)).fetchone()
        if result and result["file_path"] and media_file_matches(result["file_path"], result["file_size"]):
            return {"ok": True, "downloaded": True}
        if result and result["media_status"] == "storage_full":
            return JSONResponse({"ok": False, "reason": result["media_error"] or "Мало свободного места на диске."}, status_code=507)
        return JSONResponse({"ok": False, "reason": result["media_error"] if result else "Загрузка не завершилась."}, status_code=502)


@app.post("/api/media/dismiss")
async def api_media_dismiss(request: Request):
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        chat_id = int(body.get("chat_id", 0))
        msg_id = int(body.get("msg_id", 0))
        source = body.get("source", "messages")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if account_id <= 0 or not chat_id or msg_id <= 0 or source not in ("messages", "deleted"):
        return JSONResponse({"ok": False, "reason": "неверный идентификатор файла"}, status_code=422)
    lock = MESSAGE_LOCKS[hash((account_id, chat_id, msg_id)) % len(MESSAGE_LOCKS)]
    async with lock:
        with db() as c:
            cur = c.execute(f"""UPDATE {source} SET media_status='dismissed',
                         media_approval=CASE WHEN coalesce(file_size,0)>? THEN 'rejected' ELSE media_approval END
                         WHERE account_id=? AND chat_id=? AND msg_id=? AND media_type IS NOT NULL""",
                            (LARGE_MEDIA_APPROVAL_BYTES, account_id, chat_id, msg_id))
        if not cur.rowcount:
            return JSONResponse({"ok": False, "reason": "Запись медиа не найдена."}, status_code=404)
        with db() as c:
            c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?",(account_id,chat_id,msg_id))
    return {"ok": True}


@app.post("/api/media/delete")
async def api_media_delete(request: Request):
    """Удалить выбранные медиа, сохранив сообщения; клиент не задаёт пути на диске."""
    try:
        body = await request.json()
        account_id = int(body.get("account_id", 0))
        items = body.get("items")
    except (ValueError, TypeError, AttributeError):
        return JSONResponse({"ok": False, "reason": "неверный формат запроса"}, status_code=422)
    if account_id <= 0 or not isinstance(items, list) or not 1 <= len(items) <= 500:
        return JSONResponse({"ok": False, "reason": "выбери от 1 до 500 файлов"}, status_code=422)
    selected = []
    try:
        for item in items:
            if not isinstance(item, dict):
                raise ValueError
            chat_id, msg_id = int(item["chat_id"]), int(item["msg_id"])
            source = item.get("source", "messages")
            if msg_id <= 0 or source not in ("messages", "deleted"):
                raise ValueError
            selected.append((chat_id, msg_id, source))
    except (KeyError, ValueError, TypeError):
        return JSONResponse({"ok": False, "reason": "неверный идентификатор файла"}, status_code=422)
    if len(set(selected)) != len(selected):
        return JSONResponse({"ok": False, "reason": "в запросе есть повторяющиеся файлы"}, status_code=422)

    files_removed = detached = failed = 0
    media_root = MEDIA.resolve()
    paths_to_remove = []
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        rows = []
        for chat_id, msg_id, source in selected:
            row = c.execute(f"""SELECT file_path,media_type FROM {source}
                               WHERE account_id=? AND chat_id=? AND msg_id=?""",
                            (account_id, chat_id, msg_id)).fetchone()
            if not row or not row["media_type"]:
                return JSONResponse({"ok": False, "reason": "одно из вложений уже удалено или не найдено"}, status_code=404)
            full = None
            if row["file_path"]:
                try:
                    full = safe_media_path(row["file_path"])
                    full.relative_to(media_root)
                except (ValueError, OSError):
                    return JSONResponse({"ok": False, "reason": "путь вложения вне каталога медиа"}, status_code=409)
            rows.append((source, chat_id, msg_id, row["file_path"], full))

        selected_keys = {(source, account_id, chat_id, msg_id) for chat_id, msg_id, source in selected}
        by_path = {}
        for source, chat_id, msg_id, rel_path, full in rows:
            if rel_path:
                by_path.setdefault(rel_path, {"full": full, "selected": set()})["selected"].add(
                    (source, account_id, chat_id, msg_id))
        safe_to_remove = set()
        for rel_path, info in by_path.items():
            refs = c.execute("""SELECT 'messages' AS source,account_id,chat_id,msg_id FROM messages WHERE file_path=?
                               UNION ALL
                               SELECT 'deleted' AS source,account_id,chat_id,msg_id FROM deleted WHERE file_path=?""",
                             (rel_path, rel_path)).fetchall()
            if all((r["source"], r["account_id"], r["chat_id"], r["msg_id"]) in selected_keys for r in refs):
                safe_to_remove.add(rel_path)

        # Сначала фиксируем отвязку в БД. Если транзакция не сохранится,
        # физические файлы останутся нетронутыми.
        for rel_path in safe_to_remove:
            paths_to_remove.append((rel_path, by_path[rel_path]["full"]))
        for source, chat_id, msg_id, rel_path, _ in rows:
            c.execute("INSERT OR IGNORE INTO media_suppression VALUES(?,?,?)",(account_id,chat_id,msg_id))
            c.execute("DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?",(account_id,chat_id,msg_id))
            cur = c.execute(f"""UPDATE {source} SET file_path=NULL,media_type=NULL,file_size=NULL,media_approval=NULL,
                                media_id=NULL,media_status=NULL,media_error=NULL
                                WHERE account_id=? AND chat_id=? AND msg_id=?""",
                            (account_id, chat_id, msg_id))
            detached += cur.rowcount

    # После успешного коммита можно удалять физические файлы. Ошибка диска
    # отражается как частичный результат, а не как общий сбой после удаления.
    for _, full in paths_to_remove:
        try:
            existed = full.is_file()
            full.unlink(missing_ok=True)
            files_removed += int(existed)
        except OSError:
            failed += 1
    protected = sum(1 for _, _, _, rel_path, _ in rows if rel_path and rel_path not in safe_to_remove)
    return {"ok": True, "files": files_removed, "detached": detached,
            "protected": protected, "failed": failed}


@app.get("/api/media/file")
def api_media_file(account_id: int, chat_id: int, msg_id: int, source: str = "messages"):
    """Serve the existing attachment by database identity, never a browser-supplied path."""
    if source not in ("messages", "deleted") or account_id <= 0 or msg_id <= 0:
        return JSONResponse({"ok": False, "reason": "Неверный идентификатор файла."}, status_code=422)
    with db() as c:
        row = c.execute(f"SELECT file_path,file_size FROM {source} WHERE account_id=? AND chat_id=? AND msg_id=?",
                        (account_id, chat_id, msg_id)).fetchone()
    if not row or not row["file_path"]:
        return JSONResponse({"ok": False, "reason": "Файл ещё не сохранён. Проверьте его состояние в разделе «Файлы»."}, status_code=404)
    try:
        full = safe_media_path(row["file_path"])
        if not full.is_file():
            raise FileNotFoundError
        if full.name.endswith(".partial") or (row["file_size"] and full.stat().st_size != row["file_size"]):
            return JSONResponse({"ok": False, "reason": "Файл загружен не полностью."}, status_code=409)
    except (ValueError, OSError):
        return JSONResponse({"ok": False, "reason": "Файл не найден в хранилище."}, status_code=404)
    return FileResponse(full, filename=full.name, headers={"X-Content-Type-Options": "nosniff"})


AVATAR_LOCKS = [asyncio.Lock() for _ in range(16)]
AVATAR_SLOTS = asyncio.Semaphore(2)
AVATAR_RETRY = OrderedDict()


@app.get("/api/accounts/{account_id}/avatar")
async def api_avatar(account_id: int, entity_id: int = 0):
    """Small persistent profile cache; use only an already connected Telegram client."""
    with db() as c:
        account = c.execute("SELECT tg_user_id,status FROM accounts WHERE id=?", (account_id,)).fetchone()
        known = not entity_id or (account and entity_id == account["tg_user_id"])
        if not known:
            known = bool(c.execute("SELECT 1 FROM chats WHERE account_id=? AND chat_id=? UNION ALL SELECT 1 FROM participants WHERE account_id=? AND user_id=? LIMIT 1",
                                   (account_id, entity_id, account_id, entity_id)).fetchone())
    if not account or not known:
        return Response(status_code=404)
    key = (account_id, entity_id or account["tg_user_id"] or 0)
    path = BASE / "avatars" / f"{key[0]}_{key[1]}.jpg"
    async with AVATAR_LOCKS[hash(key) % len(AVATAR_LOCKS)]:
        exists = path.is_file()
        fresh = exists and time.time() - path.stat().st_mtime < 3600
        client = CLIENTS.get(account_id)
        retry = AVATAR_RETRY.get(key, 0)
        if not fresh and time.monotonic() >= retry and client and client.is_connected() and account["status"] == "recording":
            try:
                async with AVATAR_SLOTS:
                    photo = await asyncio.wait_for(client.download_profile_photo(
                        entity_id or "me", file=bytes, download_big=False), timeout=15)
                if photo:
                    path.parent.mkdir(exist_ok=True)
                    temporary = path.with_suffix(".tmp")
                    temporary.write_bytes(photo)
                    temporary.replace(path)
                    exists = True
                elif exists:
                    # Telegram confirmed that the profile has no photo now.
                    path.unlink()
                    exists = False
                AVATAR_RETRY[key] = time.monotonic() + 3600
            except FloodWaitError as exc:
                AVATAR_RETRY[key] = time.monotonic() + max(300, exc.seconds)
            except Exception:
                AVATAR_RETRY[key] = time.monotonic() + 300
            AVATAR_RETRY.move_to_end(key)
            while len(AVATAR_RETRY) > 2048:
                AVATAR_RETRY.popitem(last=False)
    if exists:
        return FileResponse(path, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=300", "X-Content-Type-Options": "nosniff"})
    return Response(status_code=404, headers={"Cache-Control": "private, max-age=60"})


def is_local_panel_request(request):
    """Only the direct loopback panel may control the server desktop."""
    import ipaddress
    try:
        if not request.client or not ipaddress.ip_address(request.client.host).is_loopback:
            return False
        host = request.url.hostname or ""
        if host != "localhost" and not ipaddress.ip_address(host).is_loopback:
            return False
    except ValueError:
        return False
    if any(name in request.headers for name in
           ("forwarded", "x-forwarded-for", "x-forwarded-host", "cf-connecting-ip")):
        return False
    if request.headers.get("sec-fetch-site") in ("cross-site", "same-site"):
        return False
    origin = request.headers.get("origin")
    return not origin or origin.rstrip("/") == str(request.base_url).rstrip("/")


@app.post("/api/media/reveal")
def api_media_reveal(request: Request, account_id: int, chat_id: int, msg_id: int,
                     source: str = "messages"):
    if not is_local_panel_request(request):
        return JSONResponse({"ok": False, "reason": "Папка открывается только из локальной панели на сервере. Для удалённого доступа используйте скачивание."}, status_code=403)
    response = api_media_file(account_id, chat_id, msg_id, source)
    if not isinstance(response, FileResponse):
        return response
    return reveal_saved_path(str(Path(response.path).relative_to(BASE)))


@app.get("/api/reveal")
def api_reveal(request: Request, path: str):
    if not is_local_panel_request(request):
        return JSONResponse({"ok": False, "reason": "Открытие папки доступно только из локальной панели."}, status_code=403)
    return reveal_saved_path(path)


def reveal_saved_path(path: str):
    """Показать файл в Проводнике (документы в чате). Только внутри media/."""
    path = (path or "").lstrip("/\\")        # браузер шлёт путь с ведущим слэшем
    try:
        full = (BASE / path).resolve()
        full.relative_to(MEDIA.resolve())      # путь вне хранилища — отказ
    except (ValueError, OSError):
        return {"ok": False, "reason": "путь вне хранилища"}
    if not full.exists():
        return {"ok": False, "reason": "файл не найден на диске"}
    try:
        if sys.platform != "win32":
            return {"ok": False, "reason": "открытие папки доступно только на Windows-панели"}

        import ctypes
        session = ctypes.c_ulong()
        if not ctypes.windll.kernel32.ProcessIdToSessionId(os.getpid(), ctypes.byref(session)):
            return {"ok":False,"reason":"Не удалось определить рабочий сеанс Windows"}
        if session.value == 0:
            from desktop_reveal import reveal_in_interactive_session
            return reveal_in_interactive_session(full, BASE)

        # SHOpenFolderAndSelectItems opens/activates the containing folder and
        # selects the exact file. Explorer's command-line /select handling can
        # reuse a background window and silently skip the selection.
        import ctypes
        from ctypes import wintypes

        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        ole32 = ctypes.WinDLL("ole32", use_last_error=True)
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        shell32.SHParseDisplayName.argtypes = [
            wintypes.LPCWSTR, ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_void_p), wintypes.DWORD,
            ctypes.POINTER(wintypes.DWORD),
        ]
        shell32.SHParseDisplayName.restype = ctypes.c_long
        shell32.ILFindLastID.argtypes = [ctypes.c_void_p]
        shell32.ILFindLastID.restype = ctypes.c_void_p
        shell32.SHOpenFolderAndSelectItems.argtypes = [
            ctypes.c_void_p, wintypes.UINT,
            ctypes.POINTER(ctypes.c_void_p), wintypes.DWORD,
        ]
        shell32.SHOpenFolderAndSelectItems.restype = ctypes.c_long
        shell32.ShellExecuteW.argtypes = [
            wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR,
            wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.c_int,
        ]
        shell32.ShellExecuteW.restype = ctypes.c_void_p
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        ole32.CoTaskMemFree.restype = None
        ole32.CoInitializeEx.argtypes = [ctypes.c_void_p, wintypes.DWORD]
        ole32.CoInitializeEx.restype = ctypes.c_long
        ole32.CoUninitialize.argtypes = []
        ole32.CoUninitialize.restype = None
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetClassNameW.restype = ctypes.c_int
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.ShowWindow.restype = wintypes.BOOL
        user32.IsZoomed.argtypes = [wintypes.HWND]
        user32.IsZoomed.restype = wintypes.BOOL
        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        user32.SetForegroundWindow.restype = wintypes.BOOL
        user32.BringWindowToTop.argtypes = [wintypes.HWND]
        user32.BringWindowToTop.restype = wintypes.BOOL
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetWindowTextW.restype = ctypes.c_int
        user32.IsWindowVisible.argtypes = [wintypes.HWND]
        user32.IsWindowVisible.restype = wintypes.BOOL
        enum_windows_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows.argtypes = [enum_windows_proc, wintypes.LPARAM]
        user32.EnumWindows.restype = wintypes.BOOL
        user32.SetActiveWindow.argtypes = [wintypes.HWND]
        user32.SetActiveWindow.restype = wintypes.HWND
        user32.SetFocus.argtypes = [wintypes.HWND]
        user32.SetFocus.restype = wintypes.HWND
        user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        user32.AttachThreadInput.restype = wintypes.BOOL
        user32.SwitchToThisWindow.argtypes = [wintypes.HWND, wintypes.BOOL]
        user32.SwitchToThisWindow.restype = None
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetCurrentThreadId.restype = wintypes.DWORD
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD

        # FastAPI runs sync handlers on worker threads. Initialize COM on the
        # current thread before calling the Shell namespace APIs.
        co_hr = ole32.CoInitializeEx(None, 2)  # COINIT_APARTMENTTHREADED
        com_initialized_here = co_hr in (0, 1)  # S_OK / S_FALSE
        if co_hr < 0 and co_hr != -2147417850:  # RPC_E_CHANGED_MODE: already initialized
            raise OSError(f"Не удалось инициализировать Windows Shell (HRESULT {co_hr:#x})")
        try:
            folder_pidl = ctypes.c_void_p()
            file_pidl = ctypes.c_void_p()
            hr = shell32.SHParseDisplayName(str(full.parent), None, ctypes.byref(folder_pidl), 0, None)
            if hr < 0:
                raise OSError(f"Не удалось открыть папку (HRESULT {hr:#x})")
            try:
                hr = shell32.SHParseDisplayName(str(full), None, ctypes.byref(file_pidl), 0, None)
                if hr < 0:
                    raise OSError(f"Не удалось найти файл (HRESULT {hr:#x})")
                try:
                    child_pidl = shell32.ILFindLastID(file_pidl)
                    child_items = (ctypes.c_void_p * 1)(child_pidl)
                    hr = shell32.SHOpenFolderAndSelectItems(folder_pidl, 1, child_items, 0)
                    if hr < 0:
                        raise OSError(f"Проводник не смог выделить файл (HRESULT {hr:#x})")
                finally:
                    ole32.CoTaskMemFree(file_pidl)
            finally:
                ole32.CoTaskMemFree(folder_pidl)
        finally:
            if com_initialized_here:
                ole32.CoUninitialize()

        # Prefer the activated Explorer frame. If Windows opened it without
        # activating it, find the frame for this folder by its window title.
        hwnd = None
        for _ in range(15):
            candidate = user32.GetForegroundWindow()
            class_name = ctypes.create_unicode_buffer(64)
            title = ctypes.create_unicode_buffer(512)
            if candidate and user32.GetClassNameW(candidate, class_name, len(class_name)) \
                    and class_name.value in {"CabinetWClass", "ExploreWClass"}:
                user32.GetWindowTextW(candidate, title, len(title))
            if (candidate and class_name.value in {"CabinetWClass", "ExploreWClass"}
                    and title.value.casefold().startswith(full.parent.name.casefold())):
                hwnd = candidate
                break
            matches = []
            @enum_windows_proc
            def collect_explorer(window, _):
                window_class = ctypes.create_unicode_buffer(64)
                title = ctypes.create_unicode_buffer(512)
                user32.GetClassNameW(window, window_class, len(window_class))
                user32.GetWindowTextW(window, title, len(title))
                if (user32.IsWindowVisible(window)
                        and window_class.value in {"CabinetWClass", "ExploreWClass"}
                        and title.value.casefold().startswith(full.parent.name.casefold())):
                    matches.append(window)
                return True
            user32.EnumWindows(collect_explorer, 0)
            if matches:
                hwnd = matches[-1]
                break
            time.sleep(0.1)
        if not hwnd:
            # Some Windows builds acknowledge SHOpenFolderAndSelectItems but
            # leave the requester's Explorer frame in the background. Launch
            # a maximized selection request through the shell as a fallback.
            args = f'/n,/select,"{full}"'
            result = shell32.ShellExecuteW(None, "open", "explorer.exe", args, str(full.parent), 3)
            if not result or result <= 32:
                raise OSError(f"Windows не смог запустить Проводник (код {result or 0})")
            for _ in range(25):
                candidate = user32.GetForegroundWindow()
                class_name = ctypes.create_unicode_buffer(64)
                title = ctypes.create_unicode_buffer(512)
                if candidate and user32.GetClassNameW(candidate, class_name, len(class_name)) \
                        and class_name.value in {"CabinetWClass", "ExploreWClass"}:
                    user32.GetWindowTextW(candidate, title, len(title))
                    if title.value.casefold().startswith(full.parent.name.casefold()):
                        hwnd = candidate
                        break
                matches = []
                @enum_windows_proc
                def collect_shell_window(window, _):
                    window_class = ctypes.create_unicode_buffer(64)
                    title = ctypes.create_unicode_buffer(512)
                    user32.GetClassNameW(window, window_class, len(window_class))
                    user32.GetWindowTextW(window, title, len(title))
                    if (user32.IsWindowVisible(window)
                            and window_class.value in {"CabinetWClass", "ExploreWClass"}
                            and title.value.casefold().startswith(full.parent.name.casefold())):
                        matches.append(window)
                    return True
                user32.EnumWindows(collect_shell_window, 0)
                if matches:
                    hwnd = matches[-1]
                    break
                time.sleep(0.1)
        foreground = False
        maximized = False
        if hwnd:
            user32.BringWindowToTop(hwnd)
            current_thread = kernel32.GetCurrentThreadId()
            active_window = user32.GetForegroundWindow()
            active_thread = user32.GetWindowThreadProcessId(active_window, None) if active_window else 0
            attached = bool(active_thread and active_thread != current_thread
                            and user32.AttachThreadInput(current_thread, active_thread, True))
            try:
                user32.SetForegroundWindow(hwnd)
                user32.SetActiveWindow(hwnd)
                user32.SetFocus(hwnd)
                user32.SwitchToThisWindow(hwnd, True)
            finally:
                if attached:
                    user32.AttachThreadInput(current_thread, active_thread, False)
            for _ in range(8):
                user32.ShowWindow(hwnd, 3)  # SW_SHOWMAXIMIZED, after activation
                if user32.IsZoomed(hwnd):
                    break
                time.sleep(0.1)
            for _ in range(10):
                if user32.GetForegroundWindow() == hwnd:
                    foreground = True
                    break
                time.sleep(0.05)
            maximized = bool(user32.IsZoomed(hwnd))
        if not foreground or not maximized:
            # Explorer is an out-of-process shell window. A short-lived
            # PowerShell helper running in the same interactive session can
            # activate and maximize it even when the API worker has no input
            # queue attached to the user's foreground desktop.
            import base64
            import subprocess
            title_b64 = base64.b64encode(full.parent.name.encode("utf-8")).decode("ascii")
            ps = f'''
$title = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{title_b64}'))
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class TgMonitorExplorerActivation {{
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern void SwitchToThisWindow(IntPtr h, bool altTab);
}}
'@
$target = Get-Process explorer -ErrorAction SilentlyContinue | Where-Object {{
  $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle.StartsWith($title, [StringComparison]::OrdinalIgnoreCase)
}} | Select-Object -Last 1
if (-not $target) {{ exit 2 }}
[void][TgMonitorExplorerActivation]::ShowWindow($target.MainWindowHandle, 3)
[void][TgMonitorExplorerActivation]::BringWindowToTop($target.MainWindowHandle)
[void][TgMonitorExplorerActivation]::SetForegroundWindow($target.MainWindowHandle)
[TgMonitorExplorerActivation]::SwitchToThisWindow($target.MainWindowHandle, $true)
Start-Sleep -Milliseconds 150
if ([TgMonitorExplorerActivation]::IsZoomed($target.MainWindowHandle) -and
    [TgMonitorExplorerActivation]::GetForegroundWindow() -eq $target.MainWindowHandle) {{ exit 0 }}
if ([TgMonitorExplorerActivation]::IsZoomed($target.MainWindowHandle)) {{ exit 4 }}
exit 3
'''
            encoded_ps = base64.b64encode(ps.encode("utf-16le")).decode("ascii")
            try:
                helper = subprocess.run(
                    ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive",
                     "-WindowStyle", "Hidden", "-EncodedCommand", encoded_ps],
                    capture_output=True, timeout=8,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if helper.returncode == 0:
                    foreground = maximized = True
                elif helper.returncode == 4:
                    maximized = True
            except (OSError, subprocess.TimeoutExpired):
                pass
        return {"ok": True, "foreground": foreground, "maximized": maximized}
    except Exception as exc:
        return {"ok": False, "reason": f"Не удалось открыть файл в Проводнике: {exc}"}


@app.get("/api/chats")
def api_chats(account_id: int):
    with db() as c:
        rows = c.execute("""
            SELECT ch.chat_id, ch.title, ch.type, COUNT(m.msg_id) AS n, MAX(m.date) AS last,
                   (SELECT CASE WHEN COALESCE(latest.text,'') != ''
                                THEN substr(latest.text,1,60)
                                WHEN COALESCE(latest.media_type,'') != ''
                                THEN '[' || latest.media_type || ']'
                                ELSE '' END
                    FROM messages latest
                    WHERE latest.account_id=ch.account_id AND latest.chat_id=ch.chat_id
                    ORDER BY latest.date DESC, latest.msg_id DESC LIMIT 1) AS preview
            FROM chats ch JOIN messages m ON m.account_id = ch.account_id
                         AND m.chat_id = ch.chat_id
            WHERE ch.account_id = ?
            GROUP BY ch.chat_id ORDER BY last DESC""", (account_id,)).fetchall()
        return [dict(r) for r in rows]


@app.get("/api/cleanup/chats")
def api_cleanup_chats(account_id: int):
    """All known chats, including empty ones that can be restored after full cleanup."""
    if account_id <= 0:
        return JSONResponse({"ok": False, "reason": "неверный аккаунт"}, status_code=422)
    with db() as c:
        if not c.execute("SELECT 1 FROM accounts WHERE id=?", (account_id,)).fetchone():
            return JSONResponse({"ok": False, "reason": "аккаунт не найден"}, status_code=404)
        rows = c.execute("""SELECT ch.chat_id, ch.title, COUNT(m.msg_id) AS n
                            FROM chats ch LEFT JOIN messages m
                              ON m.account_id=ch.account_id AND m.chat_id=ch.chat_id
                            WHERE ch.account_id=? GROUP BY ch.chat_id,ch.title
                            ORDER BY ch.title""", (account_id,)).fetchall()
        return [dict(r) for r in rows]


@app.get("/api/messages")
def api_messages(account_id: int, chat_id: int, limit: int = 200,
                 q: str = "", before_msg_id: int = 0, around_msg_id: int = 0):
    if account_id <= 0 or not 1 <= limit <= 1000 or before_msg_id < 0 or around_msg_id < 0:
        return JSONResponse({"ok": False, "reason": "неверный account_id, limit или курсор"}, status_code=422)
    q = q.strip()
    if len(q) > 200:
        return JSONResponse({"ok": False, "reason": "поисковый запрос слишком длинный"}, status_code=422)
    sql = """SELECT m.msg_id,m.date,m.sender_id,m.out,m.text,m.media_type,m.file_path,
                    m.media_status,m.media_error,
                    ch.type AS chat_type,p.username AS sender_username,p.phone AS sender_phone,
                    p.display_name AS sender_display_name,p.title AS sender_title
             FROM messages m
             LEFT JOIN chats ch ON ch.account_id=m.account_id AND ch.chat_id=m.chat_id
             LEFT JOIN participants p ON p.account_id=m.account_id AND p.user_id=m.sender_id
             WHERE m.account_id=? AND m.chat_id=?"""
    params = [account_id, chat_id]
    if before_msg_id:
        sql += " AND m.msg_id < ?"
        params.append(before_msg_id)
    if q:                               # поиск по буквальному фрагменту текста
        literal = q.replace("!", "!!").replace("%", "!%").replace("_", "!_")
        sql += " AND m.text LIKE ? ESCAPE '!'"
        params.append(f"%{literal}%")
    sql += " ORDER BY m.msg_id DESC LIMIT ?"
    params.append(min(limit, 1000))
    with db() as c:
        account = c.execute("SELECT name,username,phone,tg_user_id FROM accounts WHERE id=?", (account_id,)).fetchone()
        if around_msg_id:
            base = sql.rsplit(" ORDER BY", 1)[0]
            base_params = params[:-1]
            before = c.execute(base + " AND m.msg_id<=? ORDER BY m.msg_id DESC LIMIT 100",
                               (*base_params, around_msg_id)).fetchall()
            after = c.execute(base + " AND m.msg_id>? ORDER BY m.msg_id ASC LIMIT 100",
                              (*base_params, around_msg_id)).fetchall()
            rows = sorted([*before, *after], key=lambda r: r["msg_id"])
        else:
            rows = c.execute(sql, params).fetchall()
        result = []
        for row in (rows if around_msg_id else reversed(rows)):
            item = dict(row)
            profile = {
                "username": item.pop("sender_username"),
                "phone": item.pop("sender_phone"),
                "display_name": item.pop("sender_display_name"),
                "title": item.pop("sender_title"),
            }
            if any(profile.values()):
                item["sender_label"] = participant_label(item["sender_id"], profile)
            else:
                item["sender_label"] = None
            # Existing messages need no migration: resolve the archived account at read time.
            if item["out"] and account and (not item["sender_id"] or item["sender_id"] == account["tg_user_id"]):
                item["sender_label"] = ("@" + account["username"].lstrip("@") if account["username"]
                                        else account["name"] or account["phone"] or "Аккаунт")
            result.append(item)
        return result


@app.get("/api/search")
def api_search(q: str, account_id: int = 0):
    q = q.replace("\x00", "").strip()   # NUL cannot be part of an FTS5 string
    if not 2 <= len(q) <= 200 or account_id < 0:
        return JSONResponse({"ok": False, "reason": "запрос должен быть длиной 2–200 символов"}, status_code=422)
    columns = """SELECT m.account_id, m.chat_id, m.msg_id, m.date, m.out, m.text,
                    m.media_type, ch.title AS chat,
                    COALESCE(NULLIF(a.name,''),'Неизвестный аккаунт') ||
                    CASE WHEN COALESCE(a.phone,'')!='' AND a.phone!=COALESCE(a.name,'') THEN ' ('||a.phone||')'
                         WHEN COALESCE(a.username,'')!='' THEN ' (@'||a.username||')' ELSE '' END AS account """
    joins = """JOIN chats ch ON ch.account_id = m.account_id AND ch.chat_id = m.chat_id
             JOIN accounts a ON a.id = m.account_id """
    # The trigram index needs at least three characters. Indexed results are
    # confirmed by contains_fold, which ignores case for Cyrillic too. Short queries
    # and searches before the existing archive is indexed keep the previous LIKE scan
    # (letter case ignored for Latin only), which is faster than a Python check per row.
    if SEARCH_INDEX["ready"] and len(q) >= 3:
        expression = search_index_query(q)
        with db() as c:
            hits = c.execute("SELECT COUNT(*) FROM (SELECT 1 FROM messages_fts WHERE messages_fts MATCH ? LIMIT ?)",
                             (expression, SEARCH_HITS_FIRST_LIMIT + 1)).fetchone()[0]
        if hits <= SEARCH_HITS_FIRST_LIMIT:
            # Rare text: read the few candidate rows directly.
            sql = ("WITH hits(rid) AS MATERIALIZED (SELECT rowid FROM messages_fts WHERE messages_fts MATCH ?) "
                   + columns + "FROM hits CROSS JOIN messages m ON m.rowid = hits.rid " + joins
                   + "WHERE contains_fold(m.text, ?) ")
        else:
            # Frequent text: walk newest messages and stop after the page is full.
            sql = (columns + "FROM messages m " + joins
                   + "WHERE +m.rowid IN (SELECT rowid FROM messages_fts WHERE messages_fts MATCH ?) "
                   + "AND contains_fold(m.text, ?) ")
        params = [expression, q]
    else:
        literal = q.replace("!", "!!").replace("%", "!%").replace("_", "!_")
        sql = columns + "FROM messages m " + joins + "WHERE m.text LIKE ? ESCAPE '!' "
        params = [f"%{literal}%"]
    if account_id:
        sql += "AND m.account_id = ? "
        params.append(account_id)
    sql += "ORDER BY m.date DESC LIMIT 50"
    with db() as c:
        return [dict(r) for r in c.execute(sql, params).fetchall()]


async def startup_media_maintenance():
    """Startup repairs of the media archive, after the panel and ingestion are up.

    Each pass reads without a write lock and changes only the matching rows through
    the shared writer, so the panel, live receipts and history keep working while
    a large archive is checked. Attachment downloads start afterwards: only they
    touch the media files these passes move, so the two never race.
    """
    loop = asyncio.get_running_loop()

    def write(func, *args):
        return asyncio.run_coroutine_threadsafe(write_call(func, *args, _write_priority=2), loop).result()

    STARTUP_MAINTENANCE["state"] = "running"
    started = time.monotonic()
    workers_started = False

    def start_downloads():
        # Downloads no longer wait for the whole check (35–100 minutes on a large archive):
        # the steps that move or adopt files skip every message being downloaded right now.
        nonlocal workers_started
        if not workers_started and not MAINTENANCE_STOP.is_set():
            workers_started = True
            ARCHIVE_WORKERS.extend(asyncio.create_task(archive_job_worker())
                                   for _ in range(MAX_CONCURRENT_MEDIA_DOWNLOADS))

    try:
        for step, run in (
                ("service-chat", lambda: write_call(remove_service_chat, _write_priority=2)),
                ("downloads", None),
                ("interrupted-downloads", None),
                # Существующие пути обновляем до запуска загрузчиков, чтобы файлы не дублировались.
                ("media-paths", lambda: thread_call(migrate_media_paths, None, None, write)),
                ("chat-folders", lambda: thread_call(ensure_known_chat_dirs)),
                # Link legacy temporary downloads to their message records.
                ("partial-files", lambda: thread_call(recover_orphaned_media_parts, write)),
                ("missing-files", lambda: thread_call(recover_missing_media_jobs, write))):
            if MAINTENANCE_STOP.is_set():
                return
            STARTUP_MAINTENANCE["step"] = step
            if step == "downloads":
                start_downloads()
            elif run is None:
                keys = await thread_call(startup_media_keys)
                # A download started in this run is not an interrupted one.
                keys["messages"] = [key for key in keys["messages"] if key not in ARCHIVE_BUSY]
                await write_call(mark_downloads_interrupted, keys, _write_priority=2)
                photo_retries = await write_call(retry_photo_jobs, keys["photos"], _write_priority=2)
                if photo_retries:
                    print(f"[photo-variants] queued {photo_retries} existing size mismatches for verification")
            else:
                await run()
        STARTUP_MAINTENANCE["state"] = "done"
        print(f"[startup] media checks finished in {time.monotonic() - started:.0f}s")
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        # Ingestion is unaffected; files still get their normal per-job checks.
        STARTUP_MAINTENANCE["state"] = "error"
        print(f"[startup] media checks stopped at {STARTUP_MAINTENANCE['step']}: {type(exc).__name__}: {exc}")
    finally:
        STARTUP_MAINTENANCE["step"] = None
        start_downloads()


async def on_startup():
    acquire_archive_lock()
    init_db()
    MAINTENANCE_STOP.clear()
    with db() as c:
        # линковки, оборвавшиеся с прошлым прогоном панели, — убираем с сессиями
        pending = c.execute("SELECT id FROM accounts WHERE status='linking'").fetchall()
        for r in pending:
            (SESSIONS / f"account_{r['id']}.session").unlink(missing_ok=True)
            c.execute("DELETE FROM participants WHERE account_id=?", (r["id"],))
        c.execute("DELETE FROM accounts WHERE status='linking'")
    restore_cached_identities()
    try:
        await write_call(replay_ingest_spool)
    except Exception as exc:
        print(f"[ingest-replay] startup deferred: {exc}")
    # The panel, live receipts and history start now; whole-archive media checks
    # run in the background instead of keeping a large archive offline for hours.
    ARCHIVE_WORKERS.append(asyncio.create_task(startup_media_maintenance()))
    ARCHIVE_WORKERS.append(asyncio.create_task(media_dedupe_worker()))
    ARCHIVE_WORKERS.append(asyncio.create_task(ingest_maintenance()))
    if SEARCH_INDEX["available"]:
        ARCHIVE_WORKERS.append(asyncio.create_task(search_index_worker()))
    # поднимаем записыватели всех активных аккаунтов (спящие и отключённые не трогаем)
    with db() as c:
        ids = [r["id"] for r in c.execute(
            "SELECT id FROM accounts WHERE status NOT IN ('paused','disconnected','linking')"
        ).fetchall()]
    for account_id in ids:
        start_recorder(account_id)
    print(f"TG Monitor: http://{HOST}:{PORT}  |  аккаунтов поднято: {len(ids)}")


async def on_shutdown():
    MAINTENANCE_STOP.set()   # long startup passes return at their next file or SQL step
    # Cancel transfers before closing sessions so partial downloads keep their SQL paths.
    tasks = set(ARCHIVE_WORKERS) | {state["task"] for collection in (REC, BACKFILL) for state in collection.values()
             if state.get("task") and not state["task"].done()}
    tasks.update(flow[key] for collection in (FLOWS, PHONE_FLOWS) for flow in collection.values()
                 for key in ("task", "expiry_task", "request_task")
                 if flow.get(key) and flow[key] is not asyncio.current_task() and not flow[key].done())
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    ARCHIVE_WORKERS.clear()
    clients = set(CLIENTS.values())
    clients.update(flow["client"] for collection in (FLOWS, PHONE_FLOWS)
                   for flow in collection.values() if flow.get("client"))
    for client in clients:
        try:
            await client.disconnect()
        except Exception:
            pass
        finally:
            try:
                client.session.close()
            except Exception:
                pass
    await stop_ingest()
    with db() as c:
        c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    release_archive_lock()


if __name__ == "__main__":
    uvicorn.run(app, host=HOST, port=PORT, log_level="warning")

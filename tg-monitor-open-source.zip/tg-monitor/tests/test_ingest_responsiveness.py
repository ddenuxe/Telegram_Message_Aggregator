"""Real SQLite contention and bounded history work on disposable archives."""
import asyncio
from contextlib import contextmanager
import sqlite3
from pathlib import Path
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import test_reliable_ingest


class IngestResponsivenessTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message
    rows = test_reliable_ingest.ReliableIngestTests.rows

    async def test_pause_keeps_event_loop_responsive_while_sqlite_writer_is_busy(self):
        locked = threading.Event()
        def hold_writer():
            with self.app.db() as c:
                c.execute('BEGIN IMMEDIATE')
                locked.set()
                time.sleep(0.4)
        holder = asyncio.create_task(asyncio.to_thread(hold_writer))
        await asyncio.to_thread(locked.wait, 5)
        start = time.perf_counter()
        pause = asyncio.create_task(self.app.api_pause(1))
        await asyncio.sleep(0.03)
        latency = time.perf_counter() - start
        await pause
        await holder
        print(f'pause heartbeat latency: {latency * 1000:.1f} ms')
        self.assertLess(latency, 0.2, f'event loop blocked for {latency:.3f}s')
        self.assertEqual(self.rows('accounts')[0]['status'], 'paused')

    def history_client(self, messages, requests):
        dialog = SimpleNamespace(id=100, entity=None, name='Test chat')
        class Client:
            async def connect(self): pass
            async def is_user_authorized(self): return True
            def iter_dialogs(self):
                async def items(): yield dialog
                return items()
            def iter_messages(self, *args, **kwargs):
                requests.append(kwargs)
                async def items():
                    offset = kwargs.get('offset_id', 0)
                    items = messages if kwargs.get('reverse') else reversed(messages)
                    for msg in items:
                        if not offset or (msg.id > offset if kwargs.get('reverse') else msg.id < offset):
                            yield msg
                return items()
        return Client()

    async def test_first_history_pass_does_not_read_and_write_every_message_twice(self):
        a = self.app
        requests = []
        a.CLIENTS[1] = self.history_client([self.message(i) for i in range(1, 62)], requests)
        a.should_scan_dialog = lambda _: True
        transactions = []
        original = a.db
        @contextmanager
        def traced_db(*args, **kwargs):
            with original(*args, **kwargs) as c:
                dirty = False
                def trace(sql):
                    nonlocal dirty
                    if sql.lstrip().startswith(('INSERT','UPDATE','DELETE')):
                        dirty = True
                    elif sql == 'COMMIT':
                        if dirty:transactions.append(sql)
                        dirty = False
                # Directory cache snapshots also commit read transactions;
                # only write commits matter for checkpoint batching.
                c.set_trace_callback(trace)
                yield c
                c.set_trace_callback(None)
        with patch.object(a, 'db', traced_db):
            state = {}
            await a._run_backfill_inner(1, state)
        self.assertEqual(state['state'], 'done')
        self.assertEqual(len(self.rows()), 61)
        print(f'61-message initial history: {len(requests)} scans, {len(transactions)} commits')
        self.assertEqual(len(requests), 1, 'first full ascending pass already covered the entire history')
        self.assertLessEqual(len(transactions), 5, 'checkpoint must share the message transaction')
        chat = self.rows('chats')[0]
        self.assertEqual((chat['history_cursor'], chat['min_msg_id'], chat['deep_done']), (61, 1, 1))

    async def test_history_metadata_writes_do_not_block_the_event_loop(self):
        a = self.app
        requests = []
        a.CLIENTS[1] = self.history_client([], requests)
        a.should_scan_dialog = lambda _: True
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type,deep_done) VALUES(1,100,'Old','user',1)")
        original = a.db
        @contextmanager
        def slow_db(*args, **kwargs):
            time.sleep(0.12)  # disk open/read/commit latency applies to real backfill SQL
            with original(*args, **kwargs) as c:
                yield c
        with patch.object(a, 'db', slow_db):
            start = time.perf_counter()
            task = asyncio.create_task(a._run_backfill_inner(1, {}))
            await asyncio.sleep(0.03)
            latency = time.perf_counter() - start
            await task
        self.assertLess(latency, 0.2, f'event loop blocked for {latency:.3f}s')
        print(f'history heartbeat latency under slow SQL: {latency * 1000:.1f} ms')

    async def test_failed_checkpoint_rolls_back_messages_and_follow_up_jobs(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,100,'Test','user')")
            c.execute("CREATE TRIGGER reject_cursor BEFORE UPDATE OF history_cursor ON chats "
                      "BEGIN SELECT RAISE(ABORT,'checkpoint failure'); END")
        with self.assertRaises(sqlite3.IntegrityError):
            await a.store_history_batch(1, [self.message(1, media=True)], 100, 'Test', 'user', {},
                                        (1, 100, 'forward', 1))
        self.assertEqual(self.rows(), [])
        self.assertEqual(self.rows('archive_jobs'), [])
        self.assertEqual(self.rows('chats')[0]['history_cursor'], 0)

    async def test_restart_after_committed_page_recovers_remaining_and_older_history(self):
        a = self.app
        messages = [self.message(i) for i in range(1, 62)]
        await a.store_history_batch(1, messages[:25], 100, 'Test', 'user', {}, (1, 100, 'forward', 25))
        requests = []
        a.CLIENTS[1] = self.history_client(messages, requests)
        a.should_scan_dialog = lambda _: True
        state = {}
        await a._run_backfill_inner(1, state)
        self.assertEqual(state['state'], 'done')
        self.assertEqual(sorted(r['msg_id'] for r in self.rows()), list(range(1, 62)))
        chat = self.rows('chats')[0]
        self.assertEqual((chat['history_cursor'], chat['min_msg_id'], chat['deep_done']), (61, 1, 1))
        self.assertEqual(requests[0]['offset_id'], 25)
        self.assertTrue(any(not r.get('reverse') for r in requests))

    async def test_single_chat_migration_does_not_scan_the_whole_media_tree_or_read_other_chats(self):
        a = self.app
        with a.db() as c:
            c.executemany("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,?,'Test','user')", [(100,), (101,)])
            c.execute("INSERT INTO messages(account_id,chat_id,msg_id,file_path) VALUES(1,101,1,'media/other.bin')")
        queries = []
        original = a.db
        @contextmanager
        def traced_db(*args, **kwargs):
            with original(*args, **kwargs) as c:
                c.set_trace_callback(queries.append)
                yield c
        with patch.object(a, 'db', traced_db), patch.object(Path, 'rglob', side_effect=AssertionError('whole media tree scan')):
            await asyncio.to_thread(a.migrate_media_paths, 1, 100)
        selects = [q for q in queries if 'AS source_table' in q]
        self.assertEqual(len(selects), 2)
        self.assertTrue(all('m.chat_id=100' in q for q in selects), selects)

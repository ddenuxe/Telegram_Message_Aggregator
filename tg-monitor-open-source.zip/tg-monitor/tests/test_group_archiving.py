"""Group author and media behavior, isolated from the user's live archive."""
import asyncio
import importlib.util
import shutil
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace


SOURCE = Path(__file__).resolve().parents[1]


class GroupArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-monitor-groups-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            "\n[server]\nhost=127.0.0.1\nport=18096\n", encoding="utf-8")
        spec = importlib.util.spec_from_file_location("tg_monitor_group_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()
        with self.app.db() as c:
            c.execute("INSERT INTO accounts(id,username) VALUES(1,'archive')")

    def tearDown(self):
        self.temp.cleanup()

    def test_scanner_includes_megagroups_but_excludes_broadcast_channels_and_bots(self):
        a = self.app
        mega = SimpleNamespace(id=10, is_user=False, is_group=True,
                               entity=SimpleNamespace(bot=False))
        classic = SimpleNamespace(id=11, is_user=False, is_group=True,
                                  entity=SimpleNamespace(bot=False))
        channel = SimpleNamespace(id=12, is_user=False, is_group=False,
                                  entity=SimpleNamespace(bot=False))
        bot = SimpleNamespace(id=13, is_user=True, is_group=False,
                              entity=SimpleNamespace(bot=True))
        service = SimpleNamespace(id=a.SERVICE_CHAT, is_user=True, is_group=False,
                                  entity=SimpleNamespace(bot=False))
        self.assertTrue(a.should_scan_dialog(mega))
        self.assertTrue(a.should_scan_dialog(classic))
        self.assertFalse(a.should_scan_dialog(channel))
        self.assertFalse(a.should_scan_dialog(bot))
        self.assertFalse(a.should_scan_dialog(service))

    def test_history_iterator_times_out_when_telegram_never_returns_a_page(self):
        a = self.app
        a.BACKFILL_FETCH_TIMEOUT = 0.01

        class Client:
            def iter_messages(self, *_args, **_kwargs):
                async def messages():
                    await asyncio.Event().wait()
                    yield None
                return messages()

        async def check_timeout():
            iterator = a.iter_messages_with_timeout(Client(), 123)
            with self.assertRaises(asyncio.TimeoutError):
                await anext(iterator)
            await iterator.aclose()

        asyncio.run(check_timeout())

    def test_group_media_name_contains_date_author_and_unique_message_id(self):
        msg = SimpleNamespace(id=42, date=datetime(2026, 10, 2, 18, 45, tzinfo=timezone.utc))
        stamp = msg.date.astimezone().strftime("%Y-%m-%d %H-%M")
        self.assertEqual(
            self.app.media_file_name(msg, ".jpg", "group", 77, "alice"),
            f"{stamp} [@alice]",
        )
        self.assertIn("[user-77]", self.app.media_file_name(msg, ".jpg", "group", 77, None))
        self.assertEqual(self.app.media_file_name(msg, ".jpg"),
                         msg.date.astimezone().strftime("%d-%m-%Y %H-%M") + " (jpg)")

    def test_author_profile_is_normalized_once_and_returned_with_group_messages(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,10,'Group','group')")
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,sender_id,out,text)
                         VALUES(1,10,100,77,0,'hello')""")
        user = SimpleNamespace(username="alice", phone=None, first_name="Alice",
                               last_name="Example", title=None)
        a._save_participant(1, 77, user)

        rows = a.api_messages(1, 10)

        self.assertEqual(rows[0]["sender_id"], 77)
        self.assertEqual(rows[0]["sender_label"], "Alice Example (@alice)")
        self.assertEqual(rows[0]["chat_type"], "group")

    def test_lazy_sender_lookup_is_cached_after_first_message(self):
        a = self.app

        class LazyMessage:
            sender_id = 88
            sender = None
            calls = 0

            async def get_sender(self):
                self.calls += 1
                return SimpleNamespace(username="bob", phone=None, first_name="Bob",
                                       last_name=None, title=None)

        msg = LazyMessage()
        asyncio.run(a.cache_message_sender(object(), 1, msg))
        asyncio.run(a.cache_message_sender(object(), 1, msg))
        self.assertEqual(msg.calls, 1)
        with a.db() as c:
            row = c.execute("SELECT username FROM participants WHERE account_id=1 AND user_id=88").fetchone()
        self.assertEqual(row[0], "bob")

    def test_hydrates_profiles_for_old_messages_that_are_already_archived(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,10,'Group','group')")
            c.executemany("""INSERT INTO messages(account_id,chat_id,msg_id,sender_id,out)
                             VALUES(1,10,?,?,0)""", [(100, 77), (101, 77)])

        class MissingMessage:
            sender_id = 77
            sender = None

            async def get_sender(self):
                raise ValueError("not embedded in this message")

        asyncio.run(a.cache_message_sender(object(), 1, MissingMessage()))

        class Client:
            calls = []

            async def get_entity(self, sender_id):
                self.calls.append(sender_id)
                return SimpleNamespace(username="alice", phone=None, first_name="Alice",
                                       last_name=None, title=None)

        client = Client()
        asyncio.run(a.hydrate_chat_participants(client, 1, 10))
        self.assertEqual(client.calls, [77])
        with a.db() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM participants").fetchone()[0], 1)

    def test_group_media_download_is_linked_to_author_and_message_in_database(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,10,'Group','group')")

        class Message:
            id = 102
            sender_id = 77
            out = False
            action = None
            message = "picture"
            entities = []
            date = datetime(2026, 10, 2, 18, 45, tzinfo=timezone.utc)
            voice = video = audio = document = False
            photo = True
            sender = SimpleNamespace(username="alice", phone=None, first_name="Alice",
                                     last_name=None, title=None)
            file = SimpleNamespace(size=3, ext=".jpg", name=None)

            async def download_media(self, file):
                Path(file).write_bytes(b"img")
                return file

        asyncio.run(a.store_message(object(), 1, Message(), 10, "Group", "group"))

        with a.db() as c:
            row = c.execute("SELECT sender_id,file_path FROM messages WHERE account_id=1 AND chat_id=10 AND msg_id=102").fetchone()
        self.assertEqual(row["sender_id"], 77)
        self.assertIn("[@alice] [102].jpg", row["file_path"])
        self.assertTrue((self.root / row["file_path"]).is_file())

    def test_startup_path_migration_repairs_duplicate_message_id_suffix(self):
        a = self.app
        old_path = "media/@archive/Group/2026-10-02 19-45 [@alice] [102] [102].jpg"
        old_file = self.root / old_path
        old_file.parent.mkdir(parents=True)
        old_file.write_bytes(b"img")
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,10,'Group','group')")
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,file_path)
                         VALUES(1,10,102,?)""", (old_path,))

        a.migrate_media_paths()

        with a.db() as c:
            new_path = c.execute("SELECT file_path FROM messages WHERE msg_id=102").fetchone()[0]
        self.assertEqual(new_path, "media/@archive/Group/2026-10-02 19-45 [@alice] [102].jpg")
        self.assertTrue((self.root / new_path).is_file())
        self.assertFalse(old_file.exists())

    def test_incomplete_media_resets_the_chat_scan_cursor(self):
        a = self.app
        relative = "media/@archive/Chat/voice.ogg"
        path = self.root / relative
        path.parent.mkdir(parents=True)
        path.write_bytes(b"cut")
        with a.db() as c:
            c.execute("""INSERT INTO chats(account_id,chat_id,title,type,min_msg_id,deep_done)
                         VALUES(1,10,'Chat','user',25,1)""")
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,media_type,
                         file_path,file_size) VALUES(1,10,25,'voice',?,6)""", (relative,))

        self.assertEqual(a.reset_incomplete_media_chats(), 1)
        with a.db() as c:
            row = c.execute("SELECT min_msg_id,deep_done FROM chats WHERE account_id=1 AND chat_id=10").fetchone()
        self.assertEqual(tuple(row), (0, 0))

    def test_truncated_existing_media_is_replaced_and_size_verified(self):
        a = self.app
        relative = "media/@archive/Chat/legacy.ogg"
        path = self.root / relative
        path.parent.mkdir(parents=True)
        path.write_bytes(b"bad")
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,10,'Chat','user')")
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,media_type,file_path,file_size)
                         VALUES(1,10,25,'voice',?,6)""", (relative,))

        class Message:
            id = 25
            sender_id = None
            out = False
            action = None
            message = ""
            entities = []
            date = datetime(2026, 10, 2, 18, 45, tzinfo=timezone.utc)
            voice = True
            video = photo = audio = document = False
            sender = None
            file = SimpleNamespace(size=6, ext=".ogg", name=None)

            async def download_media(self, file):
                Path(file).write_bytes(b"fixed!")
                return file

        asyncio.run(a.store_message(object(), 1, Message(), 10, "Chat", "user"))
        self.assertEqual(path.read_bytes(), b"fixed!")
        with a.db() as c:
            row = c.execute("SELECT file_path,file_size FROM messages WHERE account_id=1 AND chat_id=10 AND msg_id=25").fetchone()
        self.assertEqual(tuple(row), (relative, 6))


if __name__ == "__main__":
    unittest.main()

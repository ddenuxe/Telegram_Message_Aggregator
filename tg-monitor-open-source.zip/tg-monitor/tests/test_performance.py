"""Performance regressions with disposable data; never opens the live archive."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import threading
import time
import unittest
from unittest.mock import patch
import test_reliable_ingest


class PerformanceTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    async def test_chat_preview_uses_ordered_index(self):
        with self.app.db() as c:
            plan = ' '.join(str(tuple(r)) for r in c.execute(
                'EXPLAIN QUERY PLAN SELECT text FROM messages WHERE account_id=1 '
                'AND chat_id=100 ORDER BY date DESC,msg_id DESC LIMIT 1'))
        self.assertNotIn('TEMP B-TREE', plan)

    async def test_accounts_last_date_uses_covering_index(self):
        with self.app.db() as c:
            plan = ' '.join(str(tuple(r)) for r in c.execute(
                'EXPLAIN QUERY PLAN SELECT MAX(date) FROM messages WHERE account_id=1'))
        self.assertIn('COVERING INDEX idx_msg_account_date', plan)

    async def test_concurrent_storage_requests_scan_once_and_never_wait(self):
        gate = threading.Barrier(5)
        calls = []
        def scan(root):
            calls.append(root)
            time.sleep(0.5)  # a slow first recount must not hold the panel's request threads
            return 123
        def request():
            gate.wait(timeout=5)
            started = time.monotonic()
            return self.app.api_storage(), time.monotonic() - started
        with patch.object(self.app, '_directory_bytes', scan):
            with ThreadPoolExecutor(max_workers=5) as pool:
                results = await asyncio.to_thread(lambda: list(pool.map(lambda _: request(), range(5))))
            self.assertTrue(all(took < 0.3 for _, took in results), [took for _, took in results])
            self.assertTrue(all(r['scanning'] and r['archive_bytes'] is None for r, _ in results))
            # The database is a few files: its size is there before the media count ends.
            self.assertTrue(all(r['database_bytes'] > 0 for r, _ in results))
            await asyncio.to_thread(lambda: self.app._storage_scan_lock.acquire(timeout=10)
                                    and self.app._storage_scan_lock.release())
        self.assertEqual(len(calls), 1)  # only the media folder, independent of caller count
        counted = self.app.api_storage()
        self.assertFalse(counted['scanning'])
        self.assertEqual(counted['media_bytes'], 123)

    async def test_media_size_is_known_right_after_a_restart(self):
        with patch.object(self.app, '_directory_bytes', lambda root: 4567):
            self.app.refresh_storage_snapshot()
        saved = self.app.STORAGE_SNAPSHOT_PATH
        self.assertTrue(saved.is_file())
        # A new process reads the last count instead of showing blanks for the whole recount.
        spec = importlib.util.spec_from_file_location('restarted_app', self.root / 'app.py')
        restarted = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(restarted)
        gate = threading.Event()
        def slow_scan(root):
            gate.wait(timeout=5)
            return 9999
        with patch.object(restarted, '_directory_bytes', slow_scan):
            report = restarted.api_storage()
            gate.set()
            await asyncio.to_thread(lambda: restarted._storage_scan_lock.acquire(timeout=10)
                                    and restarted._storage_scan_lock.release())
        self.assertTrue(report['scanning'])
        self.assertEqual(report['media_bytes'], 4567)
        self.assertEqual(report['archive_bytes'], report['database_bytes'] + report['database_backups_bytes']
                         + report['sessions_bytes'] + 4567)
        self.assertEqual(restarted.api_storage()['media_bytes'], 9999)

    async def test_archive_poll_does_not_acquire_sqlite_writer(self):
        class Client:
            def is_connected(self): return True
        self.app.CLIENTS[1] = Client()
        with self.app.db() as writer:
            writer.execute('BEGIN IMMEDIATE')
            # An idle media poll must coexist with a recording transaction.
            result = await asyncio.to_thread(self.app.next_archive_job)
        self.assertIsNone(result)

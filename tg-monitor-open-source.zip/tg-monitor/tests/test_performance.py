"""Performance regressions with disposable data; never opens the live archive."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
import threading
import time
import unittest
from unittest.mock import patch
import test_reliable_ingest


class PerformanceTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    async def test_chat_preview_uses_ordered_index(self):
        with self.app.db() as c:
            plan = ' '.join(str(tuple(r)) for r in c.execute(
                'EXPLAIN QUERY PLAN SELECT text FROM messages WHERE account_id=1 '
                'AND chat_id=100 ORDER BY date DESC,msg_id DESC LIMIT 1'))
        self.assertNotIn('TEMP B-TREE', plan)

    async def test_accounts_last_date_uses_covering_index(self):
        with self.app.db() as c:
            plan = ' '.join(str(tuple(r)) for r in c.execute(
                'EXPLAIN QUERY PLAN SELECT MAX(date) FROM messages WHERE account_id=1'))
        self.assertIn('COVERING INDEX idx_msg_account_date', plan)

    async def test_concurrent_storage_requests_scan_once(self):
        gate = threading.Barrier(5)
        calls = []
        def scan(root):
            calls.append(root)
            time.sleep(0.04)
            return 123
        def request():
            gate.wait(timeout=5)
            return self.app.api_storage()
        with patch.object(self.app, '_directory_bytes', scan):
            with ThreadPoolExecutor(max_workers=5) as pool:
                results = await asyncio.to_thread(lambda: list(pool.map(lambda _: request(), range(5))))
        self.assertEqual(len(calls), 2)  # media + sessions, independent of caller count
        self.assertTrue(all(r['archive_bytes'] == results[0]['archive_bytes'] for r in results))

    async def test_archive_poll_does_not_acquire_sqlite_writer(self):
        class Client:
            def is_connected(self): return True
        self.app.CLIENTS[1] = Client()
        with self.app.db() as writer:
            writer.execute('BEGIN IMMEDIATE')
            # An idle media poll must coexist with a recording transaction.
            result = await asyncio.to_thread(self.app.next_archive_job)
        self.assertIsNone(result)

"""Destructive cleanup checks run only against a temporary copy of app.py."""
import asyncio
import importlib.util
import json
import shutil
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace


SOURCE = Path(__file__).resolve().parents[1]


class RequestBody:
    def __init__(self, body):
        self.body = body

    async def json(self):
        return self.body


class CleanupTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-monitor-cleanup-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            "\n[server]\nhost=127.0.0.1\nport=18094\n", encoding="utf-8")
        spec = importlib.util.spec_from_file_location("tg_monitor_cleanup_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()
        with self.app.db() as c:
            c.executemany("INSERT INTO accounts(id,name,status) VALUES(?,?,'paused')",
                          [(1, "One"), (2, "Two"), (3, "Three")])
            c.executemany("""INSERT INTO chats(account_id,chat_id,title,max_msg_id)
                             VALUES(?,?,?,?)""",
                          [(1, 100, "Target", 50), (1, 101, "Other", 5),
                           (2, 100, "Shared", 7), (3, 300, "Unsafe", 9)])
            c.executemany("""INSERT INTO messages(account_id,chat_id,msg_id,date,file_path)
                             VALUES(?,?,?,'2026-10-01T10:00:00',?)""",
                          [(1, 100, 50, "media/only.bin"),
                           (1, 100, 49, "media/shared.bin"),
                           (1, 101, 5, "media/other.bin"),
                           (2, 100, 7, "media/shared.bin")])
            c.execute("""INSERT INTO deleted(account_id,chat_id,msg_id,date,file_path)
                         VALUES(1,100,48,'2026-09-01T10:00:00','media/trash.bin')""")
            c.executemany("""INSERT INTO participants(account_id,user_id,username)
                             VALUES(?,?,?)""", [(1, 900, "one"), (2, 901, "two")])
        for name in ("only.bin", "shared.bin", "other.bin", "trash.bin"):
            (self.root / "media" / name).write_bytes(b"fixture")
        (self.root / "sessions" / "account_1.session").write_bytes(b"fixture")

    async def asyncTearDown(self):
        self.temp.cleanup()

    async def test_full_chat_clear_keeps_other_scopes_and_blocks_old_sync(self):
        a = self.app
        preview = a.api_cleanup_full_preview("chat", 1, 100)
        self.assertEqual((preview["messages"], preview["deleted"], preview["files"]), (2, 1, 3))
        result = await a.api_cleanup_full(RequestBody({
            "scope": "chat", "account_id": 1, "chat_id": 100,
            "confirmation": "CLEAR_CHAT"}))
        self.assertEqual((result["messages"], result["deleted"], result["files"], result["protected"]),
                         (2, 1, 2, 1))
        with a.db() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages WHERE account_id=1 AND chat_id=100").fetchone()[0], 0)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM deleted WHERE account_id=1 AND chat_id=100").fetchone()[0], 0)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages WHERE account_id=1 AND chat_id=101").fetchone()[0], 1)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages WHERE account_id=2").fetchone()[0], 1)
            row = c.execute("SELECT clear_through_msg_id,deep_done FROM chats WHERE account_id=1 AND chat_id=100").fetchone()
            self.assertEqual(tuple(row), (50, 1))
        chats = a.api_cleanup_chats(1)
        self.assertEqual(next(ch["n"] for ch in chats if ch["chat_id"] == 100), 0)
        self.assertFalse((self.root / "media" / "only.bin").exists())
        self.assertFalse((self.root / "media" / "trash.bin").exists())
        self.assertTrue((self.root / "media" / "shared.bin").exists())
        self.assertTrue((self.root / "media" / "other.bin").exists())
        self.assertTrue((self.root / "sessions" / "account_1.session").exists())

        def message(msg_id):
            return SimpleNamespace(id=msg_id, action=None, voice=False, video=False,
                                   photo=False, audio=False, document=False,
                                   date=datetime.now(timezone.utc), sender_id=1,
                                   out=False, message="fixture", entities=[])
        await a.store_message(None, 1, message(49), 100, "Target", "user")
        await a.store_message(None, 1, message(51), 100, "Target", "user")
        with a.db() as c:
            ids = [r[0] for r in c.execute("SELECT msg_id FROM messages WHERE account_id=1 AND chat_id=100")]
        self.assertEqual(ids, [51])

    async def test_full_account_removal_keeps_other_account(self):
        result = await self.app.api_cleanup_full(RequestBody({
            "scope": "account", "account_id": 1, "chat_id": 0,
            "confirmation": "DELETE_ACCOUNT"}))
        self.assertEqual(result["protected"], 1)
        with self.app.db() as c:
            for table in ("accounts", "chats", "messages", "deleted", "participants", "events"):
                self.assertEqual(c.execute(f"SELECT COUNT(*) FROM {table} WHERE account_id=1" if table != "accounts"
                                           else "SELECT COUNT(*) FROM accounts WHERE id=1").fetchone()[0], 0)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM accounts WHERE id=2").fetchone()[0], 1)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages WHERE account_id=2").fetchone()[0], 1)
        self.assertFalse((self.root / "sessions" / "account_1.session").exists())
        self.assertTrue((self.root / "media" / "shared.bin").exists())

    async def test_period_delete_keeps_shared_file_and_recycle_bin(self):
        result = await self.app.api_cleanup(RequestBody({
            "account_id": 1, "chat_id": 100, "from": "2026-10-01", "to": "2026-10-01",
            "mode": "delete", "with_media": True}))
        self.assertEqual((result["deleted"], result["files"], result["protected"]), (2, 1, 1))
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages WHERE account_id=1 AND chat_id=100").fetchone()[0], 0)
            rows = c.execute("""SELECT msg_id,file_path FROM deleted
                                WHERE account_id=1 AND chat_id=100 ORDER BY msg_id""").fetchall()
            self.assertEqual([(r["msg_id"], r["file_path"]) for r in rows],
                             [(48, "media/trash.bin"), (49, "media/shared.bin"), (50, None)])
        self.assertFalse((self.root / "media" / "only.bin").exists())
        self.assertTrue((self.root / "media" / "shared.bin").exists())

    async def test_explicit_restore_can_reenable_old_chat_history(self):
        await self.app.api_cleanup_full(RequestBody({
            "scope": "chat", "account_id": 1, "chat_id": 100,
            "confirmation": "CLEAR_CHAT"}))
        started = []
        self.app.start_backfill = lambda account_id: started.append(account_id)
        result = await self.app.api_cleanup(RequestBody({
            "account_id": 1, "chat_id": 100, "mode": "restore",
            "from": "", "to": "", "with_media": False}))
        self.assertEqual(result["restored"], 0)
        self.assertTrue(result["sync_started"])
        self.assertEqual(started, [1])
        with self.app.db() as c:
            row = c.execute("""SELECT clear_through_msg_id,deep_done FROM chats
                               WHERE account_id=1 AND chat_id=100""").fetchone()
            self.assertEqual(tuple(row), (0, 0))

    async def test_wrong_scope_or_unsafe_path_aborts_without_changes(self):
        wrong_chat = self.app.api_cleanup_full_preview("chat", 1, 300)
        self.assertEqual(wrong_chat.status_code, 404)
        missing_confirmation = await self.app.api_cleanup_full(RequestBody({
            "scope": "account", "account_id": 1, "confirmation": ""}))
        self.assertEqual(missing_confirmation.status_code, 422)
        outside = self.root / "outside.bin"
        outside.write_bytes(b"keep")
        with self.app.db() as c:
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,date,file_path)
                         VALUES(3,300,9,'2026-10-01T10:00:00',?)""", (str(outside),))
        unsafe = await self.app.api_cleanup_full(RequestBody({
            "scope": "account", "account_id": 3, "chat_id": 0,
            "confirmation": "DELETE_ACCOUNT"}))
        self.assertEqual(unsafe.status_code, 409)
        period = await self.app.api_cleanup(RequestBody({
            "account_id": 3, "chat_id": 300, "from": "2026-10-01", "to": "2026-10-01",
            "mode": "delete", "with_media": True}))
        self.assertEqual(period.status_code, 409)
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM accounts WHERE id=3").fetchone()[0], 1)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages WHERE account_id=3").fetchone()[0], 1)
        self.assertTrue(outside.exists())


if __name__ == "__main__":
    unittest.main()

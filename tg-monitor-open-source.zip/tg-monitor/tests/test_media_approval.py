"""Large-media approval and global catalog checks use only a temporary database."""
import importlib.util
import shutil
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace


SOURCE = Path(__file__).resolve().parents[1]


class RequestBody:
    def __init__(self, body):
        self.body = body

    async def json(self):
        return self.body


class MediaApprovalTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-monitor-large-media-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            "\n[server]\nhost=127.0.0.1\nport=18096\n[archive]\nmax_media_mb=1024\n",
            encoding="utf-8")
        spec = importlib.util.spec_from_file_location("tg_monitor_media_approval_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()
        with self.app.db() as c:
            c.executemany("INSERT INTO accounts(id,name,username) VALUES(?,?,?)",
                          [(1, "One", "one"), (2, "Two", "two")])
            c.executemany("INSERT INTO chats(account_id,chat_id,title) VALUES(?,?,?)",
                          [(1, 10, "Z chat"), (2, 20, "A chat")])
            c.executemany("""INSERT INTO messages
                           (account_id,chat_id,msg_id,date,text,media_type,file_path,file_size)
                           VALUES(?,?,?,?,'context','document',?,?)""",
                          [(1, 10, 100, "2026-10-03T10:00:00", "media/zeta.pdf", 2**30 + 1),
                           (2, 20, 200, "2026-10-02T10:00:00", "media/alpha.pdf", 2**30 + 25)])

    async def asyncTearDown(self):
        self.temp.cleanup()

    async def test_catalog_search_filters_before_pagination_and_matches_unicode(self):
        a = self.app
        with a.db() as c:
            c.execute("UPDATE chats SET title='КуФаЙкА' WHERE account_id=1")
            c.execute("UPDATE messages SET file_path='media/Отчёт_100%.pdf' WHERE account_id=1")
        for query in ('отчёт', 'куфайка', 'ONE', '100%', '_'):
            result = a.api_media_catalog(q=query, limit=1)
            self.assertEqual(result['total'], 1, query)
            self.assertEqual(result['items'][0]['account_id'], 1)
            self.assertFalse(result['more'])
            self.assertEqual(a.api_media_catalog(q=query, limit=1, offset=1)['items'], [])
        self.assertEqual(a.api_media_catalog(q='missing')['total'], 0)
        self.assertEqual(a.api_media_catalog(q=' pdf ')['total'], 2)
        self.assertEqual(a.api_media_catalog(q='one', pending_only=True)['total'], 0)
        with a.db() as c:
            c.execute("INSERT INTO deleted(account_id,chat_id,msg_id,date,media_type,file_path) VALUES(1,10,999,'2026-10-04','document','media/deleted.zip')")
        self.assertEqual(a.api_media_catalog(q='deleted.zip')['items'][0]['record_state'], 'deleted')

    async def test_cleanup_search_keeps_account_chat_and_date_filters(self):
        a = self.app
        result = a.api_media(1, q='ZETA', from_date='2026-10-03', to_date='2026-10-03')
        self.assertEqual(result['items'][0]['file_name'], 'zeta.pdf')
        self.assertEqual(a.api_media(2, q='zeta')['items'], [])
        self.assertEqual(a.api_media(1, q='Z chat', chat_id=20)['items'], [])
        self.assertEqual(a.api_media(1, q='zeta', to_date='2026-10-02')['items'], [])
        self.assertEqual(a.api_media(1, q='%')['items'], [])

    async def test_approval_is_stored_per_message_and_removed_rows_need_approval_again(self):
        a = self.app
        telegram_message = SimpleNamespace(id=100, date=datetime(2026, 10, 3), sender_id=None,
            out=False, message="context", entities=[], file=SimpleNamespace(
                size=2**30 + 1, id=None, ext=".pdf", name="zeta.pdf"))
        class Client:
            def is_connected(self): return True
            async def get_messages(self, *_args, **_kwargs): return telegram_message
        a.CLIENTS[1] = Client()
        a.media_kind = lambda _msg: "document"
        a.render_text = lambda msg: msg.message
        async def no_sender(*_args): return None
        a.cache_message_sender = no_sender
        a.media_file_matches = lambda *_args: True
        result = await a.api_media_approval(RequestBody({
            "account_id": 1, "chat_id": 10, "msg_id": 100, "decision": "approved"}))
        self.assertEqual(result["decision"], "approved")
        with a.db() as c:
            self.assertEqual(c.execute("SELECT media_approval FROM messages WHERE account_id=1 AND msg_id=100").fetchone()[0],
                             "approved")
            c.execute("DELETE FROM messages WHERE account_id=1 AND chat_id=10 AND msg_id=100")
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,file_size,media_type)
                         VALUES(1,10,100,?, 'document')""", (2**30 + 1,))
        catalog = a.api_media_catalog()
        pending = next(item for item in catalog["items"] if item["account_id"] == 1)
        self.assertEqual(pending["approval_status"], "pending")
        self.assertEqual(catalog["pending"], 1)
        actionable = a.api_media_catalog(pending_only=True)
        self.assertEqual(actionable["total"], 1)
        self.assertEqual(actionable["items"][0]["account_id"], 1)

    async def test_approval_of_deleted_telegram_file_returns_reason_and_can_be_dismissed(self):
        a = self.app
        class Client:
            def is_connected(self): return True
            async def get_messages(self, *_args, **_kwargs): return None
        a.CLIENTS[1] = Client()
        result = await a.api_media_approval(RequestBody({
            "account_id": 1, "chat_id": 10, "msg_id": 100, "decision": "approved"}))
        self.assertEqual(result.status_code, 410)
        self.assertIn("удалён", result.body.decode("utf-8"))
        with a.db() as c:
            row = c.execute("SELECT media_approval,media_status FROM messages WHERE account_id=1 AND msg_id=100").fetchone()
        self.assertEqual(tuple(row), (None, "unavailable"))
        self.assertEqual(a.api_pending_media_count()["pending"], 0)
        dismissed = await a.api_media_dismiss(RequestBody({
            "account_id": 1, "chat_id": 10, "msg_id": 100, "source": "messages"}))
        self.assertTrue(dismissed["ok"])
        self.assertEqual(a.api_pending_media_count()["pending"], 0)
        self.assertEqual(a.api_media_catalog()["total"], 1)

    async def test_global_catalog_sorting_and_message_context(self):
        a = self.app
        by_name = a.api_media_catalog(sort="name", direction="asc")
        self.assertEqual([item["chat_title"] for item in by_name["items"]], ["A chat", "Z chat"])
        by_name_desc = a.api_media_catalog(sort="name", direction="desc")
        self.assertEqual([item["chat_title"] for item in by_name_desc["items"]], ["Z chat", "A chat"])
        by_date = a.api_media_catalog(sort="date", direction="asc")
        self.assertLess(by_date["items"][0]["date"], by_date["items"][1]["date"])
        by_size = a.api_media_catalog(sort="size", direction="desc")
        self.assertGreater(by_size["items"][0]["file_size"], by_size["items"][1]["file_size"])
        context = a.api_messages(account_id=1, chat_id=10, around_msg_id=100)
        self.assertEqual([item["msg_id"] for item in context], [100])

    async def test_reject_stops_auto_download_and_removes_pending_badge(self):
        a = self.app
        result = await a.api_media_approval(RequestBody({
            "account_id": 1, "chat_id": 10, "msg_id": 100, "decision": "rejected"}))
        self.assertEqual(result["decision"], "rejected")
        self.assertEqual(a.api_pending_media_count()["pending"], 0)
        with a.db() as c:
            self.assertEqual(c.execute("SELECT media_approval FROM messages WHERE account_id=1 AND msg_id=100").fetchone()[0],
                             "rejected")

    async def test_files_above_one_gib_require_approval_even_if_general_limit_is_higher(self):
        a = self.app
        a.LARGE_MEDIA_APPROVAL_BYTES = 100
        a.MAX_MB = 2
        async def no_sender(client, account_id, msg):
            return None
        a.cache_message_sender = no_sender
        a.media_kind = lambda msg: "document"
        a.media_file_name = lambda *args: "large-file"
        a.render_text = lambda msg: msg.message
        a.ensure_chat_dir = lambda *args: None

        class FileMessage:
            id = 300
            date = datetime(2026, 10, 3)
            sender_id = None
            out = False
            message = "large attachment"
            entities = []
            file = SimpleNamespace(size=101, ext=".bin", name="large.bin", id=701)
            downloads = 0

            async def download_media(self, file):
                self.downloads += 1
                Path(file).write_bytes(b"x" * self.file.size)
                return file

        msg = FileMessage()
        class ApprovalClient:
            def is_connected(self): return True
            async def get_messages(self, *_args, **_kwargs): return msg
        a.CLIENTS[3] = ApprovalClient()
        with a.db() as c:
            c.execute("INSERT INTO accounts(id,name) VALUES(3,'Three')")
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(3,30,'Large','user')")
        await a.store_message(None, 3, msg, 30, "Large", "user")
        self.assertEqual(msg.downloads, 0)
        with a.db() as c:
            row = c.execute("SELECT file_path,media_approval FROM messages WHERE account_id=3").fetchone()
        self.assertEqual(tuple(row), (None, "pending"))
        await a.api_media_approval(RequestBody({
            "account_id": 3, "chat_id": 30, "msg_id": 300, "decision": "approved"}))
        await a.store_message(None, 3, msg, 30, "Large", "user")
        self.assertEqual(msg.downloads, 1)
        with a.db() as c:
            row = c.execute("SELECT file_path,media_approval FROM messages WHERE account_id=3").fetchone()
        self.assertTrue(row["file_path"])
        self.assertEqual(row["media_approval"], "approved")
        saved_path = self.root / row["file_path"]
        msg.file = SimpleNamespace(size=101, ext=".bin", name="changed.bin", id=702)
        await a.store_message(None, 3, msg, 30, "Large", "user")
        self.assertEqual(msg.downloads, 1)
        self.assertFalse(saved_path.exists())
        with a.db() as c:
            row = c.execute("SELECT file_path,media_approval,media_id FROM messages WHERE account_id=3").fetchone()
        self.assertEqual(tuple(row), (None, "pending", 702))

    async def test_large_pending_media_metadata_can_be_deleted_without_file_path(self):
        a = self.app
        result = await a.api_media_delete(RequestBody({
            "account_id": 1, "items": [{"chat_id": 10, "msg_id": 100}]}))
        self.assertEqual(result["detached"], 1)
        with a.db() as c:
            row = c.execute("SELECT text,media_type,file_size,media_approval FROM messages WHERE account_id=1 AND msg_id=100").fetchone()
        self.assertEqual(tuple(row), ("context", None, None, None))

    async def test_catalog_includes_and_can_remove_media_from_recycle_bin(self):
        a = self.app
        with a.db() as c:
            c.execute("""INSERT INTO deleted(account_id,chat_id,msg_id,text,media_type,file_size)
                         VALUES(1,10,99,'old text','document',?)""", (2**30 + 5,))
        catalog = a.api_media_catalog(sort="date", direction="desc")
        deleted = next(item for item in catalog["items"] if item["record_state"] == "deleted")
        self.assertEqual(deleted["msg_id"], 99)
        result = await a.api_media_delete(RequestBody({
            "account_id": 1, "items": [{"chat_id": 10, "msg_id": 99, "source": "deleted"}]}))
        self.assertEqual(result["detached"], 1)
        with a.db() as c:
            row = c.execute("SELECT text,media_type,file_size FROM deleted WHERE account_id=1 AND msg_id=99").fetchone()
        self.assertEqual(tuple(row), ("old text", None, None))

    async def test_old_sqlite_schema_migrates_both_message_tables(self):
        a = self.app
        with a.db() as c:
            c.execute("ALTER TABLE messages DROP COLUMN media_approval")
            c.execute("ALTER TABLE deleted DROP COLUMN media_approval")
            c.execute("ALTER TABLE messages DROP COLUMN media_id")
            c.execute("ALTER TABLE deleted DROP COLUMN media_id")
        a.init_db()
        with a.db() as c:
            for table in ("messages", "deleted"):
                columns = {row[1] for row in c.execute(f"PRAGMA table_info({table})")}
                self.assertIn("media_approval", columns)
                self.assertIn("media_id", columns)

    async def test_deleted_and_reloaded_interval_requires_approval_again(self):
        a = self.app
        with a.db() as c:
            c.execute("""INSERT INTO messages
                         (account_id,chat_id,msg_id,date,text,media_type,file_size,media_approval)
                         VALUES(1,10,101,'2026-10-03T10:00:00','large','document',?,'approved')""",
                      (2**30 + 1,))
        deleted = await a.api_cleanup(RequestBody({
            "account_id": 1, "chat_id": 10, "from": "2026-10-03", "to": "2026-10-03",
            "mode": "delete", "with_media": True}))
        self.assertEqual(deleted["deleted"], 2)
        with a.db() as c:
            self.assertIsNone(c.execute("SELECT media_approval FROM deleted WHERE msg_id=101").fetchone()[0])
        a.start_backfill = lambda account_id: None
        restored = await a.api_cleanup(RequestBody({
            "account_id": 1, "chat_id": 10, "from": "2026-10-03", "to": "2026-10-03",
            "mode": "restore", "with_media": False}))
        self.assertEqual(restored["restored"], 2)
        with a.db() as c:
            self.assertIsNone(c.execute("SELECT media_approval FROM messages WHERE msg_id=101").fetchone()[0])
        catalog = a.api_media_catalog()
        restored_item = next(item for item in catalog["items"] if item["msg_id"] == 101)
        self.assertEqual(restored_item["approval_status"], "pending")


if __name__ == "__main__":
    unittest.main()

"""The panel and ingestion start before whole-archive media checks; no archive scans on the event loop."""
import asyncio
import importlib.util
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

SOURCE = Path(__file__).resolve().parents[1]


class FastStartupTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-fast-startup-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 + "\n", encoding="utf-8")
        spec = importlib.util.spec_from_file_location("fast_startup_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()
        self.app.BACKGROUND_LOAD.wait_turn = AsyncMock()
        with self.app.db() as c:
            # Paused accounts: startup must not open Telegram connections in tests.
            c.execute("INSERT INTO accounts(id,name,status) VALUES(1,'One','paused')")
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,100,'Chat','user')")
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,?,'Telegram','user')",
                      (self.app.SERVICE_CHAT,))
            c.executemany("""INSERT INTO messages(account_id,chat_id,msg_id,text,media_type,file_size,media_status,media_error)
                             VALUES(?,?,?,?,?,?,?,?)""", [
                (1, 100, 1, "text", None, None, None, None),
                (1, 100, 2, "", "document", 10, "downloading", None),
                (1, 100, 3, "", "photo", 642, "incomplete", "Неполный файл: 291 из 642"),
                (1, self.app.SERVICE_CHAT, 4, "code 12345", None, None, None, None)])
            c.execute("INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt) VALUES(1,100,3,'t','{}',9e9)")
        self.started = False

    async def asyncTearDown(self):
        if self.started:
            await self.app.on_shutdown()
        self.temp.cleanup()

    async def start(self):
        await asyncio.wait_for(self.app.on_startup(), 5)
        self.started = True

    async def wait_maintenance(self, state="done"):
        for _ in range(200):
            if self.app.STARTUP_MAINTENANCE["state"] == state:
                return
            await asyncio.sleep(0.05)
        self.fail(f"startup maintenance is {self.app.STARTUP_MAINTENANCE}")

    async def test_panel_and_ingestion_start_while_media_checks_are_still_running(self):
        a = self.app
        release = threading.Event()
        original = a.migrate_media_paths

        def slow_migration(*args):
            release.wait(10)               # a multi-gigabyte archive on a slow disk
            return original(*args)

        with patch.object(a, "migrate_media_paths", slow_migration):
            started = time.monotonic()
            await self.start()
            self.assertLess(time.monotonic() - started, 2)
            await asyncio.sleep(0.2)
            self.assertEqual(a.STARTUP_MAINTENANCE["state"], "running")
            self.assertEqual(a.api_health()["startup_maintenance"], "running")
            # Live receipts are written while the media pass is still busy.
            await a.write_call(a.persist_live_batch, [dict(account_id=1, chat_id=100, msg_id=10,
                date="2026-10-23T00:00:00+00:00", source_version="2026-10-23T00:00:00+00:00",
                capture_order=1, sender_id=None, out=0, text="live during startup", title="Chat",
                type="user", media_type=None, file_size=None, media_id=None, token="a" * 32)])
            with a.db() as c:
                self.assertEqual(c.execute("SELECT text FROM messages WHERE msg_id=10").fetchone()[0],
                                 "live during startup")
            # Attachment downloads start at once; the long check runs beside them.
            workers = [t for t in a.ARCHIVE_WORKERS if "archive_job_worker" in repr(t.get_coro())]
            self.assertEqual(len(workers), 3)
            release.set()
            await self.wait_maintenance()
        workers = [t for t in a.ARCHIVE_WORKERS if "archive_job_worker" in repr(t.get_coro())]
        self.assertEqual(len(workers), 3)              # started once, not again after the check

    async def test_background_checks_keep_every_startup_repair(self):
        a = self.app
        await self.start()
        await self.wait_maintenance()
        with a.db() as c:
            rows = {r["msg_id"]: dict(r) for r in c.execute("SELECT * FROM messages")}
            self.assertNotIn(4, rows)                                   # service chat dropped
            self.assertIsNone(c.execute("SELECT 1 FROM chats WHERE chat_id=?", (a.SERVICE_CHAT,)).fetchone())
            self.assertEqual(rows[2]["media_status"], "incomplete")     # interrupted download
            self.assertIn("прервана", rows[2]["media_error"])
            self.assertEqual(c.execute("SELECT next_attempt FROM archive_jobs WHERE msg_id=3").fetchone()[0], 0)
            self.assertEqual(c.execute("PRAGMA quick_check").fetchone()[0], "ok")

    async def test_shutdown_ends_a_long_media_pass_without_starting_downloads(self):
        a = self.app
        entered = threading.Event()

        def endless(*args):
            entered.set()
            while not a.MAINTENANCE_STOP.is_set():
                time.sleep(0.01)

        with patch.object(a, "migrate_media_paths", endless):
            await self.start()
            await asyncio.to_thread(entered.wait, 5)
            await asyncio.wait_for(a.on_shutdown(), 10)
            self.started = False
        self.assertFalse([t for t in a.ARCHIVE_WORKERS if "archive_job_worker" in repr(t.get_coro())])

    def test_file_steps_leave_a_download_in_progress_alone(self):
        a = self.app
        old = a.BASE / "media" / "Old" / "Chat" / "doc [2].pdf"
        old.parent.mkdir(parents=True)
        old.write_bytes(b"0123456789")
        with a.db() as c:
            c.execute("UPDATE messages SET file_path='media/Old/Chat/doc [2].pdf',media_status=NULL WHERE msg_id=2")
        folder = a.MEDIA / a.account_dir(1) / a.chat_dir_name(1, 100, "Chat")
        folder.mkdir(parents=True, exist_ok=True)
        part = folder / ".doc [3].jpg.0123456789ab.part"
        part.write_bytes(b"12345")
        a.ARCHIVE_BUSY.update({(1, 100, 2), (1, 100, 3)})
        a.migrate_media_paths()
        self.assertEqual(a.recover_orphaned_media_parts(), 0)
        self.assertTrue(old.is_file() and part.is_file())
        with a.db() as c:
            self.assertEqual(c.execute("SELECT file_path FROM messages WHERE msg_id=2").fetchone()[0],
                             "media/Old/Chat/doc [2].pdf")
        a.ARCHIVE_BUSY.clear()                       # the next pass handles them as before
        a.migrate_media_paths()
        self.assertEqual(a.recover_orphaned_media_parts(), 1)
        self.assertFalse(old.exists() or part.exists())

    def test_stale_file_check_uses_only_the_messages_own_rows(self):
        a = self.app
        with a.db() as c:
            c.execute("UPDATE messages SET file_path='media/One/Chat/report [2].pdf' WHERE msg_id=2")
            c.execute("""INSERT INTO deleted(account_id,chat_id,msg_id,file_path)
                         VALUES(1,100,3,'media/One/Chat/photo [3].jpg')""")
        self.assertTrue(a.media_path_referenced(1, 100, 2, "media/One/Chat/report [2].pdf"))
        self.assertTrue(a.media_path_referenced(1, 100, 3, "media/One/Chat/photo [3].jpg"))   # recycle bin
        self.assertFalse(a.media_path_referenced(1, 100, 2, "media/One/Chat/old [2].pdf"))
        self.assertFalse(a.media_path_referenced(1, 100, 2, "media/One/Chat/report [2-2].pdf"))
        # Older names without the message id may be shared: keep the file.
        self.assertTrue(a.media_path_referenced(1, 100, 2, "media/One/Chat/report.pdf"))
        self.assertTrue(a.media_path_referenced(1, 100, 2, "media/One/Chat/report [22].pdf"))

    def test_stale_file_check_is_a_primary_key_lookup(self):
        a = self.app
        with a.db() as c:
            plan = " ".join(r[3] for r in c.execute("""EXPLAIN QUERY PLAN
                SELECT 1 FROM messages WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path=?
                UNION ALL SELECT 1 FROM deleted WHERE account_id=? AND chat_id=? AND msg_id=? AND file_path=?""",
                (1, 100, 2, "x", 1, 100, 2, "x")))
        self.assertNotIn("SCAN", plan)

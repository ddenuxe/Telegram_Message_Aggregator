import asyncio
from datetime import timedelta
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock
import test_reliable_ingest


class HistoryQueueTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown=test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message=test_reliable_ingest.ReliableIngestTests.message
    rows=test_reliable_ingest.ReliableIngestTests.rows

    async def test_stalled_attachment_does_not_block_history_or_other_messages(self):
        a=self.app
        messages=[self.message(1,media=True),self.message(2)]
        started=asyncio.Event()
        async def stalled(file):
            started.set()
            await asyncio.Event().wait()
        messages[0].download_media=stalled
        dialog=SimpleNamespace(id=100,entity=None,name='Test chat')
        class Client:
            def is_connected(self): return True
            async def connect(self): pass
            async def is_user_authorized(self): return True
            def iter_dialogs(self):
                async def items(): yield dialog
                return items()
            def iter_messages(self,*args,**kwargs):
                async def items():
                    for msg in messages: yield msg
                return items()
            async def get_messages(self,chat_id,ids): return messages[ids-1]
        a.CLIENTS[1]=Client()
        a.should_scan_dialog=lambda d:True
        a.hydrate_chat_participants=AsyncMock(side_effect=AssertionError('History must not wait for profile lookups'))
        self.workers.append(asyncio.create_task(a.archive_job_worker()))
        state={}
        await asyncio.wait_for(a._run_backfill_inner(1,state),2)
        self.assertEqual(state['state'],'done')
        self.assertEqual([r['msg_id'] for r in self.rows()], [1,2])
        self.assertEqual(len(self.rows('archive_jobs')),1)
        with a.db() as c:
            self.assertEqual(tuple(c.execute('SELECT deep_done,history_cursor FROM chats WHERE account_id=1 AND chat_id=100').fetchone()),(1,2))

    async def test_repeated_history_preserves_retry_schedule_and_existing_file(self):
        a=self.app
        msg=self.message(1,media=True)
        state={}
        await a.store_history_message(None,1,msg,100,'Chat','user',state,set())
        job=self.rows('archive_jobs')[0]
        with a.db() as c:
            c.execute('UPDATE archive_jobs SET attempts=4,next_attempt=9999999999,error=?',('retry later',))
        await a.store_history_message(None,1,msg,100,'Chat','user',state,set())
        current=self.rows('archive_jobs')[0]
        self.assertEqual(current['token'],job['token'])
        self.assertEqual(current['attempts'],4)
        self.assertEqual(current['next_attempt'],9999999999)
        path=a.MEDIA/'saved.bin'
        path.write_bytes(b'x'*32)
        with a.db() as c:
            c.execute('DELETE FROM archive_jobs')
            c.execute("UPDATE messages SET file_path='media/saved.bin',media_status=NULL")
        await a.store_history_message(None,1,msg,100,'Chat','user',state,set())
        self.assertEqual(self.rows('archive_jobs'),[])
        self.assertEqual(path.read_bytes(),b'x'*32)

    async def test_history_edit_queues_new_generation_without_duplicate_message(self):
        a=self.app
        msg=self.message(1,media=True)
        await a.store_history_message(None,1,msg,100,'Chat','user',{},set())
        first=self.rows('archive_jobs')[0]['token']
        edited=self.message(1,text='edited',media=True,edited=True)
        await a.store_history_message(None,1,edited,100,'Chat','user',{},set())
        self.assertEqual(len(self.rows()),1)
        self.assertEqual(self.rows()[0]['text'],'edited')
        self.assertNotEqual(self.rows('archive_jobs')[0]['token'],first)

    async def test_queued_media_does_not_reset_completed_history_on_restart(self):
        a=self.app
        await a.store_history_message(None,1,self.message(1,media=True),100,'Chat','user',{},set())
        with a.db() as c:
            c.execute('UPDATE chats SET deep_done=1,min_msg_id=1')
        self.assertEqual(a.reset_incomplete_media_chats(),0)
        with a.db() as c:
            self.assertEqual(c.execute('SELECT deep_done FROM chats WHERE account_id=1').fetchone()[0],1)

"""Identical attachments are stored once (hard links); monitor.db and every message path stay as they were."""
import asyncio
import os
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import test_reliable_ingest


class MediaDedupeTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message

    def put(self, rel, data):
        path = self.app.BASE / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def same_file(self, a, b):
        sa, sb = os.stat(a), os.stat(b)
        return (sa.st_dev, sa.st_ino) == (sb.st_dev, sb.st_ino)

    def media_message(self, msg_id, data, document_id):
        msg = self.message(msg_id, media=True)
        msg.document = SimpleNamespace(id=document_id)
        msg.file = SimpleNamespace(size=len(data), id=f"bot-{msg_id}", ext=".bin", name="asset.bin")
        calls = []

        async def download(file, **kwargs):
            calls.append(file)
            Path(file).write_bytes(data)
            return file
        msg.download_media = download
        return msg, calls

    def snapshot(self):
        with self.app.db() as c:
            return [tuple(r) for r in c.execute("SELECT * FROM messages ORDER BY account_id,chat_id,msg_id")]

    async def run_worker(self):
        self.app.STARTUP_MAINTENANCE["state"] = "done"
        await asyncio.wait_for(self.app.media_dedupe_worker(), 20)

    async def test_existing_identical_copies_become_one_file_and_different_ones_stay(self):
        a = self.app
        a.MEDIA_DEDUPE_MIN_BYTES = 1
        photo = os.urandom(70_000)
        first = self.put("media/One/Chat A/photo [1].jpg", photo)
        second = self.put("media/Two/Chat B/photo [9].jpg", photo)
        third = self.put("media/One/Chat A/again [2].jpg", photo)
        other = self.put("media/One/Chat A/other [3].jpg", os.urandom(70_000))   # same size, other bytes
        partial = self.put("media/One/Chat A/photo [4].jpg.partial", photo)       # never touched
        before = self.snapshot()
        await self.run_worker()
        self.assertEqual(a.MEDIA_DEDUPE["state"], "done")
        self.assertTrue(self.same_file(first, second) and self.same_file(first, third))
        self.assertFalse(self.same_file(first, other))
        self.assertFalse(self.same_file(first, partial))
        for path in (first, second, third, partial):
            self.assertEqual(path.read_bytes(), photo)
        self.assertEqual(a.MEDIA_DEDUPE["linked"], 2)
        self.assertEqual(a.MEDIA_DEDUPE["saved_bytes"], 2 * len(photo))
        self.assertEqual(self.snapshot(), before)                                  # archive untouched
        # Removing one message's file keeps the shared data for the others.
        second.unlink()
        self.assertEqual(first.read_bytes(), photo)
        self.assertEqual(third.read_bytes(), photo)
        # A second run reuses stored hashes and finds nothing new.
        a.MEDIA_DEDUPE.update(state="pending", checked=0)
        await self.run_worker()
        self.assertEqual(a.MEDIA_DEDUPE["linked"], 2)

    def test_file_changed_after_hashing_is_never_replaced(self):
        a = self.app
        data = os.urandom(50_000)
        canonical = self.put("media/One/Chat/a [1].bin", data)
        duplicate = self.put("media/One/Chat/b [2].bin", data)
        st = os.stat(duplicate)
        duplicate.write_bytes(os.urandom(50_000))          # rewritten between hash and link
        self.assertEqual(a.link_identical(canonical, duplicate, (st.st_size, st.st_mtime_ns, st.st_ino)), 0)
        self.assertFalse(self.same_file(canonical, duplicate))

    def test_rewrite_hidden_by_an_unchanged_timestamp_is_never_replaced(self):
        a = self.app
        data, other = os.urandom(50_000), os.urandom(50_000)
        canonical = self.put("media/One/Chat/a [1].bin", data)
        duplicate = self.put("media/One/Chat/b [2].bin", data)
        st = os.stat(duplicate)
        duplicate.write_bytes(other)
        os.utime(duplicate, ns=(st.st_atime_ns, st.st_mtime_ns))   # same size, same mtime, same inode
        self.assertEqual(a.link_identical(canonical, duplicate, (st.st_size, st.st_mtime_ns, st.st_ino)), 0)
        self.assertFalse(self.same_file(canonical, duplicate))
        self.assertEqual(duplicate.read_bytes(), other)

    async def test_same_telegram_file_is_linked_instead_of_downloaded_again(self):
        a = self.app
        a.MEDIA_DEDUPE_MIN_BYTES = 1
        data = os.urandom(40_000)
        first, first_calls = self.media_message(1, data, document_id=777)
        await a.store_message(None, 1, first, 100, "Chat", "group")
        second, second_calls = self.media_message(2, data, document_id=777)
        await a.store_message(None, 2, second, 200, "Other chat", "group")
        self.assertEqual(len(first_calls), 1)
        self.assertEqual(second_calls, [])                          # no second download
        with a.db() as c:
            paths = [r[0] for r in c.execute("SELECT file_path FROM messages WHERE media_type IS NOT NULL ORDER BY account_id")]
            statuses = {r[0] for r in c.execute("SELECT media_status FROM messages WHERE media_type IS NOT NULL")}
        self.assertEqual(len(paths), 2)
        self.assertNotEqual(paths[0], paths[1])                     # each message keeps its own path
        self.assertEqual(statuses, {None})
        self.assertTrue(self.same_file(a.BASE / paths[0], a.BASE / paths[1]))
        self.assertEqual((a.BASE / paths[1]).read_bytes(), data)

    async def test_downloaded_file_with_identical_content_is_linked_to_the_stored_one(self):
        a = self.app
        a.MEDIA_DEDUPE_MIN_BYTES = 1
        data = os.urandom(40_000)
        first, _ = self.media_message(1, data, document_id=1001)
        second, calls = self.media_message(2, data, document_id=2002)   # resent: other Telegram id
        await a.store_message(None, 1, first, 100, "Chat", "group")
        await a.store_message(None, 1, second, 100, "Chat", "group")
        self.assertEqual(len(calls), 1)
        with a.db() as c:
            paths = [r[0] for r in c.execute("SELECT file_path FROM messages WHERE media_type IS NOT NULL ORDER BY msg_id")]
        self.assertTrue(self.same_file(a.BASE / paths[0], a.BASE / paths[1]))
        self.assertGreaterEqual(a.MEDIA_DEDUPE["saved_bytes"], len(data))

    def test_linked_partial_is_never_appended_in_place(self):
        a = self.app
        shared = self.put("media/One/Chat/x [5].bin.partial", b"a" * 1000)
        other = a.BASE / "media/One/Chat/y [6].bin.partial"
        os.link(shared, other)
        self.assertGreater(os.stat(shared).st_nlink, 1)
        # The resume rule in _store_message_locked refuses partials with more than one link.
        st = shared.stat()
        self.assertFalse(st.st_nlink <= 1)

    async def test_dedupe_failure_never_breaks_saving_a_message(self):
        a = self.app
        a.MEDIA_DEDUPE_MIN_BYTES = 1
        a.media_index_call = lambda func: (_ for _ in ()).throw(a.sqlite3.OperationalError("index locked"))
        msg, calls = self.media_message(1, os.urandom(40_000), document_id=5)
        a.reusable_media_file = lambda key, size: None
        await a.store_message(None, 1, msg, 100, "Chat", "group")
        with a.db() as c:
            row = c.execute("SELECT file_path,media_status FROM messages").fetchone()
        self.assertIsNone(row[1])
        self.assertTrue((a.BASE / row[0]).is_file())

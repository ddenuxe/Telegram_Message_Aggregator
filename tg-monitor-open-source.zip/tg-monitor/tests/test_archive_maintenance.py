"""Maintenance must preserve live receipts and avoid scans of large queues."""
from contextlib import contextmanager
import asyncio
import unittest
from unittest.mock import patch
import test_reliable_ingest


class ArchiveMaintenanceTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown

    def seed_jobs(self, account_id, count):
        with self.app.db() as c:
            c.executemany("""INSERT INTO archive_jobs
                (account_id,chat_id,msg_id,token,payload,attempts,next_attempt,error)
                VALUES(?,100,?,'unchanged-token','unchanged-payload',3,12345,'retry')""",
                ((account_id,i) for i in range(count)))

    async def test_large_valid_queue_uses_bounded_sql_work_and_changes_nothing(self):
        self.seed_jobs(1,200000)
        original = self.app.db
        steps = [0]
        def progress():
            steps[0] += 100
            return int(steps[0] > 5000)
        @contextmanager
        def bounded(*args,**kwargs):
            with original(*args,**kwargs) as c:
                c.set_progress_handler(progress,100)
                try:
                    yield c
                finally:
                    c.set_progress_handler(None,0)
        with patch.object(self.app,'db',bounded):
            self.assertEqual(await self.app.write_call(self.app.cleanup_orphaned_archive_jobs),0)
        self.assertLessEqual(steps[0],5000)
        with original() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM archive_jobs').fetchone()[0],200000)
            self.assertEqual(tuple(c.execute('SELECT token,payload,attempts,next_attempt,error FROM archive_jobs LIMIT 1').fetchone()),
                ('unchanged-token','unchanged-payload',3,12345,'retry'))

    async def test_orphans_are_removed_in_small_batches_and_valid_jobs_survive(self):
        self.seed_jobs(-10,250)
        self.seed_jobs(1,10)
        self.seed_jobs(999,120)
        removed = []
        for _ in range(6):
            removed.append(await self.app.write_call(self.app.cleanup_orphaned_archive_jobs))
        self.assertEqual(removed,[100,100,50,100,20,0])
        with self.app.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM archive_jobs').fetchone()[0],10)
            self.assertEqual(c.execute('SELECT DISTINCT account_id FROM archive_jobs').fetchone()[0],1)
            self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')

    async def test_account_created_between_probe_and_delete_keeps_its_receipts(self):
        self.seed_jobs(999,120)
        original = self.app.db
        class CreateAccountAtWriteLock:
            def __init__(self,c): self.c=c
            def execute(self,sql,args=()):
                if sql == 'BEGIN IMMEDIATE':
                    self.c.execute("INSERT INTO accounts(id,name) VALUES(999,'created during probe')")
                    self.c.commit()
                return self.c.execute(sql,args)
        @contextmanager
        def raced(*args,**kwargs):
            with original(*args,**kwargs) as c:
                yield CreateAccountAtWriteLock(c)
        with patch.object(self.app,'db',raced):
            self.assertEqual(await self.app.write_call(self.app.cleanup_orphaned_archive_jobs),0)
        with original() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM archive_jobs WHERE account_id=999').fetchone()[0],120)

    async def test_empty_queue(self):
        self.assertEqual(await self.app.write_call(self.app.cleanup_orphaned_archive_jobs),0)

    async def test_history_media_and_maintenance_share_large_queue_without_lost_writes(self):
        self.seed_jobs(1,200000)
        a=self.app
        message=test_reliable_ingest.ReliableIngestTests.message
        tasks=[]
        for start in range(200001,200081,20):
            batch=[a.live_snapshot(1,message(self,i,media=True),100,'Chat','group')
                   for i in range(start,start+20)]
            tasks.append(asyncio.create_task(a.write_call(a.persist_live_batch,batch,True,
                (1,100,'forward',start+19),_write_priority=0)))
        for msg_id in range(10,30):
            job=dict(account_id=1,chat_id=100,msg_id=msg_id,token='unchanged-token')
            tasks.append(asyncio.create_task(a.write_call(a.finish_archive_job,job)))
        tasks.append(asyncio.create_task(a.write_call(a.cleanup_orphaned_archive_jobs,_write_priority=2)))
        await asyncio.gather(*tasks)
        with a.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],80)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM archive_jobs').fetchone()[0],200060)
            self.assertEqual(c.execute('SELECT history_cursor FROM chats WHERE account_id=1 AND chat_id=100').fetchone()[0],200080)
            self.assertEqual(c.execute('SELECT payload FROM archive_jobs WHERE account_id=1 AND chat_id=100 AND msg_id=1000').fetchone()[0],'unchanged-payload')
            self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')

"""Message search index checks on a temporary copy of app.py."""
import importlib.util
import shutil
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path


SOURCE = Path(__file__).resolve().parents[1]


class SearchIndexTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-monitor-search-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            "\n[server]\nhost=127.0.0.1\nport=18097\n", encoding="utf-8")
        self.app = self.load()

    def load(self):
        spec = importlib.util.spec_from_file_location("tg_monitor_search_test", self.root / "app.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    async def asyncTearDown(self):
        await self.app.stop_ingest()
        self.temp.cleanup()

    def seed(self, rows):
        with self.app.db() as c:
            c.execute("INSERT OR IGNORE INTO accounts(id,name,status) VALUES(1,'One','paused')")
            c.execute("INSERT OR IGNORE INTO chats(account_id,chat_id,title) VALUES(1,100,'Chat')")
            c.executemany("""INSERT OR REPLACE INTO messages(account_id,chat_id,msg_id,date,text)
                             VALUES(1,100,?,?,?)""", rows)

    def found(self, q):
        result = self.app.api_search(q)
        self.assertIsInstance(result, list)
        return sorted(r["msg_id"] for r in result)

    async def test_new_messages_are_indexed_and_case_is_ignored_for_cyrillic(self):
        app = self.app
        app.init_db()
        self.assertTrue(app.SEARCH_INDEX["available"])
        self.assertTrue(app.SEARCH_INDEX["ready"])  # empty archive needs no backfill
        self.seed([(1, "2026-10-01", "Привет, Мир!"), (2, "2026-10-02", "Hello World"),
                   (3, "2026-10-03", "100% скидка_на всё")])
        self.assertEqual(self.found("привет"), [1])
        self.assertEqual(self.found("WORLD"), [2])
        self.assertEqual(self.found("100%"), [3])
        self.assertEqual(self.found('ск"'), [])
        self.assertEqual(self.found("а_н"), [3])
        self.assertEqual(self.found("ир"), [1])  # two characters: full scan path

    async def test_edits_replacements_and_deletes_keep_results_exact(self):
        app = self.app
        app.init_db()
        self.seed([(1, "2026-10-01", "первый текст"), (2, "2026-10-02", "второй текст")])
        with app.db() as c:
            c.execute("UPDATE messages SET text='исправлено' WHERE msg_id=1")
        self.seed([(2, "2026-10-02", "замена")])
        self.assertEqual(self.found("текст"), [])
        self.assertEqual(self.found("исправ"), [1])
        self.assertEqual(self.found("замен"), [2])
        with app.db() as c:
            c.execute("INSERT INTO deleted SELECT * FROM messages WHERE msg_id=2")
            c.execute("DELETE FROM messages WHERE msg_id=2")
        self.assertEqual(self.found("замен"), [])
        with app.db() as c:
            c.execute("INSERT INTO messages SELECT * FROM deleted WHERE msg_id=2")
        self.assertEqual(self.found("замен"), [2])

    async def test_existing_archive_is_backfilled_in_portions(self):
        app = self.app
        # Archive written by a version without the index.
        with closing(sqlite3.connect(self.root / "monitor.db")) as c, c:
            c.execute("""CREATE TABLE messages(account_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
                msg_id INTEGER NOT NULL, date TEXT, sender_id INTEGER, out INTEGER, text TEXT,
                media_type TEXT, file_path TEXT, file_size INTEGER,
                PRIMARY KEY(account_id, chat_id, msg_id))""")
            c.executemany("INSERT INTO messages(account_id,chat_id,msg_id,date,text) VALUES(1,100,?,?,?)",
                          [(i, f"2026-10-{1 + i % 28:02d}", f"старое сообщение {i}") for i in range(1, 51)])
        app.init_db()
        self.seed([])
        self.assertTrue(app.SEARCH_INDEX["available"])
        self.assertFalse(app.SEARCH_INDEX["ready"])
        self.assertEqual(len(self.found("старое")), 50)  # full scan before backfill
        self.seed([(51, "2026-10-29", "старое, но новое")])
        steps = 0
        while not app.SEARCH_INDEX["ready"]:
            app.search_index_backfill_step(limit=7)
            steps += 1
        self.assertEqual(steps, 8)
        self.assertEqual(len(self.found("старое")), 50)  # panel limit
        self.assertEqual(self.found("но новое"), [51])
        self.assertEqual(self.found("сообщение 42"), [42])
        # Restart keeps the finished state and does not reindex.
        app = self.app = self.load()
        app.init_db()
        self.assertTrue(app.SEARCH_INDEX["ready"])
        self.assertEqual(app.search_index_backfill_step(), 0)
        with app.db() as c:
            self.assertEqual(c.execute("PRAGMA quick_check").fetchone()[0], "ok")
            c.execute("INSERT INTO messages_fts(messages_fts) VALUES('integrity-check')")
            indexed = c.execute("SELECT COUNT(*) FROM messages_fts").fetchone()[0]
        self.assertEqual(indexed, 51)

    async def test_without_fts5_the_archive_keeps_working_and_search_scans(self):
        app = self.app
        real_init = app.init_search_index

        def unavailable(c):
            c.execute("CREATE TRIGGER IF NOT EXISTS tg_messages_fts_insert AFTER INSERT ON messages BEGIN SELECT 1; END")
            original = c.execute

            class Proxy:
                def execute(self, sql, *args):
                    if "CREATE VIRTUAL TABLE" in sql:
                        raise sqlite3.OperationalError("no such module: fts5")
                    return original(sql, *args)
            return real_init(Proxy())

        app.init_search_index = unavailable
        app.init_db()
        self.assertFalse(app.SEARCH_INDEX["available"])
        self.seed([(1, "2026-10-01", "Работает без индекса")])
        self.assertEqual(self.found("без инд"), [1])
        with app.db() as c:
            self.assertIsNone(c.execute(
                "SELECT 1 FROM sqlite_master WHERE name='tg_messages_fts_insert'").fetchone())

    async def test_existing_index_that_this_sqlite_cannot_open_is_disabled(self):
        app = self.app
        app.init_db()
        self.seed([(1, "2026-10-01", "до отката")])
        # Same archive opened by an SQLite that does not know an index option.
        with closing(sqlite3.connect(self.root / "monitor.db")) as c, c:
            c.execute("PRAGMA writable_schema=ON")
            c.execute("UPDATE sqlite_master SET sql=replace(sql,'contentless_delete=1','unknown_option=1') "
                      "WHERE name='messages_fts'")
        app = self.app = self.load()
        app.init_db()
        self.assertFalse(app.SEARCH_INDEX["available"])
        self.seed([(2, "2026-10-02", "после отката")])
        self.assertEqual(self.found("отката"), [1, 2])

    async def test_scan_before_indexing_matches_previous_like_search(self):
        app = self.app
        app.init_db()
        self.seed([(1, "2026-10-01", "Hello МИР"), (2, "2026-10-02", "100%_готово")])
        app.SEARCH_INDEX["ready"] = False
        self.assertEqual(self.found("hello"), [1])      # Latin case ignored, as before
        self.assertEqual(self.found("мир"), [])         # Cyrillic case kept, as before
        self.assertEqual(self.found("%_г"), [2])
        app.SEARCH_INDEX["ready"] = True
        self.assertEqual(self.found("мир"), [1])        # index path ignores Cyrillic case

    async def test_nul_in_query_is_ignored_instead_of_failing(self):
        self.app.init_db()
        self.seed([(1, "2026-10-01", "обычный текст")])
        self.assertEqual(self.found("обыч\x00ный"), [1])

    async def test_background_merge_keeps_index_consistent(self):
        app = self.app
        app.init_db()
        with app.db() as c:
            auto = c.execute("SELECT v FROM messages_fts_config WHERE k='automerge'").fetchone()[0]
        self.assertEqual(auto, 0)
        for n in range(1, 41):
            self.seed([(n, "2026-10-01", f"порция {n} текста")])
        app.search_index_merge_step(pages=1000)
        self.assertEqual(self.found("порция 37"), [37])
        with app.db() as c:
            c.execute("INSERT INTO messages_fts(messages_fts) VALUES('integrity-check')")


if __name__ == "__main__":
    unittest.main()

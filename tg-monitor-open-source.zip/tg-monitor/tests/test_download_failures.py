"""Downloads that keep failing stop after 3 attempts; link previews fetch the object they are archived as."""
import io
import os
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock

from PIL import Image
from telethon import TelegramClient
from telethon.tl import types
import test_reliable_ingest


def jpeg(width=64, height=64):
    output = io.BytesIO()
    Image.frombytes('L', (width, height), os.urandom(width * height)).save(output, format='JPEG', quality=95)
    return output.getvalue()


class DownloadFailureTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    rows = test_reliable_ingest.ReliableIngestTests.rows

    def queued(self, msg_id=1, attempts=0, status='incomplete', file_path=None):
        with self.app.db() as c:
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,date,text,media_type,file_size,media_status,media_error,file_path)
                         VALUES(1,100,?,'2026-10-05','текст','document',60000,?,'ServerError: No workers running',?)""",
                      (msg_id, status, file_path))
            c.execute("""INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,attempts,next_attempt)
                         VALUES(1,100,?,?,'{}',?,0)""", (msg_id, f"t{msg_id}", attempts))
        return next(r for r in self.rows('archive_jobs') if r['msg_id'] == msg_id)

    def message_row(self, msg_id=1):
        return next(r for r in self.rows() if r['msg_id'] == msg_id)

    # ---- three attempts ----

    def test_first_two_failures_are_retried_later(self):
        a = self.app
        job = self.queued()
        a.finish_archive_job(job, OSError("network"))
        first = self.rows('archive_jobs')[0]
        self.assertEqual(first['attempts'], 1)
        self.assertAlmostEqual(first['next_attempt'], time.time() + 120, delta=5)
        a.finish_archive_job(first, OSError("network"))
        second = self.rows('archive_jobs')[0]
        self.assertEqual(second['attempts'], 2)
        self.assertAlmostEqual(second['next_attempt'], time.time() + 1800, delta=5)
        self.assertEqual(self.message_row()['media_status'], 'incomplete')

    def test_third_failure_marks_file_failed_and_keeps_message(self):
        a = self.app
        partial = 'media/One/Chat/doc [1].pdf.partial'
        (a.BASE / partial).parent.mkdir(parents=True, exist_ok=True)
        (a.BASE / partial).write_bytes(b'p' * 100)
        job = self.queued(attempts=2, file_path=partial)
        a.finish_archive_job(job)            # the attempt ended with the file still incomplete
        self.assertEqual(self.rows('archive_jobs'), [])
        row = self.message_row()
        self.assertEqual((row['media_status'], row['text'], row['file_path']), ('failed', 'текст', partial))
        self.assertEqual(row['media_error'], 'ServerError: No workers running')   # the real reason stays
        self.assertTrue((a.BASE / partial).is_file())
        # Failed files are not put back into the queue on the next start.
        self.assertEqual(a.recover_missing_media_jobs(), 0)

    def test_jobs_already_retried_many_times_stop_on_their_next_failure(self):
        a = self.app
        job = self.queued(attempts=371)
        a.finish_archive_job(job, OSError("network"))
        self.assertEqual(self.rows('archive_jobs'), [])
        self.assertEqual(self.message_row()['media_status'], 'failed')

    def test_failure_without_media_error_records_the_job_error(self):
        a = self.app
        job = self.queued(attempts=2, status='queued')
        with a.db() as c:
            c.execute("UPDATE messages SET media_error=NULL")
        a.finish_archive_job(job, TimeoutError())
        row = self.message_row()
        self.assertEqual((row['media_status'], row['media_error']), ('failed', 'TimeoutError'))

    def test_flood_wait_and_full_disk_do_not_use_up_attempts(self):
        a = self.app
        job = self.queued(attempts=2)
        a.finish_archive_job(job, a.FloodWaitError(request=None, capture=600))
        pending = self.rows('archive_jobs')[0]
        self.assertEqual(pending['attempts'], 2)
        self.assertGreater(pending['next_attempt'], time.time() + 600)
        with a.db() as c:
            c.execute("UPDATE messages SET media_status='storage_full'")
        a.finish_archive_job(pending)
        self.assertEqual(self.rows('archive_jobs')[0]['attempts'], 2)
        self.assertEqual(self.message_row()['media_status'], 'storage_full')

    def test_complete_file_is_never_marked_failed_by_a_profile_job(self):
        a = self.app
        job = self.queued(attempts=2, status=None, file_path='media/One/Chat/doc [1].pdf')
        a.finish_archive_job(job, ValueError("Could not find the input entity"))
        self.assertIsNone(self.message_row()['media_status'])

    # ---- link previews ----

    def client_with(self, data):
        client = TelegramClient(None, 12345, '0' * 32)
        async def download(location, file, **kwargs):
            Path(file).write_bytes(data)
            return file
        client.download_file = AsyncMock(side_effect=download)
        return client

    def preview_message(self, photo_bytes, document):
        now = datetime.now(timezone.utc)
        photo = types.Photo(id=77, access_hash=1, file_reference=b'', date=now, dc_id=1,
                            sizes=[types.PhotoSize('y', 64, 64, len(photo_bytes))])
        page = types.WebPage(id=1, url='https://t.me/x/1', display_url='t.me/x/1', hash=0,
                             photo=photo, document=document)
        return types.Message(id=1, peer_id=types.PeerUser(100), date=now, message='https://t.me/x/1',
                             media=types.MessageMediaWebPage(webpage=page))

    def document(self, mime, attributes, size):
        return types.Document(id=55, access_hash=1, file_reference=b'', date=datetime.now(timezone.utc),
                              mime_type=mime, size=size, dc_id=1, attributes=attributes)

    async def test_preview_photo_with_a_document_downloads_the_photo(self):
        a = self.app
        data = jpeg()
        msg = self.preview_message(data, self.document('application/pdf', [types.DocumentAttributeFilename('a.pdf')], 999_999))
        client = self.client_with(data)
        msg._client = client
        self.assertEqual(a.media_kind(msg), 'photo')
        self.assertEqual(a.media_expected_size(msg), len(data))
        await a.store_message(client, 1, msg, 100, 'Chat', 'user')
        row = self.rows()[0]
        self.assertEqual((row['media_type'], row['media_status'], row['media_error']), ('photo', None, None))
        self.assertEqual((a.BASE / row['file_path']).read_bytes(), data)
        location = client.download_file.await_args.args[0]
        self.assertIsInstance(location, types.InputPhotoFileLocation)   # not the document

    async def test_preview_video_uses_the_video_size_and_is_skipped(self):
        a = self.app
        data = jpeg()
        video = self.document('video/mp4', [types.DocumentAttributeVideo(duration=3.0, w=320, h=240)], 5_000_000)
        msg = self.preview_message(data, video)
        client = self.client_with(data)
        msg._client = client
        self.assertEqual(a.media_kind(msg), 'video')
        self.assertEqual(a.photo_transfer_spec(msg), (None, None))
        self.assertEqual(a.media_expected_size(msg), 5_000_000)
        snapshot = a.live_snapshot(1, msg, 100, 'Chat', 'user')
        self.assertEqual((snapshot['file_size'], snapshot['media_id']), (5_000_000, a.media_file_info(msg, 'video').id))
        await a.store_message(client, 1, msg, 100, 'Chat', 'user')
        row = self.rows()[0]
        self.assertEqual((row['media_type'], row['media_status'], row['file_size']), ('video', 'skipped', 5_000_000))
        client.download_file.assert_not_awaited()

    # ---- photos stored by Telegram without their last bytes ----

    async def test_photo_missing_its_last_bytes_with_the_declared_size_is_kept(self):
        a = self.app
        data = jpeg()[:-5]
        with self.assertRaises(OSError):                # PIL does reject it on its own
            with Image.open(io.BytesIO(data)) as image:
                image.load()
        now = datetime.now(timezone.utc)
        photo = types.Photo(id=78, access_hash=1, file_reference=b'', date=now, dc_id=1,
                            sizes=[types.PhotoSize('y', 64, 64, len(data))])
        msg = types.Message(id=2, peer_id=types.PeerUser(100), date=now, message='',
                            media=types.MessageMediaPhoto(photo=photo))
        client = self.client_with(data)
        msg._client = client
        await a.store_message(client, 1, msg, 100, 'Chat', 'user')
        row = self.rows()[0]
        self.assertEqual(row['media_status'], None)
        self.assertEqual((a.BASE / row['file_path']).read_bytes(), data)


if __name__ == "__main__":
    unittest.main()

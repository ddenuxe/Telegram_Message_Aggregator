"""Large disposable queues: bounded selection and independent history writes."""
import asyncio
from contextlib import contextmanager
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import test_reliable_ingest


class QueueScalingTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message
    rows = test_reliable_ingest.ReliableIngestTests.rows

    async def test_slow_queue_selection_does_not_hold_history_writer(self):
        a = self.app
        entered, release = threading.Event(), threading.Event()
        def slow_select():
            entered.set()
            release.wait(3)
            return None
        with patch.object(a, 'next_archive_job', slow_select):
            worker = asyncio.create_task(a.archive_job_worker())
            self.workers.append(worker)
            await asyncio.to_thread(entered.wait, 2)
            try:
                await asyncio.wait_for(a.store_history_batch(
                    1, [self.message(1)], 100, 'Chat', 'user', {}), 0.3)
                self.assertEqual(len(self.rows()), 1)
            finally:
                release.set()

    def test_selection_work_does_not_grow_with_ready_queue(self):
        a = self.app
        a.CLIENTS[1] = SimpleNamespace(is_connected=lambda: True)
        with a.db() as c:
            c.executemany('INSERT INTO messages(account_id,chat_id,msg_id,file_size) VALUES(1,100,?,?)',
                          ((i, 100000 - i) for i in range(1, 20001)))
            c.executemany("INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt) "
                          "VALUES(1,100,?,?,?,0)", ((i, str(i), 'x' * 2048) for i in range(1, 20001)))
        steps = []
        original = a.db
        @contextmanager
        def measured(*args, **kwargs):
            with original(*args, **kwargs) as c:
                c.set_progress_handler(lambda: steps.append(1000) or 0, 1000)
                yield c
        with patch.object(a, 'db', measured):
            job = a.next_archive_job()
        self.assertIsNotNone(job)
        self.assertLess(sum(steps), 50000, 'selection scanned the whole ready queue')

    def test_queue_statistics_use_covering_index(self):
        with self.app.db() as c:
            plan = ' '.join(str(tuple(r)) for r in c.execute('EXPLAIN QUERY PLAN '
                'SELECT account_id,COUNT(*),SUM(attempts>0) FROM archive_jobs GROUP BY account_id'))
        self.assertIn('COVERING INDEX', plan)

    def test_scheduler_rotates_accounts_and_skips_paused_and_future_jobs(self):
        a = self.app
        for i in (1, 2, 3):
            a.CLIENTS[i] = SimpleNamespace(is_connected=lambda: True)
        with a.db() as c:
            c.execute("UPDATE accounts SET status='paused' WHERE id=3")
            c.executemany("INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt) "
                          "VALUES(?,100,?,'test','{}',?)", [(1,1,0),(2,1,0),(3,1,0),(1,2,9999999999)])
        self.assertEqual([a.next_archive_job()['account_id'] for _ in range(4)], [1,2,1,2])

    def test_one_account_downloads_up_to_six_files_at_once(self):
        a = self.app
        for i in (1, 2):
            a.CLIENTS[i] = SimpleNamespace(is_connected=lambda: True)
        with a.db() as c:
            c.executemany("INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt) "
                          "VALUES(?,100,?,'test','{}',0)", [(i, m) for i in (1, 2) for m in range(1, 11)])
        a.ARCHIVE_BUSY.update((1, 100, m) for m in range(1, 6))
        a.ARCHIVE_LAST_ACCOUNT = 1
        self.assertEqual(a.next_archive_job()['account_id'], 2)
        self.assertEqual(a.next_archive_job()['account_id'], 1)   # five busy: one more fits
        a.ARCHIVE_BUSY.add((1, 100, 6))
        self.assertEqual({a.next_archive_job()['account_id'] for _ in range(3)}, {2})
        self.assertEqual(a.MAX_MEDIA_DOWNLOADS_PER_ACCOUNT, 6)

    def test_flood_wait_pauses_every_file_of_that_account(self):
        a = self.app
        for i in (1, 2):
            a.CLIENTS[i] = SimpleNamespace(is_connected=lambda: True)
        with a.db() as c:
            c.executemany("INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,next_attempt) "
                          "VALUES(?,100,?,'test','{}',0)", [(i, m) for i in (1, 2) for m in (1, 2, 3)])
        job = next(r for r in self.rows('archive_jobs') if r['account_id'] == 1 and r['msg_id'] == 1)
        a.finish_archive_job(job, a.FloodWaitError(request=None, capture=600))
        # The other files of account 1 are due, yet Telegram asked the account to wait.
        self.assertEqual({a.next_archive_job()['account_id'] for _ in range(4)}, {2})
        ingest = {x['id']: x['ingest'] for x in a.api_accounts()}
        self.assertGreater(ingest[1]['telegram_wait_until'], a.time.time() + 590)
        self.assertIsNone(ingest[2]['telegram_wait_until'])
        a.ARCHIVE_ACCOUNT_WAIT[1] = a.time.time() - 1
        self.assertIn(1, {a.next_archive_job()['account_id'] for _ in range(4)})

    def test_files_are_requested_in_the_largest_parts_telegram_serves(self):
        from telethon.client import downloads
        self.assertIs(downloads.utils, self.app.tg_utils)
        # Telethon's own choice for these sizes is 128 KB, a round trip per 128 KB.
        for size in (300_000, 20 * 1024 ** 2, 99 * 1024 ** 2):
            self.assertEqual(downloads.utils.get_appropriated_part_size(size), 512)

    async def test_already_cached_profile_jobs_do_not_fetch_each_message_again(self):
        from unittest.mock import AsyncMock
        a = self.app
        msg = self.message(1)
        msg.sender_id = 123
        await a.store_history_batch(1, [msg], 100, 'Chat', 'user', {})
        self.assertEqual(len(self.rows('archive_jobs')), 1)
        with a.db() as c:
            c.execute("INSERT INTO participants(account_id,user_id,display_name) VALUES(1,123,'Cached')")
        client = SimpleNamespace(is_connected=lambda: True, get_messages=AsyncMock(side_effect=AssertionError('redundant fetch')))
        a.CLIENTS[1] = client
        a.LIVE_MESSAGES.clear()  # historical jobs no longer have an in-memory message
        self.workers.append(asyncio.create_task(a.archive_job_worker()))
        for _ in range(100):
            if not self.rows('archive_jobs'):
                break
            await asyncio.sleep(0.01)
        self.assertEqual(self.rows('archive_jobs'), [])
        client.get_messages.assert_not_called()


"""Real Telethon photo variants, with disposable archives and no network."""
import io
from datetime import datetime, timezone
from pathlib import Path
import unittest
from unittest.mock import AsyncMock

from PIL import Image
from telethon import TelegramClient
from telethon.tl import types
from telethon.tl.custom.file import File
import test_reliable_ingest


class PhotoVariantTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    rows = test_reliable_ingest.ReliableIngestTests.rows

    def photo_message(self, sizes=None):
        output = io.BytesIO()
        Image.new('L', (1, 1), 0).save(output, format='JPEG', optimize=True)
        data = output.getvalue()
        photo = types.Photo(id=99, access_hash=1, file_reference=b'',
                            date=datetime.now(timezone.utc), dc_id=1,
                            sizes=sizes or [types.PhotoSize('s', 1, 1, len(data)),
                                            types.PhotoStrippedSize('i', b'\x01\x01\x01' + b'x' * 17)])
        msg = types.Message(id=1, peer_id=types.PeerUser(100), date=photo.date,
                      message='Synthetic photo', media=types.MessageMediaPhoto(photo=photo))
        client = TelegramClient(None, 12345, '0' * 32)
        async def download(location, file, **kwargs):
            Path(file).write_bytes(data)
            return file
        client.download_file = AsyncMock(side_effect=download)
        msg._client = client
        return msg, client, data

    async def test_snapshot_size_matches_downloaded_variant_not_expanded_preview(self):
        msg, client, data = self.photo_message()
        self.assertGreater(msg.file.size, len(data))  # reproduces Telethon discrepancy
        snapshot = self.app.live_snapshot(1, msg, 100, 'Synthetic', 'user')
        self.assertEqual(snapshot['file_size'], len(data))

    async def test_real_telethon_download_clears_the_retry_instead_of_looping(self):
        msg, client, data = self.photo_message()
        a = self.app
        snapshot = a.live_snapshot(1, msg, 100, 'Synthetic', 'user')
        # Existing receipt was created by 1.2.11 with the expanded preview size.
        snapshot['file_size'] = msg.file.size
        a.persist_live_batch([snapshot])
        job = self.rows('archive_jobs')[0]
        await a.store_message(client, msg=msg, account_id=1, chat_id=100,
                              title='Synthetic', ctype='user', expected_job_token=job['token'])
        a.finish_archive_job(job)
        row = self.rows()[0]
        self.assertIsNone(row['media_status'])
        self.assertIsNone(row['media_error'])
        self.assertEqual(row['file_size'], len(data))
        self.assertEqual((a.BASE / row['file_path']).read_bytes(), data)
        self.assertEqual(self.rows('archive_jobs'), [])

    async def test_truncated_real_photo_still_stays_incomplete(self):
        msg, client, data = self.photo_message()
        async def truncate(location, file, **kwargs):
            Path(file).write_bytes(data[:20])
            return file
        client.download_file.side_effect = truncate
        await self.app.store_message(client, 1, msg, 100, 'Synthetic', 'user')
        row = self.rows()[0]
        self.assertEqual(row['media_status'], 'incomplete')
        self.assertIn('Неполный файл', row['media_error'])

    async def test_full_photo_wins_over_stripped_preview_and_video_variant(self):
        sizes=[types.PhotoSize('s', 1, 1, 291),
               types.PhotoSizeProgressive('y', 1200, 800, [500, 5000]),
               types.PhotoStrippedSize('i', b'\x01\x01\x01' + b'x' * 17)]
        msg, client, data = self.photo_message(sizes)
        msg.photo.video_sizes = [types.VideoSize('v', 1200, 800, 99999)]
        self.assertEqual(self.app.photo_transfer_spec(msg), ('y', 5000))

    async def test_stripped_only_uses_actual_reconstructed_jpeg_size(self):
        msg, client, data = self.photo_message([types.PhotoStrippedSize('i', b'\x01\x01\x01' + b'x' * 17)])
        self.assertEqual(self.app.photo_transfer_spec(msg), ('i', File(msg.photo).size))

    async def test_corrupt_jpeg_with_matching_length_is_not_published(self):
        msg, client, data = self.photo_message()
        async def corrupt(location, file, **kwargs):
            Path(file).write_bytes(b'x' * len(data))
            return file
        client.download_file.side_effect = corrupt
        await self.app.store_message(client, 1, msg, 100, 'Synthetic', 'user')
        row = self.rows()[0]
        self.assertEqual(row['media_status'], 'incomplete')
        self.assertTrue(row['file_path'].endswith('.partial'))

    async def test_startup_retries_only_existing_small_photo_size_mismatches(self):
        a = self.app
        with a.db() as c:
            for ident, kind, error, size in ((1,'photo','Неполный файл',642),
                                           (2,'document','Неполный файл',642),
                                           (3,'photo','TimeoutError',642),
                                           (4,'photo','Неполный файл',2**20)):
                c.execute("INSERT INTO messages(account_id,chat_id,msg_id,media_type,media_status,media_error,file_size) VALUES(1,100,?,?,'incomplete',?,?)",
                          (ident,kind,error,size))
                c.execute("INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,attempts,next_attempt) VALUES(1,100,?,?,?,5,9999999999)",
                          (ident,str(ident),'{}'))
        self.assertEqual(a.retry_mismatched_photo_jobs(), 1)
        jobs = self.rows('archive_jobs')
        self.assertEqual([r['next_attempt'] for r in jobs], [0,9999999999,9999999999,9999999999])
        self.assertTrue(all(r['attempts']==5 for r in jobs))


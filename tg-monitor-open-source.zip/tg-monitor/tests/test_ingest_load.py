"""Bounded ingest and partial media persistence, isolated from the live archive."""
import asyncio
import importlib.util
import shutil
import tempfile
import unittest
from unittest.mock import patch
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace


SOURCE = Path(__file__).resolve().parents[1]


class IngestLoadTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-monitor-ingest-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            "\n[server]\nhost=127.0.0.1\nport=18097\n[archive]\nmax_media_mb=1024\n",
            encoding="utf-8")
        spec = importlib.util.spec_from_file_location("tg_monitor_ingest_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()
        with self.app.db() as c:
            c.execute("INSERT INTO accounts(id,name) VALUES(1,'Load test')")
            c.executemany("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,?,?,?)",
                          [(chat_id, f"Chat {chat_id}", "group") for chat_id in range(1, 21)])
        async def no_sender(*_args):
            return None
        self.app.cache_message_sender = no_sender
        self.app.media_kind = lambda _msg: "document"
        self.app.render_text = lambda msg: msg.message
        self.app.media_file_name = lambda msg, *_args: f"message-{msg.id}"

    async def asyncTearDown(self):
        self.temp.cleanup()

    async def test_twenty_chats_are_archived_with_bounded_simultaneous_downloads(self):
        active = 0
        maximum = 0
        first_wave = asyncio.Event()
        download_limit = self.app.MAX_CONCURRENT_MEDIA_DOWNLOADS

        class Message:
            def __init__(self, msg_id):
                self.id = msg_id
                self.date = datetime(2026, 10, 4)
                self.sender_id = None
                self.out = False
                self.message = f"text {msg_id}"
                self.entities = []
                self.file = SimpleNamespace(size=64, id=msg_id, ext=".bin", name="asset.bin")

            async def download_media(self, file):
                nonlocal active, maximum
                active += 1
                maximum = max(maximum, active)
                try:
                    if active == download_limit:
                        first_wave.set()
                    await asyncio.wait_for(first_wave.wait(),5)
                    await asyncio.sleep(0.01)
                    Path(file).write_bytes(b"x" * self.file.size)
                    return file
                finally:
                    active -= 1

        await asyncio.gather(*(
            self.app.store_message(None, 1, Message(chat_id), chat_id,
                                   f"Chat {chat_id}", "group")
            for chat_id in range(1, 21)))
        self.assertEqual(maximum, self.app.MAX_CONCURRENT_MEDIA_DOWNLOADS)
        with self.app.db() as c:
            rows = c.execute("SELECT COUNT(*),SUM(file_path IS NOT NULL) FROM messages").fetchone()
        self.assertEqual(tuple(rows), (20, 20))

    async def test_partial_file_is_kept_as_message_and_marked_unavailable(self):
        app = self.app

        class Client:
            def is_connected(self):
                return True
            async def get_messages(self, *_args, **_kwargs):
                return None

        class Message:
            id = 99
            date = datetime(2026, 10, 4)
            sender_id = None
            out = False
            message = "file removed while downloading"
            entities = []
            file = SimpleNamespace(size=64, id=99, ext=".bin", name="asset.bin")

            async def download_media(self, file):
                Path(file).write_bytes(b"partial")
                raise OSError("Telegram file reference expired")

        await app.store_message(Client(), 1, Message(), 1, "Chat 1", "group")
        with app.db() as c:
            row = c.execute("SELECT text,file_path,media_status,media_error FROM messages WHERE msg_id=99").fetchone()
        self.assertEqual(row["text"], "file removed while downloading")
        self.assertTrue(row["file_path"].endswith(".partial"))
        partial = app.safe_media_path(row["file_path"])
        self.assertTrue(partial.is_file())
        self.assertEqual(partial.read_bytes(), b"partial")
        self.assertEqual(row["media_status"], "unavailable")
        self.assertIn("недоступно", row["media_error"])
        self.assertFalse(list(app.MEDIA.rglob("*.part")))
        item = next(item for item in app.api_media_catalog(limit=200)["items"]
                    if item["msg_id"] == 99)
        self.assertFalse(item["file_exists"])
        self.assertTrue(item["partial_exists"])
        self.assertEqual(item["stored_size"], len(b"partial"))

    async def test_low_disk_keeps_message_and_does_not_start_file_transfer(self):
        app = self.app
        class Message:
            id = 101
            date = datetime(2026, 10, 4)
            sender_id = None
            out = False
            message = "kept when disk is full"
            entities = []
            file = SimpleNamespace(size=1024, id=101, ext=".bin", name="asset.bin")
            downloads = 0

            async def download_media(self, _file):
                self.downloads += 1

        msg = Message()
        fake_disk = SimpleNamespace(free=100, total=1000, used=900)
        with patch.object(app.shutil, "disk_usage", return_value=fake_disk):
            await app.store_message(None, 1, msg, 1, "Chat 1", "group")
        self.assertEqual(msg.downloads, 0)
        with app.db() as c:
            row = c.execute("SELECT text,file_path,media_status FROM messages WHERE msg_id=101").fetchone()
        self.assertEqual(tuple(row), ("kept when disk is full", None, "storage_full"))

    def test_storage_api_reports_low_and_critical_space(self):
        fake_disk = SimpleNamespace(total=100 * 1024**3, used=95 * 1024**3,
                                    free=5 * 1024**3)
        with patch.object(self.app.shutil, "disk_usage", return_value=fake_disk):
            low = self.app.api_storage()
        self.assertEqual(low["disk_warning_level"], "low")
        self.assertEqual(low["archive_bytes"], low["database_bytes"] +
                         low["database_backups_bytes"] + low["sessions_bytes"] + low["media_bytes"])
        fake_disk.free = 1024**3
        with patch.object(self.app.shutil, "disk_usage", return_value=fake_disk):
            critical = self.app.api_storage()
        self.assertEqual(critical["disk_warning_level"], "critical")

    def test_startup_recovery_links_orphaned_download_part_to_message(self):
        app = self.app
        with app.db() as c:
            c.execute("INSERT INTO messages(account_id,chat_id,msg_id,media_type,file_size,media_status) "
                      "VALUES(1,1,102,'document',64,'downloading')")
        folder = app.MEDIA / app.account_dir(1) / app.chat_dir_name(1, 1, "Chat 1")
        folder.mkdir(parents=True, exist_ok=True)
        target_name = "asset [102].bin"
        orphan = folder / f".{target_name}.012345abcdef.part"
        orphan.write_bytes(b"first chunk")

        self.assertEqual(app.recover_orphaned_media_parts(), 1)
        with app.db() as c:
            row = c.execute("SELECT file_path,media_status FROM messages WHERE msg_id=102").fetchone()
        recovered = app.safe_media_path(row["file_path"])
        self.assertTrue(recovered.name.endswith(".partial"))
        self.assertEqual(recovered.read_bytes(), b"first chunk")
        self.assertEqual(row["media_status"], "incomplete")
        self.assertFalse(orphan.exists())


if __name__ == "__main__":
    unittest.main()

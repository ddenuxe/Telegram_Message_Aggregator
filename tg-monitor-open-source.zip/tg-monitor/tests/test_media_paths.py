"""Media folder path checks run against a temporary installation and database."""
import importlib.util
import shutil
import tempfile
import unittest
from pathlib import Path


SOURCE = Path(__file__).resolve().parents[1]


class MediaPathTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-monitor-media-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            "\n[server]\nhost=127.0.0.1\nport=18095\n", encoding="utf-8")
        spec = importlib.util.spec_from_file_location("tg_monitor_media_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()

    def tearDown(self):
        self.temp.cleanup()

    def test_sanitized_chat_collisions_get_distinct_folders_and_files(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO accounts(id,username) VALUES(1,'account')")
            c.executemany("INSERT INTO chats(account_id,chat_id,title) VALUES(1,?,?)",
                          [(10, "a/b"), (11, "ab")])
            c.executemany("INSERT INTO messages(account_id,chat_id,msg_id,file_path) VALUES(1,?,?,?)",
                          [(10, 100, "media/legacy/first.jpg"),
                           (11, 101, "media/legacy/second.jpg")])
        first = a.MEDIA / "legacy" / "first.jpg"
        second = a.MEDIA / "legacy" / "second.jpg"
        first.parent.mkdir()
        first.write_bytes(b"first")
        second.write_bytes(b"second")

        a.migrate_media_paths()

        with a.db() as c:
            paths = [r[0] for r in c.execute("SELECT file_path FROM messages ORDER BY chat_id")]
        self.assertNotEqual(Path(paths[0]).parent, Path(paths[1]).parent)
        self.assertTrue(all((self.root / p).is_file() for p in paths))
        self.assertEqual({(self.root / p).read_bytes() for p in paths}, {b"first", b"second"})

    def test_missing_file_keeps_database_path_and_does_not_create_destination(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO accounts(id,username) VALUES(1,'account')")
            c.execute("INSERT INTO chats(account_id,chat_id,title) VALUES(1,10,'Missing')")
            c.execute("INSERT INTO messages(account_id,chat_id,msg_id,file_path) VALUES(1,10,100,'media/gone.jpg')")

        a.migrate_media_paths()

        with a.db() as c:
            path = c.execute("SELECT file_path FROM messages").fetchone()[0]
        self.assertEqual(path, "media/gone.jpg")
        self.assertFalse((a.MEDIA / "account" / "Missing").exists())

    def test_windows_reserved_folder_name_is_made_safe(self):
        self.assertEqual(self.app._safe_name("CON"), "_CON")
        self.assertEqual(self.app._safe_name("a/b."), "ab")

    def test_adding_chat_creates_its_folder_under_the_account_folder(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO accounts(id,username) VALUES(1,'account')")
            c.execute("INSERT INTO chats(account_id,chat_id,title) VALUES(1,10,'New chat')")

        folder = a.ensure_chat_dir(1, 10, "New chat")

        self.assertEqual(folder, a.MEDIA / "@account" / "New chat")
        self.assertTrue(folder.is_dir())

    def test_account_identity_update_creates_folders_for_known_chats(self):
        a = self.app
        with a.db() as c:
            c.execute("INSERT INTO accounts(id,name,status) VALUES(1,'Account','paused')")
            c.execute("INSERT INTO chats(account_id,chat_id,title) VALUES(1,10,'Text only')")

        a.set_status(1, "recording", username="handle")

        self.assertTrue((a.MEDIA / "@handle" / "Text only").is_dir())


if __name__ == "__main__":
    unittest.main()

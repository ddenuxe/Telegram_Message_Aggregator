import base64
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import desktop_reveal


class DesktopRevealTests(unittest.TestCase):
    def test_background_request_selects_in_interactive_task_and_cleans_result(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            full=root/'media'/'файл #50%.pdf'
            full.parent.mkdir()
            full.write_bytes(b'original')
            with patch.object(desktop_reveal.subprocess,'run',return_value=SimpleNamespace(stdout=b'{"ok":true,"selected":true,"foreground":true}')) as run:
                self.assertTrue(desktop_reveal.reveal_in_interactive_session(full,root)['selected'])
                args=run.call_args.args[0]
                outer=base64.b64decode(args[-1]).decode('utf-16le')
                self.assertIn('-LogonType Interactive',outer)
                self.assertIn('Unregister-ScheduledTask',outer)
                self.assertNotIn(str(full),outer)
            self.assertEqual(full.read_bytes(),b'original')
            self.assertEqual(list((root/'.desktop-reveal').iterdir()),[])

    def test_missing_desktop_is_reported_without_claiming_success(self):
        with tempfile.TemporaryDirectory() as temp:
            with patch.object(desktop_reveal.subprocess,'run',return_value=SimpleNamespace(stdout=json.dumps({'ok':False,'reason':'No desktop'}).encode())):
                report=desktop_reveal.reveal_in_interactive_session(Path(temp)/'a.pdf',Path(temp))
                self.assertFalse(report['ok'])
                self.assertIn('No desktop',report['reason'])

    def test_invalid_helper_response_is_not_success(self):
        with tempfile.TemporaryDirectory() as temp:
            with patch.object(desktop_reveal.subprocess,'run',return_value=SimpleNamespace(stdout=b'')):
                self.assertFalse(desktop_reveal.reveal_in_interactive_session(Path(temp)/'a.pdf',Path(temp))['ok'])

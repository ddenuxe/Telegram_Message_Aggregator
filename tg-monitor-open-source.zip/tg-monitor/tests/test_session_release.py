"""Telegram session files are released even when disconnecting fails."""
import importlib.util
import shutil
import tempfile
import unittest
from pathlib import Path


SOURCE = Path(__file__).resolve().parents[1]


class SessionReleaseTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-session-release-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 + "\n", encoding="utf-8")
        spec = importlib.util.spec_from_file_location("tg_session_release_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()

    async def asyncTearDown(self):
        await self.app.stop_ingest()
        self.temp.cleanup()

    async def test_shutdown_closes_session_after_failed_disconnect(self):
        closed = []

        class Client:
            session = type("Session", (), {"close": lambda self: closed.append(True)})()

            async def disconnect(self):
                raise ConnectionError("network is gone")

        self.app.CLIENTS[1] = Client()
        await self.app.on_shutdown()
        self.assertEqual(closed, [True])

    async def test_lifespan_runs_startup_and_shutdown(self):
        calls = []

        async def startup():
            calls.append("start")

        async def shutdown():
            calls.append("stop")

        self.app.on_startup, self.app.on_shutdown = startup, shutdown
        async with self.app._lifespan(self.app.app):
            calls.append("serve")
        self.assertEqual(calls, ["start", "serve", "stop"])


if __name__ == "__main__":
    unittest.main()

"""Retry must use durable unfinished work, never enumerate the Telegram account."""
import asyncio
import time
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import test_reliable_ingest


class HistoryRetryTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message
    rows = test_reliable_ingest.ReliableIngestTests.rows

    def client(self, messages, requests):
        class Client:
            async def connect(self): pass
            async def is_user_authorized(self): return True
            async def get_input_entity(self, chat_id): return chat_id
            def iter_dialogs(self):
                raise AssertionError('Retry enumerated all Telegram chats')
            def iter_messages(self, target, **kwargs):
                requests.append((target, kwargs))
                async def items():
                    offset = kwargs.get('offset_id', 0)
                    items = messages if kwargs.get('reverse') else reversed(messages)
                    for msg in items:
                        if not offset or (msg.id > offset if kwargs.get('reverse') else msg.id < offset):
                            yield msg
                return items()
        return Client()

    async def test_retry_resumes_committed_page_and_skips_all_completed_chats(self):
        a = self.app
        a.queue_history_dialogs(1, [(100, 'Pending', 'group')])
        messages = [self.message(i) for i in range(1, 62)]
        await a.store_history_batch(1, messages[:25], 100, 'Pending', 'group', {}, (1, 100, 'forward', 25))
        with a.db() as c:
            c.executemany("INSERT INTO chats(account_id,chat_id,title,type,deep_done,history_cursor) "
                          "VALUES(1,?,'Completed','user',1,999)", [(i,) for i in range(101, 601)])
        # Simulate a process restart: only SQLite checkpoints and the plan survive.
        a.BACKFILL.clear()
        a.init_db()
        requests = []
        a.CLIENTS[1] = self.client(messages, requests)
        state = {'retry_only': True}
        await a._run_backfill_inner(1, state)
        self.assertEqual(state['state'], 'done')
        self.assertEqual(state['total'], 1)
        self.assertEqual(state['msgs'], 36)
        self.assertEqual(requests, [(100, {'reverse': True, 'offset_id': 25})])
        self.assertEqual(sorted(r['msg_id'] for r in self.rows()), list(range(1, 62)))
        self.assertEqual(a.read_pending_history(1), [])
        self.assertEqual(a.pending_history_dialogs(1), [])
        self.assertEqual(len(self.rows('chats')), 501)

    async def test_failed_update_of_completed_chat_remains_in_retry_queue(self):
        a = self.app
        await a.store_history_batch(1, [self.message(10)], 100, 'Chat', 'user', {}, (1, 100, 'forward', 10))
        a.complete_history_chat(1, 100, 10)
        a.queue_history_dialogs(1, [(100, 'Chat', 'user')])
        requests = []
        client = self.client([], requests)
        client.get_input_entity = AsyncMock(side_effect=OSError('network down'))
        a.CLIENTS[1] = client
        state = {'retry_only': True}
        with patch.object(a.asyncio, 'sleep', new=AsyncMock()):
            await a._run_backfill_inner(1, state)
        self.assertEqual(state['state'], 'partial')
        self.assertEqual(len(a.read_pending_history(1)), 1)
        client.get_input_entity = AsyncMock(return_value=100)
        await a._run_backfill_inner(1, {'retry_only': True})
        self.assertEqual(a.read_pending_history(1), [])
        self.assertEqual(requests, [(100, {'reverse': True, 'offset_id': 10})])

    async def test_button_with_no_pending_history_does_not_start_a_scan_or_reset_media(self):
        a = self.app
        await a.store_history_batch(1, [self.message(1, media=True)], 100, 'Chat', 'user', {}, (1, 100, 'forward', 1))
        a.complete_history_chat(1, 100, 1)
        with a.db() as c:
            c.execute('UPDATE archive_jobs SET attempts=4,next_attempt=?,error=?', (time.time()+3600, 'FloodWait'))
        before = self.rows('archive_jobs')
        with patch.object(a, 'start_backfill', side_effect=AssertionError('Unexpected scan')):
            result = await a.api_backfill(1)
        self.assertTrue(result['ok'])
        self.assertFalse(result['started'])
        self.assertEqual(before, self.rows('archive_jobs'))
        self.assertEqual(len(self.rows()), 1)

    async def test_button_starts_retry_mode_and_keeps_single_running_task(self):
        a = self.app
        a.queue_history_dialogs(1, [(100, 'Pending', 'user')])
        with patch.object(a, 'start_backfill', return_value=True) as start:
            result = await a.api_backfill(1)
            start.assert_called_once_with(1, retry_only=True)
        self.assertTrue(result['started'])
        a.BACKFILL[1] = {'state': 'running'}
        with patch.object(a, 'start_backfill', side_effect=AssertionError('Duplicate scan')):
            result = await a.api_backfill(1)
        self.assertFalse(result['ok'])

    async def test_legacy_unfinished_history_is_retained_but_completed_chats_are_excluded(self):
        a = self.app
        with a.db() as c:
            c.executemany("INSERT INTO chats(account_id,chat_id,title,type,deep_done,min_msg_id,history_cursor) "
                          "VALUES(1,?,'Legacy','user',?,20,30)", [(100, 0), (101, 1)])
        jobs = a.pending_history_dialogs(1)
        self.assertEqual([j['chat_id'] for j in jobs], [100])
        self.assertFalse(jobs[0]['forward_only'])
        a.init_db()
        self.assertEqual(a.read_pending_history(1), jobs)

    async def test_cancellation_keeps_plan_and_checkpoint_without_changing_saved_messages(self):
        a = self.app
        a.queue_history_dialogs(1, [(100, 'Pending', 'user'), (101, 'Not started', 'user')])
        await a.store_history_batch(1, [self.message(1)], 100, 'Pending', 'user', {}, (1, 100, 'forward', 1))
        before = self.rows()
        requests = []
        client = self.client([], requests)
        client.get_input_entity = AsyncMock(side_effect=asyncio.CancelledError())
        a.CLIENTS[1] = client
        with self.assertRaises(asyncio.CancelledError):
            await a._run_backfill_inner(1, {'retry_only': True})
        self.assertEqual(len(a.read_pending_history(1)), 2)
        self.assertEqual(self.rows(), before)
        self.assertEqual(self.rows('chats')[0]['history_cursor'], 1)

    async def test_preview_does_not_remove_pending_work(self):
        a = self.app
        await a.store_history_batch(1, [self.message(1)], 100, 'Chat', 'user', {}, (1, 100, 'forward', 1))
        a.queue_history_dialogs(1, [(100, 'Chat', 'user')])
        before = a.read_pending_history(1)
        a.api_cleanup_full_preview('chat', 1, 100)
        self.assertEqual(a.read_pending_history(1), before)

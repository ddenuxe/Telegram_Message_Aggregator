import asyncio
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock
import test_reliable_ingest


class HistoryProgressTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown=test_reliable_ingest.ReliableIngestTests.asyncTearDown

    def summary(self):
        with self.app.db() as c:
            return self.app.history_progress_summary(c)[1]

    def test_progress_is_durable_and_inserts_deletes_are_atomic(self):
        a=self.app
        a.register_history_progress(1,[100,200],True)
        self.assertEqual(self.summary()['unknown'],2)
        a.measure_history_progress(1,100,10)
        with a.db() as c:
            c.execute('INSERT INTO messages(account_id,chat_id,msg_id) VALUES(1,100,1)')
        with a.db() as c:
            c.execute('INSERT OR IGNORE INTO messages(account_id,chat_id,msg_id) VALUES(1,100,1)')
        self.assertEqual(self.summary()['saved'],1)
        with self.assertRaises(RuntimeError):
            with a.db() as c:
                c.execute('INSERT INTO messages(account_id,chat_id,msg_id) VALUES(1,100,2)')
                raise RuntimeError('rollback')
        self.assertEqual(self.summary()['saved'],1)
        a.init_db()
        self.assertEqual(self.summary()['saved'],1)
        with a.db() as c:
            c.execute('DELETE FROM messages WHERE account_id=1')
        self.assertEqual(self.summary()['saved'],0)
        a.complete_history_chat(1,100,0)
        a.complete_history_chat(1,200,0)
        self.assertEqual(self.summary()['unknown'],0)
        self.assertEqual(self.summary()['completed_chats'],2)

    def test_existing_archive_counted_once_without_reset_on_retry(self):
        a=self.app
        with a.db() as c:
            c.executemany('INSERT INTO messages(account_id,chat_id,msg_id) VALUES(1,100,?)',[(1,),(9,)])
        a.register_history_progress(1,[100],True)
        a.measure_history_progress(1,100,8)
        a.register_history_progress(1,[100],False)
        self.assertEqual(self.summary()['saved'],2)
        self.assertEqual(self.summary()['total'],8)
        self.assertEqual(self.summary()['discovered'],1)
        a.finish_history_dialog(1,100)
        # Accessible history may have changed since Telegram's count snapshot.
        self.assertEqual(self.summary()['total'],2)
        a.measure_history_progress(1,100,999)
        self.assertEqual(self.summary()['total'],2)

    def test_empty_and_legacy_unknown_plans(self):
        self.app.register_history_progress(1,[],True)
        self.assertEqual(self.summary()['unknown'],0)
        self.assertEqual(self.summary()['chats'],0)
        self.app.register_history_progress(2,[20],False)
        with self.app.db() as c:
            self.assertEqual(self.app.history_progress_summary(c)[2]['discovered'],0)

    async def test_count_only_requests_and_unavailable_count_never_fakes_zero(self):
        a=self.app
        a.register_history_progress(1,[100,200],True)
        client=SimpleNamespace(get_messages=AsyncMock(side_effect=[SimpleNamespace(total=30),OSError('offline')]))
        await a.measure_history_totals(client,1,[SimpleNamespace(id=100),SimpleNamespace(id=200)])
        self.assertEqual(self.summary()['total'],30)
        self.assertEqual(self.summary()['unknown'],1)
        client.get_messages.assert_any_await(100,limit=0)
        a.finish_history_dialog(1,200)
        self.assertEqual(self.summary()['unknown'],0)

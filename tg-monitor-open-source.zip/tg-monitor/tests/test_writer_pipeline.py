"""Thread ownership, rollback, cancellation and durable history batches."""
import asyncio
from contextlib import contextmanager
import threading
import json
import subprocess
import sys
import unittest
from unittest.mock import patch
import test_reliable_ingest


class WriterPipelineTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message

    async def test_one_writer_thread_reuses_connection_and_can_restart_after_drain(self):
        seen=[]
        def probe():
            with self.app.db() as c:
                seen.append((threading.get_ident(),c))
                return c.execute('PRAGMA synchronous').fetchone()[0]
        for _ in range(3):
            self.assertEqual(await self.app.write_call(probe),2)
        self.assertNotEqual(seen[0][0],threading.get_ident())
        self.assertTrue(all(t==seen[0][0] and c is seen[0][1] for t,c in seen))
        await self.app.stop_ingest()
        await self.app.write_call(probe)
        self.assertIsNot(seen[-1][1],seen[0][1])

    async def test_failed_transaction_rolls_back_and_next_write_succeeds(self):
        def fail():
            with self.app.db() as c:
                c.execute("INSERT INTO accounts(id,name) VALUES(999,'must rollback')")
                raise ValueError('injected failure')
        with self.assertRaisesRegex(ValueError,'injected failure'):
            await self.app.write_call(fail)
        await self.app.write_call(self.app.sql_write,"INSERT INTO accounts(id,name) VALUES(998,'next commit')")
        with self.app.db() as c:
            self.assertIsNone(c.execute('SELECT 1 FROM accounts WHERE id=999').fetchone())
            self.assertIsNotNone(c.execute('SELECT 1 FROM accounts WHERE id=998').fetchone())

    async def test_repeated_cancellation_drains_writer_before_unlocking(self):
        started=threading.Event(); release=threading.Event(); second_started=threading.Event()
        def slow_write():
            with self.app.db() as c:
                c.execute("INSERT INTO accounts(id,name) VALUES(999,'committed before cancellation')")
                started.set()
                if not release.wait(5):
                    raise RuntimeError('test release timed out')
        first=asyncio.create_task(self.app.write_call(slow_write))
        await asyncio.to_thread(started.wait,5)
        try:
            first.cancel(); await asyncio.sleep(0.01)
            first.cancel(); await asyncio.sleep(0.01)
            second=asyncio.create_task(self.app.write_call(second_started.set))
            await asyncio.sleep(0.02)
            self.assertFalse(first.done())
            self.assertFalse(second_started.is_set())
        finally:
            release.set()
            await asyncio.gather(first,return_exceptions=True)
        await second
        with self.app.db() as c:
            self.assertIsNotNone(c.execute('SELECT 1 FROM accounts WHERE id=999').fetchone())

    async def test_repeated_chat_and_profile_metadata_is_written_once_per_batch(self):
        snapshots=[]
        for i in range(1,11):
            s=self.app.live_snapshot(1,self.message(i),100,'Chat','group')
            s.update(sender_id=42,profile=['sender',None,'Sender',None,'user'])
            snapshots.append(s)
        queries=[]; original=self.app.db
        @contextmanager
        def traced(*args,**kwargs):
            with original(*args,**kwargs) as c:
                c.set_trace_callback(queries.append)
                yield c
                c.set_trace_callback(None)
        with patch.object(self.app,'db',traced):
            accepted=await self.app.write_call(self.app.persist_live_batch,snapshots,True,(1,100,'forward',10))
        self.assertTrue(all(accepted))
        self.assertEqual(sum(q.lstrip().startswith('INSERT INTO chats') for q in queries),1)
        self.assertEqual(sum(q.lstrip().startswith('INSERT INTO participants') for q in queries),1)
        with self.app.db() as c:
            self.assertEqual(tuple(c.execute('SELECT max_msg_id,history_cursor FROM chats').fetchone()),(10,10))
            self.assertEqual(c.execute('SELECT COUNT(*) FROM archive_jobs').fetchone()[0],0)

    async def test_adaptive_history_pages_keep_every_message_and_checkpoint(self):
        sizes=[]
        class Client:
            def iter_messages(_self,*args,**kwargs):
                async def items():
                    for i in range(1,401): yield self.message(i)
                return items()
        with patch.object(self.app,'HISTORY_BATCH_PAUSE',0):
            async for batch in self.app.iter_history_batches(Client(),100):
                sizes.append(len(batch))
                await self.app.store_history_batch(1,batch,100,'Chat','group',{},(1,100,'forward',batch[-1].id))
        self.assertEqual(sum(sizes),400)
        self.assertLessEqual(max(sizes),100)
        self.assertGreater(max(sizes),25)
        with self.app.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],400)
            self.assertEqual(c.execute('SELECT history_cursor FROM chats').fetchone()[0],400)

    async def test_busy_writer_reduces_history_batch_size(self):
        self.app.HISTORY_BATCH_SIZE=100
        original=self.app.write_call
        async def busy(*args,**kwargs):
            await asyncio.sleep(0.09)
            return await original(*args,**kwargs)
        with patch.object(self.app,'write_call',busy),patch.object(self.app,'HISTORY_BATCH_PAUSE',0):
            await self.app.store_history_batch(1,[self.message(i) for i in range(1,101)],100,'Chat','group',{})
        self.assertEqual(self.app.HISTORY_BATCH_SIZE,50)

    async def test_shutdown_cancels_maintenance_before_closing_writer(self):
        stopped=asyncio.Event()
        async def maintenance():
            try:
                await asyncio.sleep(60)
            finally:
                stopped.set()
        await self.app.write_call(self.app.sql_write,"UPDATE accounts SET name='shutdown test' WHERE id=1")
        task=asyncio.create_task(maintenance())
        self.app.ARCHIVE_WORKERS.append(task)
        await asyncio.sleep(0)
        await self.app.on_shutdown()
        self.assertTrue(stopped.is_set())
        self.assertTrue(task.done())
        self.assertIsNone(self.app._DB_EXECUTOR)

    async def test_process_crash_before_or_after_commit_preserves_atomic_checkpoint(self):
        snapshots=[self.app.live_snapshot(1,self.message(i,media=True),100,'Chat','group') for i in range(1,4)]
        with self.app.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title) VALUES(1,100,'Chat')")
        script='''
import asyncio,importlib.util,json,os,sys
from contextlib import contextmanager
spec=importlib.util.spec_from_file_location('crash_app',sys.argv[1])
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
batch=json.load(sys.stdin)
if sys.argv[2]=='before':
    original=a.db
    @contextmanager
    def crash_db(*args,**kwargs):
        with original(*args,**kwargs) as c:
            yield c
            os._exit(17)
    a.db=crash_db
asyncio.run(a.write_call(a.persist_live_batch,batch,True,(1,100,'forward',3)))
os._exit(18)
'''
        for mode,code,count in [('before',17,0),('after',18,3)]:
            result=await asyncio.to_thread(subprocess.run,[sys.executable,'-c',script,str(self.root/'app.py'),mode],
                input=json.dumps(snapshots),capture_output=True,text=True,timeout=20)
            self.assertEqual(result.returncode,code,result.stderr[-1000:])
            with self.app.db() as c:
                self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
                self.assertEqual(c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],count)
                self.assertEqual(c.execute('SELECT COUNT(*) FROM archive_jobs').fetchone()[0],count)
                self.assertEqual(c.execute('SELECT history_cursor FROM chats').fetchone()[0],count)

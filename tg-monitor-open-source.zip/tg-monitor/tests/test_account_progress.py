"""Archive totals must not be confused with the current history pass."""
import unittest
import test_reliable_ingest


class AccountProgressTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown

    async def test_archive_chat_count_matches_chat_list_independent_of_backfill(self):
        with self.app.db() as c:
            c.executemany("INSERT INTO chats(account_id,chat_id,title) VALUES(?,?,?)",
                          [(1, 100, 'Saved'), (1, 200, 'Empty'), (1, 300, 'Partial'),
                           (2, 400, 'Other account')])
            c.executemany("INSERT INTO messages(account_id,chat_id,msg_id) VALUES(?,?,?)",
                          [(1, 100, 1), (1, 100, 2), (1, 300, 1), (2, 400, 1)])
        self.app.BACKFILL[1] = {'state': 'running', 'done': 0, 'total': 1493}
        account = next(a for a in self.app.api_accounts() if a['id'] == 1)
        self.assertEqual(account['n_chats'], len(self.app.api_chats(1)))
        self.assertEqual(account['n_chats'], 2)
        self.assertEqual(account['n'], 3)
        self.assertEqual(account['bf']['done'], 0)

import configparser
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SOURCE=Path(__file__).resolve().parents[1]

class LauncherConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        spec=importlib.util.spec_from_file_location("launcher_test",SOURCE/"launcher.py")
        self.launcher=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.launcher)
        self.home=self.root/"new archive"
    def tearDown(self): self.temp.cleanup()
    def defaults(self):
        (self.root/"app-defaults.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash="+"0"*32+
            "\n[server]\nport=9999\n[security]\npanel_password=do-not-copy\n",encoding="utf-8")
    def initialize(self):
        with patch.object(sys,"_MEIPASS",str(self.root),create=True):
            self.launcher.ensure_configuration(self.home)
    def test_first_launch_uses_application_keys_and_fresh_local_settings(self):
        self.defaults();self.initialize()
        c=configparser.ConfigParser();c.read(self.home/"config.ini",encoding="utf-8")
        self.assertEqual(c.get("telegram","api_id"),"12345")
        self.assertEqual(c.get("telegram","api_hash"),"0"*32)
        self.assertEqual(c.getint("server","port"),9999)
        self.assertEqual(c.get("security","panel_password"),"")
        self.assertFalse((self.home/"monitor.db").exists())
    def test_existing_configuration_is_not_replaced(self):
        self.launcher.write_configuration(self.home,67890,"1"*32,port=8091,password="existing")
        before=(self.home/"config.ini").read_bytes()
        self.defaults();self.initialize()
        self.assertEqual((self.home/"config.ini").read_bytes(),before)
    def test_unconfigured_public_build_does_not_create_invalid_configuration(self):
        with self.assertRaises(ValueError): self.initialize()
        self.assertFalse((self.home/"config.ini").exists())
    def test_invalid_application_defaults_fail_before_creating_config(self):
        (self.root/"app-defaults.ini").write_text("[telegram]\napi_id=wrong\napi_hash=wrong\n",encoding="utf-8")
        with self.assertRaises(ValueError): self.initialize()
        self.assertFalse((self.home/"config.ini").exists())

import configparser
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SOURCE=Path(__file__).resolve().parents[1]

class LauncherConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        spec=importlib.util.spec_from_file_location("launcher_test",SOURCE/"launcher.py")
        self.launcher=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.launcher)
        self.home=self.root/"new archive"
    def tearDown(self): self.temp.cleanup()
    def defaults(self):
        (self.root/"app-defaults.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash="+"0"*32+
            "\n[server]\nport=9999\n[security]\npanel_password=do-not-copy\n",encoding="utf-8")
    def initialize(self):
        with patch.object(sys,"_MEIPASS",str(self.root),create=True):
            self.launcher.ensure_configuration(self.home)
    def test_first_launch_uses_application_keys_and_fresh_local_settings(self):
        self.defaults();self.initialize()
        c=configparser.ConfigParser();c.read(self.home/"config.ini",encoding="utf-8")
        self.assertEqual(c.get("telegram","api_id"),"12345")
        self.assertEqual(c.get("telegram","api_hash"),"0"*32)
        self.assertEqual(c.getint("server","port"),9999)
        self.assertEqual(c.get("security","panel_password"),"")
        self.assertFalse((self.home/"monitor.db").exists())
    def test_existing_configuration_is_not_replaced(self):
        self.launcher.write_configuration(self.home,67890,"1"*32,port=8091,password="existing")
        before=(self.home/"config.ini").read_bytes()
        self.defaults();self.initialize()
        self.assertEqual((self.home/"config.ini").read_bytes(),before)
    def test_unconfigured_public_build_does_not_create_invalid_configuration(self):
        with self.assertRaises(ValueError): self.initialize()
        self.assertFalse((self.home/"config.ini").exists())
    def test_invalid_application_defaults_fail_before_creating_config(self):
        (self.root/"app-defaults.ini").write_text("[telegram]\napi_id=wrong\napi_hash=wrong\n",encoding="utf-8")
        with self.assertRaises(ValueError): self.initialize()
        self.assertFalse((self.home/"config.ini").exists())

    @unittest.skipUnless(sys.platform == "win32", "Desktop form requires Windows Tcl/Tk")
    def test_setup_validates_before_saving_and_runs_callback_once(self):
        import tkinter as tk
        from tkinter import ttk
        root = tk.Tk()
        root.withdraw()
        try:
            calls = []
            values, save, error = self.launcher.configuration_form(root, ttk.Frame(root), self.home,
                                                                   lambda: calls.append("start"))
            values["api_id"].set("wrong")
            values["api_hash"].set("0" * 32)
            save()
            self.assertTrue(error.get())
            self.assertFalse(self.home.exists())
            self.assertEqual(calls, [])
            values["api_id"].set(" 12345 ")
            values["api_hash"].set(" " + "0" * 32 + " ")
            values["password"].set("panel%password")
            save()
            self.assertEqual(calls, ["start"])
            cfg = configparser.ConfigParser(interpolation=None)
            cfg.read(self.home / "config.ini", encoding="utf-8")
            self.assertEqual(cfg.get("telegram", "api_id"), "12345")
            self.assertEqual(cfg.get("security", "panel_password"), "panel%password")
        finally:
            root.destroy()

    @unittest.skipUnless(sys.platform == "win32", "Desktop form requires Windows Tcl/Tk")
    def test_closing_setup_does_not_create_configuration(self):
        import tkinter as tk
        from tkinter import ttk
        root = tk.Tk()
        root.withdraw()
        self.launcher.configuration_form(root, ttk.Frame(root), self.home, lambda: self.fail("Unexpected start"))
        root.destroy()
        self.assertFalse(self.home.exists())


class ProcessPriorityTests(unittest.TestCase):
    def setUp(self):
        spec = importlib.util.spec_from_file_location("launcher_priority_test", SOURCE / "launcher.py")
        self.launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.launcher)

    @unittest.skipUnless(sys.platform == "win32", "Windows process priorities")
    def test_low_disk_priority_of_scheduled_task_is_restored_to_normal(self):
        import ctypes
        kernel32, ntdll = ctypes.windll.kernel32, ctypes.windll.ntdll
        process = ctypes.c_void_p(-1)
        def io_priority():
            value = ctypes.c_ulong()
            self.assertEqual(ntdll.NtQueryInformationProcess(process, 33, ctypes.byref(value), 4, None), 0)
            return value.value
        low = ctypes.c_ulong(1)                     # what a priority-7 scheduled task gets
        self.assertEqual(ntdll.NtSetInformationProcess(process, 33, ctypes.byref(low), 4), 0)
        try:
            self.assertEqual(io_priority(), 1)
            applied = self.launcher.restore_normal_priority()
            self.assertIn("io", applied)
            self.assertIn("cpu", applied)
            self.assertEqual(io_priority(), 2)
            self.assertEqual(kernel32.GetPriorityClass(process), 0x20)
        finally:
            normal = ctypes.c_ulong(2)
            ntdll.NtSetInformationProcess(process, 33, ctypes.byref(normal), 4)

    def test_priority_restore_never_raises(self):
        self.assertIsInstance(self.launcher.restore_normal_priority(), list)


class RotatingLogTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        spec = importlib.util.spec_from_file_location("launcher_log_test", SOURCE / "launcher.py")
        self.launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.launcher)

    def tearDown(self):
        self.temp.cleanup()

    def test_log_rotates_while_running_and_keeps_bounded_copies(self):
        path = self.root / "run.log"
        log = self.launcher.RotatingLog(path, max_bytes=100, backups=2)
        for n in range(40):
            print(f"line {n:03d} " + "x" * 20, file=log)
        log.close()
        files = sorted(p.name for p in self.root.iterdir())
        self.assertEqual(files, ["run.log", "run.log.1", "run.log.2"])
        self.assertTrue(all((self.root / name).stat().st_size < 140 for name in files))
        self.assertIn("line 039", path.read_text(encoding="utf-8") + (self.root / "run.log.1").read_text(encoding="utf-8"))

    def test_oversized_log_from_previous_version_is_rotated_on_start(self):
        path = self.root / "run.log"
        path.write_bytes(b"old\n" * 100)  # exact size on Windows too
        log = self.launcher.RotatingLog(path, max_bytes=100)
        log.write("new\n")
        log.close()
        self.assertEqual(path.read_text(encoding="utf-8"), "new\n")
        self.assertEqual((self.root / "run.log.1").stat().st_size, 400)

    def test_refused_rename_keeps_writing(self):
        path = self.root / "run.log"
        log = self.launcher.RotatingLog(path, max_bytes=50)
        with patch.object(self.launcher.os, "replace", side_effect=PermissionError("in use")):
            for n in range(10):
                log.write(f"entry {n} " + "y" * 10 + "\n")
        log.close()
        self.assertIn("entry 9", path.read_text(encoding="utf-8"))
        self.assertFalse((self.root / "run.log.1").exists())

    def test_log_never_raises_when_reopening_fails(self):
        path = self.root / "run.log"
        log = self.launcher.RotatingLog(path, max_bytes=30)
        real_open = log._open
        log._open = lambda: (_ for _ in ()).throw(PermissionError("locked"))
        for n in range(5):
            line = f"lost {n} " + "z" * 30 + "\n"
            self.assertEqual(log.write(line), len(line))
        log.flush()
        log._open = real_open
        log.write("back\n")
        log.close()
        self.assertEqual(path.read_text(encoding="utf-8"), "back\n")
        self.assertTrue((self.root / "run.log.1").exists())

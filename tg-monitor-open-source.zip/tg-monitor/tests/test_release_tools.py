"""Release helper checks on synthetic files; no real release is read or written."""
import hashlib
import importlib.util
import re
import tempfile
import unittest
from pathlib import Path


SOURCE = Path(__file__).resolve().parents[1]
PREVIOUS = """\ufeff# Updater
$release = 'C:\\ProgramData\\TGMonitorReleases\\1.2.21-verified-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
$expectedArchiveSha = '{old_sha}'
$baseUrl = 'https://github.com/example/repo/releases/download/v1.2.21'
if (-not $oldHealth.ok -or $oldHealth.installation -ne $installation -or $oldHealth.version -notin @('1.2.19','1.2.20')) {{ throw 'old' }}
$transportParts = @(
    @{{name='TGMonitor-Windows-x64.zip.part01';sha='{old_sha}'}},
    @{{name='TGMonitor-Windows-x64.zip.part02';sha='{old_sha}'}}
)
$backup = 'C:\\ProgramData\\TGMonitorBackups\\before-1.2.21-verified-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
    $health = Wait-TGHealth '1.2.21'
    $ui = (Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8090/static/app.js?v=1' -TimeoutSec 10).Content
    try {{ Wait-TGHealth $oldHealth.version | Out-Null }} catch {{ }}
""".format(old_sha="A" * 64).replace("\n", "\r\n")


class ReleaseToolsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-release-tools-")
        self.root = Path(self.temp.name)
        spec = importlib.util.spec_from_file_location("tg_release_tools_test", SOURCE / "scripts" / "release_tools.py")
        self.tools = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.tools)
        self.archive = self.root / "TGMonitor-Windows-x64.zip"
        self.archive.write_bytes(bytes(range(256)) * 41)
        self.previous = self.root / "update_server_1_2_21.ps1"
        self.previous.write_bytes(PREVIOUS.encode("utf-8"))

    def tearDown(self):
        self.temp.cleanup()

    def test_split_parts_reassemble_and_are_never_overwritten(self):
        report = self.tools.split(self.archive, 3)
        parts = sorted(self.root.glob("*.part*"))
        self.assertEqual([p.name for p in parts], [f"TGMonitor-Windows-x64.zip.part0{n}" for n in (1, 2, 3)])
        self.assertEqual(b"".join(p.read_bytes() for p in parts), self.archive.read_bytes())
        self.assertEqual(report["sha256"], hashlib.sha256(self.archive.read_bytes()).hexdigest().upper())
        with self.assertRaises(SystemExit):
            self.tools.split(self.archive, 3)

    def test_updater_changes_only_release_values(self):
        self.tools.split(self.archive, 2)
        version = self.tools.source_version()
        target = self.root / "next.ps1"
        report = self.tools.make_updater(self.previous, self.archive, version, ["1.2.21"], target)
        raw = target.read_bytes()
        self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
        self.assertNotIn(b"\n", raw.replace(b"\r\n", b""))
        text = raw.decode("utf-8-sig")
        self.assertIn(f"TGMonitorReleases\\{version}-verified-", text)
        self.assertIn(f"/download/v{version}'", text)
        self.assertIn(f"Wait-TGHealth '{version}'", text)
        self.assertIn("-notin @('1.2.21')", text)
        self.assertIn(report["archive_sha256"], text)
        self.assertNotIn("A" * 64, text)
        cache_key = re.search(r"app\.js\?v=(\d+)", (SOURCE / "frontend" / "index.html").read_text(encoding="utf-8")).group(1)
        self.assertIn(f"app.js?v={cache_key}'", text)
        self.assertEqual(len(PREVIOUS.splitlines()), len(text.splitlines()))
        with self.assertRaises(SystemExit):  # never replace an existing updater
            self.tools.make_updater(self.previous, self.archive, version, ["1.2.21"], target)

    def test_updater_refuses_zip_built_before_the_source(self):
        import os
        self.tools.split(self.archive, 2)
        old = (SOURCE / "app.py").stat().st_mtime - 3600
        os.utime(self.archive, (old, old))
        with self.assertRaises(SystemExit):
            self.tools.make_updater(self.previous, self.archive, self.tools.source_version(), ["1.2.21"],
                                    self.root / "next.ps1")

    def test_updater_refuses_unexpected_previous_script(self):
        self.tools.split(self.archive, 2)
        self.previous.write_text(PREVIOUS.replace("$expectedArchiveSha", "$otherSha"), encoding="utf-8")
        target = self.root / "next.ps1"
        with self.assertRaises(SystemExit):
            self.tools.make_updater(self.previous, self.archive, self.tools.source_version(), ["1.2.21"], target)
        self.assertFalse(target.exists())


if __name__ == "__main__":
    unittest.main()

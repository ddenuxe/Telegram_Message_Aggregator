const {test} = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../frontend/app.js'), 'utf8');
function extract(start, end) { return source.slice(source.indexOf(start), source.indexOf(end, source.indexOf(start))); }

function deleteContext(failSecond = false) {
  const notices = [], calls = [], refreshes = [];
  const context = vm.createContext({
    catalogFiles: [{account_id: 1, chat_id: 10, msg_id: 1, record_state: 'messages'},
      {account_id: 2, chat_id: 20, msg_id: 2, record_state: 'messages'}],
    document: {querySelectorAll: () => [{dataset: {index: '0'}}, {dataset: {index: '1'}}]},
    mediaActionBusy: 0, pl: (_n, singular) => singular, btnBusy: () => {}, askDeleteConfirmation: async () => true,
    j: async (_url, opts) => {
      calls.push(JSON.parse(opts.body));
      if (failSecond && calls.length === 2) throw new Error('Сбой соединения');
      return {detached: 1, files: 0, failed: 1, protected: 0};
    },
    toast: (text, kind) => notices.push({text, kind}),
    loadMediaCatalog: async () => refreshes.push('catalog'), loadStorageStats: () => refreshes.push('storage'),
  });
  vm.runInContext(extract('async function deleteCatalogFiles(', 'async function openMediaContext('), context);
  return {context, notices, calls, refreshes};
}

test('bulk deletion reports disk failures and refreshes storage', async () => {
  const {context, notices, calls, refreshes} = deleteContext();
  await context.deleteCatalogFiles({});
  assert.equal(calls.length, 2);
  assert.match(notices[0].text, /не удалось удалить с диска: 2/);
  assert.equal(notices[0].kind, 'err');
  assert.deepEqual(refreshes.sort(), ['catalog', 'storage']);
  assert.equal(context.mediaActionBusy, 0);
});

test('partial bulk failure reports completed items and reloads remaining files', async () => {
  const {context, notices, refreshes} = deleteContext(true);
  await context.deleteCatalogFiles({});
  assert.match(notices[0].text, /Удалено вложений: 1/);
  assert.match(notices[0].text, /Сбой соединения/);
  assert.equal(notices[0].kind, 'err');
  assert.deepEqual(refreshes.sort(), ['catalog', 'storage']);
  assert.equal(context.mediaActionBusy, 0);
});

test('deleted Telegram file preserves its unavailable status even when the local file is missing', () => {
  const elements = {'media-catalog-list': {}, 'media-load-more': {}};
  const context = vm.createContext({catalogFiles: [{msg_id: 1, file_path: 'media/test.pdf',
    file_exists: false, partial_exists: false, media_status: 'unavailable', file_name: 'test.pdf',
    media_type: 'document', record_state: 'messages'}], catalogMore: false,
    MEDIA_LABEL: {}, esc: value => String(value || ''), fmtDate: () => '', formatBytes: () => '',
    $: id => elements[id], updateCatalogSelection: () => {}});
  vm.runInContext(extract('function renderMediaCatalog(', 'function updateCatalogSelection('), context);
  context.renderMediaCatalog();
  assert.match(elements['media-catalog-list'].innerHTML, /Файл удалён или недоступен в Telegram/);
  assert.doesNotMatch(elements['media-catalog-list'].innerHTML, /Попробовать загрузить/);
});

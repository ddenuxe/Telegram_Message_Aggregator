const {test} = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../frontend/app.js'), 'utf8');
function extract(start, end) { return source.slice(source.indexOf(start), source.indexOf(end, source.indexOf(start))); }

function deleteContext(failSecond = false) {
  const notices = [], calls = [], refreshes = [];
  const context = vm.createContext({
    catalogFiles: [{account_id: 1, chat_id: 10, msg_id: 1, record_state: 'messages'},
      {account_id: 2, chat_id: 20, msg_id: 2, record_state: 'messages'}],
    document: {querySelectorAll: () => [{dataset: {index: '0'}}, {dataset: {index: '1'}}]},
    mediaActionBusy: 0, pl: (_n, singular) => singular, btnBusy: () => {}, askDeleteConfirmation: async () => true,
    j: async (_url, opts) => {
      calls.push(JSON.parse(opts.body));
      if (failSecond && calls.length === 2) throw new Error('Сбой соединения');
      return {detached: 1, files: 0, failed: 1, protected: 0};
    },
    toast: (text, kind) => notices.push({text, kind}),
    loadMediaCatalog: async () => refreshes.push('catalog'), loadStorageStats: () => refreshes.push('storage'),
  });
  vm.runInContext(extract('async function deleteCatalogFiles(', 'async function openMediaContext('), context);
  return {context, notices, calls, refreshes};
}

test('bulk deletion reports disk failures and refreshes storage', async () => {
  const {context, notices, calls, refreshes} = deleteContext();
  await context.deleteCatalogFiles({});
  assert.equal(calls.length, 2);
  assert.match(notices[0].text, /не удалось удалить с диска: 2/);
  assert.equal(notices[0].kind, 'err');
  assert.deepEqual(refreshes.sort(), ['catalog', 'storage']);
  assert.equal(context.mediaActionBusy, 0);
});

test('partial bulk failure reports completed items and reloads remaining files', async () => {
  const {context, notices, refreshes} = deleteContext(true);
  await context.deleteCatalogFiles({});
  assert.match(notices[0].text, /Удалено вложений: 1/);
  assert.match(notices[0].text, /Сбой соединения/);
  assert.equal(notices[0].kind, 'err');
  assert.deepEqual(refreshes.sort(), ['catalog', 'storage']);
  assert.equal(context.mediaActionBusy, 0);
});

test('deleted Telegram file preserves its unavailable status even when the local file is missing', () => {
  const elements = {'media-catalog-list': {}, 'media-load-more': {}};
  const context = vm.createContext({catalogFiles: [{msg_id: 1, file_path: 'media/test.pdf',
    file_exists: false, partial_exists: false, media_status: 'unavailable', file_name: 'test.pdf',
    media_type: 'document', record_state: 'messages'}], catalogMore: false, catalogTarget: null,
    avatar: () => '', mediaFileURL: () => '/api/media/file',
    MEDIA_LABEL: {}, esc: value => String(value || ''), fmtDate: () => '', formatBytes: () => '',
    $: id => elements[id], updateCatalogSelection: () => {}});
  vm.runInContext(extract('function renderMediaCatalog(', 'function updateCatalogSelection('), context);
  context.renderMediaCatalog();
  assert.match(elements['media-catalog-list'].innerHTML, /Файл удалён или недоступен в Telegram/);
  assert.doesNotMatch(elements['media-catalog-list'].innerHTML, /Попробовать загрузить/);
});

test('login preserves the server reason and restores the submit button', async () => {
  const elements = {'login-pass': {value: 'wrong'}, 'login-status': {}, 'login-modal': {style: {display: 'flex'}}};
  const button = {dataset: {}, textContent: 'Войти', disabled: false, isConnected: true};
  const context = vm.createContext({$: id => elements[id], fetch: async () => ({status: 401, ok: false, json: async () => ({reason: 'неверный пароль'})}), location: {reload: () => assert.fail('must not reload')}, TypeError});
  vm.runInContext(extract('async function j(', 'const esc ='), context);
  vm.runInContext(extract('function btnBusy(', 'async function connectAccount('), context);
  await context.doLogin(button);
  assert.equal(elements['login-status'].textContent, 'неверный пароль');
  assert.equal(button.disabled, false);
  assert.equal(button.textContent, 'Войти');
});

test('account actions recover after failure even if account data has not changed', async () => {
  const notices = [], button = {dataset: {}, textContent: 'Продолжить', isConnected: true};
  const context = vm.createContext({j: async () => {throw new Error('Сервер занят');}, toast: text => notices.push(text), loadAccounts: () => {}});
  vm.runInContext(extract('function btnBusy(', 'async function connectAccount('), context);
  vm.runInContext(extract('async function act(', 'async function discAccount('), context);
  for (const action of ['act', 'bfStart', 'bfStop']) {
    await context[action](button, 1, 'resume');
    assert.equal(button.disabled, false);
    assert.equal(button.textContent, 'Продолжить');
  }
  assert.equal(notices[0], 'Сервер занят');
});

function connectionContext() {
  const elements = new Map(), calls = [];
  const element = id => {
    if (!elements.has(id)) elements.set(id, {style: {}, value: '', textContent: '', dataset: {}, isConnected: true, classList: {remove(){}, toggle(){}}, focus(){}});
    return elements.get(id);
  };
  let resolveRequest;
  const response = new Promise(resolve => {resolveRequest = resolve;});
  const context = vm.createContext({$: element, crypto: require('node:crypto').webcrypto, AbortSignal, toast(){},
    document: {activeElement: element('opener')}, clearInterval(){}, setInterval(){assert.fail('a closed dialog must not start polling');}, loadAccounts(){}, j: async url => {
    calls.push(url);
    if (url.endsWith('/add') || url.endsWith('/add-phone')) return response;
    return {ok: true};
  }});
  vm.runInContext(extract('let qrFid =', '// ---------- чаты и лента'), context);
  return {context, element, calls, resolveRequest};
}

test('closing before the QR response cancels the late Telegram connection', async () => {
  const {context, element, calls, resolveRequest} = connectionContext();
  const pending = context.connectAccount(element('opener'));
  context.closeQr();
  resolveRequest({ok: true, fid: 'late-qr'});
  await pending;
  assert.ok(calls.includes('/api/qr/late-qr/cancel'));
  assert.equal(element('qr-modal').style.display, 'none');
  assert.equal(element('opener').disabled, false);
});

test('closing before the phone response cancels the late Telegram connection', async () => {
  const {context, element, calls, resolveRequest} = connectionContext();
  element('ph-phone').value = '+123456789';
  const pending = context.phoneSendCode(element('send'));
  await Promise.resolve(); // let the request pass its pending-cancellation barrier
  context.closeQr();
  resolveRequest({ok: true, fid: 'late-phone'});
  await pending;
  assert.ok(calls.includes('/api/phone/late-phone/cancel'));
  assert.equal(element('send').disabled, false);
});

test('attachment URLs use database identities rather than raw filename paths', () => {
  const context = vm.createContext({URLSearchParams});
  vm.runInContext(extract('function mediaFileURL(', 'function accountLabel('), context);
  assert.equal(context.mediaFileURL(1, -100, 7), '/api/media/file?account_id=1&chat_id=-100&msg_id=7&source=messages');
});

test('avatars preserve initials and request the correct account and entity', () => {
  const context = vm.createContext({PALETTE: ['red'], esc: s => String(s || '')});
  vm.runInContext(extract('function avatar(', 'function mediaFileURL('), context);
  const html = context.avatar(2, 'Alice User', 32, 1, 42);
  assert.match(html, /AU/);
  assert.match(html, /\/api\/accounts\/1\/avatar\?entity_id=42/);
  assert.match(html, /onerror="this.remove\(\)"/);
});

test('outgoing messages use the account identity and files navigate to their catalog entry', () => {
  const elements = {feed: {}};
  const context = vm.createContext({currentAccount: 1, currentChatId: 10, currentChatTitle: 'Chat',
    accountList: [{id: 1, username: 'owner'}], feedMessages: [], feedHasOlder: false,
    MEDIA_LABEL: {document: 'Документ'}, esc: s => String(s || ''), fmtDay: () => '', fmtDate: () => '',
    hlOutsideTags: x => x, linkify: x => x, initPlayers: () => {}, avatar: () => '<span class="ava"></span>',
    mediaFileURL: () => '/api/media/file?account_id=1&chat_id=10&msg_id=7', $: id => elements[id]});
  vm.runInContext(extract('function renderFeedMessages(', '// ---------- поиск внутри чата'), context);
  context.renderFeedMessages([{msg_id: 7, out: 1, date: '2026-10-12', media_type: 'document', file_path: 'media/a #%.pdf'}], '');
  const html = elements.feed.innerHTML;
  assert.match(html, /@owner/);
  assert.doesNotMatch(html, />ТЫ</);
  assert.match(html, /data-action="catalog-file"/);
  assert.match(html, /data-msg-id="7"/);
  assert.doesNotMatch(html, /reveal-file/);
});

test('busy state does not destroy the markup of the add-account card', () => {
  const card = {tagName:'DIV', innerHTML:'<span>Подключить аккаунт</span>', textContent:'Подключить аккаунт', dataset:{}};
  const context = vm.createContext({});
  vm.runInContext(extract('function btnBusy(', 'async function connectAccount('), context);
  context.btnBusy(card,true,'Готовлю…');
  context.btnBusy(card,false);
  assert.equal(card.innerHTML,'<span>Подключить аккаунт</span>');
  assert.equal(card.textContent,'Подключить аккаунт');
});

const {test} = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../frontend/app.js'), 'utf8');
function extract(start, end) { return source.slice(source.indexOf(start), source.indexOf(end, source.indexOf(start))); }

function progressCard(overrides = {}) {
  const context = vm.createContext({Number, Date,
    esc: s => String(s ?? '').replaceAll('<', '&lt;').replaceAll('>', '&gt;'),
    avatar: () => '', accountLabel: () => 'Account', fmtDate: () => '',
    pl: (_n, one) => one, ST_LABEL: {recording: 'запись идёт'}});
  if (source.includes('function formatCount('))
    vm.runInContext(extract('function formatCount(', 'function acctCard('), context);
  vm.runInContext(extract('function acctCard(', 'function refreshSearchAccounts('), context);
  return context.acctCard({id: 1, status: 'recording', n: 800380, n_chats: 444,
    bf: {state: 'running', done: 5, total: 1493, msgs: 148069,
      current_chat: '<Large chat>', current_message: 170521},
    ingest: {pending: 396412, active: 1, retrying: 0}, ...overrides}, false);
}

// [tone, text] of one card row: "Новые сообщения", "Старые сообщения" or "Фото и файлы".
function row(html, name) {
  const m = html.match(new RegExp(`<i class="dot ?(ok|warn|err)?"></i><span class="acct-row-name">${name}</span>` +
    `<span class="acct-row-text[^"]*">([^<]*)</span>`));
  assert.ok(m, `row ${name} missing`);
  return [m[1] || '', m[2].replace(/ /g, ' ')];
}
const DONE = {saved: 100, total: 100, discovered: 1, unknown: 0, chats: 1, completed_chats: 1};

test('archive progress is weighted by messages and never invents unknown totals', () => {
  const context = vm.createContext({Number, Date});
  vm.runInContext(extract('function formatCount(', 'function acctCard('), context);
  const account=(saved,total,complete=false)=>({progress:{saved,total,discovered:1,unknown:0,chats:1,completed_chats:complete?1:0}});
  const html=context.archiveProgress([account(90,100),account(0,900)],true);
  assert.match(html,/Весь архив/);
  assert.match(html,/9%/);
  assert.match(html,/Сообщений сохранено: 90 из 1\s000 · файлов осталось скачать: 0/);
  assert.doesNotMatch(html,/45%/);
  const unknown=context.archiveProgress([account(90,100),{}],true);
  assert.match(unknown,/Сообщений сохранено: считаем…/);
  assert.doesNotMatch(unknown,/aria-valuenow|\d+%/);
  assert.match(context.archiveProgress([account(100,100)]),/99%/);
  assert.match(context.archiveProgress([account(100,100,true)]),/100%/);
  assert.match(context.archiveProgress([{...account(100,100,true),bf:{state:'partial'}}]),/99%/);
  assert.match(context.archiveProgress([account(0,0,true)]),/100%/);
  assert.doesNotMatch(context.archiveProgress([account(90,100)]),/progress-detail/);  // the card rows explain it
});

test('files still in the queue keep the whole archive below 100%', () => {
  const context = vm.createContext({Number, Date});
  vm.runInContext(extract('function formatCount(', 'function acctCard('), context);
  const html = context.archiveProgress([{progress: DONE, ingest: {pending: 100}}], true);
  assert.match(html, /≈ 50%/);
  assert.match(html, /Сообщений сохранено: 100 из 100 · файлов осталось скачать: 100/);
  assert.doesNotMatch(html, /complete/);
  const done = context.archiveProgress([{progress: DONE, ingest: {pending: 0}}]);
  assert.match(done, />100%</);
  assert.match(done, /history-progress complete/);
});

test('the card says plainly what happens with new messages, old messages and files', () => {
  const html = progressCard();
  assert.deepEqual(row(html, 'Новые сообщения'), ['ok', 'сохраняются']);
  assert.deepEqual(row(html, 'Старые сообщения'), ['ok', 'загружаем']);
  assert.deepEqual(row(html, 'Фото и файлы'), ['ok', 'скачиваем, осталось 396 412']);
  const visible = html.replace(/<[^>]+>/g, ' ');
  assert.doesNotMatch(visible, /Это текущая проверка|Обработано сообщений в этом проходе|после проверки архива|Сохранено сообщений/);
  assert.doesNotMatch(html, /170521|профил|задач|5\/1493|bf-txt/);
  assert.equal((html.match(/class="acct-row"/g) || []).length, 3);
  assert.match(html, /запись|работает/);
});

test('an account whose Telegram session was revoked offers a new login', () => {
  const html = progressCard({status: 'error', bf: {state: 'error', done: 0, total: 0}});
  assert.match(html, /onclick="connectAccount\(this\)"[^>]*>Подключить заново</);
  assert.deepEqual(row(html, 'Новые сообщения'), ['err', 'не сохраняются — нажмите «Подключить заново»']);
  assert.deepEqual(row(html, 'Старые сообщения'), ['', 'догрузим после входа в аккаунт']);
  assert.deepEqual(row(html, 'Фото и файлы'), ['', 'осталось 396 412 — скачаем после входа в аккаунт']);
  assert.doesNotMatch(html, />Пауза</);
  assert.doesNotMatch(progressCard(), /Подключить заново/);
});

test('an account without a valid login offers only a new login or the archive', () => {
  const html = progressCard({status: 'error', bf: {state: 'partial', done: 3, total: 9}});
  assert.doesNotMatch(html, /Догрузить историю/);
  assert.doesNotMatch(html, />Отключить</);
  assert.match(html, /onclick="archiveAccount\(this,1\)"[^>]*>Убрать в архив</);
  const active = progressCard({bf: {state: 'partial', done: 3, total: 9}});
  assert.match(active, />Догрузить историю</);
  assert.match(active, /onclick="discAccount\(this,1\)">Отключить</);
  assert.doesNotMatch(active, /Убрать в архив/);
});

test('the history button appears only while old messages are missing', () => {
  const complete = progressCard({progress: DONE, bf: {state: 'done'}, ingest: {pending: 88, active: 0}});
  assert.doesNotMatch(complete, /Догрузить историю|Продолжить загрузку/);
  assert.deepEqual(row(complete, 'Старые сообщения'), ['ok', 'все сохранены']);
  assert.deepEqual(row(complete, 'Фото и файлы'), ['', 'осталось 88 — ждут своей очереди']);
  assert.match(progressCard({progress: {...DONE, completed_chats: 0}, bf: {state: 'partial'}}), />Догрузить историю</);
  assert.match(progressCard({bf: {state: 'running'}}), />Остановить загрузку истории</);
});

test('a Telegram pause request is explained and waited out', () => {
  const html = progressCard({bf: {state: 'running', done: 5, total: 1493,
    msgs: 0, errs: 2, wait_until: Date.now() / 1000 + 30, note: 'Ограничение Telegram'},
    ingest: {pending: 18, active: 0, retrying: 18}});
  assert.deepEqual(row(html, 'Старые сообщения'), ['warn', 'Telegram попросил подождать — продолжим сами']);
  assert.doesNotMatch(html, /Повтор после ошибки|18 задач/);
});

test('missing archive counts are not presented as zero and completed history does not imply downloaded files', () => {
  const html = progressCard({n_chats: undefined, progress: DONE, bf: {state: 'done', done: 1493, total: 1493}});
  assert.doesNotMatch(html, /undefined|В архиве:.*0.*чат/);
  assert.deepEqual(row(html, 'Фото и файлы'), ['ok', 'скачиваем, осталось 396 412']);
});

test('green means done or working, grey waits, orange needs time or a click, red is broken', () => {
  assert.deepEqual(row(progressCard({bf: {state:'queued'}}), 'Старые сообщения'), ['', 'ждут своей очереди']);
  const paused = progressCard({status:'paused', bf:{state:'stopped'}});
  assert.deepEqual(row(paused, 'Новые сообщения'), ['', 'не сохраняются — стоит пауза']);
  assert.deepEqual(row(paused, 'Фото и файлы'), ['', 'осталось 396 412 — стоит на паузе']);
  const done = progressCard({progress: DONE, bf:{state:'done'}, ingest:{pending:0}});
  assert.deepEqual([row(done, 'Новые сообщения'), row(done, 'Старые сообщения'), row(done, 'Фото и файлы')],
    [['ok', 'сохраняются'], ['ok', 'все сохранены'], ['ok', 'все скачаны']]);
  assert.deepEqual(row(progressCard({bf:{state:'done'},ingest:{pending:5,active:0,wait_until:Date.now()/1000+60}}), 'Фото и файлы'),
    ['', 'осталось 5 — повторим попытку чуть позже']);
  assert.deepEqual(row(progressCard({bf:{state:'partial'},ingest:{pending:0}}), 'Старые сообщения'),
    ['warn', 'сохранены не все — нажмите «Догрузить историю»']);
  assert.deepEqual(row(progressCard({status:'reconnecting',bf:{state:'done'}}), 'Новые сообщения'),
    ['warn', 'нет связи с Telegram, подключаемся снова']);
  assert.deepEqual(row(progressCard({bf:{state:'done'},ingest:{pending:0,storage_error:true}}), 'Новые сообщения'),
    ['err', 'не сохраняются — не получается записать на диск']);
});

test('resume reports backend outcome and awaits fresh status before enabling button', async () => {
  let finishRefresh, refreshed=false;
  const refresh = new Promise(resolve=>{finishRefresh=resolve;});
  const notices=[], button={dataset:{},textContent:'Продолжить загрузку',isConnected:true};
  const context=vm.createContext({lastAccountSnapshot:'old',
    j:async()=>({ok:true,started:false,reason:'Фото продолжают сохраняться'}),
    toast:text=>notices.push(text),loadAccounts:async()=>{refreshed=true;await refresh;}});
  vm.runInContext(extract('function btnBusy(', 'async function connectAccount('),context);
  vm.runInContext(extract('async function bfStart(', 'async function bfStop('),context);
  const action=context.bfStart(button,1);
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(refreshed,true);
  assert.equal(button.disabled,true);
  assert.deepEqual(notices,['Фото продолжают сохраняться']);
  assert.equal(context.lastAccountSnapshot,null);
  finishRefresh(); await action;
  assert.equal(button.disabled,false);
});

test('periodic refresh skips hidden tabs and does not overlap slow requests', async () => {
  let calls = 0, finish;
  const slow = new Promise(resolve => { finish = resolve; });
  const context = vm.createContext({
    document: {hidden: true, querySelector: () => null},
    currentView: 'accounts', mediaActionBusy: 0,
    $: () => ({style: {display: 'none'}}),
    loadAccounts: () => { calls++; return slow; },
    refreshPendingMediaCount: async () => {}, loadStorageStats: async () => {},
    loadMediaCatalog: async () => {},
  });
  vm.runInContext(extract('let panelRefreshBusy', 'setInterval(refreshVisiblePanel'), context);
  await context.refreshVisiblePanel();
  assert.equal(calls, 0);
  context.document.hidden = false;
  const pending = context.refreshVisiblePanel();
  await context.refreshVisiblePanel();
  assert.equal(calls, 1);
  finish();
  await pending;
  await context.refreshVisiblePanel();
  assert.equal(calls, 2);
});

function deleteContext(failSecond = false) {
  const notices = [], calls = [], refreshes = [];
  const context = vm.createContext({
    catalogFiles: [{account_id: 1, chat_id: 10, msg_id: 1, record_state: 'messages'},
      {account_id: 2, chat_id: 20, msg_id: 2, record_state: 'messages'}],
    document: {querySelectorAll: () => [{dataset: {index: '0'}}, {dataset: {index: '1'}}]},
    mediaActionBusy: 0, pl: (_n, singular) => singular, btnBusy: () => {}, askDeleteConfirmation: async () => true,
    j: async (_url, opts) => {
      calls.push(JSON.parse(opts.body));
      if (failSecond && calls.length === 2) throw new Error('Сбой соединения');
      return {detached: 1, files: 0, failed: 1, protected: 0};
    },
    toast: (text, kind) => notices.push({text, kind}),
    loadMediaCatalog: async () => refreshes.push('catalog'), loadStorageStats: () => refreshes.push('storage'),
  });
  vm.runInContext(extract('async function deleteCatalogFiles(', 'async function openMediaContext('), context);
  return {context, notices, calls, refreshes};
}

test('bulk deletion reports disk failures and refreshes storage', async () => {
  const {context, notices, calls, refreshes} = deleteContext();
  await context.deleteCatalogFiles({});
  assert.equal(calls.length, 2);
  assert.match(notices[0].text, /не удалось удалить с диска: 2/);
  assert.equal(notices[0].kind, 'err');
  assert.deepEqual(refreshes.sort(), ['catalog', 'storage']);
  assert.equal(context.mediaActionBusy, 0);
});

test('partial bulk failure reports completed items and reloads remaining files', async () => {
  const {context, notices, refreshes} = deleteContext(true);
  await context.deleteCatalogFiles({});
  assert.match(notices[0].text, /Удалено вложений: 1/);
  assert.match(notices[0].text, /Сбой соединения/);
  assert.equal(notices[0].kind, 'err');
  assert.deepEqual(refreshes.sort(), ['catalog', 'storage']);
  assert.equal(context.mediaActionBusy, 0);
});

test('deleted Telegram file preserves its unavailable status even when the local file is missing', () => {
  const elements = {'media-catalog-list': {}, 'media-load-more': {}};
  const context = vm.createContext({catalogFiles: [{msg_id: 1, file_path: 'media/test.pdf',
    file_exists: false, partial_exists: false, media_status: 'unavailable', file_name: 'test.pdf',
    media_type: 'document', record_state: 'messages'}], catalogMore: false, catalogTarget: null,
    avatar: () => '', mediaFileURL: () => '/api/media/file',
    MEDIA_LABEL: {}, esc: value => String(value || ''), fmtDate: () => '', formatBytes: () => '',
    $: id => elements[id], updateCatalogSelection: () => {}});
  vm.runInContext(extract('function renderMediaCatalog(', 'function updateCatalogSelection('), context);
  context.renderMediaCatalog();
  assert.match(elements['media-catalog-list'].innerHTML, /Файл удалён или недоступен в Telegram/);
  assert.doesNotMatch(elements['media-catalog-list'].innerHTML, /Попробовать загрузить/);
});

test('login preserves the server reason and restores the submit button', async () => {
  const elements = {'login-pass': {value: 'wrong'}, 'login-status': {}, 'login-modal': {style: {display: 'flex'}}};
  const button = {dataset: {}, textContent: 'Войти', disabled: false, isConnected: true};
  const context = vm.createContext({$: id => elements[id], fetch: async () => ({status: 401, ok: false, json: async () => ({reason: 'неверный пароль'})}), location: {reload: () => assert.fail('must not reload')}, TypeError});
  vm.runInContext(extract('async function j(', 'const esc ='), context);
  vm.runInContext(extract('function btnBusy(', 'async function connectAccount('), context);
  await context.doLogin(button);
  assert.equal(elements['login-status'].textContent, 'неверный пароль');
  assert.equal(button.disabled, false);
  assert.equal(button.textContent, 'Войти');
});

test('account actions recover after failure even if account data has not changed', async () => {
  const notices = [], button = {dataset: {}, textContent: 'Продолжить', isConnected: true};
  const context = vm.createContext({j: async () => {throw new Error('Сервер занят');}, toast: text => notices.push(text), loadAccounts: () => {}});
  vm.runInContext(extract('function btnBusy(', 'async function connectAccount('), context);
  vm.runInContext(extract('async function act(', 'async function discAccount('), context);
  for (const action of ['act', 'bfStart', 'bfStop']) {
    await context[action](button, 1, 'resume');
    assert.equal(button.disabled, false);
    assert.equal(button.textContent, 'Продолжить');
  }
  assert.equal(notices[0], 'Сервер занят');
});

function connectionContext() {
  const elements = new Map(), calls = [];
  const element = id => {
    if (!elements.has(id)) elements.set(id, {style: {}, value: '', textContent: '', dataset: {}, isConnected: true, classList: {remove(){}, toggle(){}}, focus(){}});
    return elements.get(id);
  };
  let resolveRequest;
  const response = new Promise(resolve => {resolveRequest = resolve;});
  const context = vm.createContext({$: element, crypto: require('node:crypto').webcrypto, AbortSignal, toast(){},
    document: {activeElement: element('opener')}, clearInterval(){}, setInterval(){assert.fail('a closed dialog must not start polling');}, loadAccounts(){}, j: async url => {
    calls.push(url);
    if (url.endsWith('/add') || url.endsWith('/add-phone')) return response;
    return {ok: true};
  }});
  vm.runInContext(extract('let qrFid =', '// ---------- чаты и лента'), context);
  return {context, element, calls, resolveRequest};
}

test('closing before the QR response cancels the late Telegram connection', async () => {
  const {context, element, calls, resolveRequest} = connectionContext();
  const pending = context.connectAccount(element('opener'));
  context.closeQr();
  resolveRequest({ok: true, fid: 'late-qr'});
  await pending;
  assert.ok(calls.includes('/api/qr/late-qr/cancel'));
  assert.equal(element('qr-modal').style.display, 'none');
  assert.equal(element('opener').disabled, false);
});

test('closing before the phone response cancels the late Telegram connection', async () => {
  const {context, element, calls, resolveRequest} = connectionContext();
  element('ph-phone').value = '+123456789';
  const pending = context.phoneSendCode(element('send'));
  await Promise.resolve(); // let the request pass its pending-cancellation barrier
  context.closeQr();
  resolveRequest({ok: true, fid: 'late-phone'});
  await pending;
  assert.ok(calls.includes('/api/phone/late-phone/cancel'));
  assert.equal(element('send').disabled, false);
});

test('attachment URLs use database identities rather than raw filename paths', () => {
  const context = vm.createContext({URLSearchParams});
  vm.runInContext(extract('function mediaFileURL(', 'function accountLabel('), context);
  assert.equal(context.mediaFileURL(1, -100, 7), '/api/media/file?account_id=1&chat_id=-100&msg_id=7&source=messages');
});

test('avatars preserve initials and request the correct account and entity', () => {
  const context = vm.createContext({PALETTE: ['red'], esc: s => String(s || '')});
  vm.runInContext(extract('function avatar(', 'function mediaFileURL('), context);
  const html = context.avatar(2, 'Alice User', 32, 1, 42);
  assert.match(html, /AU/);
  assert.match(html, /\/api\/accounts\/1\/avatar\?entity_id=42/);
  assert.match(html, /onerror="this.remove\(\)"/);
});

test('outgoing messages use account identity and remote attachment clicks download directly', () => {
  const elements = {feed: {}};
  const context = vm.createContext({currentAccount: 1, currentChatId: 10, currentChatTitle: 'Chat',
    accountList: [{id: 1, username: 'owner'}], feedMessages: [], feedHasOlder: false,
    MEDIA_LABEL: {document: 'Документ'}, esc: s => String(s || ''), fmtDay: () => '', fmtDate: () => '',
    hlOutsideTags: x => x, linkify: x => x, initPlayers: () => {}, avatar: () => '<span class="ava"></span>',
    URLSearchParams, location:{hostname:'panel.example.com'}, $: id => elements[id]});
  vm.runInContext(extract('function mediaFileURL(', 'function accountLabel('), context);
  vm.runInContext(extract('function renderFeedMessages(', '// ---------- поиск внутри чата'), context);
  context.renderFeedMessages([{msg_id: 7, out: 1, date: '2026-10-12', media_type: 'document', file_path: 'media/a #%.pdf'}], '');
  const html = elements.feed.innerHTML;
  assert.match(html, /@owner/);
  assert.doesNotMatch(html, />ТЫ</);
  assert.match(html, /href="\/api\/media\/file\?account_id=1&amp;chat_id=10&amp;msg_id=7&amp;source=messages"|href="\/api\/media\/file\?account_id=1&chat_id=10&msg_id=7&source=messages"/);
  assert.match(html, / download /);
  assert.doesNotMatch(html, /catalog-file|reveal-media/);
});

test('local panel file buttons open the folder by database identity', () => {
  const context=vm.createContext({URLSearchParams,location:{hostname:'127.0.0.1'},esc:s=>String(s||'')});
  vm.runInContext(extract('function mediaFileURL(', 'function accountLabel('),context);
  const html=context.fileActionHTML(1,-100,7,'deleted','file.pdf');
  assert.match(html,/data-action="reveal-media"/);
  assert.match(html,/data-msg-id="7"/);
  assert.match(html,/data-source="deleted"/);
  assert.doesNotMatch(html,/href=|catalog-file/);
});

test('busy state does not destroy the markup of the add-account card', () => {
  const card = {tagName:'DIV', innerHTML:'<span>Подключить аккаунт</span>', textContent:'Подключить аккаунт', dataset:{}};
  const context = vm.createContext({});
  vm.runInContext(extract('function btnBusy(', 'async function connectAccount('), context);
  context.btnBusy(card,true,'Готовлю…');
  context.btnBusy(card,false);
  assert.equal(card.innerHTML,'<span>Подключить аккаунт</span>');
  assert.equal(card.textContent,'Подключить аккаунт');
});

test('after the QR scan only the password step stays on screen', async () => {
  const els = {};
  const $ = id => els[id] ||= {style: {display: 'block'}, textContent: '', focus() {}};
  const context = vm.createContext({$, connectionSeq: 1, qrFid: '5', qrTimer: 1,
    clearInterval() {}, Date, j: async () => ({state: 'pwd'})});
  vm.runInContext(extract('function refreshQr(', 'async function sendPwd('), context);
  await context.pollQr();
  assert.equal(els['qr-frame'].style.display, 'none');
  assert.equal(els['qr-hint'].style.display, 'none');
  assert.equal(els['qr-pwd'].style.display, 'block');
  assert.match(els['qr-status'].textContent, /Скан принят/);
});

test('progress shows remaining time only after enough samples of shrinking work', () => {
  const context = vm.createContext({Number, Date});
  vm.runInContext(extract('function formatCount(', 'function acctCard('), context);
  assert.equal(context.workRate('a', 4000, 0), null);
  assert.equal(context.workRate('a', 3500, 10000), null);
  assert.equal(context.workRate('a', 1000, 30000), 6000);
  assert.equal(context.workRate('b', 10, 0), null);
  assert.equal(context.workRate('b', 50, 30000), null);           // work grew: no speed
  assert.equal(context.formatDuration(0.5), 'меньше минуты');
  assert.equal(context.formatDuration(125), '~2 ч 5 мин');
  assert.equal(context.formatDuration(60 * 72), '~3 дн');
  const progress = {saved: 100, total: 1000, discovered: 1, unknown: 0, chats: 1, completed_chats: 0};
  assert.doesNotMatch(context.archiveProgress([{id: 8, progress}]), /Осталось/);
  const account = {id: 7, progress, ingest: {pending: 0}};
  context.workRate(7, 1000, Date.now() - 60000);
  assert.match(context.archiveProgress([account]), /Осталось примерно 9 мин/);
  const done = {...account, progress: {...account.progress, saved: 1000, completed_chats: 1}};
  assert.doesNotMatch(context.archiveProgress([done]), /Осталось/);
});

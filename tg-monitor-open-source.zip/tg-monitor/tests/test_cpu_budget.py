"""CPU feedback, fair page fetches and durable live/history separation."""
import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
import test_reliable_ingest


class CpuBudgetTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message

    def test_cpu_sampler_uses_system_delta_not_process_or_lifetime_average(self):
        readings=iter([(100,200),(140,300),(140,300),(170,400)])
        sampler=self.app.SystemCpuSampler(read_times=lambda:next(readings))
        self.assertIsNone(sampler.percent())
        self.assertEqual(sampler.percent(),60)
        self.assertIsNone(sampler.percent())
        self.assertEqual(sampler.percent(),70)

    async def test_high_cpu_pauses_then_resumes_below_hysteresis(self):
        readings=iter([72,59,54])
        tick=[0.0]; sleeps=[]
        async def sleep(seconds):
            tick[0]+=seconds; sleeps.append(seconds)
        budget=self.app.CpuBudget(sample=lambda:next(readings),clock=lambda:tick[0],sleep=sleep)
        await budget.wait_turn()
        self.assertGreaterEqual(tick[0],2)
        self.assertEqual(budget.snapshot()['cpu_percent'],54)
        self.assertFalse(budget.snapshot()['paused'])
        self.assertLessEqual(max(sleeps),0.25)

    async def test_missing_counter_does_not_deadlock_or_run_unpaced(self):
        tick=[0.0]
        async def sleep(seconds): tick[0]+=seconds
        budget=self.app.CpuBudget(sample=lambda:None,clock=lambda:tick[0],sleep=sleep)
        await budget.wait_turn(); await budget.wait_turn()
        self.assertGreaterEqual(tick[0],0.25)
        self.assertIsNone(budget.snapshot()['cpu_percent'])

    async def test_cancelled_cpu_wait_does_not_block_live_write_or_next_waiter(self):
        entered=asyncio.Event(); resume=asyncio.Event()
        async def sleep(seconds):
            entered.set(); await resume.wait()
        budget=self.app.CpuBudget(sample=lambda:90,sleep=sleep)
        task=asyncio.create_task(budget.wait_turn()); self.workers.append(task)
        await asyncio.wait_for(entered.wait(),1)
        with patch.object(self.app,'BACKGROUND_LOAD',budget):
            await asyncio.wait_for(self.app.capture_live_message(None,1,self.message(),100,'Chat','user'),1)
        with self.app.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],1)
        task.cancel(); await asyncio.gather(task,return_exceptions=True)
        budget._sample=lambda:10; budget._sample_at=-float('inf')
        await asyncio.wait_for(budget.wait_turn(),1)

    async def test_stalled_account_does_not_block_other_accounts_pages(self):
        a=self.app; stalled=asyncio.Event(); release=asyncio.Event()
        class Client:
            def __init__(self,hold=False): self.hold=hold
            def iter_messages(client,*args,**kwargs):
                async def items():
                    if client.hold:
                        stalled.set(); await release.wait()
                    for i in range(1,62): yield self.message(i)
                return items()
        async def consume(account,client):
            async for batch in a.iter_history_batches(client,100):
                await a.store_history_batch(account,batch,100,'Chat','user',{},(account,100,'forward',batch[-1].id))
        first=asyncio.create_task(consume(1,Client(True))); self.workers.append(first)
        await asyncio.wait_for(stalled.wait(),1)
        await asyncio.wait_for(asyncio.gather(*(consume(i,Client()) for i in range(2,12))),5)
        with a.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],610)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM chats WHERE history_cursor=61').fetchone()[0],10)
        release.set(); await first
        with a.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],671)
            self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')

    async def test_network_page_slot_released_before_consumer_and_on_fetch_error(self):
        a=self.app
        class Client:
            def iter_messages(client,*args,**kwargs):
                async def items():
                    for i in range(25): yield self.message(i+1)
                return items()
        iterator=a.iter_history_batches(Client(),100)
        await anext(iterator)
        self.assertEqual(a.HISTORY_PAGE_SEM.active,0)
        await iterator.aclose()
        class Broken:
            def iter_messages(client,*args,**kwargs):
                async def items():
                    raise RuntimeError('network down')
                    yield
                return items()
        with self.assertRaisesRegex(RuntimeError,'network down'):
            await anext(a.iter_history_batches(Broken(),100))
        self.assertEqual(a.HISTORY_PAGE_SEM.active,0)

    async def test_history_account_slot_not_held_for_entire_download(self):
        a=self.app; entered=[]; both=asyncio.Event()
        async def inner(account,state):
            entered.append(account)
            if len(entered)==2: both.set()
            await both.wait()
        with patch.object(a,'_run_backfill_inner',inner):
            await asyncio.wait_for(asyncio.gather(a.run_backfill(1,{}),a.run_backfill(2,{})),1)
        self.assertEqual(entered,[1,2])

    async def test_floodwait_releases_account_discovery_and_preserves_pending_history(self):
        a=self.app; limited=asyncio.Event()
        from telethon.errors import FloodWaitError
        class Client:
            def __init__(client,slow=False): client.slow=slow
            async def connect(client): pass
            async def is_user_authorized(client): return True
            def iter_dialogs(client):
                async def items(): yield SimpleNamespace(id=100,entity=None,name='Chat')
                return items()
            def iter_messages(client,*args,**kwargs):
                async def items():
                    if client.slow:
                        limited.set()
                        raise FloodWaitError(request=None,capture=60)
                    for i in range(1,31): yield self.message(i)
                return items()
        a.should_scan_dialog=lambda d:True
        a.CLIENTS.update({1:Client(True),2:Client()})
        a.start_backfill(1); slow=a.BACKFILL[1]['task']; self.workers.append(slow)
        await asyncio.wait_for(limited.wait(),1)
        a.start_backfill(2); other=a.BACKFILL[2]['task']; self.workers.append(other)
        await asyncio.wait_for(asyncio.shield(other),2)
        self.assertEqual(a.BACKFILL[2]['state'],'done')
        self.assertGreater(a.BACKFILL[1]['wait_until'],a.time.time())
        slow.cancel(); await asyncio.gather(slow,return_exceptions=True)
        with a.db() as c:
            self.assertEqual(c.execute('SELECT COUNT(*) FROM messages WHERE account_id=2').fetchone()[0],30)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM history_pending WHERE account_id=1').fetchone()[0],1)

    async def test_slow_transaction_still_reduces_page_without_losing_checkpoint(self):
        a=self.app; a.HISTORY_BATCH_SIZE=100
        original=a.persist_live_batch
        def slow(*args):
            import time
            time.sleep(0.1)
            return original(*args)
        with patch.object(a,'persist_live_batch',slow):
            await a.store_history_batch(1,[self.message(i) for i in range(1,101)],100,'Chat','user',{},(1,100,'forward',100))
        self.assertEqual(a.HISTORY_BATCH_SIZE,50)
        with a.db() as c:
            self.assertEqual(c.execute('SELECT history_cursor FROM chats').fetchone()[0],100)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM messages').fetchone()[0],100)

    async def test_in_progress_media_awaits_cpu_budget_and_publishes_only_complete_file(self):
        from pathlib import Path
        a=self.app; calls=[]
        message=self.message(1,media=True)
        async def download(file,progress_callback,**kwargs):
            with Path(file).open('wb') as output:
                for received in (16,32):
                    output.write(b'x'*16)
                    await progress_callback(received,32)
        async def permit(): calls.append('permit')
        message.download_media=download
        a.BACKGROUND_LOAD.wait_turn=permit
        await a.store_message(None,1,message,100,'Chat','user')
        self.assertEqual(calls,['permit','permit'])
        with a.db() as c:
            row=c.execute('SELECT file_path,media_status FROM messages').fetchone()
        self.assertIsNone(row['media_status'])
        self.assertEqual((a.BASE/row['file_path']).read_bytes(),b'x'*32)


class AdaptiveHistorySlotTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown

    def slots(self, cpu, paused=False):
        tick = [0.0]
        load = SimpleNamespace(snapshot=lambda: {"cpu_percent": cpu[0], "paused": paused})
        return self.app.AdaptiveSlots(minimum=2, maximum=4, load=load, clock=lambda: tick[0]), tick

    async def test_slots_grow_only_with_spare_cpu_and_demand_then_shrink(self):
        cpu = [30]
        slots, tick = self.slots(cpu)
        await slots.acquire(); await slots.acquire()
        third = asyncio.create_task(slots.acquire()); await asyncio.sleep(0)
        self.assertFalse(third.done())                      # starts at the old fixed two
        tick[0] = 6; slots.release()                        # spare CPU and a waiter: +1
        await asyncio.wait_for(third, 1)
        self.assertEqual((slots.limit, slots.active), (3, 2))
        for _ in range(2):
            tick[0] += 6; await slots.acquire()
        self.assertEqual((slots.limit, slots.active), (4, 4))
        fifth = asyncio.create_task(slots.acquire()); await asyncio.sleep(0)
        tick[0] += 6; slots._adjust()
        self.assertEqual(slots.limit, 4)                    # never above maximum
        self.assertFalse(fifth.done())
        cpu[0] = 58
        for _ in range(2):
            tick[0] += 6; slots.release()
        self.assertEqual((slots.limit, slots.active), (2, 2))  # shrinks, never below two
        self.assertFalse(fifth.done())                      # busy slots are not preempted
        tick[0] += 6; slots.release()
        await asyncio.wait_for(fifth, 1)
        self.assertEqual((slots.limit, slots.active), (2, 2))

    async def test_paused_cpu_gate_and_missing_counter_never_add_slots(self):
        for cpu, paused in (([20], True), ([None], False)):
            slots, tick = self.slots(cpu, paused)
            await slots.acquire(); await slots.acquire()
            waiter = asyncio.create_task(slots.acquire()); await asyncio.sleep(0)
            tick[0] = 30; slots.release()
            await asyncio.wait_for(waiter, 1)
            self.assertEqual(slots.limit, 2)

    async def test_cancelled_waiter_does_not_leak_a_slot(self):
        slots, tick = self.slots([90])
        await slots.acquire(); await slots.acquire()
        waiter = asyncio.create_task(slots.acquire()); await asyncio.sleep(0)
        waiter.cancel(); await asyncio.gather(waiter, return_exceptions=True)
        slots.release(); slots.release()
        self.assertEqual(slots.active, 0)
        async with slots:
            self.assertEqual(slots.active, 1)
        self.assertEqual(slots.active, 0)

    async def test_health_reports_history_slots(self):
        load = self.app.api_health()["background_load"]
        self.assertEqual((load["target_percent"], load["ceiling_percent"]), (55, 60))
        self.assertEqual(load["history_slots"], 2)

"""Failed or cancelled Telegram login must not leave accounts or start recording."""
import asyncio
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, Mock, patch
import test_portability


class ConnectionTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_portability.PortabilityTests.asyncSetUp
    asyncTearDown = test_portability.PortabilityTests.asyncTearDown

    def request(self, data):
        return SimpleNamespace(json=AsyncMock(return_value=data))

    async def test_phone_connection_failure_removes_placeholder_and_closes_session(self):
        client = SimpleNamespace(connect=AsyncMock(side_effect=OSError('offline')),
            disconnect=AsyncMock(), session=SimpleNamespace(close=Mock()))
        with patch.object(self.app, 'TelegramClient', return_value=client):
            result = await self.app.api_add_phone(self.request({'phone': '+1234567890'}))
        self.assertFalse(result['ok'])
        self.assertEqual(self.app.api_accounts(), [])
        client.session.close.assert_called_once()
        client.disconnect.assert_awaited_once()

    async def test_phone_code_cannot_start_recorder_after_cancel(self):
        entered, proceed = asyncio.Event(), asyncio.Event()
        async def sign_in(*args, **kwargs):
            entered.set()
            await proceed.wait()
        client = SimpleNamespace(sign_in=sign_in, disconnect=AsyncMock(), session=SimpleNamespace(close=Mock()))
        flow = {'client': client, 'account_id': 1, 'phone': '+1234567890', 'state': 'code'}
        self.app.PHONE_FLOWS['1'] = flow
        with patch.object(self.app, 'start_recorder') as recorder:
            pending = asyncio.create_task(self.app.api_phone_code('1', self.request({'code':'12345'})))
            await entered.wait()
            await self.app.api_phone_cancel('1')
            proceed.set()
            result = await pending
        self.assertEqual(result['state'], 'dead')
        recorder.assert_not_called()

    async def test_qr_password_cannot_start_recorder_after_cancel(self):
        entered, proceed = asyncio.Event(), asyncio.Event()
        async def sign_in(*args, **kwargs):
            entered.set()
            await proceed.wait()
        client = SimpleNamespace(sign_in=sign_in, disconnect=AsyncMock(), session=SimpleNamespace(close=Mock()))
        self.app.FLOWS['1'] = {'client':client, 'account_id':1, 'state':'pwd'}
        with patch.object(self.app, 'start_recorder') as recorder:
            pending = asyncio.create_task(self.app.finish_pwd('1', 'password'))
            await entered.wait()
            await self.app.api_qr_cancel('1')
            proceed.set()
            self.assertFalse(await pending)
        recorder.assert_not_called()

    async def test_incorrect_qr_password_is_a_normal_rejection(self):
        client = SimpleNamespace(sign_in=AsyncMock(side_effect=self.app.PasswordHashInvalidError(request=None)))
        self.app.FLOWS['1'] = {'client':client,'account_id':1,'state':'pwd'}
        with patch.object(self.app,'start_recorder') as recorder:
            self.assertFalse(await self.app.finish_pwd('1','wrong'))
        recorder.assert_not_called()
        self.assertEqual(self.app.FLOWS['1']['state'],'pwd')

    async def test_failed_qr_flow_is_disconnected_on_close(self):
        client = SimpleNamespace(disconnect=AsyncMock(),session=SimpleNamespace(close=Mock()))
        self.app.FLOWS['1'] = {'client':client,'account_id':1,'state':'error'}
        await self.app.api_qr_cancel('1')
        client.disconnect.assert_awaited_once()
        client.session.close.assert_called_once()
        self.assertNotIn('1',self.app.FLOWS)

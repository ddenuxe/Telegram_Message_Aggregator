"""Regression tests for the system audit, with isolated archives and fake Telegram."""
import asyncio
from contextlib import contextmanager
import json
import os
import subprocess
import sqlite3
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from test_reliable_ingest import ReliableIngestTests as Fixture


class SystemFixTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = Fixture.asyncSetUp
    asyncTearDown = Fixture.asyncTearDown
    message = Fixture.message
    capture = Fixture.capture
    rows = Fixture.rows

    def request(self, body):
        async def read(): return body
        return SimpleNamespace(json=read)

    async def backfill(self, messages, fail=False):
        dialog = SimpleNamespace(id=100, entity=None, name="Test chat")
        class Client:
            async def connect(self): pass
            async def is_user_authorized(self): return True
            async def iter_dialogs(self): yield dialog
            def is_connected(self): return True
        self.app.CLIENTS[1] = Client()
        offsets = []
        async def history(client, dialog, **kwargs):
            if fail: raise OSError("network down")
            offset = kwargs.get("offset_id", 0)
            offsets.append(offset)
            for msg in messages:
                if not kwargs.get("reverse") or msg.id > offset:
                    yield msg
        state = {}
        with patch.object(self.app,"should_scan_dialog",return_value=True), \
             patch.object(self.app,"iter_messages_with_timeout",history), \
             patch.object(self.app.asyncio,"sleep",new=AsyncMock()):
            await self.app._run_backfill_inner(1,state)
        return state,offsets

    async def test_live_receipt_cannot_advance_recovery_checkpoint(self):
        await self.capture(self.message(10))
        with self.app.db() as c:
            c.execute("UPDATE chats SET deep_done=1,min_msg_id=1,history_cursor=10")
        await self.capture(self.message(20))
        state,offsets = await self.backfill([self.message(i) for i in range(11,21)])
        self.assertEqual(sorted(r["msg_id"] for r in self.rows()),list(range(10,21)))
        self.assertEqual(offsets[0],10)
        self.assertEqual(state["state"],"done")
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT history_cursor FROM chats").fetchone()[0],20)

    async def test_pending_delete_survives_history_and_later_live_edits(self):
        msg = self.message(media=True)
        await self.capture(msg)
        job = self.rows("archive_jobs")[0]
        response = await self.app.api_media_delete(self.request(
            {"account_id":1,"items":[{"chat_id":100,"msg_id":1}]}))
        self.assertTrue(response["ok"])
        self.assertEqual(self.rows("archive_jobs"),[])
        await self.app.store_message(None,1,msg,100,"Test chat","group",job["token"])
        await self.capture(self.message(text="edited",media=True,edited=True))
        await self.app.store_message(None,1,self.message(text="edited",media=True,edited=True),100,"Test chat","group")
        row = self.rows()[0]
        self.assertEqual(row["text"],"edited")
        self.assertIsNone(row["media_type"])
        self.assertIsNone(row["file_path"])
        self.assertFalse(list(self.app.MEDIA.rglob("*.bin")))

    async def test_equal_timestamp_replay_preserves_later_capture(self):
        old = self.app.live_snapshot(1,self.message(text="older",edited=True),100,"Test chat","group")
        self.app.spool_live_batch([old])
        await self.capture(self.message(text="newer",edited=True))
        self.app.replay_ingest_spool()
        self.assertEqual(self.rows()[0]["text"],"newer")

    async def test_hundred_damaged_receipts_are_quarantined_then_good_is_replayed(self):
        self.app.INGEST_SPOOL.mkdir(exist_ok=True)
        for i in range(100):
            (self.app.INGEST_SPOOL / f"bad-{i:03}.json").write_text("broken",encoding="utf-8")
        self.app.spool_live_batch([self.app.live_snapshot(1,self.message(),100,"Test chat","group")])
        self.app.replay_ingest_spool()
        self.app.replay_ingest_spool()
        self.assertEqual(len(self.rows()),1)
        self.assertEqual(len(list((self.app.INGEST_SPOOL/"quarantine").glob("*.json"))),100)
        self.assertEqual(list(self.app.INGEST_SPOOL.glob("*.json")),[])

    async def test_malformed_profile_does_not_poison_batch(self):
        bad = self.app.live_snapshot(1,self.message(1),100,"Test chat","group")
        bad["profile"] = ["too short"]
        good = self.app.live_snapshot(1,self.message(2),100,"Test chat","group")
        self.app.spool_live_batch([bad,good])
        self.app.replay_ingest_spool()
        self.assertEqual([r["msg_id"] for r in self.rows()],[2])

    async def test_stale_transfer_preserves_referenced_legacy_file(self):
        msg = self.message(media=True)
        await self.capture(msg)
        path = self.app.MEDIA/"legacy.bin"
        path.write_bytes(b"p")
        with self.app.db() as c:
            c.execute("UPDATE messages SET file_path='media/legacy.bin',media_status='incomplete'")
        job = self.rows("archive_jobs")[0]
        async def download(file):
            Path(file).write_bytes(b"x"*32)
            await self.capture(self.message(text="new edit",media=True,edited=True))
            return file
        msg.download_media = download
        await self.app.store_message(None,1,msg,100,"Test chat","group",job["token"])
        row = self.rows()[0]
        self.assertEqual(row["text"],"new edit")
        self.assertTrue((self.root/row["file_path"]).is_file())
        self.assertEqual(len(self.rows("archive_jobs")),1)

    async def test_delete_during_transfer_cannot_restore_media_metadata(self):
        msg = self.message(media=True)
        await self.capture(msg)
        job = self.rows("archive_jobs")[0]
        async def download(file):
            Path(file).write_bytes(b"x"*32)
            await self.app.api_media_delete(self.request(
                {"account_id":1,"items":[{"chat_id":100,"msg_id":1}]}))
            return file
        msg.download_media = download
        await self.app.store_message(None,1,msg,100,"Test chat","group",job["token"])
        self.assertIsNone(self.rows()[0]["media_type"])
        self.assertIsNone(self.rows()[0]["file_path"])

    async def test_recent_offline_edit_is_reconciled(self):
        await self.capture(self.message(10,text="old"))
        with self.app.db() as c:
            c.execute("UPDATE chats SET deep_done=1,min_msg_id=1,history_cursor=10")
        state,_ = await self.backfill([self.message(10,text="changed offline",edited=True)])
        self.assertEqual(self.rows()[0]["text"],"changed offline")
        self.assertEqual(state["state"],"done")

    async def test_flood_wait_is_preserved_for_durable_retry_delay(self):
        msg=self.message(media=True)
        await self.capture(msg)
        job=self.rows("archive_jobs")[0]
        wait=self.app.FloodWaitError(request=None,capture=120)
        async def download(file): raise wait
        msg.download_media=download
        with self.assertRaises(self.app.FloodWaitError):
            await self.app.store_message(None,1,msg,100,"Test chat","group",job["token"])
        self.app.finish_archive_job(job,wait)
        self.assertEqual(self.rows()[0]["media_status"],"incomplete")
        self.assertGreater(self.rows("archive_jobs")[0]["next_attempt"],self.app.time.time()+120)

    async def test_failed_range_does_not_advance_checkpoint_and_schedules_retry(self):
        await self.capture(self.message(10))
        with self.app.db() as c:
            c.execute("UPDATE chats SET deep_done=1,history_cursor=10")
        state,_ = await self.backfill([],fail=True)
        self.assertEqual(state["state"],"partial")
        self.assertGreater(state["retry_at"],0)
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT history_cursor FROM chats").fetchone()[0],10)

    async def test_archive_lock_blocks_other_process_then_releases(self):
        env = os.environ.copy()
        env["TG_MONITOR_HOME"] = str(self.root)
        script = "import app; app.acquire_archive_lock(); app.release_archive_lock()"
        self.app.acquire_archive_lock()
        try:
            blocked = subprocess.run([sys.executable,"-c",script],cwd=self.root,env=env,
                                     capture_output=True,timeout=15)
            self.assertNotEqual(blocked.returncode,0)
            self.assertIn(b"RuntimeError",blocked.stderr)
        finally:
            self.app.release_archive_lock()
        allowed = subprocess.run([sys.executable,"-c",script],cwd=self.root,env=env,
                                 capture_output=True,timeout=15)
        self.assertEqual(allowed.returncode,0,allowed.stderr)

    async def test_maintenance_retries_active_account_and_skips_paused(self):
        with self.app.db() as c: c.execute("UPDATE accounts SET status='paused' WHERE id=1")
        self.app.BACKFILL[1]={"state":"partial","retry_at":0}
        self.app.BACKFILL[2]={"state":"partial","retry_at":0}
        self.app.CLIENTS.update({i:SimpleNamespace(is_connected=lambda:True) for i in (1,2)})
        with patch.object(self.app,"start_backfill",side_effect=asyncio.CancelledError()) as start:
            with self.assertRaises(asyncio.CancelledError): await self.app.ingest_maintenance()
            start.assert_called_once_with(2)

    async def test_commit_failure_after_promotion_recovers_file_on_retry(self):
        msg=self.message(media=True)
        await self.capture(msg)
        job=self.rows("archive_jobs")[0]
        original=self.app.db
        failed=False
        @contextmanager
        def flaky(timeout=30):
            nonlocal failed
            with original(timeout=timeout) as c:
                yield c
                row=c.execute("SELECT file_path,media_status FROM messages WHERE msg_id=1").fetchone()
                if not failed and row and row["file_path"] and row["media_status"] is None:
                    failed=True
                    raise sqlite3.OperationalError("simulated commit failure")
        with patch.object(self.app,"db",flaky):
            await self.app.store_message(None,1,msg,100,"Test chat","group",job["token"])
        row=self.rows()[0]
        self.assertTrue(failed)
        self.assertIsNone(row["media_status"])
        self.assertEqual((self.root/row["file_path"]).read_bytes(),b"x"*32)

    async def test_receiver_is_registered_before_connect_and_requests_catchup(self):
        event = SimpleNamespace(chat_id=100,chat=None,is_channel=False,is_group=True,
                                message=self.message(text="early update"))
        class Client:
            def __init__(self): self.handlers=[]; self.caught_up=False
            def add_event_handler(self,handler,event_type): self.handlers.append(handler)
            def remove_event_handler(self,handler): self.handlers=[]
            async def connect(self):
                self.test_handler_count=len(self.handlers)
                await self.handlers[0](event)
            async def is_user_authorized(self): return True
            async def get_me(self):
                return SimpleNamespace(id=123456,first_name="Test",last_name="",phone=None,username=None)
            async def catch_up(self): self.caught_up=True
            async def run_until_disconnected(self): raise asyncio.CancelledError()
        client=Client()
        with patch.object(self.app,"start_backfill",return_value=True):
            with self.assertRaises(asyncio.CancelledError):
                await self.app.recorder(1,client)
        self.assertEqual(client.test_handler_count,2)
        self.assertTrue(client.caught_up)
        self.assertEqual(self.rows()[0]["text"],"early update")
        self.assertEqual(client.handlers,[])


del Fixture  # unittest discovers TestCase classes imported at module scope, too.
if __name__ == "__main__": unittest.main()

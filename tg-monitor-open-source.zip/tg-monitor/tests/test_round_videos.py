"""Only round video messages are downloaded; ordinary videos keep their message, and files already on disk stay."""
import unittest
from pathlib import Path
from types import SimpleNamespace

import test_reliable_ingest


class RoundVideoTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message
    capture = test_reliable_ingest.ReliableIngestTests.capture
    rows = test_reliable_ingest.ReliableIngestTests.rows

    def video(self, msg_id, round_video=False, data=b"v" * 64):
        msg = self.message(msg_id, media=True)
        msg.video = msg.document = SimpleNamespace(id=500 + msg_id)
        msg.video_note = msg.video if round_video else None
        msg.file = SimpleNamespace(size=len(data), id=f"file-{msg_id}", ext=".mp4", name=None)
        calls = []

        async def download(file, **kwargs):
            calls.append(file)
            Path(file).write_bytes(data)
            return file
        msg.download_media = download
        return msg, calls

    def row(self, msg_id):
        return next(r for r in self.rows() if r["msg_id"] == msg_id)

    async def test_ordinary_video_is_saved_without_a_download_job(self):
        msg, calls = self.video(1)
        await self.capture(msg)
        row = self.row(1)
        self.assertEqual(row["text"], "Текст 👋\nстрока")
        self.assertEqual((row["media_type"], row["media_status"], row["file_path"]), ("video", "skipped", None))
        self.assertEqual(self.rows("archive_jobs"), [])
        self.assertEqual(calls, [])

    async def test_round_video_is_queued_for_download(self):
        msg, _ = self.video(2, round_video=True)
        await self.capture(msg)
        self.assertEqual(self.row(2)["media_status"], "queued")
        self.assertEqual(len(self.rows("archive_jobs")), 1)

    async def test_store_downloads_round_video_and_skips_ordinary_one(self):
        a = self.app
        ordinary, ordinary_calls = self.video(1)
        round_video, round_calls = self.video(2, round_video=True)
        await a.store_message(None, 1, ordinary, 100, "Chat", "group")
        await a.store_message(None, 1, round_video, 100, "Chat", "group")
        self.assertEqual(ordinary_calls, [])
        self.assertEqual((self.row(1)["media_status"], self.row(1)["file_path"]), ("skipped", None))
        self.assertEqual(len(round_calls), 1)
        self.assertIsNone(self.row(2)["media_status"])
        self.assertTrue((a.BASE / self.row(2)["file_path"]).is_file())

    async def test_video_already_on_disk_is_kept(self):
        a = self.app
        data = b"o" * 64
        stored = a.BASE / "media/Test 1/Chat/old video [3].mp4"
        stored.parent.mkdir(parents=True, exist_ok=True)
        stored.write_bytes(data)
        rel = str(stored.relative_to(a.BASE)).replace("\\", "/")
        with a.db() as c:
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,date,text,media_type,file_path,file_size,media_id)
                         VALUES(1,100,3,'2026-10-05T00:00:00+00:00','old','video',?,?,'file-3')""", (rel, len(data)))
        msg, calls = self.video(3, data=data)
        await a.store_message(None, 1, msg, 100, "Chat", "group")
        self.assertEqual(calls, [])
        self.assertEqual((self.row(3)["file_path"], self.row(3)["media_status"]), (rel, None))
        self.assertEqual(stored.read_bytes(), data)

    async def test_partial_video_stays_referenced_and_is_not_continued(self):
        a = self.app
        partial = a.BASE / "media/Test 1/Chat/clip [4].mp4.partial"
        partial.parent.mkdir(parents=True, exist_ok=True)
        partial.write_bytes(b"p" * 10)
        rel = str(partial.relative_to(a.BASE)).replace("\\", "/")
        with a.db() as c:
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,date,text,media_type,file_path,file_size,media_id,media_status)
                         VALUES(1,100,4,'2026-10-05T00:00:00+00:00','old','video',?,64,'file-4','incomplete')""", (rel,))
        msg, calls = self.video(4)
        await a.store_message(None, 1, msg, 100, "Chat", "group")
        self.assertEqual(calls, [])
        self.assertEqual((self.row(4)["file_path"], self.row(4)["media_status"]), (rel, "skipped"))
        self.assertTrue(partial.is_file())

    async def test_download_requested_in_panel_fetches_an_ordinary_video(self):
        a = self.app
        msg, calls = self.video(5)
        await a.store_message(None, 1, msg, 100, "Chat", "group")
        self.assertEqual(self.row(5)["media_status"], "skipped")
        await a._store_message_locked(None, 1, msg, 100, "Chat", "group", force_video=True)
        self.assertEqual(len(calls), 1)
        self.assertIsNone(self.row(5)["media_status"])
        self.assertTrue((a.BASE / self.row(5)["file_path"]).is_file())

    def test_skipped_videos_are_not_recovered_or_waiting_for_approval(self):
        a = self.app
        big = a.LARGE_MEDIA_APPROVAL_BYTES + 1
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,100,'Chat','group')")
            c.executemany("""INSERT INTO messages(account_id,chat_id,msg_id,date,media_type,file_size,media_status)
                             VALUES(1,100,?,'2026-10-05',?,?,?)""",
                          [(1, "video", 64, "skipped"), (2, "video", big, None), (3, "document", big, None)])
        self.assertEqual(a.recover_missing_media_jobs(), 0)   # the 1 GB+ ones wait for a decision instead
        self.assertEqual(a.api_pending_media_count()["pending"], 1)   # only the document
        self.assertEqual(a.incomplete_chat_media_count(1, 100), 0)


if __name__ == "__main__":
    unittest.main()

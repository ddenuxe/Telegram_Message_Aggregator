"""Durable live capture, recovery, cleanup and load; never uses the live archive."""
import asyncio
import importlib.util
import json
import shutil
import sqlite3
import tempfile
import time
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

SOURCE = Path(__file__).resolve().parents[1]


class ReliableIngestTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-reliable-ingest-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py",self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 + "\n",encoding="utf-8")
        spec = importlib.util.spec_from_file_location("reliable_ingest_test",self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()
        with self.app.db() as c:
            c.executemany("INSERT INTO accounts(id,name,status) VALUES(?,?,'recording')",
                          [(i,f"Test {i}") for i in range(1,51)])
        self.workers = []

    async def asyncTearDown(self):
        for worker in self.workers:
            worker.cancel()
        await asyncio.gather(*self.workers,return_exceptions=True)
        await self.app.stop_ingest()
        self.temp.cleanup()

    def message(self,msg_id=1,text="Текст 👋\nстрока",media=False,edited=False):
        msg = SimpleNamespace(id=msg_id,date=datetime(2026,10,5,tzinfo=timezone.utc),
            edit_date=datetime(2026,10,5,tzinfo=timezone.utc)+timedelta(hours=1) if edited else None,
            sender_id=None,out=False,message=text,entities=[],action=None,sender=None,
            voice=None,video=None,photo=None,audio=None,document=True if media else None,
            file=SimpleNamespace(size=32,id=99,ext=".bin",name="asset.bin") if media else None)
        async def download(file):
            Path(file).write_bytes(b"x"*32)
            return file
        msg.download_media = download
        return msg

    async def capture(self,msg,account=1):
        await self.app.capture_live_message(None,account,msg,100,"Test chat","group")

    def rows(self,table="messages"):
        with self.app.db() as c:
            return [dict(r) for r in c.execute(f"SELECT * FROM {table}")]

    async def test_fifty_accounts_burst_saves_every_message_without_duplicates(self):
        await asyncio.gather(*(self.capture(self.message(i),account)
            for account in range(1,51) for i in range(1,21)))
        self.assertEqual(len(self.rows()),1000)
        await self.capture(self.message(1),50)
        self.assertEqual(len(self.rows()),1000)
        self.assertLessEqual(len(self.app.LIVE_MESSAGES),256)
        self.assertEqual(self.app.INGEST_QUEUE.maxsize,256)

    async def test_text_is_committed_before_a_download_can_start(self):
        await self.capture(self.message(media=True))
        self.assertEqual(self.rows()[0]["text"],"Текст 👋\nстрока")
        self.assertEqual(self.rows()[0]["media_status"],"queued")
        self.assertEqual(len(self.rows("archive_jobs")),1)
        self.assertFalse(list(self.app.MEDIA.rglob("*.bin")))

    async def test_stalled_download_does_not_delay_text_for_fifty_accounts(self):
        msg = self.message(media=True)
        started,release = asyncio.Event(),asyncio.Event()
        async def slow_download(file):
            started.set()
            await release.wait()
            Path(file).write_bytes(b"x"*32)
            return file
        msg.download_media = slow_download
        await self.capture(msg)
        class Client:
            def is_connected(self): return True
        self.app.CLIENTS[1] = Client()
        self.workers = [asyncio.create_task(self.app.archive_job_worker())]
        await asyncio.wait_for(started.wait(),3)
        await asyncio.wait_for(asyncio.gather(*(self.capture(self.message(2),account)
            for account in range(1,51))),3)
        self.assertEqual(len(self.rows()),51)
        self.assertFalse(release.is_set())
        release.set()

    async def test_sql_failure_spools_and_recovers_lower_id_after_higher_id_is_saved(self):
        with patch.object(self.app,"persist_live_batch",side_effect=sqlite3.OperationalError("locked")):
            await self.capture(self.message(1,"must survive"))
        self.assertEqual(len(self.rows()),0)
        self.assertEqual(len(list(self.app.INGEST_SPOOL.glob("*.json"))),1)
        await self.capture(self.message(2,"newer"))
        # Restart has no memory cache; replay relies only on the on-disk receipt.
        await self.app.stop_ingest()
        self.app.LIVE_MESSAGES.clear()
        await self.app.write_call(self.app.replay_ingest_spool)
        self.assertEqual({r["msg_id"]:r["text"] for r in self.rows()},
                         {1:"must survive",2:"newer"})
        self.assertEqual(list(self.app.INGEST_SPOOL.glob("*.json")),[])

    async def test_slow_sql_does_not_block_the_event_loop(self):
        original = self.app.persist_live_batch
        def slow(batch):
            time.sleep(0.2)
            return original(batch)
        ticks = 0
        async def heartbeat():
            nonlocal ticks
            for _ in range(10):
                await asyncio.sleep(0.01)
                ticks += 1
        with patch.object(self.app,"persist_live_batch",slow):
            capture = asyncio.create_task(self.capture(self.message()))
            await heartbeat()
            self.assertFalse(capture.done())
            await capture
        self.assertEqual(ticks,10)

    async def test_replayed_queue_does_not_resurrect_deleted_or_cleared_messages(self):
        snapshots = [self.app.live_snapshot(1,self.message(i),100,"Test chat","group") for i in (1,2)]
        self.app.persist_live_batch(snapshots)
        with self.app.db() as c:
            c.execute("INSERT INTO deleted SELECT * FROM messages WHERE msg_id=1")
            c.execute("DELETE FROM messages")
            c.execute("UPDATE chats SET clear_through_msg_id=2 WHERE account_id=1 AND chat_id=100")
        self.app.persist_live_batch(snapshots)
        self.assertEqual(self.rows(),[])

    async def test_old_snapshot_and_old_worker_cannot_overwrite_an_edit(self):
        old = self.message(text="original",media=True)
        await self.capture(old)
        old_token = self.rows("archive_jobs")[0]["token"]
        edited = self.message(text="edited",media=True,edited=True)
        await self.capture(edited)
        await self.app.store_message(None,1,old,100,"Test chat","group",expected_job_token=old_token)
        self.app.persist_live_batch([self.app.live_snapshot(1,old,100,"Test chat","group")])
        self.assertEqual(self.rows()[0]["text"],"edited")
        self.assertNotEqual(self.rows("archive_jobs")[0]["token"],old_token)

    async def test_media_job_survives_restart_and_is_removed_only_after_success(self):
        msg = self.message(media=True)
        await self.capture(msg)
        await self.app.stop_ingest()
        self.app.LIVE_MESSAGES.clear()
        calls = []
        class Client:
            def is_connected(self): return True
            async def get_messages(self,chat_id,ids):
                calls.append((chat_id,ids))
                return msg
        self.app.CLIENTS[1] = Client()
        self.workers = [asyncio.create_task(self.app.archive_job_worker()) for _ in range(3)]
        async def wait_done():
            while self.rows("archive_jobs"):
                await asyncio.sleep(0.01)
        await asyncio.wait_for(wait_done(),5)
        self.assertEqual(calls,[(100,1)])
        row = self.rows()[0]
        self.assertIsNone(row["media_status"])
        self.assertEqual((self.root / row["file_path"]).read_bytes(),b"x"*32)

    async def test_retry_is_durable_backed_off_and_keeps_newer_job(self):
        await self.capture(self.message(media=True))
        job = self.rows("archive_jobs")[0]
        self.app.finish_archive_job(job,OSError("network"))
        pending = self.rows("archive_jobs")[0]
        self.assertEqual(pending["attempts"],1)
        self.assertGreater(pending["next_attempt"],time.time())
        await self.capture(self.message(text="edit",media=True,edited=True))
        self.app.finish_archive_job(job)
        self.assertEqual(len(self.rows("archive_jobs")),1)
        self.assertNotEqual(self.rows("archive_jobs")[0]["token"],job["token"])

    async def test_edit_that_removes_attachment_still_has_a_cleanup_job(self):
        await self.capture(self.message(media=True))
        await self.capture(self.message(text="text only",edited=True))
        payload = json.loads(self.rows("archive_jobs")[0]["payload"])
        self.assertTrue(payload["process_media"])
        self.assertIsNone(payload["media_type"])

    async def test_unavailable_source_does_not_delete_the_saved_text(self):
        await self.capture(self.message(media=True))
        self.app.LIVE_MESSAGES.clear()
        class Client:
            def is_connected(self): return True
            async def get_messages(self,*args,**kwargs): return None
        self.app.CLIENTS[1] = Client()
        self.workers = [asyncio.create_task(self.app.archive_job_worker())]
        async def wait_done():
            while self.rows("archive_jobs"):
                await asyncio.sleep(0.01)
        await asyncio.wait_for(wait_done(),3)
        self.assertEqual(self.rows()[0]["text"],"Текст 👋\nстрока")
        self.assertEqual(self.rows()[0]["media_status"],"unavailable")

    async def test_cancelled_receiver_still_drains_the_accepted_queue_on_shutdown(self):
        task = asyncio.create_task(self.capture(self.message()))
        await asyncio.sleep(0.001)
        task.cancel()
        await asyncio.gather(task,return_exceptions=True)
        await self.app.stop_ingest()
        self.assertEqual(len(self.rows()),1)

    async def test_damaged_receipt_does_not_block_other_recovery(self):
        snapshot = self.app.live_snapshot(1,self.message(),100,"Test chat","group")
        self.app.spool_live_batch([snapshot])
        (self.app.INGEST_SPOOL / "damaged.json").write_text("broken",encoding="utf-8")
        self.app.replay_ingest_spool()
        self.assertEqual(len(self.rows()),1)
        self.assertFalse((self.app.INGEST_SPOOL / "damaged.json").is_file())
        self.assertEqual(len(list((self.app.INGEST_SPOOL / "quarantine").glob("damaged-*.json"))),1)


if __name__ == "__main__":
    unittest.main()

"""Panel password sign-in checks on a temporary installation."""
import importlib.util
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


SOURCE = Path(__file__).resolve().parents[1]
PASSWORD = "Пароль%1"


class Body:
    def __init__(self, value=None, invalid=False):
        self.value, self.invalid = value, invalid

    async def json(self):
        if self.invalid:
            raise json.JSONDecodeError("bad", "", 0)
        return self.value


class PanelAuthTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-panel-auth-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        self.home = self.root / "data"
        self.app = self.load(PASSWORD)

    def load(self, password):
        self.home.mkdir(exist_ok=True)
        (self.home / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            f"\n[security]\npanel_password={password}\n", encoding="utf-8")
        with patch.dict(os.environ, {"TG_MONITOR_HOME": str(self.home)}):
            spec = importlib.util.spec_from_file_location("tg_panel_auth_test", self.root / "app.py")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        return module

    async def asyncTearDown(self):
        self.temp.cleanup()

    async def request(self, path, cookie=None):
        request = SimpleNamespace(url=SimpleNamespace(path=path),
                                  cookies={} if cookie is None else {"panel_key": cookie})

        async def call_next(_request):
            return "passed"
        return await self.app.auth_middleware(request, call_next)

    async def test_cyrillic_password_signs_in_and_cookie_opens_the_panel(self):
        response = await self.app.api_login(Body({"password": PASSWORD}))
        self.assertEqual(response.status_code, 200)
        cookie = response.headers["set-cookie"].split("panel_key=", 1)[1].split(";", 1)[0]
        self.assertEqual(await self.request("/api/accounts", cookie), "passed")
        self.assertEqual((await self.request("/api/accounts")).status_code, 401)
        self.assertEqual((await self.request("/api/accounts", "Чужое")).status_code, 401)
        self.assertEqual((await self.request("/media/a.jpg", cookie + "0")).status_code, 401)

    async def test_wrong_or_malformed_login_is_rejected_without_server_error(self):
        for body in (Body({"password": "wrong"}), Body({"password": 12345}), Body([1]), Body(invalid=True)):
            response = await self.app.api_login(body)
            self.assertEqual(response.status_code, 401)

    async def test_cookie_does_not_reveal_password_and_survives_restart(self):
        import hashlib
        cookie = self.app.COOKIE_VALUE
        self.assertNotEqual(cookie, hashlib.sha256(PASSWORD.encode()).hexdigest())
        self.assertTrue((self.home / "panel-secret.key").is_file())
        self.assertEqual(self.load(PASSWORD).COOKIE_VALUE, cookie)
        self.assertNotEqual(self.load(PASSWORD + "x").COOKIE_VALUE, cookie)
        (self.home / "panel-secret.key").unlink()
        self.assertNotEqual(self.load(PASSWORD).COOKIE_VALUE, cookie)

    async def test_without_password_panel_is_open_and_no_key_is_created(self):
        shutil.rmtree(self.home)
        app = self.load("")
        self.assertEqual(app.COOKIE_VALUE, "")
        self.assertFalse((self.home / "panel-secret.key").exists())
        self.app = app
        self.assertEqual(await self.request("/api/accounts"), "passed")

    async def test_control_token_with_non_ascii_header_is_refused(self):
        with patch.dict(os.environ, {"TG_MONITOR_CONTROL_TOKEN": "secret"}):
            response = await self.app.api_runtime_stop(SimpleNamespace(headers={"authorization": "Bearer секрет"}))
        self.assertEqual(response.status_code, 403)


if __name__ == "__main__":
    unittest.main()

"""Fresh archives, independent data directories and safe application shutdown."""
import asyncio
import importlib.util
import os
from pathlib import Path
import shutil
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

SOURCE = Path(__file__).resolve().parents[1]


class PortabilityTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-portable-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        spec = importlib.util.spec_from_file_location("tg_launcher_test", SOURCE / "launcher.py")
        self.launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.launcher)
        self.home = self.root / "Другая установка" / "data"
        self.launcher.write_configuration(self.home, "12345", "0" * 32, password="a%password")
        with patch.dict(os.environ, {"TG_MONITOR_HOME": str(self.home)}):
            spec = importlib.util.spec_from_file_location("tg_archive_portable_test", self.root / "app.py")
            self.app = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.app)
        self.app.init_db()

    async def asyncTearDown(self):
        self.temp.cleanup()

    async def test_new_database_and_resources_are_independent_of_working_directory(self):
        app = self.app
        self.assertEqual(app.BASE, self.home)
        self.assertEqual(app.FRONTEND, self.root / "frontend")
        self.assertEqual(app.PANEL_PASSWORD, "a%password")
        self.assertEqual(app.api_accounts(), [])
        with app.db() as c:
            self.assertEqual(c.execute("PRAGMA quick_check").fetchone()[0], "ok")
            tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({"accounts", "chats", "messages", "deleted", "participants"} <= tables)
        self.assertEqual(app.api_health()["installation"], self.launcher.installation_id(self.home))
        self.assertEqual(app.safe_media_path("media/test.bin"), self.home / "media" / "test.bin")
        with self.assertRaises(ValueError):
            app.safe_media_path("../outside.bin")

    async def test_shutdown_control_requires_its_separate_token(self):
        app = self.app
        app.RUNTIME_SERVER = SimpleNamespace(should_exit=False)
        with patch.dict(os.environ, {"TG_MONITOR_CONTROL_TOKEN": "secret"}):
            response = await app.api_runtime_stop(SimpleNamespace(headers={}))
            self.assertEqual(response.status_code, 403)
            self.assertFalse(app.RUNTIME_SERVER.should_exit)
            self.assertEqual(await app.api_runtime_stop(SimpleNamespace(headers={"authorization": "Bearer secret"})), {"ok": True})
            self.assertTrue(app.RUNTIME_SERVER.should_exit)

    async def test_graceful_shutdown_cancels_work_and_closes_sessions(self):
        stopped = asyncio.Event()

        async def work():
            try:
                await asyncio.sleep(100)
            finally:
                stopped.set()

        class Client:
            session_closed = False
            disconnected = False

            async def disconnect(self):
                self.disconnected = True

            @property
            def session(self):
                return SimpleNamespace(close=lambda: setattr(self, "session_closed", True))

        task = asyncio.create_task(work())
        await asyncio.sleep(0)
        client = Client()
        self.app.REC[1] = {"task": task}
        self.app.CLIENTS[1] = client
        await self.app.on_shutdown()
        self.assertTrue(task.cancelled())
        self.assertTrue(stopped.is_set())
        self.assertTrue(client.disconnected and client.session_closed)

    def test_configuration_rejects_invalid_values_without_writing(self):
        empty_home = self.root / "unused"
        with self.assertRaises(ValueError):
            self.launcher.write_configuration(empty_home, "bad", "secret")
        self.assertFalse((empty_home / "config.ini").exists())


if __name__ == "__main__":
    unittest.main()

"""A login ended by Telegram always becomes «нужен повторный вход», wherever it is noticed."""
import asyncio
import importlib.util
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from telethon import errors


SOURCE = Path(__file__).resolve().parents[1]


class SessionLostTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="tg-monitor-session-lost-")
        self.root = Path(self.temp.name)
        shutil.copy2(SOURCE / "app.py", self.root / "app.py")
        (self.root / "frontend").mkdir()
        (self.root / "config.ini").write_text(
            "[telegram]\napi_id=12345\napi_hash=" + "0" * 32 +
            "\n[server]\nhost=127.0.0.1\nport=18097\n", encoding="utf-8")
        spec = importlib.util.spec_from_file_location("tg_monitor_session_lost_test", self.root / "app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)
        self.app.init_db()
        with self.app.db() as c:
            c.execute("INSERT INTO accounts(id,username,status) VALUES(1,'archive','recording')")
        self.app.start_backfill = lambda *_args, **_kwargs: None

    def tearDown(self):
        asyncio.run(self.app.stop_ingest())
        self.temp.cleanup()

    def status(self):
        with self.app.db() as c:
            return c.execute("SELECT status FROM accounts WHERE id=1").fetchone()[0]

    def events(self):
        with self.app.db() as c:
            return [tuple(r) for r in c.execute("SELECT kind,note FROM events WHERE account_id=1 ORDER BY id")]

    def client(self, me=True, catch_up_error=None, run_error=None):
        class Client:
            disconnected = False
            def add_event_handler(self, handler, event):
                pass
            def remove_event_handler(self, handler):
                pass
            def is_connected(self):
                return not self.disconnected
            async def connect(self):
                pass
            async def disconnect(self):
                self.disconnected = True
            async def is_user_authorized(self):
                return True  # Telethon caches the first successful check
            async def get_me(self):
                if not me:
                    return None
                return SimpleNamespace(id=123, first_name="Test", last_name=None, username="test", phone=None)
            async def catch_up(self):
                if catch_up_error:
                    raise catch_up_error
            async def run_until_disconnected(self):
                if run_error:
                    raise run_error
                await asyncio.sleep(3600)
        return Client()

    def test_only_a_lost_login_counts_as_lost(self):
        lost = self.app.session_lost
        self.assertTrue(lost(errors.AuthKeyUnregisteredError(request=None)))
        self.assertTrue(lost(errors.SessionRevokedError(request=None)))
        self.assertTrue(lost(errors.SessionExpiredError(request=None)))
        self.assertTrue(lost(errors.UserDeactivatedBanError(request=None)))
        self.assertTrue(lost(errors.AuthKeyDuplicatedError(request=None)))
        self.assertFalse(lost(errors.SessionPasswordNeededError(request=None)))
        self.assertFalse(lost(errors.FloodWaitError(request=None, capture=5)))
        self.assertFalse(lost(ConnectionError("network")))

    def test_session_ended_while_running_shows_relogin_not_endless_reconnecting(self):
        a = self.app
        a.LOGGED.add(1)
        client = self.client(me=False)
        asyncio.run(asyncio.wait_for(a.recorder(1, client), 5))  # returns instead of looping
        self.assertEqual(self.status(), "error")
        self.assertEqual(self.events(), [("revoked", "сеанс завершён из Telegram")])
        self.assertNotIn(1, a.CLIENTS)

    def test_telegram_rejecting_the_key_mid_session_shows_relogin(self):
        a = self.app
        client = self.client(catch_up_error=errors.AuthKeyUnregisteredError(request=None))
        asyncio.run(asyncio.wait_for(a.recorder(1, client), 5))
        self.assertEqual(self.status(), "error")
        self.assertEqual(self.events()[-1][0], "revoked")
        self.assertNotIn(1, a.CLIENTS)

    def test_network_drop_still_reconnects(self):
        a = self.app
        client = self.client(run_error=ConnectionError("network"))
        async def check():
            task = asyncio.create_task(a.recorder(1, client))
            await asyncio.sleep(0.5)
            self.assertFalse(task.done())
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        asyncio.run(check())
        self.assertEqual(self.status(), "reconnecting")

    def test_history_cannot_be_continued_without_a_login(self):
        a = self.app
        with a.db() as c:
            c.execute("UPDATE accounts SET status='error' WHERE id=1")
        started = []
        a.start_backfill = lambda *args, **kwargs: started.append(args) or True
        response = asyncio.run(a.api_backfill(1))
        self.assertEqual(response.status_code, 409)
        self.assertIn("Подключить заново", json.loads(response.body)["reason"])
        self.assertEqual(started, [])

    def test_a_lost_session_file_is_closed_even_if_disconnect_fails(self):
        a = self.app
        closed = []
        client = self.client(me=False)
        async def broken_disconnect():
            raise RuntimeError("disconnect failed before closing the session")
        client.disconnect = broken_disconnect
        client.session = SimpleNamespace(close=lambda: closed.append(True))
        asyncio.run(asyncio.wait_for(a.recorder(1, client), 5))
        self.assertEqual(self.status(), "error")
        self.assertEqual(closed, [True])  # Windows can now replace the file on a new login

    def test_paused_account_is_left_alone(self):
        a = self.app
        with a.db() as c:
            c.execute("UPDATE accounts SET status='paused' WHERE id=1")
        asyncio.run(a.end_lost_session(1))
        self.assertEqual(self.status(), "paused")
        self.assertEqual(self.events(), [])

    def test_file_job_keeps_its_attempts_when_the_login_is_lost(self):
        a = self.app
        token = "t" * 32
        payload = {"media_type": "document", "title": "Chat", "type": "user",
                   "process_media": True, "file_size": 10, "sender_id": None}
        with a.db() as c:
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,5,'Chat','user')")
            c.execute("""INSERT INTO messages(account_id,chat_id,msg_id,date,text,media_type,media_status)
                         VALUES(1,5,7,'2026-10-29T00:00:00','x','document','queued')""")
            c.execute("""INSERT INTO archive_jobs(account_id,chat_id,msg_id,token,payload,attempts,next_attempt,priority)
                         VALUES(1,5,7,?,?,0,0,0)""", (token, json.dumps(payload)))
        async def no_wait():
            pass
        a.BACKGROUND_LOAD.wait_turn = no_wait
        async def lost_download(*_args, **_kwargs):
            raise errors.AuthKeyUnregisteredError(request=None)
        a.store_message = lost_download
        async def check():
            a.CLIENTS[1] = self.client()
            a.LIVE_MESSAGES[token] = SimpleNamespace(file=None)
            worker = asyncio.create_task(a.archive_job_worker())
            await asyncio.sleep(1.5)
            worker.cancel()
            await asyncio.gather(worker, return_exceptions=True)
        asyncio.run(check())
        with a.db() as c:
            job = c.execute("SELECT attempts FROM archive_jobs WHERE account_id=1").fetchone()
            media = c.execute("SELECT media_status FROM messages WHERE account_id=1").fetchone()[0]
        self.assertEqual(job[0], 0)
        self.assertNotEqual(media, "failed")
        self.assertEqual(self.status(), "error")
        self.assertNotIn(1, a.CLIENTS)
        with a.db() as c:  # an account waiting for a new login hands out no file jobs
            c.execute("UPDATE archive_jobs SET next_attempt=0")
        a.CLIENTS[1] = self.client()
        self.assertIsNone(a.next_archive_job())


if __name__ == "__main__":
    unittest.main()

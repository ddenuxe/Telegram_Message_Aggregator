"""Durability and bounded scheduling on disposable archives only."""
import asyncio
from contextlib import contextmanager
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch
import test_reliable_ingest


class SimplificationTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown
    message = test_reliable_ingest.ReliableIngestTests.message
    rows = test_reliable_ingest.ReliableIngestTests.rows

    def assert_counts(self):
        with self.app.db() as c:
            for aid in (1,2):
                actual = (c.execute('SELECT COUNT(*) FROM messages WHERE account_id=?',(aid,)).fetchone()[0],
                          *c.execute('SELECT COUNT(*),COALESCE(SUM(attempts>0),0) FROM archive_jobs WHERE account_id=?',(aid,)).fetchone())
                row = c.execute('SELECT messages,pending,retrying FROM account_counts WHERE account_id=?',(aid,)).fetchone()
                self.assertEqual(tuple(row) if row else (0,0,0),actual)

    async def test_counts_follow_edits_file_completion_retries_cleanup_and_rollback(self):
        a=self.app
        await a.store_history_batch(1,[self.message(1,media=True)],100,'Chat','user',{})
        self.assert_counts()
        await a.store_message(None,1,self.message(1,media=True),100,'Chat','user')
        self.assert_counts()  # saving the file must not count the message twice
        with a.db() as c:
            c.execute('UPDATE archive_jobs SET attempts=4')
        self.assert_counts()
        with self.assertRaises(RuntimeError):
            with a.db() as c:
                c.execute('DELETE FROM messages')
                c.execute('DELETE FROM archive_jobs')
                raise RuntimeError('rollback')
        self.assert_counts()
        with a.db() as c:
            c.execute('UPDATE archive_jobs SET account_id=2,attempts=0')
            c.execute('UPDATE messages SET account_id=2')
        self.assert_counts()
        a.init_db()
        self.assert_counts()
        with a.db() as c:
            c.execute('DELETE FROM messages')
            c.execute('DELETE FROM archive_jobs')
        self.assert_counts()

    async def test_live_file_bypasses_old_history_without_starving_history(self):
        a=self.app
        await a.store_history_batch(1,[self.message(i,media=True) for i in range(1,151)],100,'Chat','user',{})
        for i in range(200,210):
            a.persist_live_batch([a.live_snapshot(1,self.message(i,media=True),100,'Chat','user')])
        a.CLIENTS[1]=SimpleNamespace(is_connected=lambda:True)
        selected=[]
        for _ in range(10):
            job=a.next_archive_job()
            selected.append(job['msg_id'])
            with a.db() as c:
                c.execute('DELETE FROM archive_jobs WHERE account_id=? AND chat_id=? AND msg_id=?',
                          (job['account_id'],job['chat_id'],job['msg_id']))
        self.assertTrue(all(i>=200 for i in selected[:8]))
        self.assertLess(selected[8],200)
        self.assertGreaterEqual(selected[9],200)
        self.assert_counts()

    async def test_two_files_can_progress_in_one_account_without_duplicate_claims(self):
        a=self.app
        await a.store_history_batch(1,[self.message(i,media=True) for i in range(1,4)],100,'Chat','user',{})
        a.CLIENTS[1]=SimpleNamespace(is_connected=lambda:True)
        first=a.next_archive_job()
        a.ARCHIVE_BUSY.add((1,100,first['msg_id']))
        second=a.next_archive_job()
        self.assertNotEqual(first['msg_id'],second['msg_id'])
        a.ARCHIVE_BUSY.add((1,100,second['msg_id']))
        self.assertIsNone(a.next_archive_job())

    async def test_waiting_history_is_queued_cancelable_and_does_not_start_twice(self):
        a=self.app
        a.BACKFILL_SEM=asyncio.Semaphore(0)
        self.assertTrue(a.start_backfill(1,retry_only=True))
        task=a.BACKFILL[1]['task']; self.workers.append(task)
        await asyncio.sleep(0)
        self.assertEqual(a.BACKFILL[1]['state'],'queued')
        self.assertFalse(a.start_backfill(1,retry_only=True))
        self.assertTrue((await a.api_backfill_stop(1))['ok'])
        await asyncio.gather(task,return_exceptions=True)
        self.assertEqual(a.BACKFILL[1]['state'],'stopped')

    async def test_resume_wakes_file_workers_without_restarting_completed_history(self):
        a=self.app
        await a.store_history_batch(1,[self.message(1,media=True)],100,'Chat','user',{},(1,100,'forward',1))
        a.complete_history_chat(1,100,1)
        a.ARCHIVE_WAKE.clear()
        before=self.rows('archive_jobs')
        with patch.object(a,'start_backfill',side_effect=AssertionError('full scan')):
            reply=await a.api_backfill(1)
        self.assertIn('уже все сохранены',reply['reason'])
        self.assertIn('скачиваются сами',reply['reason'])
        self.assertTrue(a.ARCHIVE_WAKE.is_set())
        self.assertEqual(self.rows('archive_jobs'),before)

    def test_panel_does_not_recount_the_whole_message_or_job_archive(self):
        a=self.app
        with a.db() as c:
            c.executemany('INSERT INTO messages(account_id,chat_id,msg_id) VALUES(1,100,?)',[(i,) for i in range(20000)])
        statements=[]
        original=a.db
        @contextmanager
        def traced(*args,**kwargs):
            with original(*args,**kwargs) as c:
                c.set_trace_callback(statements.append)
                yield c
        with patch.object(a,'db',traced):
            result=a.api_accounts()
        self.assertEqual(result[0]['n'],20000)
        self.assertFalse(any('COUNT(*) FROM messages' in q or 'archive_jobs GROUP BY' in q for q in statements))

    async def test_legacy_counter_migration_keeps_records_and_runs_only_once(self):
        a=self.app
        await a.store_history_batch(1,[self.message(1,media=True),self.message(2)],100,'Chat','user',{})
        with a.db() as c:
            c.execute('UPDATE archive_jobs SET attempts=3,next_attempt=9999999999')
            for row in c.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE 'tg_counts_%'").fetchall():
                c.execute('DROP TRIGGER '+row[0])
            c.execute('DROP TABLE account_counts')
            c.execute('DROP TABLE tg_schema_versions')
        before=self.rows(),self.rows('archive_jobs')
        a.init_db()
        self.assert_counts()
        self.assertEqual(before,(self.rows(),self.rows('archive_jobs')))
        with a.db() as c:
            c.execute("INSERT OR REPLACE INTO messages(account_id,chat_id,msg_id,text) VALUES(1,100,1,'replacement')")
        self.assert_counts()
        a.init_db()
        self.assert_counts()

    async def test_missing_file_recovery_preserves_history_and_does_not_duplicate_receipts(self):
        a=self.app
        await a.store_history_batch(1,[self.message(1,media=True),self.message(2,media=True)],100,'Chat','user',{},(1,100,'forward',2))
        a.complete_history_chat(1,100,1)
        with a.db() as c:
            c.execute('DELETE FROM archive_jobs')
            c.execute("UPDATE messages SET media_approval='rejected' WHERE msg_id=2")
        history=self.rows('chats')
        self.assertEqual(a.recover_missing_media_jobs(),1)
        receipt=self.rows('archive_jobs')
        self.assertEqual(receipt[0]['msg_id'],1)
        self.assertEqual(a.recover_missing_media_jobs(),0)
        self.assertEqual(self.rows('archive_jobs'),receipt)
        self.assertEqual(self.rows('chats'),history)
        self.assert_counts()

    def test_directory_lookup_reuses_normalized_titles_and_tracks_committed_renames(self):
        a=self.app
        with a.db() as c:
            c.executemany('INSERT INTO chats(account_id,chat_id,title) VALUES(1,?,?)',[(1,'Chat'),(2,'Other')])
        self.assertEqual(a.chat_dir_name(1,1,'Chat'),'Chat')
        with patch.object(a,'_safe_name',wraps=a._safe_name) as normalize:
            for _ in range(20):self.assertEqual(a.chat_dir_name(1,1,'Chat'),'Chat')
            self.assertEqual(normalize.call_count,20,'all chat names were normalized again per file')
        with a.db() as c:c.execute("UPDATE chats SET title='Chat' WHERE chat_id=2")
        self.assertEqual(a.chat_dir_name(1,1,'Chat'),'Chat (1)')
        self.assertEqual(a.chat_dir_name(1,2,'Chat'),'Chat (2)')
        with self.assertRaises(RuntimeError):
            with a.db() as c:
                c.execute("UPDATE chats SET title='Rolled back' WHERE chat_id=2")
                raise RuntimeError('rollback')
        self.assertEqual(a.chat_dir_name(1,1,'Chat'),'Chat (1)')
        with a.db() as c:c.execute('DELETE FROM chats WHERE chat_id=2')
        self.assertEqual(a.chat_dir_name(1,1,'Chat'),'Chat')

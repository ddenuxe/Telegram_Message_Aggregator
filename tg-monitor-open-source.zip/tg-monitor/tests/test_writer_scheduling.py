"""Contention, bounded background fairness and cancellation at writer handoff."""
import asyncio
import threading
import unittest
import test_reliable_ingest


class WriterSchedulingTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_reliable_ingest.ReliableIngestTests.asyncSetUp
    asyncTearDown = test_reliable_ingest.ReliableIngestTests.asyncTearDown

    async def test_messages_pass_background_with_bounded_fairness_and_fifo(self):
        lock=self.app.DatabaseWriteLock()
        order=[]
        await lock.acquire()
        async def work(priority,label):
            async with lock.at(priority):
                order.append(label)
        tasks=[asyncio.create_task(work(1,'media')),asyncio.create_task(work(2,'cleanup'))]
        tasks += [asyncio.create_task(work(0,i)) for i in range(40)]
        await asyncio.sleep(0)
        lock.release()
        await asyncio.gather(*tasks)
        self.assertEqual(order[:8],list(range(8)))
        self.assertLessEqual(order.index('media'),17)
        self.assertLessEqual(order.index('cleanup'),17)
        self.assertEqual([x for x in order if isinstance(x,int)],list(range(40)))
        self.assertFalse(lock.locked())

    async def test_cancelled_waiter_skipped_before_its_handler_runs(self):
        lock=self.app.DatabaseWriteLock()
        await lock.acquire()
        task=asyncio.create_task(lock.acquire(0))
        await asyncio.sleep(0)
        task.cancel()
        lock.release()
        with self.assertRaises(asyncio.CancelledError):
            await task
        async with lock.at(2):
            self.assertTrue(lock.locked())
        self.assertFalse(lock.locked())

    async def test_cancellation_immediately_after_grant_releases_ownership(self):
        lock=self.app.DatabaseWriteLock()
        await lock.acquire()
        task=asyncio.create_task(lock.acquire(0))
        await asyncio.sleep(0)
        lock.release()
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertFalse(lock.locked())
        async with lock:
            pass

    async def test_mixed_actual_writes_remain_serialized_and_all_commit(self):
        started=threading.Event(); release=threading.Event()
        order=[]
        def hold():
            started.set()
            if not release.wait(5): raise RuntimeError('test release timed out')
        first=asyncio.create_task(self.app.write_call(hold))
        await asyncio.to_thread(started.wait,5)
        def write(label):
            with self.app.db() as c:
                c.execute('INSERT INTO events(account_id,kind,note) VALUES(1,?,?)',('schedule',label))
                order.append(label)
        tasks=[asyncio.create_task(self.app.write_call(write,'media',_write_priority=1)),
               asyncio.create_task(self.app.write_call(write,'cleanup',_write_priority=2))]
        tasks += [asyncio.create_task(self.app.write_call(write,str(i),_write_priority=0)) for i in range(30)]
        await asyncio.sleep(0)
        release.set()
        await asyncio.gather(first,*tasks)
        self.assertEqual(order[:8],[str(i) for i in range(8)])
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM events WHERE kind='schedule'").fetchone()[0],32)
            self.assertEqual(c.execute('PRAGMA quick_check').fetchone()[0],'ok')
            self.assertEqual(c.execute('PRAGMA synchronous').fetchone()[0],2)

"""Regression checks use temporary archives and mocked Telegram clients only."""
import asyncio
import hashlib
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
import test_portability


class RequestedUIFixTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_portability.PortabilityTests.asyncSetUp
    asyncTearDown = test_portability.PortabilityTests.asyncTearDown

    def seed(self, status="recording", filename="document #50% & файл.pdf"):
        a = self.app
        path = a.MEDIA / filename
        path.write_bytes(b"saved attachment")
        with a.db() as c:
            c.execute("INSERT INTO accounts(id,name,username,tg_user_id,status) VALUES(1,'Name','owner',99,?)", (status,))
            c.execute("INSERT INTO chats(account_id,chat_id,title,type) VALUES(1,10,'Chat','user')")
            c.execute("INSERT INTO messages(account_id,chat_id,msg_id,sender_id,out,date,media_type,file_path,file_size) VALUES(1,10,7,99,1,'2026-10-12','document',?,?)",
                      ("media/" + filename, path.stat().st_size))
        return path

    async def test_outgoing_label_resolves_username_without_changing_saved_message(self):
        self.seed()
        self.assertEqual(self.app.api_messages(1, 10)[0]["sender_label"], "@owner")
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT sender_id,out FROM messages").fetchone()[:], (99, 1))

    async def test_username_absent_uses_account_name(self):
        self.seed()
        with self.app.db() as c:
            c.execute("UPDATE accounts SET username=NULL")
        self.assertEqual(self.app.api_messages(1, 10)[0]["sender_label"], "Name")

    async def test_file_lookup_handles_reserved_characters_without_copy_or_database_changes(self):
        path = self.seed()
        before = hashlib.sha256(path.read_bytes()).digest()
        response = self.app.api_media_file(1, 10, 7)
        self.assertEqual(response.path, path)
        self.assertIn("attachment", response.headers["content-disposition"])
        self.assertEqual(hashlib.sha256(path.read_bytes()).digest(), before)
        self.assertEqual(len(list(self.app.MEDIA.iterdir())), 1)
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages").fetchone()[0], 1)

    async def test_file_lookup_rejects_wrong_message_and_source(self):
        self.seed()
        self.assertEqual(self.app.api_media_file(1, 11, 7).status_code, 404)
        self.assertEqual(self.app.api_media_file(1, 10, 7, "accounts").status_code, 422)

    async def test_file_lookup_rejects_path_outside_media(self):
        self.seed()
        with self.app.db() as c:
            c.execute("UPDATE messages SET file_path='../config.ini'")
        self.assertEqual(self.app.api_media_file(1, 10, 7).status_code, 404)

    async def test_partial_and_missing_files_report_error(self):
        path = self.seed()
        path.write_bytes(b"part")
        self.assertEqual(self.app.api_media_file(1, 10, 7).status_code, 409)
        path.unlink()
        self.assertEqual(self.app.api_media_file(1, 10, 7).status_code, 404)

    async def test_catalog_targets_exact_database_identity(self):
        self.seed()
        with self.app.db() as c:
            c.execute("INSERT INTO messages(account_id,chat_id,msg_id,date,media_type,file_path) VALUES(1,11,7,'2026-10-12','document','media/other.pdf')")
        result = self.app.api_media_catalog(account_id=1, chat_id=10, msg_id=7)
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["items"][0]["chat_id"], 10)
        self.assertEqual(self.app.api_media_catalog(q="other", account_id=1, chat_id=10, msg_id=7)["total"], 0)

    async def test_paused_account_cannot_start_manual_or_automatic_history(self):
        self.seed("paused")
        self.assertFalse(self.app.start_backfill(1))
        self.assertEqual((await self.app.api_backfill(1)).status_code, 409)
        self.assertEqual(self.app.BACKFILL, {})

    async def test_pause_cancels_active_job_and_preserves_archive(self):
        path = self.seed()
        task = asyncio.create_task(asyncio.sleep(60))
        self.app.ARCHIVE_JOB_TASKS[(1, 10, 7)] = task
        self.assertEqual(await self.app.api_pause(1), {"ok": True})
        self.assertTrue(task.cancelled())
        self.assertTrue(path.exists())
        with self.app.db() as c:
            self.assertEqual(c.execute("SELECT status FROM accounts").fetchone()[0], "paused")
            self.assertEqual(c.execute("SELECT COUNT(*) FROM messages").fetchone()[0], 1)

    async def test_avatar_download_is_cached_without_modifying_media_or_database(self):
        self.seed()
        client = SimpleNamespace(is_connected=lambda: True, download_profile_photo=AsyncMock(return_value=b"jpeg"))
        self.app.CLIENTS[1] = client
        first = await self.app.api_avatar(1)
        second = await self.app.api_avatar(1)
        self.assertEqual(first.path, second.path)
        client.download_profile_photo.assert_awaited_once()
        self.assertEqual(len(list(self.app.MEDIA.iterdir())), 1)
        self.assertEqual(len(list((self.app.BASE / "avatars").iterdir())), 1)

    async def test_paused_avatar_uses_cache_without_starting_telegram_client(self):
        self.seed("paused")
        avatar = self.app.BASE / "avatars" / "1_99.jpg"
        avatar.parent.mkdir()
        avatar.write_bytes(b"jpeg")
        with patch.object(self.app, "TelegramClient") as constructor:
            self.assertEqual((await self.app.api_avatar(1)).path, avatar)
            constructor.assert_not_called()

    async def test_unknown_avatar_entity_is_not_queried(self):
        self.seed()
        client = SimpleNamespace(is_connected=lambda: True, download_profile_photo=AsyncMock())
        self.app.CLIENTS[1] = client
        self.assertEqual((await self.app.api_avatar(1, 123456)).status_code, 404)
        client.download_profile_photo.assert_not_called()

    async def test_http_file_download_requires_login_and_serves_original_bytes(self):
        path = self.seed()
        async def get(url, authenticated=False):
            route, _, query = url.partition("?")
            messages = []
            headers = [(b"host", b"test")]
            if authenticated:
                headers.append((b"cookie", f"{self.app.COOKIE_NAME}={self.app.COOKIE_VALUE}".encode()))
            scope = {"type": "http", "asgi": {"version": "3.0", "spec_version": "2.4"},
                     "http_version": "1.1", "method": "GET", "scheme": "http", "path": route,
                     "raw_path": route.encode(), "query_string": query.encode(), "root_path": "",
                     "headers": headers, "server": ("test", 80), "client": ("127.0.0.1", 1234)}
            received = False
            async def receive():
                nonlocal received
                if not received:
                    received = True
                    return {"type": "http.request", "body": b"", "more_body": False}
                await asyncio.Event().wait()
            async def send(message):
                messages.append(message)
            await asyncio.wait_for(self.app.app(scope, receive, send), 5)
            start = next(m for m in messages if m["type"] == "http.response.start")
            body = b"".join(m.get("body", b"") for m in messages if m["type"] == "http.response.body")
            return start["status"], dict(start["headers"]), body
        url = "/api/media/file?account_id=1&chat_id=10&msg_id=7"
        self.assertEqual((await get(url))[0], 401)
        self.assertEqual((await get("/api/accounts/1/avatar"))[0], 401)
        status, headers, body = await get(url, True)
        self.assertEqual(status, 200)
        self.assertEqual(body, path.read_bytes())
        self.assertIn(b"filename*=utf-8''", headers[b"content-disposition"])


if __name__ == "__main__":
    unittest.main()
